package com.example.printer

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import com.example.data.model.LicenseInfo
import com.example.data.model.PrinterSettings
import com.example.data.model.TransactionRecord
import com.example.data.repository.PosRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class BluetoothPrinterManager(private val context: Context) {

    companion object {
        // Standard SPP UUID for Bluetooth Serial / Thermal Printers
        private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

        // ESC/POS Command Constants
        val CMD_INIT = byteArrayOf(0x1B, 0x40) // Initialize printer
        val CMD_ALIGN_LEFT = byteArrayOf(0x1B, 0x61, 0x00)
        val CMD_ALIGN_CENTER = byteArrayOf(0x1B, 0x61, 0x01)
        val CMD_ALIGN_RIGHT = byteArrayOf(0x1B, 0x61, 0x02)
        val CMD_BOLD_ON = byteArrayOf(0x1B, 0x45, 0x01)
        val CMD_BOLD_OFF = byteArrayOf(0x1B, 0x45, 0x00)
        val CMD_DOUBLE_ON = byteArrayOf(0x1B, 0x21, 0x30) // Double height & width
        val CMD_DOUBLE_OFF = byteArrayOf(0x1B, 0x21, 0x00) // Normal font
        val CMD_FONT_B = byteArrayOf(0x1B, 0x4D, 0x01) // Small / condensed font B
        val CMD_FONT_A = byteArrayOf(0x1B, 0x4D, 0x00) // Standard font A
        val CMD_CUT_PAPER = byteArrayOf(0x1D, 0x56, 0x41, 0x00) // GS V A 0: Feed paper and full cut
        val CMD_CUT_PAPER_FEED = byteArrayOf(0x1D, 0x56, 0x41, 0x00) // GS V A 0: Feed paper and full cut
        val CMD_CUT_PARTIAL = byteArrayOf(0x1D, 0x56, 0x01) // GS V 1: Partial cut
        val CMD_CUT_ESCI = byteArrayOf(0x1B, 0x69) // ESC i: Full cut on older thermal printers
        val CMD_FEED_3 = "\n\n\n".toByteArray(Charsets.US_ASCII)
    }

    private val bluetoothAdapter: BluetoothAdapter? by lazy {
        try {
            BluetoothAdapter.getDefaultAdapter()
        } catch (e: Exception) {
            null
        }
    }

    fun isBluetoothAvailable(): Boolean = bluetoothAdapter != null

    fun isBluetoothEnabled(): Boolean = bluetoothAdapter?.isEnabled == true

    @SuppressLint("MissingPermission")
    fun getPairedPrinters(): List<BluetoothDevice> {
        val adapter = bluetoothAdapter ?: return emptyList()
        if (!adapter.isEnabled) return emptyList()
        return try {
            adapter.bondedDevices?.toList() ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun testPrint(
        deviceAddress: String,
        storeName: String,
        paperSize: String,
        autoCut: Boolean = true,
        template: String = "KLASIK"
    ): Result<String> = withContext(Dispatchers.IO) {
        val maxChars = if (paperSize == "80mm") 48 else 32
        val divider = "-".repeat(maxChars)
        val doubleDivider = "=".repeat(maxChars)

        val output = mutableListOf<ByteArray>()
        output.add(CMD_INIT)
        output.add(CMD_ALIGN_CENTER)
        output.add(CMD_DOUBLE_ON)
        output.add("$storeName\n".toByteArray(Charsets.US_ASCII))
        output.add(CMD_DOUBLE_OFF)
        output.add("UJI CETAK NOTA KASIR\n".toByteArray(Charsets.US_ASCII))
        output.add(CMD_ALIGN_LEFT)
        output.add("$doubleDivider\n".toByteArray(Charsets.US_ASCII))
        output.add("Waktu     : ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale("id", "ID")).format(Date())}\n".toByteArray(Charsets.US_ASCII))
        output.add("Printer   : $deviceAddress\n".toByteArray(Charsets.US_ASCII))
        output.add("Kertas    : Thermal $paperSize ($maxChars kolom)\n".toByteArray(Charsets.US_ASCII))
        output.add("Template  : $template\n".toByteArray(Charsets.US_ASCII))
        output.add("Auto-Cut  : ${if (autoCut) "AKTIF (Pemotong Otomatis)" else "NONAKTIF"}\n".toByteArray(Charsets.US_ASCII))
        output.add("$divider\n".toByteArray(Charsets.US_ASCII))
        output.add(CMD_ALIGN_CENTER)
        output.add(CMD_BOLD_ON)
        output.add("PRINTER SIAP DIGUNAKAN!\n".toByteArray(Charsets.US_ASCII))
        output.add(CMD_BOLD_OFF)
        output.add("Pengaturan Struk Kasir Berhasil Disimpan.\n".toByteArray(Charsets.US_ASCII))
        output.add(CMD_ALIGN_LEFT)
        output.add("$doubleDivider\n".toByteArray(Charsets.US_ASCII))
        output.add(CMD_FEED_3)

        if (autoCut) {
            output.add(CMD_CUT_PAPER_FEED)
            output.add(CMD_CUT_PARTIAL)
            output.add(CMD_CUT_ESCI)
        }

        val allBytes = output.reduce { acc, bytes -> acc + bytes }
        sendBytesToDevice(deviceAddress, allBytes)
    }

    suspend fun printReceipt(
        transaction: TransactionRecord,
        licenseInfo: LicenseInfo,
        settings: PrinterSettings
    ): Result<String> = withContext(Dispatchers.IO) {
        if (settings.selectedDeviceAddress.isBlank()) {
            return@withContext Result.failure(Exception("Alamat printer Bluetooth belum dipilih di Pengaturan."))
        }

        val maxChars = if (settings.paperSize == "80mm") 48 else 32
        val divider = when (settings.receiptTemplate) {
            "ELEGAN" -> "*".repeat(maxChars)
            "KOMPAK" -> "-".repeat(maxChars)
            "MODERN" -> "―".repeat(maxChars).ifBlank { "-".repeat(maxChars) }
            else -> "-".repeat(maxChars)
        }
        val doubleDivider = when (settings.receiptTemplate) {
            "ELEGAN" -> "=".repeat(maxChars)
            "MODERN" -> "―".repeat(maxChars).ifBlank { "=".repeat(maxChars) }
            else -> "=".repeat(maxChars)
        }

        val output = mutableListOf<ByteArray>()
        output.add(CMD_INIT)

        // Set Font mode
        if (settings.fontSizePreset == "KECIL") {
            output.add(CMD_FONT_B)
        } else {
            output.add(CMD_FONT_A)
        }

        if (settings.fontWeightPreset == "BOLD") {
            output.add(CMD_BOLD_ON)
        }

        // 1. Header: Store Info
        if (settings.printHeader) {
            output.add(CMD_ALIGN_CENTER)
            output.add(CMD_DOUBLE_ON)
            output.add("${licenseInfo.storeName.uppercase(Locale.ROOT)}\n".toByteArray(Charsets.US_ASCII))
            output.add(CMD_DOUBLE_OFF)

            if (licenseInfo.storeAddress.isNotBlank()) {
                output.add("${licenseInfo.storeAddress}\n".toByteArray(Charsets.US_ASCII))
            }
            if (licenseInfo.storePhone.isNotBlank()) {
                output.add("Telp/WA: ${licenseInfo.storePhone}\n".toByteArray(Charsets.US_ASCII))
            }
        }

        if (settings.customHeader.isNotBlank()) {
            output.add(CMD_ALIGN_CENTER)
            output.add("${settings.customHeader}\n".toByteArray(Charsets.US_ASCII))
        }

        if (transaction.status == "VOID") {
            output.add(CMD_ALIGN_CENTER)
            output.add(CMD_BOLD_ON)
            output.add("*** STRUK VOID / PEMBATALAN ***\n".toByteArray(Charsets.US_ASCII))
            output.add(CMD_BOLD_OFF)
            output.add("Alasan: ${transaction.voidReason}\n".toByteArray(Charsets.US_ASCII))
            if (transaction.voidBy.isNotBlank()) {
                output.add("Otorisasi Oleh: ${transaction.voidBy}\n".toByteArray(Charsets.US_ASCII))
            }
        }

        output.add(CMD_ALIGN_LEFT)
        output.add("$doubleDivider\n".toByteArray(Charsets.US_ASCII))

        // 2. Metadata: Receipt No, Time, Cashier, Shift, Customer
        output.add(formatTwoColumn("No. Struk", transaction.receiptNumber, maxChars).toByteArray(Charsets.US_ASCII))
        output.add(formatTwoColumn("Waktu", PosRepository.formatDate(transaction.timestamp), maxChars).toByteArray(Charsets.US_ASCII))

        val resolvedCashier = transaction.cashierName.ifBlank { "Kasir" }
        if (settings.printCashier) {
            val shiftInfo = if (settings.printShift) " (Shift ${transaction.shiftNumber})" else ""
            output.add(formatTwoColumn("Kasir", "$resolvedCashier$shiftInfo", maxChars).toByteArray(Charsets.US_ASCII))
        } else if (settings.printShift) {
            output.add(formatTwoColumn("Shift", "Shift ${transaction.shiftNumber}", maxChars).toByteArray(Charsets.US_ASCII))
        }

        if (settings.printCustomer && transaction.customerName.isNotBlank() && transaction.customerName != "Pelanggan Umum") {
            output.add(formatTwoColumn("Pelanggan", transaction.customerName, maxChars).toByteArray(Charsets.US_ASCII))
        }

        output.add("$divider\n".toByteArray(Charsets.US_ASCII))

        // 3. Items List
        try {
            val jsonArray = JSONArray(transaction.itemsJson)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val name = obj.optString("name", "Item")
                val qty = obj.optInt("quantity", obj.optInt("qty", 1))
                val price = obj.optLong("price", 0L)
                val unit = obj.optString("unit", "")
                val note = obj.optString("note", "")
                val subtotal = obj.optLong("subtotal", price * qty)

                val subtotalStr = PosRepository.formatRupiah(subtotal)
                val unitStr = if (unit.isNotBlank() && unit != "Pcs") " $unit" else ""

                if (settings.receiptTemplate == "KOMPAK") {
                    // Single compact line: e.g. "2x Indomie      Rp 6.000"
                    val itemHeader = "${qty}x $name"
                    if (itemHeader.length + subtotalStr.length + 1 <= maxChars) {
                        output.add(formatTwoColumn(itemHeader, subtotalStr, maxChars).toByteArray(Charsets.US_ASCII))
                    } else {
                        output.add("$name\n".toByteArray(Charsets.US_ASCII))
                        output.add(formatTwoColumn("  $qty$unitStr x ${PosRepository.formatRupiah(price)}", subtotalStr, maxChars).toByteArray(Charsets.US_ASCII))
                    }
                } else {
                    output.add("$name\n".toByteArray(Charsets.US_ASCII))
                    val qtyPrice = "  $qty$unitStr x ${PosRepository.formatRupiah(price)}"
                    output.add(formatTwoColumn(qtyPrice, subtotalStr, maxChars).toByteArray(Charsets.US_ASCII))
                }

                if (settings.printNotes && note.isNotBlank()) {
                    output.add("  ($note)\n".toByteArray(Charsets.US_ASCII))
                }
            }
        } catch (e: Exception) {
            output.add("Item: ${transaction.itemsJson}\n".toByteArray(Charsets.US_ASCII))
        }

        output.add("$divider\n".toByteArray(Charsets.US_ASCII))

        // 4. Calculations: Subtotal, Discount, Tax
        output.add(formatTwoColumn("Subtotal", PosRepository.formatRupiah(transaction.subtotal), maxChars).toByteArray(Charsets.US_ASCII))
        if (transaction.discount > 0) {
            output.add(formatTwoColumn("Diskon", "-${PosRepository.formatRupiah(transaction.discount)}", maxChars).toByteArray(Charsets.US_ASCII))
        }
        if (transaction.tax > 0) {
            output.add(formatTwoColumn("Pajak (PPN)", PosRepository.formatRupiah(transaction.tax), maxChars).toByteArray(Charsets.US_ASCII))
        }

        output.add("$doubleDivider\n".toByteArray(Charsets.US_ASCII))

        // 5. Total
        output.add(CMD_BOLD_ON)
        output.add(formatTwoColumn("TOTAL", PosRepository.formatRupiah(transaction.totalAmount), maxChars).toByteArray(Charsets.US_ASCII))
        if (settings.fontWeightPreset != "BOLD") {
            output.add(CMD_BOLD_OFF)
        }

        output.add(formatTwoColumn("Metode Bayar", transaction.paymentMethod, maxChars).toByteArray(Charsets.US_ASCII))
        output.add(formatTwoColumn("Bayar", PosRepository.formatRupiah(transaction.paidAmount), maxChars).toByteArray(Charsets.US_ASCII))
        output.add(formatTwoColumn("Kembalian", PosRepository.formatRupiah(transaction.changeAmount), maxChars).toByteArray(Charsets.US_ASCII))

        if (settings.printNotes && transaction.notes.isNotBlank()) {
            output.add("$divider\n".toByteArray(Charsets.US_ASCII))
            output.add("Catatan: ${transaction.notes}\n".toByteArray(Charsets.US_ASCII))
        }

        output.add("$doubleDivider\n".toByteArray(Charsets.US_ASCII))

        // 6. Footer & Thank you messages
        if (settings.printFooter) {
            output.add(CMD_ALIGN_CENTER)
            if (settings.customFooter.isNotBlank()) {
                output.add("${settings.customFooter}\n".toByteArray(Charsets.US_ASCII))
            } else if (licenseInfo.receiptFooter.isNotBlank()) {
                output.add("${licenseInfo.receiptFooter}\n".toByteArray(Charsets.US_ASCII))
            }
        }

        // 7. Blank feed lines before cutting
        val feedCount = settings.feedLines.coerceIn(1, 6)
        output.add("\n".repeat(feedCount).toByteArray(Charsets.US_ASCII))

        // 8. Auto-Cut Paper
        if (settings.cutPaper) {
            output.add(CMD_CUT_PAPER_FEED)
            output.add(CMD_CUT_PARTIAL)
            output.add(CMD_CUT_ESCI)
        }

        val allBytes = output.reduce { acc, bytes -> acc + bytes }
        sendBytesToDevice(settings.selectedDeviceAddress, allBytes)
    }

    suspend fun printPriceLabels(
        items: List<Pair<com.example.data.model.Product, Int>>,
        storeName: String,
        settings: PrinterSettings,
        labelType: String = "SHELF_STANDAR"
    ): Result<String> = withContext(Dispatchers.IO) {
        if (settings.selectedDeviceAddress.isBlank()) {
            return@withContext Result.failure(Exception("Alamat printer belum dipilih di Pengaturan."))
        }
        val output = mutableListOf<ByteArray>()
        val maxChars = if (settings.paperSize == "80mm") 48 else 32
        val divider = "-".repeat(maxChars)
        val doubleDivider = "=".repeat(maxChars)
        val dateFormat = SimpleDateFormat("dd/MM/yy HH:mm", Locale("id", "ID"))
        val dateStr = dateFormat.format(Date())

        for ((product, copies) in items) {
            for (c in 1..copies) {
                output.add(CMD_INIT)
                when (labelType.uppercase()) {
                    "BARCODE_STICKER" -> {
                        // Stiker Barcode Kompak
                        output.add(CMD_ALIGN_CENTER)
                        output.add(CMD_BOLD_ON)
                        output.add("${product.name}\n".toByteArray(Charsets.US_ASCII))
                        output.add(CMD_DOUBLE_ON)
                        output.add("${PosRepository.formatRupiah(product.sellPrice)}\n".toByteArray(Charsets.US_ASCII))
                        output.add(CMD_DOUBLE_OFF)
                        output.add(CMD_BOLD_OFF)
                        output.add("||| |||| || ||| ||||\n".toByteArray(Charsets.US_ASCII))
                        output.add("SKU: ${product.sku.ifBlank { "PROD-${product.id}" }}\n".toByteArray(Charsets.US_ASCII))
                        output.add("$divider\n\n".toByteArray(Charsets.US_ASCII))
                    }
                    "PROMO_GROSIR" -> {
                        // Label Promo & Grosir
                        output.add(CMD_ALIGN_CENTER)
                        output.add(CMD_BOLD_ON)
                        output.add("*** PROMO & GROSIR ***\n".toByteArray(Charsets.US_ASCII))
                        output.add(CMD_BOLD_OFF)
                        output.add("$doubleDivider\n".toByteArray(Charsets.US_ASCII))
                        output.add(CMD_ALIGN_LEFT)
                        output.add(CMD_BOLD_ON)
                        output.add("${product.name}\n".toByteArray(Charsets.US_ASCII))
                        output.add(CMD_BOLD_OFF)
                        output.add(CMD_ALIGN_CENTER)
                        output.add(CMD_DOUBLE_ON)
                        output.add(CMD_BOLD_ON)
                        output.add("${PosRepository.formatRupiah(product.sellPrice)}\n".toByteArray(Charsets.US_ASCII))
                        output.add(CMD_DOUBLE_OFF)
                        output.add(CMD_BOLD_OFF)
                        output.add("HARGA SPESIAL / ${product.unit.ifBlank { "PCS" }.uppercase()}\n".toByteArray(Charsets.US_ASCII))
                        val tiers = product.getTieredPrices()
                        if (tiers.isNotEmpty()) {
                            output.add(CMD_ALIGN_LEFT)
                            output.add("Grosir: min ${tiers.first().minQty} -> ${PosRepository.formatRupiah(tiers.first().unitPrice)}\n".toByteArray(Charsets.US_ASCII))
                        }
                        output.add(CMD_ALIGN_CENTER)
                        output.add("||| |||| || ||| ||||\n".toByteArray(Charsets.US_ASCII))
                        output.add("SKU: ${product.sku.ifBlank { "PROD-${product.id}" }}\n".toByteArray(Charsets.US_ASCII))
                        output.add("$doubleDivider\n\n".toByteArray(Charsets.US_ASCII))
                    }
                    "MINIMALIS" -> {
                        // Minimalis Monokrom
                        output.add(CMD_ALIGN_LEFT)
                        output.add("${storeName.ifBlank { "POS PRO" }}\n".toByteArray(Charsets.US_ASCII))
                        output.add(CMD_BOLD_ON)
                        output.add("${product.name}\n".toByteArray(Charsets.US_ASCII))
                        output.add(CMD_DOUBLE_ON)
                        output.add("${PosRepository.formatRupiah(product.sellPrice)}\n".toByteArray(Charsets.US_ASCII))
                        output.add(CMD_DOUBLE_OFF)
                        output.add(CMD_BOLD_OFF)
                        output.add("Satuan: ${product.unit.ifBlank { "PCS" }} | SKU: ${product.sku.ifBlank { "-" }}\n".toByteArray(Charsets.US_ASCII))
                        output.add("$divider\n\n".toByteArray(Charsets.US_ASCII))
                    }
                    else -> { // Default SHELF_STANDAR
                        output.add(CMD_ALIGN_CENTER)
                        output.add(CMD_BOLD_ON)
                        output.add("${storeName.ifBlank { "LABEL HARGA" }}\n".toByteArray(Charsets.US_ASCII))
                        output.add(CMD_BOLD_OFF)
                        output.add("$divider\n".toByteArray(Charsets.US_ASCII))

                        output.add(CMD_ALIGN_LEFT)
                        output.add(CMD_BOLD_ON)
                        output.add("${product.name}\n".toByteArray(Charsets.US_ASCII))
                        output.add(CMD_BOLD_OFF)
                        if (product.sku.isNotBlank()) {
                            output.add("SKU: ${product.sku} | ${product.category}\n".toByteArray(Charsets.US_ASCII))
                        }

                        output.add(CMD_ALIGN_CENTER)
                        output.add(CMD_DOUBLE_ON)
                        output.add(CMD_BOLD_ON)
                        output.add("${PosRepository.formatRupiah(product.sellPrice)}\n".toByteArray(Charsets.US_ASCII))
                        output.add(CMD_DOUBLE_OFF)
                        output.add(CMD_BOLD_OFF)
                        output.add("per ${product.unit.ifBlank { "pcs" }}\n".toByteArray(Charsets.US_ASCII))

                        val repacks = product.getRepackUnits()
                        if (repacks.isNotEmpty()) {
                            output.add(CMD_ALIGN_LEFT)
                            val rStr = repacks.joinToString(", ") { "${it.unitName}: ${PosRepository.formatRupiah(it.sellPrice)}" }
                            output.add("Grosir/Repack: $rStr\n".toByteArray(Charsets.US_ASCII))
                        }

                        output.add(CMD_ALIGN_CENTER)
                        output.add("||| |||| || ||| ||||\n".toByteArray(Charsets.US_ASCII))
                        output.add(CMD_ALIGN_RIGHT)
                        output.add("Tgl: $dateStr\n".toByteArray(Charsets.US_ASCII))
                        output.add("$divider\n\n".toByteArray(Charsets.US_ASCII))
                    }
                }
            }
        }

        output.add(CMD_FEED_3)
        if (settings.cutPaper) {
            output.add(CMD_CUT_PAPER_FEED)
            output.add(CMD_CUT_PARTIAL)
            output.add(CMD_CUT_ESCI)
        }

        val allBytes = output.reduce { acc, bytes -> acc + bytes }
        sendBytesToDevice(settings.selectedDeviceAddress, allBytes)
    }

    @SuppressLint("MissingPermission")
    private fun sendBytesToDevice(deviceAddress: String, data: ByteArray): Result<String> {
        val adapter = bluetoothAdapter ?: return Result.failure(Exception("Bluetooth tidak didukung di perangkat ini."))
        val device = try {
            adapter.getRemoteDevice(deviceAddress)
        } catch (e: Exception) {
            return Result.failure(Exception("Perangkat Bluetooth tidak valid: ${e.message}"))
        }

        var socket: BluetoothSocket? = null
        var outputStream: OutputStream? = null

        return try {
            socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
            // Cancel discovery before connecting for reliable socket handshake
            try {
                adapter.cancelDiscovery()
            } catch (ignored: Exception) {}

            socket.connect()
            outputStream = socket.outputStream
            outputStream.write(data)
            outputStream.flush()
            Result.success("Struk berhasil dikirim ke printer: ${device.name ?: deviceAddress}")
        } catch (e: Exception) {
            Result.failure(Exception("Gagal menghubungkan ke printer (${device.name ?: deviceAddress}): ${e.message}"))
        } finally {
            try {
                outputStream?.close()
            } catch (ignored: Exception) {}
            try {
                socket?.close()
            } catch (ignored: Exception) {}
        }
    }

    private fun formatTwoColumn(left: String, right: String, totalWidth: Int): String {
        val availableSpace = totalWidth - left.length - right.length
        return if (availableSpace > 0) {
            left + " ".repeat(availableSpace) + right + "\n"
        } else {
            val truncatedLeft = if (left.length > totalWidth - right.length - 1) {
                left.substring(0, (totalWidth - right.length - 1).coerceAtLeast(1))
            } else {
                left
            }
            val spaces = (totalWidth - truncatedLeft.length - right.length).coerceAtLeast(1)
            truncatedLeft + " ".repeat(spaces) + right + "\n"
        }
    }
}
