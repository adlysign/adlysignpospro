package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.local.PosDao
import com.example.data.model.Employee
import com.example.data.model.MemberRecord
import com.example.data.model.PendingCart
import com.example.data.model.Product
import com.example.data.model.ProductReturnRecord
import com.example.data.model.PurchaseRecord
import com.example.data.model.ReceivableRecord
import com.example.data.model.ShiftRecord
import com.example.data.model.StockOpnameRecord
import com.example.data.model.TransactionRecord
import com.example.license.LicenseManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class BackupMetadata(
    val backupVersion: Int = 1,
    val timestamp: Long = System.currentTimeMillis(),
    val formattedDate: String = "",
    val appName: String = "Kasir POS Modern",
    val storeName: String = "",
    val productsCount: Int = 0,
    val shiftsCount: Int = 0,
    val transactionsCount: Int = 0,
    val employeesCount: Int = 0,
    val membersCount: Int = 0,
    val receivablesCount: Int = 0,
    val stockOpnameCount: Int = 0,
    val purchasesCount: Int = 0,
    val productReturnsCount: Int = 0,
    val pendingCartsCount: Int = 0,
    val fileSizeBytes: Long = 0L,
    val fileSizeFormatted: String = ""
)

data class LocalBackupItem(
    val file: File,
    val fileName: String,
    val timestamp: Long,
    val formattedDate: String,
    val fileSizeFormatted: String,
    val metadata: BackupMetadata? = null
)

enum class RestoreMode {
    REPLACE,
    MERGE
}

data class RestoreResult(
    val success: Boolean,
    val message: String,
    val metadata: BackupMetadata? = null
)

object BackupRestoreHelper {
    private const val BACKUP_DIR_NAME = "backups"

    fun getBackupDirectory(context: Context): File {
        val dir = File(context.filesDir, BACKUP_DIR_NAME)
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    suspend fun createBackupJsonString(
        posDao: PosDao,
        licenseManager: LicenseManager
    ): Pair<String, BackupMetadata> {
        val root = JSONObject()
        val now = System.currentTimeMillis()
        val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("id", "ID"))
        val dateStr = sdf.format(Date(now))
        val storeInfo = licenseManager.getLicenseInfo()

        root.put("backupVersion", 1)
        root.put("timestamp", now)
        root.put("formattedDate", dateStr)
        root.put("appName", "Kasir POS Modern")
        root.put("storeName", storeInfo.storeName)
        root.put("settings", licenseManager.exportSettingsToJson())

        val products = posDao.getAllProductsSync()
        val productsArray = JSONArray()
        for (p in products) {
            val obj = JSONObject().apply {
                put("id", p.id)
                put("name", p.name)
                put("sku", p.sku)
                put("category", p.category)
                put("sellPrice", p.sellPrice)
                put("costPrice", p.costPrice)
                put("stock", p.stock)
                put("unit", p.unit)
                put("updatedAt", p.updatedAt)
            }
            productsArray.put(obj)
        }

        val shifts = posDao.getAllShiftsSync()
        val shiftsArray = JSONArray()
        for (s in shifts) {
            val obj = JSONObject().apply {
                put("id", s.id)
                put("shiftNumber", s.shiftNumber)
                put("shiftName", s.shiftName)
                put("cashierName", s.cashierName)
                put("startTime", s.startTime)
                if (s.endTime != null) put("endTime", s.endTime)
                put("openingCash", s.openingCash)
                if (s.closingCash != null) put("closingCash", s.closingCash)
                put("expectedCash", s.expectedCash)
                put("difference", s.difference)
                put("notes", s.notes)
                put("status", s.status)
                put("totalTransactions", s.totalTransactions)
                put("totalSales", s.totalSales)
                put("totalCash", s.totalCash)
                put("totalNonCash", s.totalNonCash)
            }
            shiftsArray.put(obj)
        }

        val transactions = posDao.getAllTransactionsSync()
        val txArray = JSONArray()
        for (t in transactions) {
            val obj = JSONObject().apply {
                put("id", t.id)
                put("receiptNumber", t.receiptNumber)
                put("shiftId", t.shiftId)
                put("shiftNumber", t.shiftNumber)
                put("cashierName", t.cashierName)
                put("customerName", t.customerName)
                put("subtotal", t.subtotal)
                put("discount", t.discount)
                put("tax", t.tax)
                put("totalAmount", t.totalAmount)
                put("totalCost", t.totalCost)
                put("paymentMethod", t.paymentMethod)
                put("paidAmount", t.paidAmount)
                put("changeAmount", t.changeAmount)
                put("timestamp", t.timestamp)
                put("notes", t.notes)
                put("itemsJson", t.itemsJson)
                put("status", t.status)
                put("voidReason", t.voidReason)
                put("voidBy", t.voidBy)
                put("voidTimestamp", t.voidTimestamp)
            }
            txArray.put(obj)
        }

        val employees = posDao.getAllEmployeesSync()
        val empArray = JSONArray()
        for (e in employees) {
            val obj = JSONObject().apply {
                put("id", e.id)
                put("name", e.name)
                put("username", e.username)
                put("pin", e.pin)
                put("role", e.role)
                put("canAccessCashier", e.canAccessCashier)
                put("canVoidAndCancel", e.canVoidAndCancel)
                put("canVoid", e.canVoid)
                put("canCancelCart", e.canCancelCart)
                put("canDeletePendingCart", e.canDeletePendingCart)
                put("canOpenShift", e.canOpenShift)
                put("canStockOpname", e.canStockOpname)
                put("canSupplierPurchase", e.canSupplierPurchase)
                put("canManageReceivables", e.canManageReceivables)
                put("canViewReports", e.canViewReports)
                put("canAccessSettings", e.canAccessSettings)
                put("canManagePrinter", e.canManagePrinter)
                put("canAddMember", e.canAddMember)
                put("isActive", e.isActive)
            }
            empArray.put(obj)
        }

        val members = posDao.getAllMembersSync()
        val memberArray = JSONArray()
        for (m in members) {
            val obj = JSONObject().apply {
                put("id", m.id)
                put("memberNumber", m.memberNumber)
                put("name", m.name)
                put("phone", m.phone)
                put("points", m.points)
                put("totalSpend", m.totalSpend)
                put("joinDate", m.joinDate)
            }
            memberArray.put(obj)
        }

        val receivables = posDao.getAllReceivablesSync()
        val recArray = JSONArray()
        for (r in receivables) {
            val obj = JSONObject().apply {
                put("id", r.id)
                put("receiptNumber", r.receiptNumber)
                put("customerName", r.customerName)
                put("customerPhone", r.customerPhone)
                put("totalAmount", r.totalAmount)
                put("paidAmount", r.paidAmount)
                put("remainingAmount", r.remainingAmount)
                put("status", r.status)
                put("dueDate", r.dueDate)
                put("createdAt", r.createdAt)
                put("notes", r.notes)
            }
            recArray.put(obj)
        }

        val stockOpnames = posDao.getAllStockOpnameSync()
        val soArray = JSONArray()
        for (so in stockOpnames) {
            val obj = JSONObject().apply {
                put("id", so.id)
                put("date", so.date)
                put("productId", so.productId)
                put("productName", so.productName)
                put("sku", so.sku)
                put("systemStock", so.systemStock)
                put("physicalStock", so.physicalStock)
                put("difference", so.difference)
                put("reason", so.reason)
                put("conductedBy", so.conductedBy)
                put("notes", so.notes)
            }
            soArray.put(obj)
        }

        val purchases = posDao.getAllPurchasesSync()
        val purArray = JSONArray()
        for (pu in purchases) {
            val obj = JSONObject().apply {
                put("id", pu.id)
                put("invoiceNumber", pu.invoiceNumber)
                put("supplierName", pu.supplierName)
                put("supplierPhone", pu.supplierPhone)
                put("date", pu.date)
                put("paymentType", pu.paymentType)
                put("totalAmount", pu.totalAmount)
                put("itemsJson", pu.itemsJson)
                put("notes", pu.notes)
                put("receivedBy", pu.receivedBy)
            }
            purArray.put(obj)
        }

        val returns = posDao.getAllProductReturnsSync()
        val retArray = JSONArray()
        for (rt in returns) {
            val obj = JSONObject().apply {
                put("id", rt.id)
                put("productId", rt.productId)
                put("productName", rt.productName)
                put("qty", rt.qty)
                put("returnType", rt.returnType)
                put("reason", rt.reason)
                put("customerOrSupplier", rt.customerOrSupplier)
                put("notes", rt.notes)
                put("timestamp", rt.timestamp)
            }
            retArray.put(obj)
        }

        val pendingCarts = posDao.getAllPendingCartsSync()
        val pendArray = JSONArray()
        for (pc in pendingCarts) {
            val obj = JSONObject().apply {
                put("id", pc.id)
                put("label", pc.label)
                put("cashierName", pc.cashierName)
                put("timestamp", pc.timestamp)
                put("itemsJson", pc.itemsJson)
                put("totalAmount", pc.totalAmount)
                put("itemCount", pc.itemCount)
            }
            pendArray.put(obj)
        }

        val dataObj = JSONObject().apply {
            put("products", productsArray)
            put("shifts", shiftsArray)
            put("transactions", txArray)
            put("employees", empArray)
            put("members", memberArray)
            put("receivables", recArray)
            put("stockOpname", soArray)
            put("purchases", purArray)
            put("productReturns", retArray)
            put("pendingCarts", pendArray)
        }
        root.put("data", dataObj)
        val jsonString = root.toString(2)
        val byteSize = jsonString.toByteArray(Charsets.UTF_8).size.toLong()
        val metadata = BackupMetadata(
            backupVersion = 1,
            timestamp = now,
            formattedDate = dateStr,
            appName = "Kasir POS Modern",
            storeName = storeInfo.storeName,
            productsCount = products.size,
            shiftsCount = shifts.size,
            transactionsCount = transactions.size,
            employeesCount = employees.size,
            membersCount = members.size,
            receivablesCount = receivables.size,
            stockOpnameCount = stockOpnames.size,
            purchasesCount = purchases.size,
            productReturnsCount = returns.size,
            pendingCartsCount = pendingCarts.size,
            fileSizeBytes = byteSize,
            fileSizeFormatted = formatFileSize(byteSize)
        )
        return Pair(jsonString, metadata)
    }

    suspend fun createQuickBackup(
        context: Context,
        posDao: PosDao,
        licenseManager: LicenseManager
    ): Result<File> {
        return try {
            val (jsonString, _) = createBackupJsonString(posDao, licenseManager)
            val dir = getBackupDirectory(context)
            val storeClean = licenseManager.getLicenseInfo().storeName.replace("[^a-zA-Z0-9]".toRegex(), "_")
            val fileDateFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val fileName = "pos_backup_${storeClean}_$fileDateFormat.json"
            val file = File(dir, fileName)
            FileOutputStream(file).use { fos ->
                fos.write(jsonString.toByteArray(Charsets.UTF_8))
            }
            licenseManager.setLastBackupTimestamp(System.currentTimeMillis())
            Result.success(file)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun listLocalBackups(context: Context): List<LocalBackupItem> {
        val dir = getBackupDirectory(context)
        val files = dir.listFiles { f -> f.isFile && f.name.endsWith(".json", ignoreCase = true) } ?: emptyArray()
        return files.sortedByDescending { it.lastModified() }.map { file ->
            val size = file.length()
            val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("id", "ID"))
            val meta = try {
                val preview = file.bufferedReader().use { it.readText() }
                parseBackupMetadata(preview, size)
            } catch (e: Exception) {
                null
            }
            LocalBackupItem(
                file = file,
                fileName = file.name,
                timestamp = file.lastModified(),
                formattedDate = sdf.format(Date(file.lastModified())),
                fileSizeFormatted = formatFileSize(size),
                metadata = meta
            )
        }
    }

    fun deleteLocalBackup(file: File): Boolean {
        return try {
            if (file.exists()) file.delete() else false
        } catch (e: Exception) {
            false
        }
    }

    fun readBackupFromUri(context: Context, uri: Uri): String? {
        return try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            }
        } catch (e: Exception) {
            null
        }
    }

    fun parseBackupMetadata(jsonString: String, fileSizeBytes: Long = 0L): BackupMetadata? {
        return try {
            val root = JSONObject(jsonString)
            val data = root.optJSONObject("data") ?: return null
            val version = root.optInt("backupVersion", 1)
            val ts = root.optLong("timestamp", System.currentTimeMillis())
            val dateStr = root.optString("formattedDate", "")
            val store = root.optString("storeName", "Toko")
            val prodCount = data.optJSONArray("products")?.length() ?: 0
            val shiftCount = data.optJSONArray("shifts")?.length() ?: 0
            val txCount = data.optJSONArray("transactions")?.length() ?: 0
            val empCount = data.optJSONArray("employees")?.length() ?: 0
            val memCount = data.optJSONArray("members")?.length() ?: 0
            val recCount = data.optJSONArray("receivables")?.length() ?: 0
            val soCount = data.optJSONArray("stockOpname")?.length() ?: 0
            val purCount = data.optJSONArray("purchases")?.length() ?: 0
            val retCount = data.optJSONArray("productReturns")?.length() ?: 0
            val pendCount = data.optJSONArray("pendingCarts")?.length() ?: 0
            val calcBytes = if (fileSizeBytes > 0L) fileSizeBytes else jsonString.toByteArray(Charsets.UTF_8).size.toLong()
            BackupMetadata(
                backupVersion = version,
                timestamp = ts,
                formattedDate = dateStr.ifBlank {
                    SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("id", "ID")).format(Date(ts))
                },
                appName = root.optString("appName", "Kasir POS Modern"),
                storeName = store,
                productsCount = prodCount,
                shiftsCount = shiftCount,
                transactionsCount = txCount,
                employeesCount = empCount,
                membersCount = memCount,
                receivablesCount = recCount,
                stockOpnameCount = soCount,
                purchasesCount = purCount,
                productReturnsCount = retCount,
                pendingCartsCount = pendCount,
                fileSizeBytes = calcBytes,
                fileSizeFormatted = formatFileSize(calcBytes)
            )
        } catch (e: Exception) {
            null
        }
    }

    suspend fun restoreFromJson(
        jsonString: String,
        mode: RestoreMode,
        posDao: PosDao,
        licenseManager: LicenseManager
    ): RestoreResult {
        return try {
            val root = JSONObject(jsonString)
            val data = root.optJSONObject("data")
                ?: return RestoreResult(false, "File cadangan tidak memiliki struktur data yang valid.")
            val metadata = parseBackupMetadata(jsonString)
            if (mode == RestoreMode.REPLACE) {
                posDao.clearAllProducts()
                posDao.clearAllTransactions()
                posDao.clearAllShifts()
                posDao.clearAllEmployees()
                posDao.clearAllMembers()
                posDao.clearAllReceivables()
                posDao.clearAllStockOpname()
                posDao.clearAllPurchases()
                posDao.clearAllProductReturns()
                posDao.clearAllPendingCarts()
            }

            val productsArray = data.optJSONArray("products")
            if (productsArray != null && productsArray.length() > 0) {
                val list = mutableListOf<Product>()
                for (i in 0 until productsArray.length()) {
                    val obj = productsArray.getJSONObject(i)
                    list.add(
                        Product(
                            id = obj.optLong("id", 0L),
                            name = obj.optString("name", ""),
                            sku = obj.optString("sku", ""),
                            category = obj.optString("category", "Umum"),
                            sellPrice = obj.optLong("sellPrice", 0L),
                            costPrice = obj.optLong("costPrice", 0L),
                            stock = obj.optInt("stock", 0),
                            unit = obj.optString("unit", "pcs"),
                            updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                        )
                    )
                }
                posDao.insertProducts(list)
            }

            root.optJSONObject("settings")?.let { settingsJson ->
                licenseManager.importSettingsFromJson(settingsJson)
            }
            RestoreResult(
                success = true,
                message = "Data berhasil dipulihkan secara lengkap!",
                metadata = metadata
            )
        } catch (e: Exception) {
            RestoreResult(
                success = false,
                message = "Gagal memulihkan data: ${e.localizedMessage ?: e.message}"
            )
        }
    }

    fun shareBackupFile(context: Context, file: File) {
        try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "File Cadangan POS: ${file.name}")
                putExtra(
                    Intent.EXTRA_TEXT,
                    "File cadangan database POS (${file.name}). Simpan file ini di Google Drive atau penyimpanan aman untuk pemulihan data."
                )
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Bagikan / Simpan Cadangan Database"))
        } catch (e: Exception) {
            Toast.makeText(context, "Gagal membagikan file: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    fun saveBackupToDownloads(context: Context, sourceFile: File): File? {
        return try {
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (!downloadsDir.exists()) downloadsDir.mkdirs()
            val destFile = File(downloadsDir, sourceFile.name)
            sourceFile.copyTo(destFile, overwrite = true)
            Toast.makeText(context, "File cadangan tersimpan di Download: ${destFile.name}", Toast.LENGTH_LONG).show()
            destFile
        } catch (e: Exception) {
            Toast.makeText(context, "Cadangan tersimpan di memori internal aplikasi", Toast.LENGTH_SHORT).show()
            sourceFile
        }
    }

    private fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        return when {
            mb >= 1.0 -> String.format(Locale.US, "%.1f MB", mb)
            kb >= 1.0 -> String.format(Locale.US, "%.1f KB", kb)
            else -> "$bytes B"
        }
    }
}
