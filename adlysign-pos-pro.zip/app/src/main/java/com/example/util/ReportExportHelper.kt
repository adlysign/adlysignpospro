package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Environment
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONArray
import com.example.data.model.LicenseInfo
import com.example.data.model.Product
import com.example.data.model.ProductReturnRecord
import com.example.data.model.PurchaseRecord
import com.example.data.model.ReceivableRecord
import com.example.data.model.StockOpnameRecord
import com.example.data.model.TransactionRecord
import com.example.data.repository.PosRepository
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ProductSalesMetric(
    val product: Product,
    val totalSoldQty: Int,
    val totalRevenue: Long,
    val totalCost: Long,
    val totalProfit: Long
)

data class ComprehensiveReportData(
    val periodLabel: String,
    val startDate: Long,
    val endDate: Long,
    val storeInfo: LicenseInfo,
    val transactions: List<TransactionRecord>,
    val fastMoving: List<ProductSalesMetric>,
    val slowMoving: List<ProductSalesMetric>,
    val purchases: List<PurchaseRecord>,
    val returns: List<ProductReturnRecord>,
    val stockOpnames: List<StockOpnameRecord>,
    val voidTransactions: List<TransactionRecord>,
    val receivables: List<ReceivableRecord>
) {
    val successTransactions = transactions.filter { !it.isVoid }
    val totalOmset = successTransactions.sumOf { it.totalAmount }
    val totalHpp = successTransactions.sumOf { it.totalCost }
    val totalProfit = (totalOmset - totalHpp).coerceAtLeast(0L)
    val totalDiscounts = successTransactions.sumOf { it.discount }
    val totalTransactionsCount = successTransactions.size
    val averageBasket = if (totalTransactionsCount > 0) totalOmset / totalTransactionsCount else 0L

    val totalPurchasesAmount = purchases.sumOf { it.totalAmount }
    val supplierPurchases = purchases.filter { it.purchaseType != "STORE_PURCHASE" }
    val storePurchases = purchases.filter { it.purchaseType == "STORE_PURCHASE" }
    val totalSupplierPurchasesAmount = supplierPurchases.sumOf { it.totalAmount }
    val totalStorePurchasesAmount = storePurchases.sumOf { it.totalAmount }
    val totalReceivablesRemaining = receivables.sumOf { it.remainingAmount }
    val totalVoidCount = voidTransactions.size
    val totalVoidAmount = voidTransactions.sumOf { it.totalAmount }

    val cashTransactions = successTransactions.filter { it.paymentMethod == "TUNAI" }
    val totalCashAmount = cashTransactions.sumOf { it.totalAmount }

    val campuranTransactions = successTransactions.filter { it.paymentMethod.startsWith("CAMPURAN") }
    val totalCampuranAmount = campuranTransactions.sumOf { it.totalAmount }
    val totalCampuranCount = campuranTransactions.size

    val qrisTransactions = successTransactions.filter { it.paymentMethod == "QRIS" }
    val totalQrisAmount = qrisTransactions.sumOf { it.totalAmount }

    val transferTransactions = successTransactions.filter { it.paymentMethod == "TRANSFER" || it.paymentMethod == "DEBIT" }
    val totalTransferAmount = transferTransactions.sumOf { it.totalAmount }

    val piutangTransactions = successTransactions.filter { it.paymentMethod == "PIUTANG" }
    val totalPiutangAmount = piutangTransactions.sumOf { it.totalAmount }

    val campuranCashPartTotal = campuranTransactions.sumOf { tx ->
        val match = Regex("Tunai Rp\\s*([0-9.]+)").find(tx.paymentMethod)
        val parsed = match?.groupValues?.get(1)?.replace(".", "")?.toLongOrNull() ?: (tx.totalAmount / 2)
        parsed.coerceIn(0L, tx.totalAmount)
    }
    val campuranNonCashPartTotal = (totalCampuranAmount - campuranCashPartTotal).coerceAtLeast(0L)
    val totalRealPhysicalCash = totalCashAmount + campuranCashPartTotal
}

object ReportExportHelper {

    // =========================================================================
    // 1. GENERATE WORD (.DOC) DOCUMENT
    // =========================================================================
    fun generateWordDocument(context: Context, data: ComprehensiveReportData): File {
        val fileName = "Laporan_POS_${data.storeInfo.storeName.replace(" ", "_")}_${System.currentTimeMillis()}.doc"
        val file = File(context.cacheDir, fileName)

        val htmlContent = buildWordHtml(data)
        FileOutputStream(file).use { out ->
            out.write(htmlContent.toByteArray(Charsets.UTF_8))
        }
        return file
    }

    private fun buildWordHtml(data: ComprehensiveReportData): String {
        val nowFormatted = SimpleDateFormat("dd MMMM yyyy, HH:mm", Locale("id", "ID")).format(Date())

        return buildString {
            append("""
                <html xmlns:o="urn:schemas-microsoft-com:office:office" 
                      xmlns:w="urn:schemas-microsoft-com:office:word" 
                      xmlns="http://www.w3.org/TR/REC-html40">
                <head>
                <meta charset="utf-8">
                <title>Laporan Keuangan & Operasional POS</title>
                <!--[if gte mso 9]>
                <xml>
                <w:WordDocument>
                <w:View>Print</w:View>
                <w:Zoom>100</w:Zoom>
                <w:DoNotOptimizeForBrowser/>
                </w:WordDocument>
                </xml>
                <![endif]-->
                <style>
                    body {
                        font-family: 'Segoe UI', Calibri, Arial, sans-serif;
                        font-size: 11pt;
                        color: #1E293B;
                        margin: 20px;
                        line-height: 1.4;
                    }
                    .header-box {
                        border-bottom: 2px solid #059669;
                        padding-bottom: 12px;
                        margin-bottom: 20px;
                    }
                    .store-title {
                        font-size: 20pt;
                        font-weight: bold;
                        color: #065F46;
                        margin: 0;
                    }
                    .store-subtitle {
                        font-size: 10pt;
                        color: #64748B;
                        margin: 2px 0;
                    }
                    .report-title {
                        font-size: 15pt;
                        font-weight: bold;
                        color: #0F172A;
                        margin-top: 14px;
                    }
                    .kpi-table {
                        width: 100%;
                        border-collapse: collapse;
                        margin-bottom: 24px;
                    }
                    .kpi-card {
                        border: 1px solid #CBD5E1;
                        background-color: #F8FAFC;
                        padding: 12px;
                        text-align: center;
                    }
                    .kpi-label {
                        font-size: 9.5pt;
                        color: #64748B;
                        text-transform: uppercase;
                    }
                    .kpi-value {
                        font-size: 15pt;
                        font-weight: bold;
                        color: #0F172A;
                        margin-top: 4px;
                    }
                    .kpi-profit {
                        color: #059669;
                    }
                    .section-title {
                        font-size: 13pt;
                        font-weight: bold;
                        color: #065F46;
                        border-left: 4px solid #059669;
                        padding-left: 8px;
                        margin-top: 24px;
                        margin-bottom: 8px;
                    }
                    .data-table {
                        width: 100%;
                        border-collapse: collapse;
                        margin-bottom: 18px;
                    }
                    .data-table th {
                        background-color: #065F46;
                        color: #FFFFFF;
                        font-weight: bold;
                        padding: 7px 10px;
                        font-size: 9.5pt;
                        text-align: left;
                        border: 1px solid #065F46;
                    }
                    .data-table td {
                        padding: 6px 10px;
                        font-size: 9.5pt;
                        border: 1px solid #E2E8F0;
                    }
                    .data-table tr:nth-child(even) {
                        background-color: #F8FAFC;
                    }
                    .badge-green {
                        background-color: #ECFDF5;
                        color: #065F46;
                        font-weight: bold;
                        padding: 2px 6px;
                        border-radius: 4px;
                        font-size: 8.5pt;
                    }
                    .badge-red {
                        background-color: #FEF2F2;
                        color: #DC2626;
                        font-weight: bold;
                        padding: 2px 6px;
                        border-radius: 4px;
                        font-size: 8.5pt;
                    }
                    .badge-amber {
                        background-color: #FFFBEB;
                        color: #D97706;
                        font-weight: bold;
                        padding: 2px 6px;
                        border-radius: 4px;
                        font-size: 8.5pt;
                    }
                    .badge-purple {
                        background-color: #F3E8FF;
                        color: #7C3AED;
                        font-weight: bold;
                        padding: 2px 6px;
                        border-radius: 4px;
                        font-size: 8.5pt;
                    }
                    .badge-blue {
                        background-color: #EFF6FF;
                        color: #2563EB;
                        font-weight: bold;
                        padding: 2px 6px;
                        border-radius: 4px;
                        font-size: 8.5pt;
                    }
                    .signature-table {
                        width: 100%;
                        margin-top: 40px;
                        border: none;
                    }
                    .signature-table td {
                        border: none;
                        text-align: center;
                        width: 50%;
                    }
                </style>
                </head>
                <body>
                    <div class="header-box">
                        <div class="store-title">${data.storeInfo.storeName.uppercase()}</div>
                        <div class="store-subtitle">${data.storeInfo.storeAddress} • Telp: ${data.storeInfo.storePhone}</div>
                        <div class="report-title">LAPORAN KEUANGAN & OPERASIONAL LENGKAP</div>
                        <div class="store-subtitle">Periode: <b>${data.periodLabel}</b> | Dicetak: <b>$nowFormatted</b></div>
                    </div>

                    <!-- RINGKASAN FINANSIAL EKSEKUTIF -->
                    <table class="kpi-table">
                        <tr>
                            <td class="kpi-card" style="width: 25%;">
                                <div class="kpi-label">Total Omset Penjualan</div>
                                <div class="kpi-value">${PosRepository.formatRupiah(data.totalOmset)}</div>
                            </td>
                            <td class="kpi-card" style="width: 25%;">
                                <div class="kpi-label">Harga Pokok (HPP)</div>
                                <div class="kpi-value">${PosRepository.formatRupiah(data.totalHpp)}</div>
                            </td>
                            <td class="kpi-card" style="width: 25%;">
                                <div class="kpi-label">Estimasi Laba Bersih</div>
                                <div class="kpi-value kpi-profit">${PosRepository.formatRupiah(data.totalProfit)}</div>
                            </td>
                            <td class="kpi-card" style="width: 25%;">
                                <div class="kpi-label">Rata-Rata Keranjang</div>
                                <div class="kpi-value">${PosRepository.formatRupiah(data.averageBasket)}</div>
                            </td>
                        </tr>
                        <tr>
                            <td class="kpi-card">
                                <div class="kpi-label">Transaksi Berhasil</div>
                                <div class="kpi-value">${data.totalTransactionsCount} Struk</div>
                            </td>
                            <td class="kpi-card">
                                <div class="kpi-label">Total Belanja & Kulakan</div>
                                <div class="kpi-value">${PosRepository.formatRupiah(data.totalPurchasesAmount)}</div>
                                <div style="font-size: 10px; color: #64748B; margin-top: 2px;">
                                    Toko: ${PosRepository.formatRupiah(data.totalStorePurchasesAmount)} | Sup: ${PosRepository.formatRupiah(data.totalSupplierPurchasesAmount)}
                                </div>
                            </td>
                            <td class="kpi-card">
                                <div class="kpi-label">Piutang Pelanggan</div>
                                <div class="kpi-value" style="color: #D97706;">${PosRepository.formatRupiah(data.totalReceivablesRemaining)}</div>
                            </td>
                            <td class="kpi-card">
                                <div class="kpi-label">Void / Batal Transaksi</div>
                                <div class="kpi-value" style="color: #DC2626;">${data.totalVoidCount} Kali (${PosRepository.formatRupiah(data.totalVoidAmount)})</div>
                            </td>
                        </tr>
                    </table>

                    <!-- REKAPITULASI ARUS KAS METODE PEMBAYARAN -->
                    <div class="section-title">Rekapitulasi Arus Kas Berdasarkan Metode Pembayaran</div>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Metode Pembayaran</th>
                                <th style="text-align: center; width: 90px;">Jumlah Struk</th>
                                <th style="text-align: right; width: 160px;">Total Penerimaan (Rp)</th>
                                <th>Keterangan / Aliran Dana Kasir</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><b>1. Pembayaran Tunai (Murni)</b></td>
                                <td style="text-align: center;">${data.cashTransactions.size} Struk</td>
                                <td style="text-align: right; font-weight: bold; color: #059669;">${PosRepository.formatRupiah(data.totalCashAmount)}</td>
                                <td>Uang fisik langsung masuk laci kasir</td>
                            </tr>
                            <tr>
                                <td><b>2. Pembayaran Campuran (Split Pay)</b></td>
                                <td style="text-align: center;"><span class="badge-purple">${data.totalCampuranCount} Struk</span></td>
                                <td style="text-align: right; font-weight: bold; color: #7C3AED;">${PosRepository.formatRupiah(data.totalCampuranAmount)}</td>
                                <td>Porsi Tunai: <b>${PosRepository.formatRupiah(data.campuranCashPartTotal)}</b> &bull; Porsi Non-Tunai: <b>${PosRepository.formatRupiah(data.campuranNonCashPartTotal)}</b></td>
                            </tr>
                            <tr>
                                <td><b>3. Pembayaran QRIS</b></td>
                                <td style="text-align: center;">${data.qrisTransactions.size} Struk</td>
                                <td style="text-align: right; font-weight: bold; color: #2563EB;">${PosRepository.formatRupiah(data.totalQrisAmount)}</td>
                                <td>Settlement saldo e-wallet / digital QRIS</td>
                            </tr>
                            <tr>
                                <td><b>4. Transfer Bank / Kartu Debit</b></td>
                                <td style="text-align: center;">${data.transferTransactions.size} Struk</td>
                                <td style="text-align: right; font-weight: bold; color: #0284C7;">${PosRepository.formatRupiah(data.totalTransferAmount)}</td>
                                <td>Rekening bank toko / settlement mesin EDC</td>
                            </tr>
                            <tr>
                                <td><b>5. Piutang Pelanggan</b></td>
                                <td style="text-align: center;">${data.piutangTransactions.size} Struk</td>
                                <td style="text-align: right; font-weight: bold; color: #D97706;">${PosRepository.formatRupiah(data.totalPiutangAmount)}</td>
                                <td>Kasbon belanja yang belum dilunasi</td>
                            </tr>
                            <tr style="background-color: #F0FDF4; font-weight: bold;">
                                <td colspan="2">TOTAL REAL UANG FISIK DI LACI KASIR (Tunai Murni + Porsi Tunai Campuran):</td>
                                <td style="text-align: right; color: #059669; font-size: 11pt;">${PosRepository.formatRupiah(data.totalRealPhysicalCash)}</td>
                                <td style="color: #065F46;">Wajib dicocokkan saat serah terima / tutup shift kasir</td>
                            </tr>
                        </tbody>
                    </table>

                    <!-- SEKSI 1: BARANG CEPAT LAKU (FAST MOVING) -->
                    <div class="section-title">1. Daftar Barang Cepat Laku (Top Fast-Moving Products)</div>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th style="width: 40px; text-align: center;">No</th>
                                <th>Nama Produk</th>
                                <th>Kategori</th>
                                <th style="text-align: center;">Terjual</th>
                                <th style="text-align: right;">Total Omset</th>
                                <th style="text-align: right;">Est. Laba</th>
                                <th style="text-align: center;">Status</th>
                            </tr>
                        </thead>
                        <tbody>
            """.trimIndent())

            if (data.fastMoving.isEmpty()) {
                append("<tr><td colspan='7' style='text-align: center; color: #94A3B8;'>Belum ada data penjualan pada periode ini.</td></tr>")
            } else {
                data.fastMoving.forEachIndexed { index, item ->
                    append("""
                        <tr>
                            <td style="text-align: center;"><b>#${index + 1}</b></td>
                            <td><b>${item.product.name}</b> <span style="font-size: 8.5pt; color: #64748B;">(${item.product.sku})</span></td>
                            <td>${item.product.category}</td>
                            <td style="text-align: center; font-weight: bold; color: #065F46;">${item.totalSoldQty} ${item.product.unit}</td>
                            <td style="text-align: right; font-weight: bold;">${PosRepository.formatRupiah(item.totalRevenue)}</td>
                            <td style="text-align: right; color: #059669; font-weight: bold;">${PosRepository.formatRupiah(item.totalProfit)}</td>
                            <td style="text-align: center;"><span class="badge-green">FAST MOVING</span></td>
                        </tr>
                    """.trimIndent())
                }
            }

            append("""
                        </tbody>
                    </table>

                    <!-- SEKSI 2: BARANG KURANG LAKU (SLOW MOVING) -->
                    <div class="section-title">2. Daftar Barang Kurang Laku (Slow Moving & Dead Stock)</div>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th style="width: 40px; text-align: center;">No</th>
                                <th>Nama Produk</th>
                                <th>Kategori</th>
                                <th style="text-align: center;">Terjual</th>
                                <th style="text-align: center;">Sisa Stok Fisik</th>
                                <th style="text-align: right;">Nilai Aset Terparkir</th>
                                <th style="text-align: center;">Status Analisis</th>
                            </tr>
                        </thead>
                        <tbody>
            """.trimIndent())

            if (data.slowMoving.isEmpty()) {
                append("<tr><td colspan='7' style='text-align: center; color: #94A3B8;'>Semua produk bergerak baik atau data belum tersedia.</td></tr>")
            } else {
                data.slowMoving.forEachIndexed { index, item ->
                    val assetValue = item.product.stock * item.product.costPrice
                    append("""
                        <tr>
                            <td style="text-align: center;">${index + 1}</td>
                            <td><b>${item.product.name}</b></td>
                            <td>${item.product.category}</td>
                            <td style="text-align: center;">${item.totalSoldQty} ${item.product.unit}</td>
                            <td style="text-align: center; font-weight: bold; color: #D97706;">${item.product.stock} ${item.product.unit}</td>
                            <td style="text-align: right;">${PosRepository.formatRupiah(assetValue)}</td>
                            <td style="text-align: center;"><span class="badge-amber">SLOW MOVING</span></td>
                        </tr>
                    """.trimIndent())
                }
            }

            append("""
                        </tbody>
                    </table>

                    <!-- SEKSI 3: LAPORAN PEMBELIAN SUPPLIER & BELANJA TOKO -->
                    <div class="section-title">3. Laporan Pembelian Supplier & Belanja Toko (Pengadaan Barang)</div>
                    <div style="margin-bottom: 8px; font-size: 11px; color: #475569;">
                        <b>Rekap Pengadaan:</b> Belanja Toko: <b>${PosRepository.formatRupiah(data.totalStorePurchasesAmount)}</b> (${data.storePurchases.size} Nota) &bull; Pembelian Supplier: <b>${PosRepository.formatRupiah(data.totalSupplierPurchasesAmount)}</b> (${data.supplierPurchases.size} Faktur)
                    </div>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th style="width: 35px; text-align: center;">No</th>
                                <th>Tanggal</th>
                                <th>Jenis</th>
                                <th>No. Faktur / Nota</th>
                                <th>Supplier / Toko Mitra</th>
                                <th>Tipe Bayar</th>
                                <th style="text-align: right;">Total Belanja</th>
                                <th>Diterima Oleh</th>
                            </tr>
                        </thead>
                        <tbody>
            """.trimIndent())

            if (data.purchases.isEmpty()) {
                append("<tr><td colspan='8' style='text-align: center; color: #94A3B8;'>Belum ada catatan pembelian barang supplier maupun belanja toko pada periode ini.</td></tr>")
            } else {
                data.purchases.forEachIndexed { idx, p ->
                    val isStore = p.purchaseType == "STORE_PURCHASE"
                    val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("id", "ID")).format(Date(p.date))
                    val jenisBadge = if (isStore) "<span class='badge-green'>Belanja Toko</span>" else "<span class='badge-blue'>Supplier</span>"
                    append("""
                        <tr>
                            <td style="text-align: center;">${idx + 1}</td>
                            <td>$dateStr</td>
                            <td>$jenisBadge</td>
                            <td><b>${p.invoiceNumber}</b></td>
                            <td>${p.supplierName}</td>
                            <td><span class="${if (p.paymentType == "TUNAI") "badge-green" else "badge-amber"}">${p.paymentType}</span></td>
                            <td style="text-align: right; font-weight: bold; color: ${if (isStore) "#15803D" else "#1D4ED8"};">${PosRepository.formatRupiah(p.totalAmount)}</td>
                            <td>${p.receivedBy}</td>
                        </tr>
                    """.trimIndent())
                }
            }

            append("""
                        </tbody>
                    </table>

                    <!-- SEKSI 4: LAPORAN RETUR BARANG -->
                    <div class="section-title">4. Laporan Retur Barang (Pelanggan / Supplier / Cacat)</div>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th style="width: 40px; text-align: center;">No</th>
                                <th>Waktu</th>
                                <th>Nama Barang</th>
                                <th style="text-align: center;">Qty</th>
                                <th>Tipe Retur</th>
                                <th>Alasan</th>
                                <th>Pelanggan / Pihak</th>
                            </tr>
                        </thead>
                        <tbody>
            """.trimIndent())

            if (data.returns.isEmpty()) {
                append("<tr><td colspan='7' style='text-align: center; color: #94A3B8;'>Tidak ada pencatatan retur barang.</td></tr>")
            } else {
                data.returns.forEachIndexed { idx, r ->
                    val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("id", "ID")).format(Date(r.timestamp))
                    val typeBadge = if (r.returnType == "MASUK_STOK") {
                        "<span class='badge-green'>+ Stok Pelanggan</span>"
                    } else {
                        "<span class='badge-red'>- Stok Rusak</span>"
                    }
                    append("""
                        <tr>
                            <td style="text-align: center;">${idx + 1}</td>
                            <td>$dateStr</td>
                            <td><b>${r.productName}</b></td>
                            <td style="text-align: center; font-weight: bold;">${r.qty}</td>
                            <td>$typeBadge</td>
                            <td>${r.reason}</td>
                            <td>${r.customerOrSupplier.ifBlank { "-" }}</td>
                        </tr>
                    """.trimIndent())
                }
            }

            append("""
                        </tbody>
                    </table>

                    <!-- SEKSI 5: LAPORAN STOK OPNAME -->
                    <div class="section-title">5. Laporan Stok Opname (Audit Fisik vs Sistem)</div>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th style="width: 40px; text-align: center;">No</th>
                                <th>Tanggal</th>
                                <th>Produk</th>
                                <th style="text-align: center;">Stok Sistem</th>
                                <th style="text-align: center;">Stok Fisik</th>
                                <th style="text-align: center;">Selisih</th>
                                <th>Alasan & Pemeriksa</th>
                            </tr>
                        </thead>
                        <tbody>
            """.trimIndent())

            if (data.stockOpnames.isEmpty()) {
                append("<tr><td colspan='7' style='text-align: center; color: #94A3B8;'>Belum ada riwayat pelaksanaan stok opname.</td></tr>")
            } else {
                data.stockOpnames.forEachIndexed { idx, so ->
                    val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("id", "ID")).format(Date(so.date))
                    val diffStr = if (so.difference >= 0) "+${so.difference}" else "${so.difference}"
                    val diffBadge = when {
                        so.difference == 0 -> "<span class='badge-green'>Sesuai (0)</span>"
                        so.difference < 0 -> "<span class='badge-red'>$diffStr Kurang</span>"
                        else -> "<span class='badge-amber'>$diffStr Lebih</span>"
                    }
                    append("""
                        <tr>
                            <td style="text-align: center;">${idx + 1}</td>
                            <td>$dateStr</td>
                            <td><b>${so.productName}</b> <span style="font-size: 8.5pt; color: #64748B;">(${so.sku})</span></td>
                            <td style="text-align: center;">${so.systemStock}</td>
                            <td style="text-align: center; font-weight: bold;">${so.physicalStock}</td>
                            <td style="text-align: center;">$diffBadge</td>
                            <td>${so.reason} (${so.conductedBy})</td>
                        </tr>
                    """.trimIndent())
                }
            }

            append("""
                        </tbody>
                    </table>

                    <!-- SEKSI 6: LAPORAN TRANSAKSI DIBATALKAN (VOID) -->
                    <div class="section-title">6. Laporan Transaksi Dibatalkan (VOID)</div>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th style="width: 40px; text-align: center;">No</th>
                                <th>Waktu Void</th>
                                <th>No. Struk</th>
                                <th>Kasir</th>
                                <th>Alasan Pembatalan</th>
                                <th>Supervisor Otorisasi</th>
                                <th style="text-align: right;">Nilai Dibatalkan</th>
                            </tr>
                        </thead>
                        <tbody>
            """.trimIndent())

            if (data.voidTransactions.isEmpty()) {
                append("<tr><td colspan='7' style='text-align: center; color: #94A3B8;'>Tidak ada transaksi yang dibatalkan (VOID) pada periode ini.</td></tr>")
            } else {
                data.voidTransactions.forEachIndexed { idx, v ->
                    val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("id", "ID")).format(Date(if (v.voidTimestamp > 0) v.voidTimestamp else v.timestamp))
                    append("""
                        <tr>
                            <td style="text-align: center;">${idx + 1}</td>
                            <td>$dateStr</td>
                            <td><b>${v.receiptNumber}</b></td>
                            <td>${v.cashierName}</td>
                            <td><span class="badge-red">${v.voidReason.ifBlank { "Kesalahan Input" }}</span></td>
                            <td>${v.voidBy.ifBlank { "Supervisor" }}</td>
                            <td style="text-align: right; font-weight: bold; color: #DC2626;">${PosRepository.formatRupiah(v.totalAmount)}</td>
                        </tr>
                    """.trimIndent())
                }
            }

            append("""
                        </tbody>
                    </table>

                    <!-- SEKSI 7: LAPORAN BUKU PIUTANG PELANGGAN -->
                    <div class="section-title">7. Laporan Piutang & Kasbon Pelanggan</div>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th style="width: 40px; text-align: center;">No</th>
                                <th>No. Bon</th>
                                <th>Nama Pelanggan</th>
                                <th>No. Telp</th>
                                <th style="text-align: right;">Total Bon</th>
                                <th style="text-align: right;">Sisa Piutang</th>
                                <th style="text-align: center;">Status</th>
                            </tr>
                        </thead>
                        <tbody>
            """.trimIndent())

            if (data.receivables.isEmpty()) {
                append("<tr><td colspan='7' style='text-align: center; color: #94A3B8;'>Tidak ada catatan piutang aktif.</td></tr>")
            } else {
                data.receivables.forEachIndexed { idx, r ->
                    val statusBadge = if (r.status == "LUNAS") {
                        "<span class='badge-green'>LUNAS</span>"
                    } else {
                        "<span class='badge-amber'>BELUM LUNAS</span>"
                    }
                    append("""
                        <tr>
                            <td style="text-align: center;">${idx + 1}</td>
                            <td><b>${r.receiptNumber}</b></td>
                            <td><b>${r.customerName}</b></td>
                            <td>${r.customerPhone.ifBlank { "-" }}</td>
                            <td style="text-align: right;">${PosRepository.formatRupiah(r.totalAmount)}</td>
                            <td style="text-align: right; font-weight: bold; color: ${if (r.remainingAmount > 0) "#DC2626" else "#059669"};">${PosRepository.formatRupiah(r.remainingAmount)}</td>
                            <td style="text-align: center;">$statusBadge</td>
                        </tr>
                    """.trimIndent())
                }
            }

            append("""
                        </tbody>
                    </table>

                    <!-- TANDA TANGAN -->
                    <table class="signature-table">
                        <tr>
                            <td>
                                Dilaporkan oleh,<br><br><br><br>
                                <b>( Kasir / Admin Toko )</b>
                            </td>
                            <td>
                                Mengetahui & Menyetujui,<br><br><br><br>
                                <b>( Pemilik / Supervisor Toko )</b>
                            </td>
                        </tr>
                    </table>
                </body>
                </html>
            """.trimIndent())
        }
    }

    // =========================================================================
    // 2. GENERATE PDF DOCUMENT NATIVELY
    // =========================================================================
    fun generatePdfDocument(context: Context, data: ComprehensiveReportData): File {
        val fileName = "Laporan_POS_${data.storeInfo.storeName.replace(" ", "_")}_${System.currentTimeMillis()}.pdf"
        val file = File(context.cacheDir, fileName)

        val pdfDocument = PdfDocument()
        val pageWidth = 595 // Standard A4 width in points
        val pageHeight = 842 // Standard A4 height in points
        var pageNumber = 1

        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        val nowFormatted = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("id", "ID")).format(Date())

        var currentPage = pdfDocument.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
        var canvas: Canvas = currentPage.canvas
        var currentY = 40f

        fun drawHeaderAndFooter(c: Canvas, pNum: Int) {
            // Header Top Bar
            paint.color = Color.parseColor("#065F46")
            paint.style = Paint.Style.FILL
            c.drawRect(30f, 25f, pageWidth - 30f, 28f, paint)

            // Footer Bottom
            paint.color = Color.parseColor("#CBD5E1")
            c.drawRect(30f, pageHeight - 35f, pageWidth - 30f, pageHeight - 34f, paint)
            textPaint.textSize = 8.5f
            textPaint.color = Color.parseColor("#64748B")
            textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            c.drawText("${data.storeInfo.storeName} • Laporan POS • Dicetak $nowFormatted", 30f, pageHeight - 22f, textPaint)
            c.drawText("Halaman $pNum", pageWidth - 75f, pageHeight - 22f, textPaint)
        }

        fun checkPageBreak(requiredHeight: Float) {
            if (currentY + requiredHeight > pageHeight - 45f) {
                drawHeaderAndFooter(canvas, pageNumber)
                pdfDocument.finishPage(currentPage)
                pageNumber++
                currentPage = pdfDocument.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
                canvas = currentPage.canvas
                currentY = 45f
            }
        }

        // --- FIRST PAGE HEADER ---
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.textSize = 17f
        textPaint.color = Color.parseColor("#065F46")
        canvas.drawText(data.storeInfo.storeName.uppercase(), 30f, currentY + 14f, textPaint)
        currentY += 20f

        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        textPaint.textSize = 9.5f
        textPaint.color = Color.parseColor("#64748B")
        canvas.drawText("${data.storeInfo.storeAddress} | Telp: ${data.storeInfo.storePhone}", 30f, currentY + 10f, textPaint)
        currentY += 16f

        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.textSize = 12.5f
        textPaint.color = Color.parseColor("#0F172A")
        canvas.drawText("LAPORAN KEUANGAN & OPERASIONAL LENGKAP", 30f, currentY + 12f, textPaint)
        currentY += 15f

        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        textPaint.textSize = 9.5f
        textPaint.color = Color.parseColor("#475569")
        canvas.drawText("Periode: ${data.periodLabel}   |   Dicetak: $nowFormatted", 30f, currentY + 10f, textPaint)
        currentY += 20f

        // Green Divider
        paint.color = Color.parseColor("#059669")
        paint.style = Paint.Style.FILL
        canvas.drawRect(30f, currentY, pageWidth - 30f, currentY + 2f, paint)
        currentY += 14f

        // --- KPI SUMMARY CARDS (2 Rows x 4 Columns) ---
        val cardWidth = (pageWidth - 60f - 24f) / 4f
        val cardHeight = 44f

        fun drawKpiCard(x: Float, y: Float, label: String, value: String, isAccent: Boolean = false) {
            paint.color = if (isAccent) Color.parseColor("#ECFDF5") else Color.parseColor("#F8FAFC")
            paint.style = Paint.Style.FILL
            val rect = RectF(x, y, x + cardWidth, y + cardHeight)
            canvas.drawRoundRect(rect, 4f, 4f, paint)

            paint.color = if (isAccent) Color.parseColor("#A7F3D0") else Color.parseColor("#E2E8F0")
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1f
            canvas.drawRoundRect(rect, 4f, 4f, paint)

            textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textPaint.textSize = 7.5f
            textPaint.color = Color.parseColor("#64748B")
            canvas.drawText(label, x + 8f, y + 14f, textPaint)

            textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textPaint.textSize = 10f
            textPaint.color = if (isAccent) Color.parseColor("#065F46") else Color.parseColor("#0F172A")
            canvas.drawText(value, x + 8f, y + 32f, textPaint)
        }

        // Row 1
        drawKpiCard(30f, currentY, "TOTAL OMSET", PosRepository.formatRupiah(data.totalOmset))
        drawKpiCard(30f + (cardWidth + 8f), currentY, "TOTAL HPP", PosRepository.formatRupiah(data.totalHpp))
        drawKpiCard(30f + (cardWidth + 8f) * 2, currentY, "EST. LABA BERSIH", PosRepository.formatRupiah(data.totalProfit), isAccent = true)
        drawKpiCard(30f + (cardWidth + 8f) * 3, currentY, "RATA2 KERANJANG", PosRepository.formatRupiah(data.averageBasket))
        currentY += cardHeight + 8f

        // Row 2
        drawKpiCard(30f, currentY, "TOTAL TRANSAKSI", "${data.totalTransactionsCount} Struk")
        drawKpiCard(30f + (cardWidth + 8f), currentY, "BELANJA & KULAKAN", PosRepository.formatRupiah(data.totalPurchasesAmount))
        drawKpiCard(30f + (cardWidth + 8f) * 2, currentY, "PIUTANG PELANGGAN", PosRepository.formatRupiah(data.totalReceivablesRemaining))
        drawKpiCard(30f + (cardWidth + 8f) * 3, currentY, "VOID / BATAL", "${data.totalVoidCount}x (${PosRepository.formatRupiah(data.totalVoidAmount)})")
        currentY += cardHeight + 18f

        // Helper to draw section header
        fun drawSectionHeader(title: String) {
            checkPageBreak(30f)
            paint.color = Color.parseColor("#059669")
            paint.style = Paint.Style.FILL
            canvas.drawRect(30f, currentY, 34f, currentY + 14f, paint)

            textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textPaint.textSize = 11f
            textPaint.color = Color.parseColor("#065F46")
            canvas.drawText(title, 40f, currentY + 11f, textPaint)
            currentY += 20f
        }

        // Helper to draw table header
        fun drawTableHeader(colTitles: List<String>, colWidths: List<Float>) {
            checkPageBreak(22f)
            paint.color = Color.parseColor("#065F46")
            paint.style = Paint.Style.FILL
            canvas.drawRect(30f, currentY, pageWidth - 30f, currentY + 18f, paint)

            textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textPaint.textSize = 8.5f
            textPaint.color = Color.WHITE

            var curX = 36f
            colTitles.forEachIndexed { i, title ->
                canvas.drawText(title, curX, currentY + 12f, textPaint)
                curX += colWidths[i]
            }
            currentY += 18f
        }

        // Helper to draw table row
        fun drawTableRow(values: List<String>, colWidths: List<Float>, isEven: Boolean) {
            checkPageBreak(18f)
            if (isEven) {
                paint.color = Color.parseColor("#F8FAFC")
                paint.style = Paint.Style.FILL
                canvas.drawRect(30f, currentY, pageWidth - 30f, currentY + 16f, paint)
            }
            // Bottom border
            paint.color = Color.parseColor("#F1F5F9")
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 0.5f
            canvas.drawLine(30f, currentY + 16f, pageWidth - 30f, currentY + 16f, paint)

            textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textPaint.textSize = 8.5f
            textPaint.color = Color.parseColor("#1E293B")

            var curX = 36f
            values.forEachIndexed { i, v ->
                // Truncate if too long
                val maxChars = (colWidths[i] / 5.2f).toInt()
                val displayStr = if (v.length > maxChars && maxChars > 3) v.take(maxChars - 2) + ".." else v
                canvas.drawText(displayStr, curX, currentY + 11f, textPaint)
                curX += colWidths[i]
            }
            currentY += 16f
        }

        // --- ARUS KAS METODE PEMBAYARAN ---
        drawSectionHeader("Arus Kas Berdasarkan Metode Pembayaran")
        val payCols = listOf("Metode Bayar", "Struk", "Total Penerimaan", "Rincian Dana Masuk")
        val payWidths = listOf(110f, 55f, 115f, 255f)
        drawTableHeader(payCols, payWidths)
        drawTableRow(listOf("Tunai (Murni)", "${data.cashTransactions.size}", PosRepository.formatRupiah(data.totalCashAmount), "Uang fisik di laci kasir"), payWidths, false)
        drawTableRow(listOf("Campuran", "${data.totalCampuranCount}", PosRepository.formatRupiah(data.totalCampuranAmount), "Tunai: ${PosRepository.formatRupiah(data.campuranCashPartTotal)} • Non-Tunai: ${PosRepository.formatRupiah(data.campuranNonCashPartTotal)}"), payWidths, true)
        drawTableRow(listOf("QRIS", "${data.qrisTransactions.size}", PosRepository.formatRupiah(data.totalQrisAmount), "Digital QRIS e-wallet"), payWidths, false)
        drawTableRow(listOf("Transfer / Debit", "${data.transferTransactions.size}", PosRepository.formatRupiah(data.totalTransferAmount), "Bank / EDC debit"), payWidths, true)
        drawTableRow(listOf("Piutang", "${data.piutangTransactions.size}", PosRepository.formatRupiah(data.totalPiutangAmount), "Kasbon belum lunas"), payWidths, false)
        currentY += 12f

        // --- 1. FAST MOVING ---
        drawSectionHeader("1. Barang Cepat Laku (Top Fast Moving Products)")
        val fastCols = listOf("No", "Nama Produk", "Kategori", "Qty", "Omset", "Laba")
        val fastWidths = listOf(30f, 175f, 95f, 60f, 90f, 85f)
        drawTableHeader(fastCols, fastWidths)
        if (data.fastMoving.isEmpty()) {
            drawTableRow(listOf("-", "Belum ada penjualan", "-", "-", "-", "-"), fastWidths, false)
        } else {
            data.fastMoving.take(10).forEachIndexed { i, it ->
                drawTableRow(
                    listOf(
                        "#${i + 1}",
                        it.product.name,
                        it.product.category,
                        "${it.totalSoldQty} ${it.product.unit}",
                        PosRepository.formatRupiah(it.totalRevenue),
                        PosRepository.formatRupiah(it.totalProfit)
                    ),
                    fastWidths,
                    i % 2 == 1
                )
            }
        }
        currentY += 12f

        // --- 2. SLOW MOVING ---
        drawSectionHeader("2. Barang Kurang Laku (Slow Moving / Stok Mengendap)")
        val slowCols = listOf("No", "Nama Produk", "Kategori", "Terjual", "Sisa Stok", "Aset Terparkir")
        val slowWidths = listOf(30f, 175f, 95f, 60f, 75f, 100f)
        drawTableHeader(slowCols, slowWidths)
        if (data.slowMoving.isEmpty()) {
            drawTableRow(listOf("-", "Semua produk bergerak baik", "-", "-", "-", "-"), slowWidths, false)
        } else {
            data.slowMoving.take(10).forEachIndexed { i, it ->
                val asset = it.product.stock * it.product.costPrice
                drawTableRow(
                    listOf(
                        "${i + 1}",
                        it.product.name,
                        it.product.category,
                        "${it.totalSoldQty} ${it.product.unit}",
                        "${it.product.stock} ${it.product.unit}",
                        PosRepository.formatRupiah(asset)
                    ),
                    slowWidths,
                    i % 2 == 1
                )
            }
        }
        currentY += 12f

        // --- 3. PEMBELIAN SUPPLIER & BELANJA TOKO ---
        drawSectionHeader("3. Laporan Pembelian Supplier & Belanja Toko")
        val buyCols = listOf("No", "Jenis", "No. Faktur/Nota", "Supplier/Toko", "Metode", "Total", "Penerima")
        val buyWidths = listOf(25f, 65f, 100f, 135f, 55f, 85f, 70f)
        drawTableHeader(buyCols, buyWidths)
        if (data.purchases.isEmpty()) {
            drawTableRow(listOf("-", "-", "Tidak ada pembelian/belanja", "-", "-", "-", "-"), buyWidths, false)
        } else {
            data.purchases.take(12).forEachIndexed { i, p ->
                val jenis = if (p.purchaseType == "STORE_PURCHASE") "Belanja" else "Supplier"
                drawTableRow(
                    listOf(
                        "${i + 1}",
                        jenis,
                        p.invoiceNumber,
                        p.supplierName,
                        p.paymentType,
                        PosRepository.formatRupiah(p.totalAmount),
                        p.receivedBy
                    ),
                    buyWidths,
                    i % 2 == 1
                )
            }
        }
        currentY += 12f

        // --- 4. RETUR BARANG ---
        drawSectionHeader("4. Laporan Retur Barang")
        val retCols = listOf("No", "Nama Produk", "Qty", "Jenis Retur", "Alasan", "Pihak")
        val retWidths = listOf(30f, 150f, 45f, 95f, 120f, 95f)
        drawTableHeader(retCols, retWidths)
        if (data.returns.isEmpty()) {
            drawTableRow(listOf("-", "Tidak ada retur barang", "-", "-", "-", "-"), retWidths, false)
        } else {
            data.returns.take(10).forEachIndexed { i, r ->
                val type = if (r.returnType == "MASUK_STOK") "+Stok Pelanggan" else "-Stok Rusak"
                drawTableRow(
                    listOf(
                        "${i + 1}",
                        r.productName,
                        "${r.qty}",
                        type,
                        r.reason,
                        r.customerOrSupplier.ifBlank { "-" }
                    ),
                    retWidths,
                    i % 2 == 1
                )
            }
        }
        currentY += 12f

        // --- 5. STOK OPNAME ---
        drawSectionHeader("5. Laporan Stok Opname")
        val soCols = listOf("No", "Nama Produk", "Sistem", "Fisik", "Selisih", "Pemeriksa")
        val soWidths = listOf(30f, 175f, 60f, 60f, 80f, 130f)
        drawTableHeader(soCols, soWidths)
        if (data.stockOpnames.isEmpty()) {
            drawTableRow(listOf("-", "Belum ada stok opname", "-", "-", "-", "-"), soWidths, false)
        } else {
            data.stockOpnames.take(10).forEachIndexed { i, so ->
                val diffStr = if (so.difference >= 0) "+${so.difference}" else "${so.difference}"
                drawTableRow(
                    listOf(
                        "${i + 1}",
                        so.productName,
                        "${so.systemStock}",
                        "${so.physicalStock}",
                        diffStr,
                        "${so.conductedBy} (${so.reason})"
                    ),
                    soWidths,
                    i % 2 == 1
                )
            }
        }
        currentY += 12f

        // --- 6. VOID TRANSAKSI ---
        drawSectionHeader("6. Laporan Transaksi Dibatalkan (VOID)")
        val voidCols = listOf("No", "No. Struk", "Kasir", "Alasan", "Otorisasi", "Nilai")
        val voidWidths = listOf(30f, 110f, 85f, 140f, 85f, 85f)
        drawTableHeader(voidCols, voidWidths)
        if (data.voidTransactions.isEmpty()) {
            drawTableRow(listOf("-", "Tidak ada transaksi VOID", "-", "-", "-", "-"), voidWidths, false)
        } else {
            data.voidTransactions.take(10).forEachIndexed { i, v ->
                drawTableRow(
                    listOf(
                        "${i + 1}",
                        v.receiptNumber,
                        v.cashierName,
                        v.voidReason.ifBlank { "Salah Input" },
                        v.voidBy.ifBlank { "Supervisor" },
                        PosRepository.formatRupiah(v.totalAmount)
                    ),
                    voidWidths,
                    i % 2 == 1
                )
            }
        }
        currentY += 12f

        // --- 7. PIUTANG PELANGGAN ---
        drawSectionHeader("7. Laporan Piutang Pelanggan")
        val piuCols = listOf("No", "No. Bon", "Pelanggan", "Total Bon", "Sisa Piutang", "Status")
        val piuWidths = listOf(30f, 100f, 135f, 95f, 95f, 80f)
        drawTableHeader(piuCols, piuWidths)
        if (data.receivables.isEmpty()) {
            drawTableRow(listOf("-", "Tidak ada piutang aktif", "-", "-", "-", "-"), piuWidths, false)
        } else {
            data.receivables.take(10).forEachIndexed { i, r ->
                drawTableRow(
                    listOf(
                        "${i + 1}",
                        r.receiptNumber,
                        r.customerName,
                        PosRepository.formatRupiah(r.totalAmount),
                        PosRepository.formatRupiah(r.remainingAmount),
                        if (r.status == "LUNAS") "LUNAS" else "BELUM LUNAS"
                    ),
                    piuWidths,
                    i % 2 == 1
                )
            }
        }
        currentY += 30f

        // --- SIGNATURE SECTION ---
        checkPageBreak(50f)
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        textPaint.textSize = 9.5f
        textPaint.color = Color.parseColor("#475569")
        canvas.drawText("Petugas Kasir / Admin,", 60f, currentY, textPaint)
        canvas.drawText("Pemilik / Supervisor Toko,", pageWidth - 190f, currentY, textPaint)

        currentY += 40f
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.color = Color.parseColor("#0F172A")
        canvas.drawText("( ................................... )", 50f, currentY, textPaint)
        canvas.drawText("( ................................... )", pageWidth - 200f, currentY, textPaint)

        // Finish last page
        drawHeaderAndFooter(canvas, pageNumber)
        pdfDocument.finishPage(currentPage)

        // Write to file
        FileOutputStream(file).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()
        return file
    }

    // =========================================================================
    // 3. INTENT HELPERS: SHARE, OPEN & DOWNLOAD
    // =========================================================================
    fun shareDocument(context: Context, file: File, mimeType: String, subject: String) {
        try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, "Berikut terlampir $subject.")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Bagikan Dokumen Laporan"))
        } catch (e: Exception) {
            Toast.makeText(context, "Gagal membagikan dokumen: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    fun openDocument(context: Context, file: File, mimeType: String) {
        try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            // Fallback to share chooser if no default app installed
            shareDocument(context, file, mimeType, "Laporan Toko")
        }
    }

    fun saveToDownloads(context: Context, sourceFile: File, displayName: String): File? {
        return try {
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (!downloadsDir.exists()) downloadsDir.mkdirs()
            val destFile = File(downloadsDir, displayName)
            sourceFile.copyTo(destFile, overwrite = true)
            Toast.makeText(context, "Dokumen tersimpan di folder Download: ${destFile.name}", Toast.LENGTH_LONG).show()
            destFile
        } catch (e: Exception) {
            Toast.makeText(context, "Dokumen disimpan di cache: ${sourceFile.name}", Toast.LENGTH_SHORT).show()
            sourceFile
        }
    }

    // =========================================================================
    // 4. DOKUMEN KHUSUS: STOK OPNAME (SELISIH & BERITA ACARA), RETUR, PEMBELIAN, PIUTANG
    // =========================================================================

    private fun wrapHtmlDoc(title: String, storeInfo: LicenseInfo, bodyContent: String): String {
        val nowFormatted = SimpleDateFormat("dd MMMM yyyy, HH:mm", Locale("id", "ID")).format(Date())
        return """
            <html xmlns:o="urn:schemas-microsoft-com:office:office" 
                  xmlns:w="urn:schemas-microsoft-com:office:word" 
                  xmlns="http://www.w3.org/TR/REC-html40">
            <head>
            <meta charset="utf-8">
            <title>$title</title>
            <style>
                body { font-family: 'Segoe UI', Calibri, Arial, sans-serif; font-size: 11pt; color: #1e293b; margin: 30px; line-height: 1.5; }
                h1 { font-size: 18pt; color: #0f172a; margin: 0 0 4px 0; }
                h2 { font-size: 13pt; color: #0284c7; margin: 18px 0 6px 0; border-bottom: 2px solid #0284c7; padding-bottom: 4px; }
                .store-header { border-bottom: 2px solid #0f172a; padding-bottom: 12px; margin-bottom: 20px; }
                .meta-table { width: 100%; margin-bottom: 16px; border: none; }
                .meta-table td { padding: 3px 0; border: none; font-size: 10pt; }
                table.data-table { width: 100%; border-collapse: collapse; margin-top: 10px; margin-bottom: 20px; }
                table.data-table th { background-color: #0f172a; color: #ffffff; padding: 8px 10px; font-size: 9.5pt; text-align: left; border: 1px solid #0f172a; }
                table.data-table td { padding: 7px 10px; border: 1px solid #cbd5e1; font-size: 9.5pt; }
                table.data-table tr:nth-child(even) { background-color: #f8fafc; }
                .badge-danger { background-color: #fee2e2; color: #b91c1c; font-weight: bold; padding: 2px 6px; border-radius: 4px; font-size: 8.5pt; }
                .badge-success { background-color: #dcfce7; color: #15803d; font-weight: bold; padding: 2px 6px; border-radius: 4px; font-size: 8.5pt; }
                .badge-warning { background-color: #fef3c7; color: #b45309; font-weight: bold; padding: 2px 6px; border-radius: 4px; font-size: 8.5pt; }
                .signature-table { width: 100%; margin-top: 40px; border: none; }
                .signature-table td { width: 50%; text-align: center; vertical-align: top; border: none; font-size: 10pt; }
            </style>
            </head>
            <body>
                <div class="store-header">
                    <h1>${storeInfo.storeName}</h1>
                    <div style="font-size: 9.5pt; color: #64748b;">${storeInfo.storeAddress} | Telp: ${storeInfo.storePhone}</div>
                </div>
                <h2>$title</h2>
                <div style="font-size: 9pt; color: #64748b; margin-bottom: 14px;">Dicetak pada: $nowFormatted</div>
                $bodyContent
                <table class="signature-table">
                    <tr>
                        <td>
                            Petugas Pelaksana / Admin,<br><br><br><br><br>
                            <b>( ............................................ )</b>
                        </td>
                        <td>
                            Mengetahui & Menyetujui,<br>
                            Supervisor / Pemilik Toko<br><br><br><br>
                            <b>( ............................................ )</b>
                        </td>
                    </tr>
                </table>
            </body>
            </html>
        """.trimIndent()
    }

    /**
     * 4.1 Dokumen Cetak Selisih Stok Opname (Untuk cek ulang barang tidak sesuai)
     */
    fun generateStockOpnameDiscrepancyDoc(
        context: Context,
        storeInfo: LicenseInfo,
        taskCode: String,
        taskTitle: String,
        conductedBy: String,
        discrepancyItems: List<StockOpnameRecord>
    ): File {
        val fileName = "Selisih_SO_${taskCode}_${System.currentTimeMillis()}.doc"
        val file = File(context.cacheDir, fileName)

        val totalDiscrepancyQty = discrepancyItems.sumOf { Math.abs(it.difference) }
        val body = buildString {
            append("""
                <table class="meta-table">
                    <tr><td style="width: 140px;"><b>No. Tugas SO:</b></td><td>$taskCode</td></tr>
                    <tr><td><b>Judul Tugas:</b></td><td>$taskTitle</td></tr>
                    <tr><td><b>Petugas:</b></td><td>$conductedBy</td></tr>
                    <tr><td><b>Total SKU Selisih:</b></td><td><b>${discrepancyItems.size} produk</b> (Hanya produk yang memiliki selisih fisik vs sistem)</td></tr>
                    <tr><td><b>Total Unit Selisih:</b></td><td><b>$totalDiscrepancyQty unit</b></td></tr>
                </table>
                <p style="background-color: #fffbeb; border-left: 4px solid #f59e0b; padding: 8px 12px; font-size: 9.5pt; color: #92400e;">
                    <b>Catatan Pemeriksaan Ulang:</b> Dokumen ini memuat daftar produk yang belum cocok antara stok komputer dan hitungan fisik. Lakukan penghitungan ulang fisik sebelum melakukan penyesuaian akhir (finalisasi).
                </p>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th style="width: 30px;">No</th>
                            <th>SKU/Barcode</th>
                            <th>Nama Produk</th>
                            <th style="text-align: right;">Stok Sistem</th>
                            <th style="text-align: right;">Hitung Fisik</th>
                            <th style="text-align: right;">Selisih</th>
                            <th>Alasan / Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
            """.trimIndent())

            if (discrepancyItems.isEmpty()) {
                append("""<tr><td colspan="7" style="text-align: center; color: #16a34a; font-weight: bold; padding: 20px;">Selamat! Tidak ada selisih stok (Seluruh produk cocok dengan stok sistem).</td></tr>""")
            } else {
                discrepancyItems.forEachIndexed { i, item ->
                    val diffBadge = if (item.difference > 0) {
                        "<span class=\"badge-success\">+${item.difference} ${item.unit} (Lebih)</span>"
                    } else {
                        "<span class=\"badge-danger\">${item.difference} ${item.unit} (Kurang)</span>"
                    }
                    append("""
                        <tr>
                            <td style="text-align: center;">${i + 1}</td>
                            <td>${item.sku.ifBlank { "-" }}</td>
                            <td><b>${item.productName}</b></td>
                            <td style="text-align: right;">${item.systemStock} ${item.unit}</td>
                            <td style="text-align: right; font-weight: bold;">${item.physicalStock} ${item.unit}</td>
                            <td style="text-align: right;">$diffBadge</td>
                            <td>${item.reason}${if (item.notes.isNotBlank()) " (${item.notes})" else ""}</td>
                        </tr>
                    """.trimIndent())
                }
            }

            append("""
                    </tbody>
                </table>
            """.trimIndent())
        }

        val html = wrapHtmlDoc("Laporan Selisih Stok Opname (Checklist)", storeInfo, body)
        FileOutputStream(file).use { it.write(html.toByteArray(Charsets.UTF_8)) }
        return file
    }

    /**
     * 4.2 Dokumen Berita Acara Penyelesaian Stok Opname (Final)
     */
    fun generateStockOpnameFinalDoc(
        context: Context,
        storeInfo: LicenseInfo,
        taskCode: String,
        taskTitle: String,
        conductedBy: String,
        allItems: List<StockOpnameRecord>,
        notes: String
    ): File {
        val fileName = "Berita_Acara_SO_${taskCode}_${System.currentTimeMillis()}.doc"
        val file = File(context.cacheDir, fileName)

        val totalItems = allItems.size
        val matchedCount = allItems.count { it.difference == 0 }
        val discrepancyItems = allItems.filter { it.difference != 0 }

        val body = buildString {
            append("""
                <table class="meta-table">
                    <tr><td style="width: 160px;"><b>No. Dokumen / Tugas:</b></td><td><b>$taskCode</b></td></tr>
                    <tr><td><b>Nama Kegiatan:</b></td><td>$taskTitle</td></tr>
                    <tr><td><b>Penanggung Jawab:</b></td><td>$conductedBy</td></tr>
                    <tr><td><b>Total SKU Diperiksa:</b></td><td>$totalItems SKU</td></tr>
                    <tr><td><b>Produk Cocok (Sesuai):</b></td><td><span class="badge-success">$matchedCount SKU (${if (totalItems > 0) (matchedCount * 100 / totalItems) else 0}%)</span></td></tr>
                    <tr><td><b>Produk Berselisih:</b></td><td><span class="badge-danger">${discrepancyItems.size} SKU</span></td></tr>
                    <tr><td><b>Catatan Penyelesaian:</b></td><td>${notes.ifBlank { "Telah dilakukan penyesuaian stok fisik dan disinkronkan ke dalam sistem POS." }}</td></tr>
                </table>

                <table class="data-table">
                    <thead>
                        <tr>
                            <th style="width: 25px;">No</th>
                            <th>SKU</th>
                            <th>Nama Produk</th>
                            <th style="text-align: right;">Stok Awal</th>
                            <th style="text-align: right;">Hasil Fisik</th>
                            <th style="text-align: right;">Selisih</th>
                            <th>Status & Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
            """.trimIndent())

            allItems.forEachIndexed { i, item ->
                val statusText = if (item.difference == 0) {
                    "<span class=\"badge-success\">SESUAI</span>"
                } else if (item.difference > 0) {
                    "<span class=\"badge-warning\">SURPLUS (+${item.difference})</span>"
                } else {
                    "<span class=\"badge-danger\">DEFISIT (${item.difference})</span>"
                }
                append("""
                    <tr>
                        <td style="text-align: center;">${i + 1}</td>
                        <td>${item.sku.ifBlank { "-" }}</td>
                        <td><b>${item.productName}</b></td>
                        <td style="text-align: right;">${item.systemStock} ${item.unit}</td>
                        <td style="text-align: right; font-weight: bold;">${item.physicalStock} ${item.unit}</td>
                        <td style="text-align: right;">${if (item.difference > 0) "+${item.difference}" else "${item.difference}"} ${item.unit}</td>
                        <td>$statusText ${item.reason}</td>
                    </tr>
                """.trimIndent())
            }

            append("""
                    </tbody>
                </table>
            """.trimIndent())
        }

        val html = wrapHtmlDoc("Berita Acara Hasil Stok Opname", storeInfo, body)
        FileOutputStream(file).use { it.write(html.toByteArray(Charsets.UTF_8)) }
        return file
    }

    /**
     * 4.3 Dokumen Riwayat Retur Barang
     */
    fun generateProductReturnDoc(
        context: Context,
        storeInfo: LicenseInfo,
        returns: List<ProductReturnRecord>
    ): File {
        val fileName = "Riwayat_Retur_${System.currentTimeMillis()}.doc"
        val file = File(context.cacheDir, fileName)
        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("id", "ID"))

        val totalQty = returns.sumOf { it.qty }
        val body = buildString {
            append("""
                <table class="meta-table">
                    <tr><td style="width: 140px;"><b>Total Transaksi Retur:</b></td><td><b>${returns.size} kali</b></td></tr>
                    <tr><td><b>Total Kuantitas Retur:</b></td><td><b>$totalQty unit</b></td></tr>
                </table>

                <table class="data-table">
                    <thead>
                        <tr>
                            <th style="width: 25px;">No</th>
                            <th>Tanggal</th>
                            <th>Nama Produk</th>
                            <th style="text-align: center;">Qty</th>
                            <th>Tipe Retur</th>
                            <th>Alasan</th>
                            <th>Pelanggan / Pihak</th>
                            <th>Catatan</th>
                        </tr>
                    </thead>
                    <tbody>
            """.trimIndent())

            if (returns.isEmpty()) {
                append("""<tr><td colspan="8" style="text-align: center; padding: 20px;">Belum ada riwayat retur barang.</td></tr>""")
            } else {
                returns.forEachIndexed { i, r ->
                    val typeBadge = if (r.returnType == "MASUK_STOK") {
                        "<span class=\"badge-success\">Masuk Stok (Pelanggan)</span>"
                    } else {
                        "<span class=\"badge-danger\">Keluar Stok (Rusak/Supplier)</span>"
                    }
                    append("""
                        <tr>
                            <td style="text-align: center;">${i + 1}</td>
                            <td>${dateFormat.format(Date(r.timestamp))}</td>
                            <td><b>${r.productName}</b></td>
                            <td style="text-align: center; font-weight: bold;">${r.qty}</td>
                            <td>$typeBadge</td>
                            <td>${r.reason}</td>
                            <td>${r.customerOrSupplier.ifBlank { "-" }}</td>
                            <td>${r.notes.ifBlank { "-" }}</td>
                        </tr>
                    """.trimIndent())
                }
            }

            append("""
                    </tbody>
                </table>
            """.trimIndent())
        }

        val html = wrapHtmlDoc("Dokumen Laporan Riwayat Retur Barang", storeInfo, body)
        FileOutputStream(file).use { it.write(html.toByteArray(Charsets.UTF_8)) }
        return file
    }

    /**
     * 4.4 Dokumen Riwayat Pembelian Supplier
     */
    fun generateSupplierPurchaseDoc(
        context: Context,
        storeInfo: LicenseInfo,
        purchases: List<PurchaseRecord>
    ): File {
        val fileName = "Riwayat_Pengadaan_Belanja_${System.currentTimeMillis()}.doc"
        val file = File(context.cacheDir, fileName)
        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("id", "ID"))

        val totalAmount = purchases.sumOf { it.totalAmount }
        val storePurchases = purchases.filter { it.purchaseType == "STORE_PURCHASE" }
        val supplierPurchases = purchases.filter { it.purchaseType != "STORE_PURCHASE" }

        val body = buildString {
            append("""
                <table class="meta-table">
                    <tr><td style="width: 180px;"><b>Total Transaksi Pengadaan:</b></td><td><b>${purchases.size} transaksi</b></td></tr>
                    <tr><td><b>Belanja Toko (Operasional):</b></td><td><b>${PosRepository.formatRupiah(storePurchases.sumOf { it.totalAmount })} (${storePurchases.size} nota)</b></td></tr>
                    <tr><td><b>Pembelian Supplier Resmi:</b></td><td><b>${PosRepository.formatRupiah(supplierPurchases.sumOf { it.totalAmount })} (${supplierPurchases.size} faktur)</b></td></tr>
                    <tr><td><b>Total Pengeluaran Belanja:</b></td><td><b>${PosRepository.formatRupiah(totalAmount)}</b></td></tr>
                </table>

                <table class="data-table">
                    <thead>
                        <tr>
                            <th style="width: 25px;">No</th>
                            <th>Jenis</th>
                            <th>No. Faktur / Nota</th>
                            <th>Tanggal</th>
                            <th>Supplier / Toko Mitra</th>
                            <th>No. Telp</th>
                            <th>Pembayaran</th>
                            <th style="text-align: right;">Total Nilai (Rp)</th>
                            <th>Penerima</th>
                        </tr>
                    </thead>
                    <tbody>
            """.trimIndent())

            if (purchases.isEmpty()) {
                append("""<tr><td colspan="9" style="text-align: center; padding: 20px;">Belum ada riwayat pembelian supplier maupun belanja toko.</td></tr>""")
            } else {
                purchases.forEachIndexed { i, p ->
                    val isStore = p.purchaseType == "STORE_PURCHASE"
                    val jenis = if (isStore) "Belanja Toko" else "Supplier"
                    append("""
                        <tr>
                            <td style="text-align: center;">${i + 1}</td>
                            <td><span class="${if (isStore) "badge-green" else "badge-blue"}">$jenis</span></td>
                            <td><b>${p.invoiceNumber}</b></td>
                            <td>${dateFormat.format(Date(p.date))}</td>
                            <td><b>${p.supplierName}</b></td>
                            <td>${p.supplierPhone.ifBlank { "-" }}</td>
                            <td>${p.paymentType}</td>
                            <td style="text-align: right; font-weight: bold; color: ${if (isStore) "#15803D" else "#1D4ED8"};">${PosRepository.formatRupiah(p.totalAmount)}</td>
                            <td>${p.receivedBy}</td>
                        </tr>
                    """.trimIndent())
                }
            }

            append("""
                    </tbody>
                </table>
            """.trimIndent())
        }

        val html = wrapHtmlDoc("Dokumen Laporan Pembelian Supplier & Belanja Toko", storeInfo, body)
        FileOutputStream(file).use { it.write(html.toByteArray(Charsets.UTF_8)) }
        return file
    }

    /**
     * 4.5 Dokumen Buku Piutang & Kasbon
     */
    fun generateReceivableDoc(
        context: Context,
        storeInfo: LicenseInfo,
        receivables: List<ReceivableRecord>
    ): File {
        val fileName = "Buku_Piutang_${System.currentTimeMillis()}.doc"
        val file = File(context.cacheDir, fileName)
        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("id", "ID"))

        val totalRemaining = receivables.filter { it.status == "BELUM_LUNAS" }.sumOf { it.remainingAmount }
        val totalAll = receivables.sumOf { it.totalAmount }

        val body = buildString {
            append("""
                <table class="meta-table">
                    <tr><td style="width: 160px;"><b>Total Catatan Piutang:</b></td><td><b>${receivables.size} debitur</b></td></tr>
                    <tr><td><b>Total Nilai Piutang:</b></td><td><b>${PosRepository.formatRupiah(totalAll)}</b></td></tr>
                    <tr><td><b>Sisa Piutang Belum Lunas:</b></td><td><b style="color: #dc2626;">${PosRepository.formatRupiah(totalRemaining)}</b></td></tr>
                </table>

                <table class="data-table">
                    <thead>
                        <tr>
                            <th style="width: 25px;">No</th>
                            <th>No. Struk</th>
                            <th>Nama Pelanggan</th>
                            <th>No. Telp</th>
                            <th style="text-align: right;">Total Piutang</th>
                            <th style="text-align: right;">Sudah Dibayar</th>
                            <th style="text-align: right;">Sisa Piutang</th>
                            <th style="text-align: center;">Status</th>
                        </tr>
                    </thead>
                    <tbody>
            """.trimIndent())

            if (receivables.isEmpty()) {
                append("""<tr><td colspan="8" style="text-align: center; padding: 20px;">Tidak ada catatan piutang aktif.</td></tr>""")
            } else {
                receivables.forEachIndexed { i, r ->
                    val statusBadge = if (r.status == "LUNAS") {
                        "<span class=\"badge-success\">LUNAS</span>"
                    } else {
                        "<span class=\"badge-danger\">BELUM LUNAS</span>"
                    }
                    append("""
                        <tr>
                            <td style="text-align: center;">${i + 1}</td>
                            <td><b>${r.receiptNumber}</b></td>
                            <td><b>${r.customerName}</b></td>
                            <td>${r.customerPhone.ifBlank { "-" }}</td>
                            <td style="text-align: right;">${PosRepository.formatRupiah(r.totalAmount)}</td>
                            <td style="text-align: right;">${PosRepository.formatRupiah(r.paidAmount)}</td>
                            <td style="text-align: right; font-weight: bold; color: ${if (r.remainingAmount > 0) "#dc2626" else "#15803d"};">${PosRepository.formatRupiah(r.remainingAmount)}</td>
                            <td style="text-align: center;">$statusBadge</td>
                        </tr>
                    """.trimIndent())
                }
            }

            append("""
                    </tbody>
                </table>
            """.trimIndent())
        }

        val html = wrapHtmlDoc("Buku Laporan Piutang & Kasbon Pelanggan", storeInfo, body)
        FileOutputStream(file).use { it.write(html.toByteArray(Charsets.UTF_8)) }
        return file
    }

    /**
     * Export price tag labels as a printable HTML document (ready for A4 sticker sheet or shelf talkers).
     */
    fun exportPriceLabelsHtml(
        context: Context,
        items: List<Pair<com.example.data.model.Product, Int>>,
        storeInfo: LicenseInfo,
        labelType: String = "SHELF_TALKER"
    ): File {
        val fileName = "Label_Harga_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())}.html"
        val file = File(context.cacheDir, fileName)
        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale("id", "ID"))
        val dateStr = dateFormat.format(Date())

        val body = buildString {
            append("""
                <div class="no-print" style="margin-bottom: 20px; background: #e0f2fe; border: 1px solid #0284c7; padding: 12px 16px; border-radius: 8px; display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <strong style="color: #0369a1; font-size: 14px;">Lembar Siap Cetak Label Harga Rak</strong>
                        <div style="font-size: 12px; color: #334155;">Gunakan Ctrl+P / menu cetak peramban untuk mencetak ke printer kertas stiker atau A4.</div>
                    </div>
                    <button onclick="window.print()" style="background: #0284c7; color: white; border: none; padding: 8px 16px; border-radius: 6px; font-weight: bold; cursor: pointer;">Cetak Label</button>
                </div>

                <style>
                    .label-grid {
                        display: flex;
                        flex-wrap: wrap;
                        gap: 12px;
                        justify-content: flex-start;
                    }
                    /* Model 1: Standar Rak Minimarket */
                    .price-label-card {
                        width: 220px;
                        border: 2px solid #0f172a;
                        border-radius: 8px;
                        background: #ffffff;
                        overflow: hidden;
                        box-sizing: border-box;
                        page-break-inside: avoid;
                        margin-bottom: 8px;
                        font-family: Arial, sans-serif;
                    }
                    .label-header {
                        background: #0284c7;
                        color: #ffffff;
                        padding: 4px 8px;
                        font-size: 11px;
                        font-weight: bold;
                        text-transform: uppercase;
                        display: flex;
                        justify-content: space-between;
                        align-items: center;
                    }
                    .label-body {
                        padding: 8px 10px;
                    }
                    .product-title {
                        font-size: 13px;
                        font-weight: bold;
                        color: #0f172a;
                        line-height: 1.2;
                        min-height: 32px;
                        margin-bottom: 4px;
                    }
                    .product-meta {
                        font-size: 10px;
                        color: #64748b;
                        margin-bottom: 6px;
                    }
                    .price-box {
                        background: #f8fafc;
                        border: 1px dashed #cbd5e1;
                        border-radius: 6px;
                        padding: 6px;
                        text-align: center;
                        margin-bottom: 6px;
                    }
                    .price-val {
                        font-size: 20px;
                        font-weight: 900;
                        color: #dc2626;
                        letter-spacing: -0.5px;
                    }
                    .price-unit {
                        font-size: 10px;
                        color: #475569;
                        font-weight: bold;
                    }
                    .barcode-mock {
                        letter-spacing: 3px;
                        font-family: monospace;
                        font-weight: bold;
                        font-size: 11px;
                        text-align: center;
                        border-top: 1px solid #e2e8f0;
                        padding-top: 4px;
                        color: #1e293b;
                    }
                    .promo-badge {
                        background: #fef08a;
                        color: #854d0e;
                        font-size: 9px;
                        font-weight: bold;
                        padding: 2px 4px;
                        border-radius: 4px;
                        margin-bottom: 4px;
                        display: inline-block;
                    }
                    /* Model 2: Stiker Barcode Kompak */
                    .sticker-card {
                        width: 180px;
                        border: 1.5px solid #334155;
                        border-radius: 6px;
                        background: #ffffff;
                        padding: 8px;
                        box-sizing: border-box;
                        page-break-inside: avoid;
                        margin-bottom: 6px;
                        font-family: Arial, sans-serif;
                        text-align: center;
                    }
                    .sticker-title {
                        font-size: 11px;
                        font-weight: bold;
                        color: #0f172a;
                        white-space: nowrap;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        margin-bottom: 2px;
                    }
                    .sticker-price {
                        font-size: 16px;
                        font-weight: 900;
                        color: #0f172a;
                        margin: 3px 0;
                    }
                    .sticker-barcode {
                        font-family: monospace;
                        font-size: 14px;
                        letter-spacing: 2px;
                        font-weight: bold;
                        margin-top: 4px;
                        color: #000000;
                    }
                    .sticker-sku {
                        font-size: 9px;
                        color: #475569;
                    }
                    /* Model 3: Promo & Grosir */
                    .promo-card {
                        width: 230px;
                        border: 2px solid #dc2626;
                        border-radius: 8px;
                        background: #fff;
                        overflow: hidden;
                        box-sizing: border-box;
                        page-break-inside: avoid;
                        margin-bottom: 8px;
                        font-family: Arial, sans-serif;
                    }
                    .promo-header {
                        background: #dc2626;
                        color: #fff;
                        padding: 4px 8px;
                        font-size: 11px;
                        font-weight: bold;
                        display: flex;
                        justify-content: space-between;
                    }
                    /* Model 4: Minimalis Monokrom */
                    .minimal-card {
                        width: 200px;
                        border: 1px solid #94a3b8;
                        border-radius: 4px;
                        background: #fff;
                        padding: 10px;
                        box-sizing: border-box;
                        page-break-inside: avoid;
                        margin-bottom: 8px;
                        font-family: 'Segoe UI', Arial, sans-serif;
                    }
                    .minimal-title {
                        font-size: 12px;
                        font-weight: 600;
                        color: #1e293b;
                        margin-bottom: 4px;
                    }
                    .minimal-price {
                        font-size: 18px;
                        font-weight: 800;
                        color: #0f172a;
                    }
                    @media print {
                        .no-print { display: none !important; }
                        body { margin: 0; padding: 0; background: white; }
                        .label-grid { gap: 8px; }
                        .price-label-card, .promo-card, .sticker-card, .minimal-card { border: 1.5px solid black; }
                    }
                </style>

                <div class="label-grid">
            """.trimIndent())

            for ((product, copies) in items) {
                for (c in 1..copies) {
                    val repacks = product.getRepackUnits()
                    val tiers = product.getTieredPrices()
                    val promoInfo = when {
                        tiers.isNotEmpty() -> "Grosir: ≥${tiers.first().minQty} ${product.unit} (${PosRepository.formatRupiah(tiers.first().unitPrice)})"
                        repacks.isNotEmpty() -> "Repack: ${repacks.first().unitName} (${PosRepository.formatRupiah(repacks.first().sellPrice)})"
                        else -> null
                    }

                    when (labelType.uppercase()) {
                        "BARCODE_STICKER" -> {
                            append("""
                                <div class="sticker-card">
                                    <div class="sticker-title">${product.name}</div>
                                    <div class="sticker-price">${PosRepository.formatRupiah(product.sellPrice)} <span style="font-size: 9px; font-weight: normal;">/${product.unit.ifBlank { "PCS" }}</span></div>
                                    <div class="sticker-barcode">|||| ||| ||||| ||</div>
                                    <div class="sticker-sku">${product.sku.ifBlank { "PROD-${product.id}" }}</div>
                                </div>
                            """.trimIndent())
                        }
                        "PROMO_GROSIR" -> {
                            append("""
                                <div class="promo-card">
                                    <div class="promo-header">
                                        <span>★ SPESIAL PROMO / GROSIR ★</span>
                                        <span style="font-size: 9px;">$dateStr</span>
                                    </div>
                                    <div class="label-body">
                                        <div class="product-title">${product.name}</div>
                                        <div class="product-meta">SKU: ${product.sku.ifBlank { "-" }}</div>
                                        <div class="price-box" style="background: #fef2f2; border-color: #fca5a5;">
                                            <div class="price-val" style="color: #dc2626;">${PosRepository.formatRupiah(product.sellPrice)}</div>
                                            <div class="price-unit">HARGA SATUAN / ${product.unit.ifBlank { "PCS" }.uppercase()}</div>
                                        </div>
                                        ${if (promoInfo != null) "<div class=\"promo-badge\" style=\"background:#fee2e2; color:#991b1b;\">$promoInfo</div>" else ""}
                                        <div class="barcode-mock">||| |||| || ||||<br>${product.sku.ifBlank { "PROD-${product.id}" }}</div>
                                    </div>
                                </div>
                            """.trimIndent())
                        }
                        "MINIMALIS" -> {
                            append("""
                                <div class="minimal-card">
                                    <div style="font-size: 9px; color: #64748b; text-transform: uppercase;">${storeInfo.storeName.ifBlank { "POS PRO" }}</div>
                                    <div class="minimal-title">${product.name}</div>
                                    <div class="minimal-price">${PosRepository.formatRupiah(product.sellPrice)}</div>
                                    <div style="font-size: 9px; color: #94a3b8; margin-bottom: 6px;">Satuan: ${product.unit.ifBlank { "PCS" }}</div>
                                    <div style="font-family: monospace; font-size: 10px; color: #334155; border-top: 1px solid #e2e8f0; padding-top: 4px;">
                                        ||| |||| |||| || • ${product.sku.ifBlank { "PROD-${product.id}" }}
                                    </div>
                                </div>
                            """.trimIndent())
                        }
                        else -> { // Default SHELF_STANDAR
                            append("""
                                <div class="price-label-card">
                                    <div class="label-header">
                                        <span>${storeInfo.storeName.ifBlank { "MINIMARKET POS" }}</span>
                                        <span style="font-size: 9px;">$dateStr</span>
                                    </div>
                                    <div class="label-body">
                                        <div class="product-title">${product.name}</div>
                                        <div class="product-meta">SKU: ${product.sku.ifBlank { "-" }} | ${product.category}</div>
                                        
                                        ${if (promoInfo != null) "<div class=\"promo-badge\">$promoInfo</div>" else ""}
                                        
                                        <div class="price-box">
                                            <div class="price-val">${PosRepository.formatRupiah(product.sellPrice)}</div>
                                            <div class="price-unit">per ${product.unit.ifBlank { "PCS" }.uppercase()}</div>
                                        </div>
                                        <div class="barcode-mock">||| |||| || ||||<br>${product.sku.ifBlank { "PROD-${product.id}" }}</div>
                                    </div>
                                </div>
                            """.trimIndent())
                        }
                    }
                }
            }

            append("""
                </div>
            """.trimIndent())
        }

        val html = wrapHtmlDoc("Label Harga Produk", storeInfo, body)
        FileOutputStream(file).use { it.write(html.toByteArray(Charsets.UTF_8)) }
        return file
    }
}
