package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Environment
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONArray
import com.example.data.model.LicenseInfo
import com.example.data.model.Product
import com.example.data.model.ProductReturnRecord
import com.example.data.model.PurchaseRecord
import com.example.data.model.ReceivableRecord
import com.example.data.model.StockOpnameRecord
import com.example.data.model.TransactionRecord
import com.example.data.repository.PosRepository
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ProductSalesMetric(
    val product: Product,
    val totalSoldQty: Int,
    val totalRevenue: Long,
    val totalCost: Long,
    val totalProfit: Long
)

data class ComprehensiveReportData(
    val periodLabel: String,
    val startDate: Long,
    val endDate: Long,
    val storeInfo: LicenseInfo,
    val transactions: List<TransactionRecord>,
    val fastMoving: List<ProductSalesMetric>,
    val slowMoving: List<ProductSalesMetric>,
    val purchases: List<PurchaseRecord>,
    val returns: List<ProductReturnRecord>,
    val stockOpnames: List<StockOpnameRecord>,
    val voidTransactions: List<TransactionRecord>,
    val receivables: List<ReceivableRecord>
) {
    val successTransactions = transactions.filter { !it.isVoid }
    val totalOmset = successTransactions.sumOf { it.totalAmount }
    val totalHpp = successTransactions.sumOf { it.totalCost }
    val totalProfit = (totalOmset - totalHpp).coerceAtLeast(0L)
    val totalDiscounts = successTransactions.sumOf { it.discount }
    val totalTransactionsCount = successTransactions.size
    val averageBasket = if (totalTransactionsCount > 0) totalOmset / totalTransactionsCount else 0L

    val totalPurchasesAmount = purchases.sumOf { it.totalAmount }
    val totalReceivablesRemaining = receivables.sumOf { it.remainingAmount }
    val totalVoidCount = voidTransactions.size
    val totalVoidAmount = voidTransactions.sumOf { it.totalAmount }
}

object ReportExportHelper {

    // =========================================================================
    // 1. GENERATE WORD (.DOC) DOCUMENT
    // =========================================================================
    fun generateWordDocument(context: Context, data: ComprehensiveReportData): File {
        val fileName = "Laporan_POS_${data.storeInfo.storeName.replace(" ", "_")}_${System.currentTimeMillis()}.doc"
        val file = File(context.cacheDir, fileName)

        val htmlContent = buildWordHtml(data)
        FileOutputStream(file).use { out ->
            out.write(htmlContent.toByteArray(Charsets.UTF_8))
        }
        return file
    }

    private fun buildWordHtml(data: ComprehensiveReportData): String {
        val nowFormatted = SimpleDateFormat("dd MMMM yyyy, HH:mm", Locale("id", "ID")).format(Date())

        return buildString {
            append("""
                <html xmlns:o="urn:schemas-microsoft-com:office:office" 
                      xmlns:w="urn:schemas-microsoft-com:office:word" 
                      xmlns="http://www.w3.org/TR/REC-html40">
                <head>
                <meta charset="utf-8">
                <title>Laporan Keuangan & Operasional POS</title>
                <!--[if gte mso 9]>
                <xml>
                <w:WordDocument>
                <w:View>Print</w:View>
                <w:Zoom>100</w:Zoom>
                <w:DoNotOptimizeForBrowser/>
                </w:WordDocument>
                </xml>
                <![endif]-->
                <style>
                    body {
                        font-family: 'Segoe UI', Calibri, Arial, sans-serif;
                        font-size: 11pt;
                        color: #1E293B;
                        margin: 20px;
                        line-height: 1.4;
                    }
                    .header-box {
                        border-bottom: 2px solid #059669;
                        padding-bottom: 12px;
                        margin-bottom: 20px;
                    }
                    .store-title {
                        font-size: 20pt;
                        font-weight: bold;
                        color: #065F46;
                        margin: 0;
                    }
                    .store-subtitle {
                        font-size: 10pt;
                        color: #64748B;
                        margin: 2px 0;
                    }
                    .report-title {
                        font-size: 15pt;
                        font-weight: bold;
                        color: #0F172A;
                        margin-top: 14px;
                    }
                    .kpi-table {
                        width: 100%;
                        border-collapse: collapse;
                        margin-bottom: 24px;
                    }
                    .kpi-card {
                        border: 1px solid #CBD5E1;
                        background-color: #F8FAFC;
                        padding: 12px;
                        text-align: center;
                    }
                    .kpi-label {
                        font-size: 9.5pt;
                        color: #64748B;
                        text-transform: uppercase;
                    }
                    .kpi-value {
                        font-size: 15pt;
                        font-weight: bold;
                        color: #0F172A;
                        margin-top: 4px;
                    }
                    .kpi-profit {
                        color: #059669;
                    }
                    .section-title {
                        font-size: 13pt;
                        font-weight: bold;
                        color: #065F46;
                        border-left: 4px solid #059669;
                        padding-left: 8px;
                        margin-top: 24px;
                        margin-bottom: 8px;
                    }
                    .data-table {
                        width: 100%;
                        border-collapse: collapse;
                        margin-bottom: 18px;
                    }
                    .data-table th {
                        background-color: #065F46;
                        color: #FFFFFF;
                        font-weight: bold;
                        padding: 7px 10px;
                        font-size: 9.5pt;
                        text-align: left;
                        border: 1px solid #065F46;
                    }
                    .data-table td {
                        padding: 6px 10px;
                        font-size: 9.5pt;
                        border: 1px solid #E2E8F0;
                    }
                    .data-table tr:nth-child(even) {
                        background-color: #F8FAFC;
                    }
                    .badge-green {
                        background-color: #ECFDF5;
                        color: #065F46;
                        font-weight: bold;
                        padding: 2px 6px;
                        border-radius: 4px;
                        font-size: 8.5pt;
                    }
                    .badge-red {
                        background-color: #FEF2F2;
                        color: #DC2626;
                        font-weight: bold;
                        padding: 2px 6px;
                        border-radius: 4px;
                        font-size: 8.5pt;
                    }
                    .badge-amber {
                        background-color: #FFFBEB;
                        color: #D97706;
                        font-weight: bold;
                        padding: 2px 6px;
                        border-radius: 4px;
                        font-size: 8.5pt;
                    }
                    .signature-table {
                        width: 100%;
                        margin-top: 40px;
                        border: none;
                    }
                    .signature-table td {
                        border: none;
                        text-align: center;
                        width: 50%;
                    }
                </style>
                </head>
                <body>
                    <div class="header-box">
                        <div class="store-title">${data.storeInfo.storeName.uppercase()}</div>
                        <div class="store-subtitle">${data.storeInfo.storeAddress} • Telp: ${data.storeInfo.storePhone}</div>
                        <div class="report-title">LAPORAN KEUANGAN & OPERASIONAL LENGKAP</div>
                        <div class="store-subtitle">Periode: <b>${data.periodLabel}</b> | Dicetak: <b>$nowFormatted</b></div>
                    </div>

                    <!-- RINGKASAN FINANSIAL EKSEKUTIF -->
                    <table class="kpi-table">
                        <tr>
                            <td class="kpi-card" style="width: 25%;">
                                <div class="kpi-label">Total Omset Penjualan</div>
                                <div class="kpi-value">${PosRepository.formatRupiah(data.totalOmset)}</div>
                            </td>
                            <td class="kpi-card" style="width: 25%;">
                                <div class="kpi-label">Harga Pokok (HPP)</div>
                                <div class="kpi-value">${PosRepository.formatRupiah(data.totalHpp)}</div>
                            </td>
                            <td class="kpi-card" style="width: 25%;">
                                <div class="kpi-label">Estimasi Laba Bersih</div>
                                <div class="kpi-value kpi-profit">${PosRepository.formatRupiah(data.totalProfit)}</div>
                            </td>
                            <td class="kpi-card" style="width: 25%;">
                                <div class="kpi-label">Rata-Rata Keranjang</div>
                                <div class="kpi-value">${PosRepository.formatRupiah(data.averageBasket)}</div>
                            </td>
                        </tr>
                        <tr>
                            <td class="kpi-card">
                                <div class="kpi-label">Transaksi Berhasil</div>
                                <div class="kpi-value">${data.totalTransactionsCount} Struk</div>
                            </td>
                            <td class="kpi-card">
                                <div class="kpi-label">Total Kulakan (Beli)</div>
                                <div class="kpi-value">${PosRepository.formatRupiah(data.totalPurchasesAmount)}</div>
                            </td>
                            <td class="kpi-card">
                                <div class="kpi-label">Piutang Pelanggan</div>
                                <div class="kpi-value" style="color: #D97706;">${PosRepository.formatRupiah(data.totalReceivablesRemaining)}</div>
                            </td>
                            <td class="kpi-card">
                                <div class="kpi-label">Void / Batal Transaksi</div>
                                <div class="kpi-value" style="color: #DC2626;">${data.totalVoidCount} Kali (${PosRepository.formatRupiah(data.totalVoidAmount)})</div>
                            </td>
                        </tr>
                    </table>

                    <!-- SEKSI 1: BARANG CEPAT LAKU (FAST MOVING) -->
                    <div class="section-title">1. Daftar Barang Cepat Laku (Top Fast-Moving Products)</div>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th style="width: 40px; text-align: center;">No</th>
                                <th>Nama Produk</th>
                                <th>Kategori</th>
                                <th style="text-align: center;">Terjual</th>
                                <th style="text-align: right;">Total Omset</th>
                                <th style="text-align: right;">Est. Laba</th>
                                <th style="text-align: center;">Status</th>
                            </tr>
                        </thead>
                        <tbody>
            """.trimIndent())

            if (data.fastMoving.isEmpty()) {
                append("<tr><td colspan='7' style='text-align: center; color: #94A3B8;'>Belum ada data penjualan pada periode ini.</td></tr>")
            } else {
                data.fastMoving.forEachIndexed { index, item ->
                    append("""
                        <tr>
                            <td style="text-align: center;"><b>#${index + 1}</b></td>
                            <td><b>${item.product.name}</b> <span style="font-size: 8.5pt; color: #64748B;">(${item.product.sku})</span></td>
                            <td>${item.product.category}</td>
                            <td style="text-align: center; font-weight: bold; color: #065F46;">${item.totalSoldQty} ${item.product.unit}</td>
                            <td style="text-align: right; font-weight: bold;">${PosRepository.formatRupiah(item.totalRevenue)}</td>
                            <td style="text-align: right; color: #059669; font-weight: bold;">${PosRepository.formatRupiah(item.totalProfit)}</td>
                            <td style="text-align: center;"><span class="badge-green">FAST MOVING</span></td>
                        </tr>
                    """.trimIndent())
                }
            }

            append("""
                        </tbody>
                    </table>

                    <!-- SEKSI 2: BARANG KURANG LAKU (SLOW MOVING) -->
                    <div class="section-title">2. Daftar Barang Kurang Laku (Slow Moving & Dead Stock)</div>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th style="width: 40px; text-align: center;">No</th>
                                <th>Nama Produk</th>
                                <th>Kategori</th>
                                <th style="text-align: center;">Terjual</th>
                                <th style="text-align: center;">Sisa Stok Fisik</th>
                                <th style="text-align: right;">Nilai Aset Terparkir</th>
                                <th style="text-align: center;">Status Analisis</th>
                            </tr>
                        </thead>
                        <tbody>
            """.trimIndent())

            if (data.slowMoving.isEmpty()) {
                append("<tr><td colspan='7' style='text-align: center; color: #94A3B8;'>Semua produk bergerak baik atau data belum tersedia.</td></tr>")
            } else {
                data.slowMoving.forEachIndexed { index, item ->
                    val assetValue = item.product.stock * item.product.costPrice
                    append("""
                        <tr>
                            <td style="text-align: center;">${index + 1}</td>
                            <td><b>${item.product.name}</b></td>
                            <td>${item.product.category}</td>
                            <td style="text-align: center;">${item.totalSoldQty} ${item.product.unit}</td>
                            <td style="text-align: center; font-weight: bold; color: #D97706;">${item.product.stock} ${item.product.unit}</td>
                            <td style="text-align: right;">${PosRepository.formatRupiah(assetValue)}</td>
                            <td style="text-align: center;"><span class="badge-amber">SLOW MOVING</span></td>
                        </tr>
                    """.trimIndent())
                }
            }

            append("""
                        </tbody>
                    </table>

                    <!-- SEKSI 3: LAPORAN PEMBELIAN SUPPLIER (KULAKAN) -->
                    <div class="section-title">3. Laporan Pembelian Barang dari Supplier (Kulakan)</div>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th style="width: 40px; text-align: center;">No</th>
                                <th>Tanggal</th>
                                <th>No. Faktur</th>
                                <th>Nama Supplier</th>
                                <th>Tipe Bayar</th>
                                <th style="text-align: right;">Total Belanja</th>
                                <th>Diterima Oleh</th>
                            </tr>
                        </thead>
                        <tbody>
            """.trimIndent())

            if (data.purchases.isEmpty()) {
                append("<tr><td colspan='7' style='text-align: center; color: #94A3B8;'>Belum ada catatan pembelian barang supplier pada periode ini.</td></tr>")
            } else {
                data.purchases.forEachIndexed { idx, p ->
                    val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("id", "ID")).format(Date(p.date))
                    append("""
                        <tr>
                            <td style="text-align: center;">${idx + 1}</td>
                            <td>$dateStr</td>
                            <td><b>${p.invoiceNumber}</b></td>
                            <td>${p.supplierName}</td>
                            <td><span class="${if (p.paymentType == "TUNAI") "badge-green" else "badge-amber"}">${p.paymentType}</span></td>
                            <td style="text-align: right; font-weight: bold;">${PosRepository.formatRupiah(p.totalAmount)}</td>
                            <td>${p.receivedBy}</td>
                        </tr>
                    """.trimIndent())
                }
            }

            append("""
                        </tbody>
                    </table>

                    <!-- SEKSI 4: LAPORAN RETUR BARANG -->
                    <div class="section-title">4. Laporan Retur Barang (Pelanggan / Supplier / Cacat)</div>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th style="width: 40px; text-align: center;">No</th>
                                <th>Waktu</th>
                                <th>Nama Barang</th>
                                <th style="text-align: center;">Qty</th>
                                <th>Tipe Retur</th>
                                <th>Alasan</th>
                                <th>Pelanggan / Pihak</th>
                            </tr>
                        </thead>
                        <tbody>
            """.trimIndent())

            if (data.returns.isEmpty()) {
                append("<tr><td colspan='7' style='text-align: center; color: #94A3B8;'>Tidak ada pencatatan retur barang.</td></tr>")
            } else {
                data.returns.forEachIndexed { idx, r ->
                    val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("id", "ID")).format(Date(r.timestamp))
                    val typeBadge = if (r.returnType == "MASUK_STOK") {
                        "<span class='badge-green'>+ Stok Pelanggan</span>"
                    } else {
                        "<span class='badge-red'>- Stok Rusak</span>"
                    }
                    append("""
                        <tr>
                            <td style="text-align: center;">${idx + 1}</td>
                            <td>$dateStr</td>
                            <td><b>${r.productName}</b></td>
                            <td style="text-align: center; font-weight: bold;">${r.qty}</td>
                            <td>$typeBadge</td>
                            <td>${r.reason}</td>
                            <td>${r.customerOrSupplier.ifBlank { "-" }}</td>
                        </tr>
                    """.trimIndent())
                }
            }

            append("""
                        </tbody>
                    </table>

                    <!-- SEKSI 5: LAPORAN STOK OPNAME -->
                    <div class="section-title">5. Laporan Stok Opname (Audit Fisik vs Sistem)</div>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th style="width: 40px; text-align: center;">No</th>
                                <th>Tanggal</th>
                                <th>Produk</th>
                                <th style="text-align: center;">Stok Sistem</th>
                                <th style="text-align: center;">Stok Fisik</th>
                                <th style="text-align: center;">Selisih</th>
                                <th>Alasan & Pemeriksa</th>
                            </tr>
                        </thead>
                        <tbody>
            """.trimIndent())

            if (data.stockOpnames.isEmpty()) {
                append("<tr><td colspan='7' style='text-align: center; color: #94A3B8;'>Belum ada riwayat pelaksanaan stok opname.</td></tr>")
            } else {
                data.stockOpnames.forEachIndexed { idx, so ->
                    val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("id", "ID")).format(Date(so.date))
                    val diffStr = if (so.difference >= 0) "+${so.difference}" else "${so.difference}"
                    val diffBadge = when {
                        so.difference == 0 -> "<span class='badge-green'>Sesuai (0)</span>"
                        so.difference < 0 -> "<span class='badge-red'>$diffStr Kurang</span>"
                        else -> "<span class='badge-amber'>$diffStr Lebih</span>"
                    }
                    append("""
                        <tr>
                            <td style="text-align: center;">${idx + 1}</td>
                            <td>$dateStr</td>
                            <td><b>${so.productName}</b> <span style="font-size: 8.5pt; color: #64748B;">(${so.sku})</span></td>
                            <td style="text-align: center;">${so.systemStock}</td>
                            <td style="text-align: center; font-weight: bold;">${so.physicalStock}</td>
                            <td style="text-align: center;">$diffBadge</td>
                            <td>${so.reason} (${so.conductedBy})</td>
                        </tr>
                    """.trimIndent())
                }
            }

            append("""
                        </tbody>
                    </table>

                    <!-- SEKSI 6: LAPORAN TRANSAKSI DIBATALKAN (VOID) -->
                    <div class="section-title">6. Laporan Transaksi Dibatalkan (VOID)</div>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th style="width: 40px; text-align: center;">No</th>
                                <th>Waktu Void</th>
                                <th>No. Struk</th>
                                <th>Kasir</th>
                                <th>Alasan Pembatalan</th>
                                <th>Supervisor Otorisasi</th>
                                <th style="text-align: right;">Nilai Dibatalkan</th>
                            </tr>
                        </thead>
                        <tbody>
            """.trimIndent())

            if (data.voidTransactions.isEmpty()) {
                append("<tr><td colspan='7' style='text-align: center; color: #94A3B8;'>Tidak ada transaksi yang dibatalkan (VOID) pada periode ini.</td></tr>")
            } else {
                data.voidTransactions.forEachIndexed { idx, v ->
                    val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("id", "ID")).format(Date(if (v.voidTimestamp > 0) v.voidTimestamp else v.timestamp))
                    append("""
                        <tr>
                            <td style="text-align: center;">${idx + 1}</td>
                            <td>$dateStr</td>
                            <td><b>${v.receiptNumber}</b></td>
                            <td>${v.cashierName}</td>
                            <td><span class="badge-red">${v.voidReason.ifBlank { "Kesalahan Input" }}</span></td>
                            <td>${v.voidBy.ifBlank { "Supervisor" }}</td>
                            <td style="text-align: right; font-weight: bold; color: #DC2626;">${PosRepository.formatRupiah(v.totalAmount)}</td>
                        </tr>
                    """.trimIndent())
                }
            }

            append("""
                        </tbody>
                    </table>

                    <!-- SEKSI 7: LAPORAN BUKU PIUTANG PELANGGAN -->
                    <div class="section-title">7. Laporan Piutang & Kasbon Pelanggan</div>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th style="width: 40px; text-align: center;">No</th>
                                <th>No. Bon</th>
                                <th>Nama Pelanggan</th>
                                <th>No. Telp</th>
                                <th style="text-align: right;">Total Bon</th>
                                <th style="text-align: right;">Sisa Piutang</th>
                                <th style="text-align: center;">Status</th>
                            </tr>
                        </thead>
                        <tbody>
            """.trimIndent())

            if (data.receivables.isEmpty()) {
                append("<tr><td colspan='7' style='text-align: center; color: #94A3B8;'>Tidak ada catatan piutang aktif.</td></tr>")
            } else {
                data.receivables.forEachIndexed { idx, r ->
                    val statusBadge = if (r.status == "LUNAS") {
                        "<span class='badge-green'>LUNAS</span>"
                    } else {
                        "<span class='badge-amber'>BELUM LUNAS</span>"
                    }
                    append("""
                        <tr>
                            <td style="text-align: center;">${idx + 1}</td>
                            <td><b>${r.receiptNumber}</b></td>
                            <td><b>${r.customerName}</b></td>
                            <td>${r.customerPhone.ifBlank { "-" }}</td>
                            <td style="text-align: right;">${PosRepository.formatRupiah(r.totalAmount)}</td>
                            <td style="text-align: right; font-weight: bold; color: ${if (r.remainingAmount > 0) "#DC2626" else "#059669"};">${PosRepository.formatRupiah(r.remainingAmount)}</td>
                            <td style="text-align: center;">$statusBadge</td>
                        </tr>
                    """.trimIndent())
                }
            }

            append("""
                        </tbody>
                    </table>

                    <!-- TANDA TANGAN -->
                    <table class="signature-table">
                        <tr>
                            <td>
                                Dilaporkan oleh,<br><br><br><br>
                                <b>( Kasir / Admin Toko )</b>
                            </td>
                            <td>
                                Mengetahui & Menyetujui,<br><br><br><br>
                                <b>( Pemilik / Supervisor Toko )</b>
                            </td>
                        </tr>
                    </table>
                </body>
                </html>
            """.trimIndent())
        }
    }

    // =========================================================================
    // 2. GENERATE PDF DOCUMENT NATIVELY
    // =========================================================================
    fun generatePdfDocument(context: Context, data: ComprehensiveReportData): File {
        val fileName = "Laporan_POS_${data.storeInfo.storeName.replace(" ", "_")}_${System.currentTimeMillis()}.pdf"
        val file = File(context.cacheDir, fileName)

        val pdfDocument = PdfDocument()
        val pageWidth = 595 // Standard A4 width in points
        val pageHeight = 842 // Standard A4 height in points
        var pageNumber = 1

        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        val nowFormatted = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("id", "ID")).format(Date())

        var currentPage = pdfDocument.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
        var canvas: Canvas = currentPage.canvas
        var currentY = 40f

        fun drawHeaderAndFooter(c: Canvas, pNum: Int) {
            // Header Top Bar
            paint.color = Color.parseColor("#065F46")
            paint.style = Paint.Style.FILL
            c.drawRect(30f, 25f, pageWidth - 30f, 28f, paint)

            // Footer Bottom
            paint.color = Color.parseColor("#CBD5E1")
            c.drawRect(30f, pageHeight - 35f, pageWidth - 30f, pageHeight - 34f, paint)
            textPaint.textSize = 8.5f
            textPaint.color = Color.parseColor("#64748B")
            textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            c.drawText("${data.storeInfo.storeName} • Laporan POS • Dicetak $nowFormatted", 30f, pageHeight - 22f, textPaint)
            c.drawText("Halaman $pNum", pageWidth - 75f, pageHeight - 22f, textPaint)
        }

        fun checkPageBreak(requiredHeight: Float) {
            if (currentY + requiredHeight > pageHeight - 45f) {
                drawHeaderAndFooter(canvas, pageNumber)
                pdfDocument.finishPage(currentPage)
                pageNumber++
                currentPage = pdfDocument.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
                canvas = currentPage.canvas
                currentY = 45f
            }
        }

        // --- FIRST PAGE HEADER ---
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.textSize = 17f
        textPaint.color = Color.parseColor("#065F46")
        canvas.drawText(data.storeInfo.storeName.uppercase(), 30f, currentY + 14f, textPaint)
        currentY += 20f

        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        textPaint.textSize = 9.5f
        textPaint.color = Color.parseColor("#64748B")
        canvas.drawText("${data.storeInfo.storeAddress} | Telp: ${data.storeInfo.storePhone}", 30f, currentY + 10f, textPaint)
        currentY += 16f

        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.textSize = 12.5f
        textPaint.color = Color.parseColor("#0F172A")
        canvas.drawText("LAPORAN KEUANGAN & OPERASIONAL LENGKAP", 30f, currentY + 12f, textPaint)
        currentY += 15f

        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        textPaint.textSize = 9.5f
        textPaint.color = Color.parseColor("#475569")
        canvas.drawText("Periode: ${data.periodLabel}   |   Dicetak: $nowFormatted", 30f, currentY + 10f, textPaint)
        currentY += 20f

        // Green Divider
        paint.color = Color.parseColor("#059669")
        paint.style = Paint.Style.FILL
        canvas.drawRect(30f, currentY, pageWidth - 30f, currentY + 2f, paint)
        currentY += 14f

        // --- KPI SUMMARY CARDS (2 Rows x 4 Columns) ---
        val cardWidth = (pageWidth - 60f - 24f) / 4f
        val cardHeight = 44f

        fun drawKpiCard(x: Float, y: Float, label: String, value: String, isAccent: Boolean = false) {
            paint.color = if (isAccent) Color.parseColor("#ECFDF5") else Color.parseColor("#F8FAFC")
            paint.style = Paint.Style.FILL
            val rect = RectF(x, y, x + cardWidth, y + cardHeight)
            canvas.drawRoundRect(rect, 4f, 4f, paint)

            paint.color = if (isAccent) Color.parseColor("#A7F3D0") else Color.parseColor("#E2E8F0")
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1f
            canvas.drawRoundRect(rect, 4f, 4f, paint)

            textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textPaint.textSize = 7.5f
            textPaint.color = Color.parseColor("#64748B")
            canvas.drawText(label, x + 8f, y + 14f, textPaint)

            textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textPaint.textSize = 10f
            textPaint.color = if (isAccent) Color.parseColor("#065F46") else Color.parseColor("#0F172A")
            canvas.drawText(value, x + 8f, y + 32f, textPaint)
        }

        // Row 1
        drawKpiCard(30f, currentY, "TOTAL OMSET", PosRepository.formatRupiah(data.totalOmset))
        drawKpiCard(30f + (cardWidth + 8f), currentY, "TOTAL HPP", PosRepository.formatRupiah(data.totalHpp))
        drawKpiCard(30f + (cardWidth + 8f) * 2, currentY, "EST. LABA BERSIH", PosRepository.formatRupiah(data.totalProfit), isAccent = true)
        drawKpiCard(30f + (cardWidth + 8f) * 3, currentY, "RATA2 KERANJANG", PosRepository.formatRupiah(data.averageBasket))
        currentY += cardHeight + 8f

        // Row 2
        drawKpiCard(30f, currentY, "TOTAL TRANSAKSI", "${data.totalTransactionsCount} Struk")
        drawKpiCard(30f + (cardWidth + 8f), currentY, "KULAKAN SUPPLIER", PosRepository.formatRupiah(data.totalPurchasesAmount))
        drawKpiCard(30f + (cardWidth + 8f) * 2, currentY, "PIUTANG PELANGGAN", PosRepository.formatRupiah(data.totalReceivablesRemaining))
        drawKpiCard(30f + (cardWidth + 8f) * 3, currentY, "VOID / BATAL", "${data.totalVoidCount}x (${PosRepository.formatRupiah(data.totalVoidAmount)})")
        currentY += cardHeight + 18f

        // Helper to draw section header
        fun drawSectionHeader(title: String) {
            checkPageBreak(30f)
            paint.color = Color.parseColor("#059669")
            paint.style = Paint.Style.FILL
            canvas.drawRect(30f, currentY, 34f, currentY + 14f, paint)

            textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textPaint.textSize = 11f
            textPaint.color = Color.parseColor("#065F46")
            canvas.drawText(title, 40f, currentY + 11f, textPaint)
            currentY += 20f
        }

        // Helper to draw table header
        fun drawTableHeader(colTitles: List<String>, colWidths: List<Float>) {
            checkPageBreak(22f)
            paint.color = Color.parseColor("#065F46")
            paint.style = Paint.Style.FILL
            canvas.drawRect(30f, currentY, pageWidth - 30f, currentY + 18f, paint)

            textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textPaint.textSize = 8.5f
            textPaint.color = Color.WHITE

            var curX = 36f
            colTitles.forEachIndexed { i, title ->
                canvas.drawText(title, curX, currentY + 12f, textPaint)
                curX += colWidths[i]
            }
            currentY += 18f
        }

        // Helper to draw table row
        fun drawTableRow(values: List<String>, colWidths: List<Float>, isEven: Boolean) {
            checkPageBreak(18f)
            if (isEven) {
                paint.color = Color.parseColor("#F8FAFC")
                paint.style = Paint.Style.FILL
                canvas.drawRect(30f, currentY, pageWidth - 30f, currentY + 16f, paint)
            }
            // Bottom border
            paint.color = Color.parseColor("#F1F5F9")
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 0.5f
            canvas.drawLine(30f, currentY + 16f, pageWidth - 30f, currentY + 16f, paint)

            textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textPaint.textSize = 8.5f
            textPaint.color = Color.parseColor("#1E293B")

            var curX = 36f
            values.forEachIndexed { i, v ->
                // Truncate if too long
                val maxChars = (colWidths[i] / 5.2f).toInt()
                val displayStr = if (v.length > maxChars && maxChars > 3) v.take(maxChars - 2) + ".." else v
                canvas.drawText(displayStr, curX, currentY + 11f, textPaint)
                curX += colWidths[i]
            }
            currentY += 16f
        }

        // --- 1. FAST MOVING ---
        drawSectionHeader("1. Barang Cepat Laku (Top Fast Moving Products)")
        val fastCols = listOf("No", "Nama Produk", "Kategori", "Qty", "Omset", "Laba")
        val fastWidths = listOf(30f, 175f, 95f, 60f, 90f, 85f)
        drawTableHeader(fastCols, fastWidths)
        if (data.fastMoving.isEmpty()) {
            drawTableRow(listOf("-", "Belum ada penjualan", "-", "-", "-", "-"), fastWidths, false)
        } else {
            data.fastMoving.take(10).forEachIndexed { i, it ->
                drawTableRow(
                    listOf(
                        "#${i + 1}",
                        it.product.name,
                        it.product.category,
                        "${it.totalSoldQty} ${it.product.unit}",
                        PosRepository.formatRupiah(it.totalRevenue),
                        PosRepository.formatRupiah(it.totalProfit)
                    ),
                    fastWidths,
                    i % 2 == 1
                )
            }
        }
        currentY += 12f

        // --- 2. SLOW MOVING ---
        drawSectionHeader("2. Barang Kurang Laku (Slow Moving / Stok Mengendap)")
        val slowCols = listOf("No", "Nama Produk", "Kategori", "Terjual", "Sisa Stok", "Aset Terparkir")
        val slowWidths = listOf(30f, 175f, 95f, 60f, 75f, 100f)
        drawTableHeader(slowCols, slowWidths)
        if (data.slowMoving.isEmpty()) {
            drawTableRow(listOf("-", "Semua produk bergerak baik", "-", "-", "-", "-"), slowWidths, false)
        } else {
            data.slowMoving.take(10).forEachIndexed { i, it ->
                val asset = it.product.stock * it.product.costPrice
                drawTableRow(
                    listOf(
                        "${i + 1}",
                        it.product.name,
                        it.product.category,
                        "${it.totalSoldQty} ${it.product.unit}",
                        "${it.product.stock} ${it.product.unit}",
                        PosRepository.formatRupiah(asset)
                    ),
                    slowWidths,
                    i % 2 == 1
                )
            }
        }
        currentY += 12f

        // --- 3. PEMBELIAN SUPPLIER ---
        drawSectionHeader("3. Laporan Pembelian Supplier (Kulakan)")
        val buyCols = listOf("No", "No. Faktur", "Supplier", "Metode", "Total", "Penerima")
        val buyWidths = listOf(30f, 110f, 140f, 75f, 95f, 85f)
        drawTableHeader(buyCols, buyWidths)
        if (data.purchases.isEmpty()) {
            drawTableRow(listOf("-", "Tidak ada pembelian", "-", "-", "-", "-"), buyWidths, false)
        } else {
            data.purchases.take(10).forEachIndexed { i, p ->
                drawTableRow(
                    listOf(
                        "${i + 1}",
                        p.invoiceNumber,
                        p.supplierName,
                        p.paymentType,
                        PosRepository.formatRupiah(p.totalAmount),
                        p.receivedBy
                    ),
                    buyWidths,
                    i % 2 == 1
                )
            }
        }
        currentY += 12f

        // --- 4. RETUR BARANG ---
        drawSectionHeader("4. Laporan Retur Barang")
        val retCols = listOf("No", "Nama Produk", "Qty", "Jenis Retur", "Alasan", "Pihak")
        val retWidths = listOf(30f, 150f, 45f, 95f, 120f, 95f)
        drawTableHeader(retCols, retWidths)
        if (data.returns.isEmpty()) {
            drawTableRow(listOf("-", "Tidak ada retur barang", "-", "-", "-", "-"), retWidths, false)
        } else {
            data.returns.take(10).forEachIndexed { i, r ->
                val type = if (r.returnType == "MASUK_STOK") "+Stok Pelanggan" else "-Stok Rusak"
                drawTableRow(
                    listOf(
                        "${i + 1}",
                        r.productName,
                        "${r.qty}",
                        type,
                        r.reason,
                        r.customerOrSupplier.ifBlank { "-" }
                    ),
                    retWidths,
                    i % 2 == 1
                )
            }
        }
        currentY += 12f

        // --- 5. STOK OPNAME ---
        drawSectionHeader("5. Laporan Stok Opname")
        val soCols = listOf("No", "Nama Produk", "Sistem", "Fisik", "Selisih", "Pemeriksa")
        val soWidths = listOf(30f, 175f, 60f, 60f, 80f, 130f)
        drawTableHeader(soCols, soWidths)
        if (data.stockOpnames.isEmpty()) {
            drawTableRow(listOf("-", "Belum ada stok opname", "-", "-", "-", "-"), soWidths, false)
        } else {
            data.stockOpnames.take(10).forEachIndexed { i, so ->
                val diffStr = if (so.difference >= 0) "+${so.difference}" else "${so.difference}"
                drawTableRow(
                    listOf(
                        "${i + 1}",
                        so.productName,
                        "${so.systemStock}",
                        "${so.physicalStock}",
                        diffStr,
                        "${so.conductedBy} (${so.reason})"
                    ),
                    soWidths,
                    i % 2 == 1
                )
            }
        }
        currentY += 12f

        // --- 6. VOID TRANSAKSI ---
        drawSectionHeader("6. Laporan Transaksi Dibatalkan (VOID)")
        val voidCols = listOf("No", "No. Struk", "Kasir", "Alasan", "Otorisasi", "Nilai")
        val voidWidths = listOf(30f, 110f, 85f, 140f, 85f, 85f)
        drawTableHeader(voidCols, voidWidths)
        if (data.voidTransactions.isEmpty()) {
            drawTableRow(listOf("-", "Tidak ada transaksi VOID", "-", "-", "-", "-"), voidWidths, false)
        } else {
            data.voidTransactions.take(10).forEachIndexed { i, v ->
                drawTableRow(
                    listOf(
                        "${i + 1}",
                        v.receiptNumber,
                        v.cashierName,
                        v.voidReason.ifBlank { "Salah Input" },
                        v.voidBy.ifBlank { "Supervisor" },
                        PosRepository.formatRupiah(v.totalAmount)
                    ),
                    voidWidths,
                    i % 2 == 1
                )
            }
        }
        currentY += 12f

        // --- 7. PIUTANG PELANGGAN ---
        drawSectionHeader("7. Laporan Piutang Pelanggan")
        val piuCols = listOf("No", "No. Bon", "Pelanggan", "Total Bon", "Sisa Piutang", "Status")
        val piuWidths = listOf(30f, 100f, 135f, 95f, 95f, 80f)
        drawTableHeader(piuCols, piuWidths)
        if (data.receivables.isEmpty()) {
            drawTableRow(listOf("-", "Tidak ada piutang aktif", "-", "-", "-", "-"), piuWidths, false)
        } else {
            data.receivables.take(10).forEachIndexed { i, r ->
                drawTableRow(
                    listOf(
                        "${i + 1}",
                        r.receiptNumber,
                        r.customerName,
                        PosRepository.formatRupiah(r.totalAmount),
                        PosRepository.formatRupiah(r.remainingAmount),
                        if (r.status == "LUNAS") "LUNAS" else "BELUM LUNAS"
                    ),
                    piuWidths,
                    i % 2 == 1
                )
            }
        }
        currentY += 30f

        // --- SIGNATURE SECTION ---
        checkPageBreak(50f)
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        textPaint.textSize = 9.5f
        textPaint.color = Color.parseColor("#475569")
        canvas.drawText("Petugas Kasir / Admin,", 60f, currentY, textPaint)
        canvas.drawText("Pemilik / Supervisor Toko,", pageWidth - 190f, currentY, textPaint)

        currentY += 40f
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.color = Color.parseColor("#0F172A")
        canvas.drawText("( ................................... )", 50f, currentY, textPaint)
        canvas.drawText("( ................................... )", pageWidth - 200f, currentY, textPaint)

        // Finish last page
        drawHeaderAndFooter(canvas, pageNumber)
        pdfDocument.finishPage(currentPage)

        // Write to file
        FileOutputStream(file).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()
        return file
    }

    // =========================================================================
    // 3. INTENT HELPERS: SHARE, OPEN & DOWNLOAD
    // =========================================================================
    fun shareDocument(context: Context, file: File, mimeType: String, subject: String) {
        try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, "Berikut terlampir $subject.")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Bagikan Dokumen Laporan"))
        } catch (e: Exception) {
            Toast.makeText(context, "Gagal membagikan dokumen: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    fun openDocument(context: Context, file: File, mimeType: String) {
        try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            // Fallback to share chooser if no default app installed
            shareDocument(context, file, mimeType, "Laporan Toko")
        }
    }

    fun saveToDownloads(context: Context, sourceFile: File, displayName: String): File? {
        return try {
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (!downloadsDir.exists()) downloadsDir.mkdirs()
            val destFile = File(downloadsDir, displayName)
            sourceFile.copyTo(destFile, overwrite = true)
            Toast.makeText(context, "Dokumen tersimpan di folder Download: ${destFile.name}", Toast.LENGTH_LONG).show()
            destFile
        } catch (e: Exception) {
            Toast.makeText(context, "Dokumen disimpan di cache: ${sourceFile.name}", Toast.LENGTH_SHORT).show()
            sourceFile
        }
    }

    // =========================================================================
    // 4. DOKUMEN KHUSUS: STOK OPNAME (SELISIH & BERITA ACARA), RETUR, PEMBELIAN, PIUTANG
    // =========================================================================

    private fun wrapHtmlDoc(title: String, storeInfo: LicenseInfo, bodyContent: String): String {
        val nowFormatted = SimpleDateFormat("dd MMMM yyyy, HH:mm", Locale("id", "ID")).format(Date())
        return """
            <html xmlns:o="urn:schemas-microsoft-com:office:office" 
                  xmlns:w="urn:schemas-microsoft-com:office:word" 
                  xmlns="http://www.w3.org/TR/REC-html40">
            <head>
            <meta charset="utf-8">
            <title>$title</title>
            <style>
                body { font-family: 'Segoe UI', Calibri, Arial, sans-serif; font-size: 11pt; color: #1e293b; margin: 30px; line-height: 1.5; }
                h1 { font-size: 18pt; color: #0f172a; margin: 0 0 4px 0; }
                h2 { font-size: 13pt; color: #0284c7; margin: 18px 0 6px 0; border-bottom: 2px solid #0284c7; padding-bottom: 4px; }
                .store-header { border-bottom: 2px solid #0f172a; padding-bottom: 12px; margin-bottom: 20px; }
                .meta-table { width: 100%; margin-bottom: 16px; border: none; }
                .meta-table td { padding: 3px 0; border: none; font-size: 10pt; }
                table.data-table { width: 100%; border-collapse: collapse; margin-top: 10px; margin-bottom: 20px; }
                table.data-table th { background-color: #0f172a; color: #ffffff; padding: 8px 10px; font-size: 9.5pt; text-align: left; border: 1px solid #0f172a; }
                table.data-table td { padding: 7px 10px; border: 1px solid #cbd5e1; font-size: 9.5pt; }
                table.data-table tr:nth-child(even) { background-color: #f8fafc; }
                .badge-danger { background-color: #fee2e2; color: #b91c1c; font-weight: bold; padding: 2px 6px; border-radius: 4px; font-size: 8.5pt; }
                .badge-success { background-color: #dcfce7; color: #15803d; font-weight: bold; padding: 2px 6px; border-radius: 4px; font-size: 8.5pt; }
                .badge-warning { background-color: #fef3c7; color: #b45309; font-weight: bold; padding: 2px 6px; border-radius: 4px; font-size: 8.5pt; }
                .signature-table { width: 100%; margin-top: 40px; border: none; }
                .signature-table td { width: 50%; text-align: center; vertical-align: top; border: none; font-size: 10pt; }
            </style>
            </head>
            <body>
                <div class="store-header">
                    <h1>${storeInfo.storeName}</h1>
                    <div style="font-size: 9.5pt; color: #64748b;">${storeInfo.storeAddress} | Telp: ${storeInfo.storePhone}</div>
                </div>
                <h2>$title</h2>
                <div style="font-size: 9pt; color: #64748b; margin-bottom: 14px;">Dicetak pada: $nowFormatted</div>
                $bodyContent
                <table class="signature-table">
                    <tr>
                        <td>
                            Petugas Pelaksana / Admin,<br><br><br><br><br>
                            <b>( ............................................ )</b>
                        </td>
                        <td>
                            Mengetahui & Menyetujui,<br>
                            Supervisor / Pemilik Toko<br><br><br><br>
                            <b>( ............................................ )</b>
                        </td>
                    </tr>
                </table>
            </body>
            </html>
        """.trimIndent()
    }

    /**
     * 4.1 Dokumen Cetak Selisih Stok Opname (Untuk cek ulang barang tidak sesuai)
     */
    fun generateStockOpnameDiscrepancyDoc(
        context: Context,
        storeInfo: LicenseInfo,
        taskCode: String,
        taskTitle: String,
        conductedBy: String,
        discrepancyItems: List<StockOpnameRecord>
    ): File {
        val fileName = "Selisih_SO_${taskCode}_${System.currentTimeMillis()}.doc"
        val file = File(context.cacheDir, fileName)

        val totalDiscrepancyQty = discrepancyItems.sumOf { Math.abs(it.difference) }
        val body = buildString {
            append("""
                <table class="meta-table">
                    <tr><td style="width: 140px;"><b>No. Tugas SO:</b></td><td>$taskCode</td></tr>
                    <tr><td><b>Judul Tugas:</b></td><td>$taskTitle</td></tr>
                    <tr><td><b>Petugas:</b></td><td>$conductedBy</td></tr>
                    <tr><td><b>Total SKU Selisih:</b></td><td><b>${discrepancyItems.size} produk</b> (Hanya produk yang memiliki selisih fisik vs sistem)</td></tr>
                    <tr><td><b>Total Unit Selisih:</b></td><td><b>$totalDiscrepancyQty unit</b></td></tr>
                </table>
                <p style="background-color: #fffbeb; border-left: 4px solid #f59e0b; padding: 8px 12px; font-size: 9.5pt; color: #92400e;">
                    <b>Catatan Pemeriksaan Ulang:</b> Dokumen ini memuat daftar produk yang belum cocok antara stok komputer dan hitungan fisik. Lakukan penghitungan ulang fisik sebelum melakukan penyesuaian akhir (finalisasi).
                </p>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th style="width: 30px;">No</th>
                            <th>SKU/Barcode</th>
                            <th>Nama Produk</th>
                            <th style="text-align: right;">Stok Sistem</th>
                            <th style="text-align: right;">Hitung Fisik</th>
                            <th style="text-align: right;">Selisih</th>
                            <th>Alasan / Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
            """.trimIndent())

            if (discrepancyItems.isEmpty()) {
                append("""<tr><td colspan="7" style="text-align: center; color: #16a34a; font-weight: bold; padding: 20px;">Selamat! Tidak ada selisih stok (Seluruh produk cocok dengan stok sistem).</td></tr>""")
            } else {
                discrepancyItems.forEachIndexed { i, item ->
                    val diffBadge = if (item.difference > 0) {
                        "<span class=\"badge-success\">+${item.difference} ${item.unit} (Lebih)</span>"
                    } else {
                        "<span class=\"badge-danger\">${item.difference} ${item.unit} (Kurang)</span>"
                    }
                    append("""
                        <tr>
                            <td style="text-align: center;">${i + 1}</td>
                            <td>${item.sku.ifBlank { "-" }}</td>
                            <td><b>${item.productName}</b></td>
                            <td style="text-align: right;">${item.systemStock} ${item.unit}</td>
                            <td style="text-align: right; font-weight: bold;">${item.physicalStock} ${item.unit}</td>
                            <td style="text-align: right;">$diffBadge</td>
                            <td>${item.reason}${if (item.notes.isNotBlank()) " (${item.notes})" else ""}</td>
                        </tr>
                    """.trimIndent())
                }
            }

            append("""
                    </tbody>
                </table>
            """.trimIndent())
        }

        val html = wrapHtmlDoc("Laporan Selisih Stok Opname (Checklist)", storeInfo, body)
        FileOutputStream(file).use { it.write(html.toByteArray(Charsets.UTF_8)) }
        return file
    }

    /**
     * 4.2 Dokumen Berita Acara Penyelesaian Stok Opname (Final)
     */
    fun generateStockOpnameFinalDoc(
        context: Context,
        storeInfo: LicenseInfo,
        taskCode: String,
        taskTitle: String,
        conductedBy: String,
        allItems: List<StockOpnameRecord>,
        notes: String
    ): File {
        val fileName = "Berita_Acara_SO_${taskCode}_${System.currentTimeMillis()}.doc"
        val file = File(context.cacheDir, fileName)

        val totalItems = allItems.size
        val matchedCount = allItems.count { it.difference == 0 }
        val discrepancyItems = allItems.filter { it.difference != 0 }

        val body = buildString {
            append("""
                <table class="meta-table">
                    <tr><td style="width: 160px;"><b>No. Dokumen / Tugas:</b></td><td><b>$taskCode</b></td></tr>
                    <tr><td><b>Nama Kegiatan:</b></td><td>$taskTitle</td></tr>
                    <tr><td><b>Penanggung Jawab:</b></td><td>$conductedBy</td></tr>
                    <tr><td><b>Total SKU Diperiksa:</b></td><td>$totalItems SKU</td></tr>
                    <tr><td><b>Produk Cocok (Sesuai):</b></td><td><span class="badge-success">$matchedCount SKU (${if (totalItems > 0) (matchedCount * 100 / totalItems) else 0}%)</span></td></tr>
                    <tr><td><b>Produk Berselisih:</b></td><td><span class="badge-danger">${discrepancyItems.size} SKU</span></td></tr>
                    <tr><td><b>Catatan Penyelesaian:</b></td><td>${notes.ifBlank { "Telah dilakukan penyesuaian stok fisik dan disinkronkan ke dalam sistem POS." }}</td></tr>
                </table>

                <table class="data-table">
                    <thead>
                        <tr>
                            <th style="width: 25px;">No</th>
                            <th>SKU</th>
                            <th>Nama Produk</th>
                            <th style="text-align: right;">Stok Awal</th>
                            <th style="text-align: right;">Hasil Fisik</th>
                            <th style="text-align: right;">Selisih</th>
                            <th>Status & Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
            """.trimIndent())

            allItems.forEachIndexed { i, item ->
                val statusText = if (item.difference == 0) {
                    "<span class=\"badge-success\">SESUAI</span>"
                } else if (item.difference > 0) {
                    "<span class=\"badge-warning\">SURPLUS (+${item.difference})</span>"
                } else {
                    "<span class=\"badge-danger\">DEFISIT (${item.difference})</span>"
                }
                append("""
                    <tr>
                        <td style="text-align: center;">${i + 1}</td>
                        <td>${item.sku.ifBlank { "-" }}</td>
                        <td><b>${item.productName}</b></td>
                        <td style="text-align: right;">${item.systemStock} ${item.unit}</td>
                        <td style="text-align: right; font-weight: bold;">${item.physicalStock} ${item.unit}</td>
                        <td style="text-align: right;">${if (item.difference > 0) "+${item.difference}" else "${item.difference}"} ${item.unit}</td>
                        <td>$statusText ${item.reason}</td>
                    </tr>
                """.trimIndent())
            }

            append("""
                    </tbody>
                </table>
            """.trimIndent())
        }

        val html = wrapHtmlDoc("Berita Acara Hasil Stok Opname", storeInfo, body)
        FileOutputStream(file).use { it.write(html.toByteArray(Charsets.UTF_8)) }
        return file
    }

    /**
     * 4.3 Dokumen Riwayat Retur Barang
     */
    fun generateProductReturnDoc(
        context: Context,
        storeInfo: LicenseInfo,
        returns: List<ProductReturnRecord>
    ): File {
        val fileName = "Riwayat_Retur_${System.currentTimeMillis()}.doc"
        val file = File(context.cacheDir, fileName)
        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("id", "ID"))

        val totalQty = returns.sumOf { it.qty }
        val body = buildString {
            append("""
                <table class="meta-table">
                    <tr><td style="width: 140px;"><b>Total Transaksi Retur:</b></td><td><b>${returns.size} kali</b></td></tr>
                    <tr><td><b>Total Kuantitas Retur:</b></td><td><b>$totalQty unit</b></td></tr>
                </table>

                <table class="data-table">
                    <thead>
                        <tr>
                            <th style="width: 25px;">No</th>
                            <th>Tanggal</th>
                            <th>Nama Produk</th>
                            <th style="text-align: center;">Qty</th>
                            <th>Tipe Retur</th>
                            <th>Alasan</th>
                            <th>Pelanggan / Pihak</th>
                            <th>Catatan</th>
                        </tr>
                    </thead>
                    <tbody>
            """.trimIndent())

            if (returns.isEmpty()) {
                append("""<tr><td colspan="8" style="text-align: center; padding: 20px;">Belum ada riwayat retur barang.</td></tr>""")
            } else {
                returns.forEachIndexed { i, r ->
                    val typeBadge = if (r.returnType == "MASUK_STOK") {
                        "<span class=\"badge-success\">Masuk Stok (Pelanggan)</span>"
                    } else {
                        "<span class=\"badge-danger\">Keluar Stok (Rusak/Supplier)</span>"
                    }
                    append("""
                        <tr>
                            <td style="text-align: center;">${i + 1}</td>
                            <td>${dateFormat.format(Date(r.timestamp))}</td>
                            <td><b>${r.productName}</b></td>
                            <td style="text-align: center; font-weight: bold;">${r.qty}</td>
                            <td>$typeBadge</td>
                            <td>${r.reason}</td>
                            <td>${r.customerOrSupplier.ifBlank { "-" }}</td>
                            <td>${r.notes.ifBlank { "-" }}</td>
                        </tr>
                    """.trimIndent())
                }
            }

            append("""
                    </tbody>
                </table>
            """.trimIndent())
        }

        val html = wrapHtmlDoc("Dokumen Laporan Riwayat Retur Barang", storeInfo, body)
        FileOutputStream(file).use { it.write(html.toByteArray(Charsets.UTF_8)) }
        return file
    }

    /**
     * 4.4 Dokumen Riwayat Pembelian Supplier
     */
    fun generateSupplierPurchaseDoc(
        context: Context,
        storeInfo: LicenseInfo,
        purchases: List<PurchaseRecord>
    ): File {
        val fileName = "Riwayat_Pembelian_${System.currentTimeMillis()}.doc"
        val file = File(context.cacheDir, fileName)
        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("id", "ID"))

        val totalAmount = purchases.sumOf { it.totalAmount }
        val body = buildString {
            append("""
                <table class="meta-table">
                    <tr><td style="width: 160px;"><b>Total Faktur Pembelian:</b></td><td><b>${purchases.size} transaksi</b></td></tr>
                    <tr><td><b>Total Pengeluaran Belanja:</b></td><td><b>${PosRepository.formatRupiah(totalAmount)}</b></td></tr>
                </table>

                <table class="data-table">
                    <thead>
                        <tr>
                            <th style="width: 25px;">No</th>
                            <th>No. Faktur</th>
                            <th>Tanggal</th>
                            <th>Nama Supplier</th>
                            <th>No. Telp</th>
                            <th>Pembayaran</th>
                            <th style="text-align: right;">Total Nilai (Rp)</th>
                            <th>Penerima</th>
                        </tr>
                    </thead>
                    <tbody>
            """.trimIndent())

            if (purchases.isEmpty()) {
                append("""<tr><td colspan="8" style="text-align: center; padding: 20px;">Belum ada riwayat pembelian supplier.</td></tr>""")
            } else {
                purchases.forEachIndexed { i, p ->
                    append("""
                        <tr>
                            <td style="text-align: center;">${i + 1}</td>
                            <td><b>${p.invoiceNumber}</b></td>
                            <td>${dateFormat.format(Date(p.date))}</td>
                            <td><b>${p.supplierName}</b></td>
                            <td>${p.supplierPhone.ifBlank { "-" }}</td>
                            <td>${p.paymentType}</td>
                            <td style="text-align: right; font-weight: bold;">${PosRepository.formatRupiah(p.totalAmount)}</td>
                            <td>${p.receivedBy}</td>
                        </tr>
                    """.trimIndent())
                }
            }

            append("""
                    </tbody>
                </table>
            """.trimIndent())
        }

        val html = wrapHtmlDoc("Dokumen Laporan Pembelian Barang (Supplier)", storeInfo, body)
        FileOutputStream(file).use { it.write(html.toByteArray(Charsets.UTF_8)) }
        return file
    }

    /**
     * 4.5 Dokumen Buku Piutang & Kasbon
     */
    fun generateReceivableDoc(
        context: Context,
        storeInfo: LicenseInfo,
        receivables: List<ReceivableRecord>
    ): File {
        val fileName = "Buku_Piutang_${System.currentTimeMillis()}.doc"
        val file = File(context.cacheDir, fileName)
        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("id", "ID"))

        val totalRemaining = receivables.filter { it.status == "BELUM_LUNAS" }.sumOf { it.remainingAmount }
        val totalAll = receivables.sumOf { it.totalAmount }

        val body = buildString {
            append("""
                <table class="meta-table">
                    <tr><td style="width: 160px;"><b>Total Catatan Piutang:</b></td><td><b>${receivables.size} debitur</b></td></tr>
                    <tr><td><b>Total Nilai Piutang:</b></td><td><b>${PosRepository.formatRupiah(totalAll)}</b></td></tr>
                    <tr><td><b>Sisa Piutang Belum Lunas:</b></td><td><b style="color: #dc2626;">${PosRepository.formatRupiah(totalRemaining)}</b></td></tr>
                </table>

                <table class="data-table">
                    <thead>
                        <tr>
                            <th style="width: 25px;">No</th>
                            <th>No. Struk</th>
                            <th>Nama Pelanggan</th>
                            <th>No. Telp</th>
                            <th style="text-align: right;">Total Piutang</th>
                            <th style="text-align: right;">Sudah Dibayar</th>
                            <th style="text-align: right;">Sisa Piutang</th>
                            <th style="text-align: center;">Status</th>
                        </tr>
                    </thead>
                    <tbody>
            """.trimIndent())

            if (receivables.isEmpty()) {
                append("""<tr><td colspan="8" style="text-align: center; padding: 20px;">Tidak ada catatan piutang aktif.</td></tr>""")
            } else {
                receivables.forEachIndexed { i, r ->
                    val statusBadge = if (r.status == "LUNAS") {
                        "<span class=\"badge-success\">LUNAS</span>"
                    } else {
                        "<span class=\"badge-danger\">BELUM LUNAS</span>"
                    }
                    append("""
                        <tr>
                            <td style="text-align: center;">${i + 1}</td>
                            <td><b>${r.receiptNumber}</b></td>
                            <td><b>${r.customerName}</b></td>
                            <td>${r.customerPhone.ifBlank { "-" }}</td>
                            <td style="text-align: right;">${PosRepository.formatRupiah(r.totalAmount)}</td>
                            <td style="text-align: right;">${PosRepository.formatRupiah(r.paidAmount)}</td>
                            <td style="text-align: right; font-weight: bold; color: ${if (r.remainingAmount > 0) "#dc2626" else "#15803d"};">${PosRepository.formatRupiah(r.remainingAmount)}</td>
                            <td style="text-align: center;">$statusBadge</td>
                        </tr>
                    """.trimIndent())
                }
            }

            append("""
                    </tbody>
                </table>
            """.trimIndent())
        }

        val html = wrapHtmlDoc("Buku Laporan Piutang & Kasbon Pelanggan", storeInfo, body)
        FileOutputStream(file).use { it.write(html.toByteArray(Charsets.UTF_8)) }
        return file
    }
}
