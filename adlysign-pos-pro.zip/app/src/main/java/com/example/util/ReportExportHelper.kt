package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Environment
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONArray
import com.example.data.model.LicenseInfo
import com.example.data.model.Product
import com.example.data.model.ProductReturnRecord
import com.example.data.model.PurchaseRecord
import com.example.data.model.ReceivableRecord
import com.example.data.model.StockOpnameRecord
import com.example.data.model.TransactionRecord
import com.example.data.repository.PosRepository
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ProductSalesMetric(
    val product: Product,
    val totalSoldQty: Int,
    val totalRevenue: Long,
    val totalCost: Long,
    val totalProfit: Long
)

data class ComprehensiveReportData(
    val periodLabel: String,
    val startDate: Long,
    val endDate: Long,
    val storeInfo: LicenseInfo,
    val transactions: List<TransactionRecord>,
    val fastMoving: List<ProductSalesMetric>,
    val slowMoving: List<ProductSalesMetric>,
    val purchases: List<PurchaseRecord>,
    val returns: List<ProductReturnRecord>,
    val stockOpnames: List<StockOpnameRecord>,
    val voidTransactions: List<TransactionRecord>,
    val receivables: List<ReceivableRecord>
) {
    val successTransactions = transactions.filter { !it.isVoid }
    val totalOmset = successTransactions.sumOf { it.totalAmount }
    val totalHpp = successTransactions.sumOf { it.totalCost }
    val totalProfit = (totalOmset - totalHpp).coerceAtLeast(0L)
    val totalDiscounts = successTransactions.sumOf { it.discount }
    val totalTransactionsCount = successTransactions.size
    val averageBasket = if (totalTransactionsCount > 0) totalOmset / totalTransactionsCount else 0L
    val totalPurchasesAmount = purchases.sumOf { it.totalAmount }
    val totalReceivablesRemaining = receivables.sumOf { it.remainingAmount }
    val totalVoidCount = voidTransactions.size
    val totalVoidAmount = voidTransactions.sumOf { it.totalAmount }
}

object ReportExportHelper {

    fun generateWordDocument(context: Context, data: ComprehensiveReportData): File {
        val fileName = "Laporan_POS_${data.storeInfo.storeName.replace(" ", "_")}_${System.currentTimeMillis()}.doc"
        val file = File(context.cacheDir, fileName)
        val htmlContent = buildWordHtml(data)
        FileOutputStream(file).use { out ->
            out.write(htmlContent.toByteArray(Charsets.UTF_8))
        }
        return file
    }

    private fun buildWordHtml(data: ComprehensiveReportData): String {
        val nowFormatted = SimpleDateFormat("dd MMMM yyyy, HH:mm", Locale("id", "ID")).format(Date())
        return buildString {
            append("""
                <html xmlns:o="urn:schemas-microsoft-com:office:office" 
                      xmlns:w="urn:schemas-microsoft-com:office:word" 
                      xmlns="http://www.w3.org/TR/REC-html40">
                <head>
                <meta charset="utf-8">
                <title>Laporan Keuangan & Operasional POS</title>
                <style>
                    body { font-family: 'Segoe UI', Calibri, Arial, sans-serif; font-size: 11pt; color: #1E293B; margin: 20px; line-height: 1.4; }
                    .header-box { border-bottom: 2px solid #059669; padding-bottom: 12px; margin-bottom: 20px; }
                    .store-title { font-size: 20pt; font-weight: bold; color: #065F46; margin: 0; }
                    .store-subtitle { font-size: 10pt; color: #64748B; margin: 2px 0; }
                    .report-title { font-size: 15pt; font-weight: bold; color: #0F172A; margin-top: 14px; }
                    .kpi-table { width: 100%; border-collapse: collapse; margin-bottom: 24px; }
                    .kpi-card { border: 1px solid #CBD5E1; background-color: #F8FAFC; padding: 12px; text-align: center; }
                    .kpi-label { font-size: 9.5pt; color: #64748B; text-transform: uppercase; }
                    .kpi-value { font-size: 15pt; font-weight: bold; color: #0F172A; margin-top: 4px; }
                    .kpi-profit { color: #059669; }
                    .section-title { font-size: 13pt; font-weight: bold; color: #065F46; border-left: 4px solid #059669; padding-left: 8px; margin-top: 24px; margin-bottom: 8px; }
                    .data-table { width: 100%; border-collapse: collapse; margin-bottom: 18px; }
                    .data-table th { background-color: #065F46; color: #FFFFFF; font-weight: bold; padding: 7px 10px; font-size: 9.5pt; text-align: left; border: 1px solid #065F46; }
                    .data-table td { padding: 6px 10px; font-size: 9.5pt; border: 1px solid #E2E8F0; }
                    .data-table tr:nth-child(even) { background-color: #F8FAFC; }
                    .signature-table { width: 100%; margin-top: 40px; border: none; }
                    .signature-table td { border: none; text-align: center; width: 50%; }
                </style>
                </head>
                <body>
                    <div class="header-box">
                        <div class="store-title">${data.storeInfo.storeName.uppercase()}</div>
                        <div class="store-subtitle">${data.storeInfo.storeAddress} | Telp: ${data.storeInfo.storePhone}</div>
                        <div class="report-title">LAPORAN KEUANGAN & OPERASIONAL LENGKAP</div>
                        <div class="store-subtitle">Periode: <b>${data.periodLabel}</b> | Dicetak: <b>$nowFormatted</b></div>
                    </div>
                    <table class="kpi-table">
                        <tr>
                            <td class="kpi-card" style="width: 25%;">
                                <div class="kpi-label">Total Omset Penjualan</div>
                                <div class="kpi-value">${PosRepository.formatRupiah(data.totalOmset)}</div>
                            </td>
                            <td class="kpi-card" style="width: 25%;">
                                <div class="kpi-label">Harga Pokok (HPP)</div>
                                <div class="kpi-value">${PosRepository.formatRupiah(data.totalHpp)}</div>
                            </td>
                            <td class="kpi-card" style="width: 25%;">
                                <div class="kpi-label">Estimasi Laba Bersih</div>
                                <div class="kpi-value kpi-profit">${PosRepository.formatRupiah(data.totalProfit)}</div>
                            </td>
                            <td class="kpi-card" style="width: 25%;">
                                <div class="kpi-label">Rata-Rata Keranjang</div>
                                <div class="kpi-value">${PosRepository.formatRupiah(data.averageBasket)}</div>
                            </td>
                        </tr>
                    </table>
                    <div class="section-title">1. Daftar Barang Cepat Laku (Top Fast-Moving)</div>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th style="width: 40px; text-align: center;">No</th>
                                <th>Nama Produk</th>
                                <th>Kategori</th>
                                <th style="text-align: center;">Terjual</th>
                                <th style="text-align: right;">Total Omset</th>
                                <th style="text-align: right;">Est. Laba</th>
                            </tr>
                        </thead>
                        <tbody>
            """.trimIndent())
            if (data.fastMoving.isEmpty()) {
                append("<tr><td colspan='6' style='text-align: center; color: #94A3B8;'>Belum ada data penjualan.</td></tr>")
            } else {
                data.fastMoving.forEachIndexed { index, item ->
                    append("""
                        <tr>
                            <td style="text-align: center;">#${index + 1}</td>
                            <td><b>${item.product.name}</b> (${item.product.sku})</td>
                            <td>${item.product.category}</td>
                            <td style="text-align: center; font-weight: bold; color: #065F46;">${item.totalSoldQty} ${item.product.unit}</td>
                            <td style="text-align: right;">${PosRepository.formatRupiah(item.totalRevenue)}</td>
                            <td style="text-align: right; color: #059669;">${PosRepository.formatRupiah(item.totalProfit)}</td>
                        </tr>
                    """.trimIndent())
                }
            }
            append("""
                        </tbody>
                    </table>
                    <div class="section-title">2. Laporan Pembelian Supplier</div>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th style="width: 40px; text-align: center;">No</th>
                                <th>No. Faktur</th>
                                <th>Supplier</th>
                                <th>Pembayaran</th>
                                <th style="text-align: right;">Total Nilai</th>
                                <th>Penerima</th>
                            </tr>
                        </thead>
                        <tbody>
            """.trimIndent())
            if (data.purchases.isEmpty()) {
                append("<tr><td colspan='6' style='text-align: center; color: #94A3B8;'>Belum ada catatan pembelian.</td></tr>")
            } else {
                data.purchases.forEachIndexed { idx, p ->
                    append("""
                        <tr>
                            <td style="text-align: center;">${idx + 1}</td>
                            <td><b>${p.invoiceNumber}</b></td>
                            <td>${p.supplierName}</td>
                            <td>${p.paymentType}</td>
                            <td style="text-align: right; font-weight: bold;">${PosRepository.formatRupiah(p.totalAmount)}</td>
                            <td>${p.receivedBy}</td>
                        </tr>
                    """.trimIndent())
                }
            }
            append("""
                        </tbody>
                    </table>
                </body>
                </html>
            """.trimIndent())
        }
    }

    fun generatePdfDocument(context: Context, data: ComprehensiveReportData): File {
        val fileName = "Laporan_POS_${data.storeInfo.storeName.replace(" ", "_")}_${System.currentTimeMillis()}.pdf"
        val file = File(context.cacheDir, fileName)
        val pdfDocument = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)

        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.textSize = 16f
        textPaint.color = Color.parseColor("#065F46")
        canvas.drawText(data.storeInfo.storeName.uppercase(), 30f, 50f, textPaint)

        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        textPaint.textSize = 10f
        textPaint.color = Color.parseColor("#64748B")
        canvas.drawText("${data.storeInfo.storeAddress} | Telp: ${data.storeInfo.storePhone}", 30f, 68f, textPaint)

        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.textSize = 12f
        textPaint.color = Color.parseColor("#0F172A")
        canvas.drawText("Laporan Keuangan & Penjualan POS (${data.periodLabel})", 30f, 90f, textPaint)

        textPaint.textSize = 10f
        textPaint.color = Color.parseColor("#1E293B")
        canvas.drawText("Total Omset: ${PosRepository.formatRupiah(data.totalOmset)}", 30f, 120f, textPaint)
        canvas.drawText("Total HPP: ${PosRepository.formatRupiah(data.totalHpp)}", 30f, 138f, textPaint)
        canvas.drawText("Estimasi Laba Bersih: ${PosRepository.formatRupiah(data.totalProfit)}", 30f, 156f, textPaint)
        canvas.drawText("Total Transaksi: ${data.totalTransactionsCount} Struk", 30f, 174f, textPaint)

        pdfDocument.finishPage(page)
        FileOutputStream(file).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()
        return file
    }

    /**
     * Generate single purchase invoice / shopping document (.doc format)
     */
    fun generateSingleSupplierPurchaseInvoiceDoc(
        context: Context,
        storeInfo: LicenseInfo,
        purchase: PurchaseRecord
    ): File {
        val isBelanjaToko = purchase.notes.contains("[Belanja Toko]") || purchase.invoiceNumber.startsWith("STRUK")
        val docType = if (isBelanjaToko) "Struk_Belanja" else "Faktur_Beli"
        val docTitle = if (isBelanjaToko) "Bukti Belanja Toko (Struk Belanja)" else "Bukti Penerimaan Barang Supplier (Faktur Beli)"
        val noLabel = if (isBelanjaToko) "Nomor Struk" else "Nomor Faktur"
        val partnerLabel = if (isBelanjaToko) "Nama Toko Mitra" else "Nama Supplier"
        val cleanNotes = purchase.notes.replace("[Belanja Toko]", "").trim()

        val fileName = "${docType}_${purchase.invoiceNumber.replace("[^a-zA-Z0-9]".toRegex(), "_")}_${System.currentTimeMillis()}.doc"
        val file = File(context.cacheDir, fileName)
        val dateFormat = SimpleDateFormat("dd MMMM yyyy, HH:mm", Locale("id", "ID"))
        val dateStr = dateFormat.format(Date(purchase.date))

        val body = buildString {
            append("""
                <div style="border: 1px solid #CBD5E1; padding: 14px; background: #F8FAFC; border-radius: 8px; margin-bottom: 16px;">
                    <table style="width: 100%; border: none;">
                        <tr><td style="width: 160px;"><b>$noLabel:</b></td><td><b>${purchase.invoiceNumber}</b></td></tr>
                        <tr><td><b>$partnerLabel:</b></td><td><b>${purchase.supplierName}</b></td></tr>
                        <tr><td><b>No. Kontak:</b></td><td>${purchase.supplierPhone.ifBlank { "-" }}</td></tr>
                        <tr><td><b>Tanggal & Jam:</b></td><td>$dateStr</td></tr>
                        <tr><td><b>Metode Pembayaran:</b></td><td><b>${purchase.paymentType}</b></td></tr>
                        <tr><td><b>Petugas / User Login Aktif:</b></td><td><b>${purchase.receivedBy}</b></td></tr>
                        ${if (cleanNotes.isNotBlank()) "<tr><td><b>Catatan:</b></td><td>$cleanNotes</td></tr>" else ""}
                    </table>
                </div>
                <h3>Rincian Barang Masuk:</h3>
                <table style="width: 100%; border-collapse: collapse; margin-top: 8px; margin-bottom: 16px;">
                    <thead>
                        <tr style="background-color: #0F172A; color: white;">
                            <th style="padding: 8px; border: 1px solid #0F172A; text-align: center; width: 30px;">No</th>
                            <th style="padding: 8px; border: 1px solid #0F172A; text-align: left;">Nama Produk / Barang</th>
                            <th style="padding: 8px; border: 1px solid #0F172A; text-align: center; width: 70px;">Qty Masuk</th>
                            <th style="padding: 8px; border: 1px solid #0F172A; text-align: right; width: 120px;">Harga Beli Satuan</th>
                            <th style="padding: 8px; border: 1px solid #0F172A; text-align: right; width: 130px;">Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
            """.trimIndent())

            try {
                val array = JSONArray(purchase.itemsJson)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val name = obj.optString("name", "Produk")
                    val qty = obj.optInt("qty", 1)
                    val buyPrice = obj.optLong("buyPrice", 0L)
                    val subtotal = obj.optLong("subtotal", qty * buyPrice)
                    append("""
                        <tr style="background-color: ${if (i % 2 == 1) "#F8FAFC" else "#FFFFFF"};">
                            <td style="padding: 7px; border: 1px solid #CBD5E1; text-align: center;">${i + 1}</td>
                            <td style="padding: 7px; border: 1px solid #CBD5E1;"><b>$name</b></td>
                            <td style="padding: 7px; border: 1px solid #CBD5E1; text-align: center; font-weight: bold;">$qty</td>
                            <td style="padding: 7px; border: 1px solid #CBD5E1; text-align: right;">${PosRepository.formatRupiah(buyPrice)}</td>
                            <td style="padding: 7px; border: 1px solid #CBD5E1; text-align: right; font-weight: bold;">${PosRepository.formatRupiah(subtotal)}</td>
                        </tr>
                    """.trimIndent())
                }
            } catch (_: Exception) {}

            append("""
                    </tbody>
                    <tfoot>
                        <tr style="background-color: #E2E8F0; font-weight: bold;">
                            <td colspan="4" style="padding: 10px; text-align: right; border: 1px solid #CBD5E1;">TOTAL TAGIHAN:</td>
                            <td style="padding: 10px; text-align: right; border: 1px solid #CBD5E1; color: #065F46; font-size: 13pt;">${PosRepository.formatRupiah(purchase.totalAmount)}</td>
                        </tr>
                    </tfoot>
                </table>

                <table style="width: 100%; border: none; margin-top: 40px;">
                    <tr>
                        <td style="text-align: center; width: 50%;">
                            Petugas / Penerima (User Aktif):<br><br><br><br>
                            <b>(${purchase.receivedBy.ifBlank { "Kasir / Petugas" }})</b>
                        </td>
                        <td style="text-align: center; width: 50%;">
                            Pihak ${if (isBelanjaToko) "Toko Mitra" else "Supplier"}:<br><br><br><br>
                            <b>(${purchase.supplierName.ifBlank { "-" }})</b>
                        </td>
                    </tr>
                </table>
            """.trimIndent())
        }

        val html = wrapHtmlDoc(docTitle, storeInfo, body)
        FileOutputStream(file).use { it.write(html.toByteArray(Charsets.UTF_8)) }
        return file
    }

    /**
     * Generate single purchase invoice / shopping document (.pdf format)
     */
    fun generatePurchasePdf(
        context: Context,
        storeInfo: LicenseInfo,
        purchase: PurchaseRecord
    ): File {
        val isBelanjaToko = purchase.notes.contains("[Belanja Toko]") || purchase.invoiceNumber.startsWith("STRUK")
        val docType = if (isBelanjaToko) "Struk_Belanja" else "Faktur_Beli"
        val docTitle = if (isBelanjaToko) "STRUK BELANJA TOKO" else "FAKTUR PEMBELIAN SUPPLIER"
        val fileName = "${docType}_${purchase.invoiceNumber.replace("[^a-zA-Z0-9]".toRegex(), "_")}_${System.currentTimeMillis()}.pdf"
        val file = File(context.cacheDir, fileName)

        val pdfDocument = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)

        // Store Header
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.textSize = 15f
        textPaint.color = Color.parseColor("#065F46")
        canvas.drawText(storeInfo.storeName.uppercase(), 36f, 48f, textPaint)

        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        textPaint.textSize = 9f
        textPaint.color = Color.parseColor("#64748B")
        canvas.drawText("${storeInfo.storeAddress} | Telp: ${storeInfo.storePhone}", 36f, 64f, textPaint)

        // Divider
        val linePaint = Paint().apply {
            color = Color.parseColor("#CBD5E1")
            strokeWidth = 1f
        }
        canvas.drawLine(36f, 74f, 559f, 74f, linePaint)

        // Title
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.textSize = 13f
        textPaint.color = Color.parseColor("#0F172A")
        canvas.drawText(docTitle, 36f, 96f, textPaint)

        // Meta info
        val dateFormat = SimpleDateFormat("dd MMMM yyyy, HH:mm", Locale("id", "ID"))
        val dateStr = dateFormat.format(Date(purchase.date))
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        textPaint.textSize = 10f
        textPaint.color = Color.parseColor("#1E293B")

        var y = 118f
        val noLabel = if (isBelanjaToko) "No. Struk" else "No. Faktur"
        val partnerLabel = if (isBelanjaToko) "Nama Toko" else "Supplier"
        canvas.drawText("$noLabel: ${purchase.invoiceNumber}", 36f, y, textPaint)
        canvas.drawText("$partnerLabel: ${purchase.supplierName}", 300f, y, textPaint)
        y += 18f
        canvas.drawText("Tanggal: $dateStr", 36f, y, textPaint)
        canvas.drawText("Pembayaran: ${purchase.paymentType}", 300f, y, textPaint)
        y += 18f
        canvas.drawText("User Login / Petugas: ${purchase.receivedBy}", 36f, y, textPaint)
        if (purchase.supplierPhone.isNotBlank()) {
            canvas.drawText("No. Kontak: ${purchase.supplierPhone}", 300f, y, textPaint)
        }
        y += 24f

        // Table Header
        canvas.drawLine(36f, y - 6f, 559f, y - 6f, linePaint)
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.textSize = 9f
        textPaint.color = Color.parseColor("#0F172A")
        canvas.drawText("NO", 40f, y + 8f, textPaint)
        canvas.drawText("NAMA PRODUK", 70f, y + 8f, textPaint)
        canvas.drawText("QTY", 340f, y + 8f, textPaint)
        canvas.drawText("HARGA BELI", 400f, y + 8f, textPaint)
        canvas.drawText("SUBTOTAL", 480f, y + 8f, textPaint)
        y += 16f
        canvas.drawLine(36f, y, 559f, y, linePaint)

        // Table Rows
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        try {
            val array = JSONArray(purchase.itemsJson)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val name = obj.optString("name", "Produk")
                val qty = obj.optInt("qty", 1)
                val buyPrice = obj.optLong("buyPrice", 0L)
                val subtotal = obj.optLong("subtotal", qty * buyPrice)

                y += 18f
                if (y > 750f) break
                canvas.drawText("${i + 1}", 40f, y, textPaint)
                val cleanName = if (name.length > 32) name.substring(0, 30) + ".." else name
                canvas.drawText(cleanName, 70f, y, textPaint)
                canvas.drawText("$qty", 345f, y, textPaint)
                canvas.drawText(PosRepository.formatRupiah(buyPrice), 400f, y, textPaint)
                canvas.drawText(PosRepository.formatRupiah(subtotal), 480f, y, textPaint)
            }
        } catch (_: Exception) {}

        y += 16f
        canvas.drawLine(36f, y, 559f, y, linePaint)

        // Total
        y += 20f
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.textSize = 12f
        textPaint.color = Color.parseColor("#065F46")
        canvas.drawText("TOTAL TAGIHAN: ${PosRepository.formatRupiah(purchase.totalAmount)}", 330f, y, textPaint)

        // Signatures
        y += 40f
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        textPaint.textSize = 9f
        textPaint.color = Color.parseColor("#334155")
        canvas.drawText("Petugas / Penerima:", 60f, y, textPaint)
        canvas.drawText("Pihak ${if (isBelanjaToko) "Toko Mitra" else "Supplier"}:", 400f, y, textPaint)
        y += 45f
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("(${purchase.receivedBy})", 60f, y, textPaint)
        canvas.drawText("(${purchase.supplierName})", 400f, y, textPaint)

        pdfDocument.finishPage(page)
        FileOutputStream(file).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()
        return file
    }

    private fun wrapHtmlDoc(title: String, storeInfo: LicenseInfo, bodyContent: String): String {
        val nowFormatted = SimpleDateFormat("dd MMMM yyyy, HH:mm", Locale("id", "ID")).format(Date())
        return """
            <html xmlns:o="urn:schemas-microsoft-com:office:office" 
                  xmlns:w="urn:schemas-microsoft-com:office:word" 
                  xmlns="http://www.w3.org/TR/REC-html40">
            <head>
            <meta charset="utf-8">
            <title>$title</title>
            <style>
                body { font-family: 'Segoe UI', Calibri, Arial, sans-serif; font-size: 11pt; color: #1e293b; margin: 30px; line-height: 1.5; }
                h1 { font-size: 18pt; color: #0f172a; margin: 0 0 4px 0; }
                h2 { font-size: 13pt; color: #0284c7; margin: 18px 0 6px 0; border-bottom: 2px solid #0284c7; padding-bottom: 4px; }
                .store-header { border-bottom: 2px solid #0f172a; padding-bottom: 12px; margin-bottom: 20px; }
            </style>
            </head>
            <body>
                <div class="store-header">
                    <h1>${storeInfo.storeName}</h1>
                    <div style="font-size: 9.5pt; color: #64748b;">${storeInfo.storeAddress} | Telp: ${storeInfo.storePhone}</div>
                </div>
                <h2>$title</h2>
                <div style="font-size: 9pt; color: #64748b; margin-bottom: 14px;">Waktu Cetak: $nowFormatted</div>
                $bodyContent
            </body>
            </html>
        """.trimIndent()
    }

    fun generateStockOpnameDiscrepancyDoc(
        context: Context,
        storeInfo: LicenseInfo,
        taskCode: String,
        taskTitle: String,
        conductedBy: String,
        discrepancyItems: List<StockOpnameRecord>
    ): File {
        val fileName = "Selisih_SO_${taskCode}_${System.currentTimeMillis()}.doc"
        val file = File(context.cacheDir, fileName)
        val body = "<p>Laporan Selisih Stok Opname: ${discrepancyItems.size} produk berselisih.</p>"
        val html = wrapHtmlDoc("Laporan Selisih Stok Opname", storeInfo, body)
        FileOutputStream(file).use { it.write(html.toByteArray(Charsets.UTF_8)) }
        return file
    }

    fun generateStockOpnameFinalDoc(
        context: Context,
        storeInfo: LicenseInfo,
        taskCode: String,
        taskTitle: String,
        conductedBy: String,
        allItems: List<StockOpnameRecord>,
        notes: String
    ): File {
        val fileName = "Berita_Acara_SO_${taskCode}_${System.currentTimeMillis()}.doc"
        val file = File(context.cacheDir, fileName)
        val body = "<p>Berita Acara SO: $taskTitle ($taskCode) telah selesai. Total item: ${allItems.size}.</p>"
        val html = wrapHtmlDoc("Berita Acara Stok Opname", storeInfo, body)
        FileOutputStream(file).use { it.write(html.toByteArray(Charsets.UTF_8)) }
        return file
    }

    fun generateSalesReportDoc(
        context: Context,
        storeInfo: LicenseInfo,
        transactions: List<TransactionRecord>,
        periodName: String
    ): File {
        val fileName = "Laporan_Penjualan_${System.currentTimeMillis()}.doc"
        val file = File(context.cacheDir, fileName)
        val validTrx = transactions.filter { !it.isVoid }
        val omset = validTrx.sumOf { it.totalAmount }
        val untung = validTrx.sumOf { it.profit }
        val body = buildString {
            append("""
                <div style="background:#f1f5f9; padding:12px; border-radius:6px; margin-bottom:14px;">
                    <p><b>Periode:</b> $periodName</p>
                    <p><b>Total Nota Transaksi:</b> ${validTrx.size} Struk</p>
                    <p><b>Total Omset:</b> ${PosRepository.formatRupiah(omset)}</p>
                    <p><b>Estimasi Laba Kotor:</b> ${PosRepository.formatRupiah(untung)}</p>
                </div>
                <h3>Daftar Transaksi:</h3>
                <table style="width:100%; border-collapse:collapse;" border="1">
                    <tr style="background:#0F172A; color:white;">
                        <th style="padding:6px;">No. Struk</th>
                        <th style="padding:6px;">Kasir</th>
                        <th style="padding:6px;">Pelanggan</th>
                        <th style="padding:6px;">Metode</th>
                        <th style="padding:6px; text-align:right;">Total</th>
                    </tr>
            """.trimIndent())
            validTrx.take(100).forEach { tx ->
                append("""
                    <tr>
                        <td style="padding:5px;">${tx.receiptNumber}</td>
                        <td style="padding:5px;">${tx.cashierName}</td>
                        <td style="padding:5px;">${tx.customerName}</td>
                        <td style="padding:5px;">${tx.paymentMethod}</td>
                        <td style="padding:5px; text-align:right;">${PosRepository.formatRupiah(tx.totalAmount)}</td>
                    </tr>
                """.trimIndent())
            }
            append("</table>")
        }
        val html = wrapHtmlDoc("Laporan Penjualan Kasir", storeInfo, body)
        FileOutputStream(file).use { it.write(html.toByteArray(Charsets.UTF_8)) }
        return file
    }

    fun generateStockReportDoc(
        context: Context,
        storeInfo: LicenseInfo,
        products: List<Product>
    ): File {
        val fileName = "Laporan_Stok_${System.currentTimeMillis()}.doc"
        val file = File(context.cacheDir, fileName)
        val body = buildString {
            append("""
                <p>Total Jenis Barang: <b>${products.size}</b> produk</p>
                <table style="width:100%; border-collapse:collapse;" border="1">
                    <tr style="background:#0284C7; color:white;">
                        <th style="padding:6px;">SKU</th>
                        <th style="padding:6px;">Nama Produk</th>
                        <th style="padding:6px;">Kategori</th>
                        <th style="padding:6px; text-align:center;">Stok Sistem</th>
                        <th style="padding:6px; text-align:right;">Harga Jual</th>
                    </tr>
            """.trimIndent())
            products.forEach { p ->
                append("""
                    <tr>
                        <td style="padding:5px;">${p.sku}</td>
                        <td style="padding:5px;">${p.name}</td>
                        <td style="padding:5px;">${p.category}</td>
                        <td style="padding:5px; text-align:center;"><b>${p.stock} ${p.unit}</b></td>
                        <td style="padding:5px; text-align:right;">${PosRepository.formatRupiah(p.sellPrice)}</td>
                    </tr>
                """.trimIndent())
            }
            append("</table>")
        }
        val html = wrapHtmlDoc("Laporan Stok Barang Toko", storeInfo, body)
        FileOutputStream(file).use { it.write(html.toByteArray(Charsets.UTF_8)) }
        return file
    }

    fun openDocument(context: Context, file: File, mimeType: String) {
        try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            shareDocument(context, file, mimeType, "Dokumen POS")
        }
    }

    fun shareDocument(context: Context, file: File, mimeType: String, subject: String) {
        try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, subject)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Bagikan Dokumen"))
        } catch (e: Exception) {
            Toast.makeText(context, "Gagal membagikan: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun saveToDownloads(context: Context, sourceFile: File, displayName: String): File? {
        return try {
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (!downloadsDir.exists()) downloadsDir.mkdirs()
            val destFile = File(downloadsDir, displayName)
            sourceFile.copyTo(destFile, overwrite = true)
            Toast.makeText(context, "Tersimpan di folder Download: ${destFile.name}", Toast.LENGTH_LONG).show()
            destFile
        } catch (e: Exception) {
            sourceFile
        }
    }
}
