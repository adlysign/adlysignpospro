package com.example.util

import java.util.Calendar

object ShiftScheduleHelper {
    data class ShiftScheduleInfo(
        val shiftNumber: Int,
        val name: String,
        val timeRange: String,
        val startHour: Int,
        val endHour: Int
    )

    val SHIFTS = listOf(
        ShiftScheduleInfo(1, "Shift 1 - Pagi", "07:00 - 15:00", 7, 15),
        ShiftScheduleInfo(2, "Shift 2 - Siang", "15:00 - 23:00", 15, 23),
        ShiftScheduleInfo(3, "Shift 3 - Malam", "23:00 - 07:00", 23, 7)
    )

    /**
     * Menentukan shift berapa yang sah/valid dibuka berdasarkan jam saat ini.
     * Shift 1: 07:00 - 14:59 (jam 7 s/d 14)
     * Shift 2: 15:00 - 22:59 (jam 15 s/d 22)
     * Shift 3: 23:00 - 06:59 (jam 23 atau jam 0..6)
     */
    fun getValidShiftForTime(calendar: Calendar = Calendar.getInstance()): Int {
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        return when (hour) {
            in 7..14 -> 1
            in 15..22 -> 2
            else -> 3
        }
    }

    /**
     * Memeriksa apakah nomor shift yang dipilih oleh kasir sesuai dengan jam buka saat ini.
     */
    fun validateShiftOpening(selectedShiftNumber: Int, calendar: Calendar = Calendar.getInstance()): Result<Unit> {
        val validShift = getValidShiftForTime(calendar)
        if (selectedShiftNumber == validShift) {
            return Result.success(Unit)
        }

        val currentValidSchedule = SHIFTS.find { it.shiftNumber == validShift }
        val attemptedSchedule = SHIFTS.find { it.shiftNumber == selectedShiftNumber }

        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val min = calendar.get(Calendar.MINUTE)
        val timeStr = String.format("%02d:%02d", hour, min)

        val message = "Shift ditolak! Jam saat ini ($timeStr) adalah jadwal ${currentValidSchedule?.name} (${currentValidSchedule?.timeRange}). Anda tidak dapat membuka ${attemptedSchedule?.name ?: "Shift $selectedShiftNumber"}."
        return Result.failure(Exception(message))
    }
}
