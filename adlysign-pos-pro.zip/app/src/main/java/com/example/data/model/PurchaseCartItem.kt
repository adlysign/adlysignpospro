package com.example.data.model

data class PurchaseCartItem(
    val product: Product,
    val qty: Int = 1,
    val selectedUnit: String = product.unit,
    val unitMultiplier: Int = 1,
    val buyPricePerUnit: Long = product.costPrice
) {
    val totalBaseUnits: Int
        get() = qty * unitMultiplier.coerceAtLeast(1)

    val subtotal: Long
        get() = buyPricePerUnit * qty

    val effectiveCostPerBaseUnit: Long
        get() = if (unitMultiplier > 0) buyPricePerUnit / unitMultiplier else buyPricePerUnit
}
