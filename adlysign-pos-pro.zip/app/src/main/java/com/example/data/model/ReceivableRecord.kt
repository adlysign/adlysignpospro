package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "receivables")
data class ReceivableRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val receiptNumber: String,
    val customerName: String,
    val customerPhone: String = "",
    val totalAmount: Long,
    val paidAmount: Long = 0L,
    val remainingAmount: Long, // totalAmount - paidAmount
    val status: String = "BELUM_LUNAS", // "BELUM_LUNAS", "LUNAS"
    val dueDate: Long,
    val createdAt: Long = System.currentTimeMillis(),
    val notes: String = ""
)
