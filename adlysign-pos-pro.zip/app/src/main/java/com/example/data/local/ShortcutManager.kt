package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.PosShortcutAction
import com.example.data.model.ShortcutConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

class ShortcutManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("pos_shortcuts_prefs", Context.MODE_PRIVATE)

    private val _shortcuts = MutableStateFlow<List<ShortcutConfig>>(emptyList())
    val shortcuts: StateFlow<List<ShortcutConfig>> = _shortcuts.asStateFlow()

    init {
        loadShortcuts()
    }

    private fun getDefaultShortcuts(): List<ShortcutConfig> {
        return listOf(
            ShortcutConfig("F1", PosShortcutAction.GALERI_PRODUK, true),
            ShortcutConfig("F2", PosShortcutAction.SCAN_BARCODE, true),
            ShortcutConfig("F3", PosShortcutAction.PRODUK_CEPAT, true),
            ShortcutConfig("F4", PosShortcutAction.CLOSE_SHIFT, true),
            ShortcutConfig("F5", PosShortcutAction.VOID_LAST, true),
            ShortcutConfig("F6", PosShortcutAction.STOK_OPNAME, true),
            ShortcutConfig("F7", PosShortcutAction.PENDING_CART, true),
            ShortcutConfig("F8", PosShortcutAction.MEMBER, true),
            ShortcutConfig("F9", PosShortcutAction.PEMBELIAN, true),
            ShortcutConfig("F10", PosShortcutAction.PIUTANG, true),
            ShortcutConfig("F11", PosShortcutAction.KUNCI_KASIR, true),
            ShortcutConfig("F12", PosShortcutAction.BAYAR, true)
        )
    }

    fun loadShortcuts() {
        val jsonString = prefs.getString(KEY_SHORTCUTS, null)
        if (jsonString.isNullOrBlank()) {
            _shortcuts.value = getDefaultShortcuts()
            saveShortcutsToPrefs(_shortcuts.value)
            return
        }

        try {
            val array = JSONArray(jsonString)
            val list = mutableListOf<ShortcutConfig>()
            val defaultMap = getDefaultShortcuts().associateBy { it.keyName }

            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val key = obj.getString("keyName")
                val actionStr = obj.getString("action")
                val isEnabled = obj.optBoolean("isEnabled", true)
                val action = try {
                    PosShortcutAction.valueOf(actionStr)
                } catch (_: Exception) {
                    defaultMap[key]?.action ?: PosShortcutAction.DISABLED
                }
                list.add(ShortcutConfig(key, action, isEnabled))
            }

            // Ensure all F1 to F12 exist
            val existingKeys = list.map { it.keyName }.toSet()
            for (defaultConfig in getDefaultShortcuts()) {
                if (!existingKeys.contains(defaultConfig.keyName)) {
                    list.add(defaultConfig)
                }
            }

            // Sort F1..F12
            list.sortBy { it.keyName.removePrefix("F").toIntOrNull() ?: 99 }
            _shortcuts.value = list
        } catch (e: Exception) {
            _shortcuts.value = getDefaultShortcuts()
        }
    }

    fun updateShortcut(keyName: String, action: PosShortcutAction, isEnabled: Boolean) {
        val current = _shortcuts.value.toMutableList()
        val index = current.indexOfFirst { it.keyName.equals(keyName, ignoreCase = true) }
        if (index >= 0) {
            current[index] = current[index].copy(action = action, isEnabled = isEnabled)
        } else {
            current.add(ShortcutConfig(keyName, action, isEnabled))
        }
        _shortcuts.value = current
        saveShortcutsToPrefs(current)
    }

    fun toggleShortcut(keyName: String, isEnabled: Boolean) {
        val current = _shortcuts.value.toMutableList()
        val index = current.indexOfFirst { it.keyName.equals(keyName, ignoreCase = true) }
        if (index >= 0) {
            current[index] = current[index].copy(isEnabled = isEnabled)
            _shortcuts.value = current
            saveShortcutsToPrefs(current)
        }
    }

    fun resetToDefaults() {
        val defaults = getDefaultShortcuts()
        _shortcuts.value = defaults
        saveShortcutsToPrefs(defaults)
    }

    private fun saveShortcutsToPrefs(list: List<ShortcutConfig>) {
        try {
            val array = JSONArray()
            for (item in list) {
                val obj = JSONObject().apply {
                    put("keyName", item.keyName)
                    put("action", item.action.name)
                    put("isEnabled", item.isEnabled)
                }
                array.put(obj)
            }
            prefs.edit().putString(KEY_SHORTCUTS, array.toString()).apply()
        } catch (_: Exception) {}
    }

    companion object {
        private const val KEY_SHORTCUTS = "configured_shortcuts_json"
    }
}
