package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "purchases")
data class PurchaseRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val invoiceNumber: String, // No Faktur Supplier (e.g. INV-INDOMARCO-009)
    val supplierName: String,
    val supplierPhone: String = "",
    val date: Long = System.currentTimeMillis(),
    val paymentType: String = "TUNAI", // "TUNAI" or "TEMPO"
    val totalAmount: Long,
    val itemsJson: String, // JSON array: [{"productId":1, "name":"...", "buyPrice":15000, "qty":10, "subtotal":150000}]
    val notes: String = "",
    val receivedBy: String,
    val purchaseType: String = "SUPPLIER" // "SUPPLIER" or "STORE_PURCHASE"
) {
    val timestamp: Long get() = date
}
