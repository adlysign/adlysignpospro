package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stock_opname")
data class StockOpnameRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val taskCode: String = "",
    val date: Long = System.currentTimeMillis(),
    val productId: Long = 0L,
    val productName: String = "",
    val sku: String = "",
    val systemStock: Int = 0,
    val physicalStock: Int = 0,
    val difference: Int = 0, // physicalStock - systemStock
    val reason: String = "PENYESUAIAN",
    val conductedBy: String = "Kasir",
    val notes: String = "",
    val unit: String = "pcs"
) {
    val timestamp: Long get() = date
}
