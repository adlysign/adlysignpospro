package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stock_opname")
data class StockOpnameRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val date: Long = System.currentTimeMillis(),
    val productId: Long,
    val productName: String,
    val sku: String,
    val systemStock: Int,
    val physicalStock: Int,
    val difference: Int, // physicalStock - systemStock
    val reason: String, // "Selisih / Hilang", "Rusak / Basi", "Expired / Kedaluwarsa", "Salah Hitung", "Lainnya"
    val conductedBy: String,
    val notes: String = ""
) {
    val timestamp: Long get() = date
}
