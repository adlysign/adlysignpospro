package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import org.json.JSONArray
import org.json.JSONObject

data class RepackUnit(
    val unitName: String, // e.g. "pack", "box", "dus", "bungkus", "slop", "bal", "renceng"
    val multiplier: Int,  // how many base units it contains, e.g. 10 pcs, 24 pcs
    val sellPrice: Long   // selling price per this repack unit
)

data class TieredPrice(
    val minQty: Int,      // minimum quantity to trigger this price
    val unitPrice: Long   // price per base unit when reached
)

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val sku: String = "",
    val category: String,
    val sellPrice: Long,
    val costPrice: Long = 0,
    val stock: Int = 100,
    val unit: String = "pcs",
    val repackUnitsJson: String = "",
    val tieredPricesJson: String = "",
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun getRepackUnits(): List<RepackUnit> {
        if (repackUnitsJson.isBlank()) return emptyList()
        return try {
            val list = mutableListOf<RepackUnit>()
            val arr = JSONArray(repackUnitsJson)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    RepackUnit(
                        unitName = obj.optString("unitName", "").trim(),
                        multiplier = obj.optInt("multiplier", 1).coerceAtLeast(1),
                        sellPrice = obj.optLong("sellPrice", sellPrice)
                    )
                )
            }
            list.filter { it.unitName.isNotBlank() }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun getTieredPrices(): List<TieredPrice> {
        if (tieredPricesJson.isBlank()) return emptyList()
        return try {
            val list = mutableListOf<TieredPrice>()
            val arr = JSONArray(tieredPricesJson)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    TieredPrice(
                        minQty = obj.optInt("minQty", 1).coerceAtLeast(1),
                        unitPrice = obj.optLong("unitPrice", sellPrice)
                    )
                )
            }
            list.sortedByDescending { it.minQty }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /**
     * Calculates the unit price given a quantity and unit name.
     * If unitName matches a repack unit, returns its sell price.
     * If unitName is base unit, checks if quantity triggers any tiered wholesale price.
     */
    fun calculateUnitPrice(qty: Int, unitName: String = unit): Long {
        val repacks = getRepackUnits()
        val matchedRepack = repacks.find { it.unitName.equals(unitName, ignoreCase = true) }
        if (matchedRepack != null) {
            return matchedRepack.sellPrice
        }
        // Check tiered wholesale prices for base unit
        val tiers = getTieredPrices()
        val applicableTier = tiers.firstOrNull { qty >= it.minQty }
        if (applicableTier != null) {
            return applicableTier.unitPrice
        }
        return sellPrice
    }

    companion object {
        fun encodeRepackUnits(list: List<RepackUnit>): String {
            val arr = JSONArray()
            list.forEach {
                val obj = JSONObject()
                obj.put("unitName", it.unitName)
                obj.put("multiplier", it.multiplier)
                obj.put("sellPrice", it.sellPrice)
                arr.put(obj)
            }
            return arr.toString()
        }

        fun encodeTieredPrices(list: List<TieredPrice>): String {
            val arr = JSONArray()
            list.forEach {
                val obj = JSONObject()
                obj.put("minQty", it.minQty)
                obj.put("unitPrice", it.unitPrice)
                arr.put(obj)
            }
            return arr.toString()
        }
    }
}
