package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val sku: String = "",
    val category: String,
    val sellPrice: Long,
    val costPrice: Long = 0,
    val stock: Int = 100,
    val unit: String = "pcs",
    val updatedAt: Long = System.currentTimeMillis()
)
