package com.example.data.model

data class SupplierData(
    val id: String = java.util.UUID.randomUUID().toString(),
    val name: String,
    val phone: String = "",
    val address: String = "",
    val notes: String = ""
)

data class StorePartnerData(
    val id: String = java.util.UUID.randomUUID().toString(),
    val name: String,
    val phone: String = "",
    val address: String = "",
    val notes: String = ""
)
