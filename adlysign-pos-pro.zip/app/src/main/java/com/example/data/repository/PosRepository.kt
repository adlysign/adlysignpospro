package com.example.data.repository

import com.example.data.local.PosDao
import com.example.data.model.CartItem
import com.example.data.model.Employee
import com.example.data.model.LicenseInfo
import com.example.data.model.MemberRecord
import com.example.data.model.PendingCart
import com.example.data.model.PointSettings
import com.example.data.model.Product
import com.example.data.model.PurchaseRecord
import com.example.data.model.ReceivableRecord
import com.example.data.model.ShiftRecord
import com.example.data.model.StockOpnameRecord
import com.example.data.model.StockOpnameTask
import com.example.data.model.TransactionRecord
import com.example.license.LicenseManager
import com.example.util.ShiftScheduleHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class PosRepository(
    private val posDao: PosDao,
    private val licenseManager: LicenseManager
) {

    // --- Products ---
    val allProducts: Flow<List<Product>> = posDao.getAllProducts()

    suspend fun insertProduct(product: Product): Long = withContext(Dispatchers.IO) {
        posDao.insertProduct(product)
    }

    suspend fun updateProduct(product: Product) = withContext(Dispatchers.IO) {
        posDao.updateProduct(product)
    }

    suspend fun deleteProduct(product: Product) = withContext(Dispatchers.IO) {
        posDao.deleteProduct(product)
    }

    suspend fun findProductByBarcode(code: String): Product? = withContext(Dispatchers.IO) {
        posDao.getProductBySku(code.trim())
    }

    // --- Shifts ---
    val allShifts: Flow<List<ShiftRecord>> = posDao.getAllShifts()
    val activeShift: Flow<ShiftRecord?> = posDao.getActiveShift()

    fun getTodayShifts(): Flow<List<ShiftRecord>> {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return posDao.getShiftsToday(calendar.timeInMillis)
    }

    suspend fun startNewShift(
        shiftNumber: Int,
        shiftName: String,
        cashierName: String,
        openingCash: Long,
        notes: String = ""
    ): Result<Long> = withContext(Dispatchers.IO) {
        // 1. Time Schedule Validation ala Alfamart
        val timeValidation = ShiftScheduleHelper.validateShiftOpening(shiftNumber)
        if (timeValidation.isFailure) {
            return@withContext Result.failure(
                timeValidation.exceptionOrNull() ?: Exception("Shift tidak sesuai dengan waktu operasional.")
            )
        }

        // 2. Prevent opening multiple active shifts
        val currentActive = posDao.getActiveShiftSync()
        if (currentActive != null) {
            return@withContext Result.failure(
                Exception("Shift #${currentActive.shiftNumber} (${currentActive.cashierName}) masih aktif! Tutup shift terlebih dahulu.")
            )
        }

        val newShift = ShiftRecord(
            shiftNumber = shiftNumber,
            shiftName = shiftName,
            cashierName = cashierName,
            startTime = System.currentTimeMillis(),
            openingCash = openingCash,
            expectedCash = openingCash,
            notes = notes,
            status = "ACTIVE"
        )
        val id = posDao.insertShift(newShift)
        Result.success(id)
    }

    suspend fun closeActiveShift(
        closingCash: Long,
        notes: String
    ): Result<ShiftRecord> = withContext(Dispatchers.IO) {
        val active = posDao.getActiveShiftSync()
            ?: return@withContext Result.failure(Exception("Tidak ada shift aktif untuk ditutup."))

        // Validation: Cannot close shift if there are pending carts!
        val pendingCount = posDao.getPendingCartCountSync()
        if (pendingCount > 0) {
            return@withContext Result.failure(
                Exception("Tidak bisa tutup shift! Masih ada $pendingCount transaksi pending (tertahan). Harap selesaikan atau batalkan semua transaksi pending terlebih dahulu.")
            )
        }

        val diff = closingCash - active.expectedCash
        val updated = active.copy(
            endTime = System.currentTimeMillis(),
            closingCash = closingCash,
            difference = diff,
            notes = if (notes.isNotBlank()) notes else active.notes,
            status = "CLOSED"
        )
        posDao.updateShift(updated)
        Result.success(updated)
    }

    // --- Transactions & Checkout ---
    val allTransactions: Flow<List<TransactionRecord>> = posDao.getAllTransactions()
    val totalTransactionsCount: Flow<Int> = posDao.getTotalTransactionsCountFlow()

    fun getTransactionsForShift(shiftId: Long): Flow<List<TransactionRecord>> =
        posDao.getTransactionsByShift(shiftId)

    suspend fun checkout(
        cartItems: List<CartItem>,
        paymentMethod: String,
        paidAmount: Long,
        customerName: String = "Pelanggan Umum",
        customerPhone: String = "",
        discount: Long = 0L,
        tax: Long = 0L,
        notes: String = "",
        member: MemberRecord? = null,
        pointsRedeemed: Int = 0,
        pointDiscount: Long = 0L,
        dueDateDays: Int = 14,
        cashierName: String = ""
    ): Result<TransactionRecord> = withContext(Dispatchers.IO) {
        if (cartItems.isEmpty()) {
            return@withContext Result.failure(Exception("Keranjang transaksi masih kosong."))
        }

        val license = licenseManager.getLicenseInfo()
        if (!license.canTransact) {
            return@withContext Result.failure(
                Exception("Batas uji coba (50 transaksi) telah tercapai. Silakan masukkan kunci lisensi untuk melanjutkan!")
            )
        }

        val active = posDao.getActiveShiftSync()
            ?: return@withContext Result.failure(
                Exception("Tidak ada shift yang aktif! Buka shift kasir terlebih dahulu sebelum transaksi.")
            )

        val subtotal = cartItems.sumOf { it.subtotal }
        val totalDiscount = discount + pointDiscount
        val totalAmount = (subtotal - totalDiscount + tax).coerceAtLeast(0L)
        val totalCost = cartItems.sumOf { it.totalCost }

        val isCash = paymentMethod == "TUNAI"
        val isPiutang = paymentMethod == "PIUTANG"

        if (isCash && paidAmount < totalAmount) {
            return@withContext Result.failure(Exception("Uang pembayaran kurang dari total tagihan!"))
        }

        val changeAmount = if (isCash) (paidAmount - totalAmount).coerceAtLeast(0L) else 0L

        // Generate receipt number e.g. TRX-20260920-142530
        val timeStr = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.getDefault()).format(Date())
        val receiptNo = "TRX-$timeStr"

        // Build items JSON
        val itemsArray = JSONArray()
        for (item in cartItems) {
            val obj = JSONObject().apply {
                put("id", item.product.id)
                put("name", item.product.name)
                put("category", item.product.category)
                put("price", item.customUnitPrice)
                put("costPrice", item.product.costPrice * item.unitMultiplier)
                put("quantity", item.quantity)
                put("unit", item.selectedUnit)
                put("unitMultiplier", item.unitMultiplier)
                put("subtotal", item.subtotal)
                if (item.note.isNotBlank()) put("note", item.note)
            }
            itemsArray.put(obj)
        }

        val effectiveCashier = cashierName.ifBlank { active.cashierName }.ifBlank { "Kasir" }
        val transaction = TransactionRecord(
            receiptNumber = receiptNo,
            shiftId = active.id,
            shiftNumber = active.shiftNumber,
            cashierName = effectiveCashier,
            customerName = if (customerName.isNotBlank()) customerName else (member?.name ?: "Pelanggan Umum"),
            subtotal = subtotal,
            discount = totalDiscount,
            tax = tax,
            totalAmount = totalAmount,
            totalCost = totalCost,
            paymentMethod = paymentMethod,
            paidAmount = if (isCash) paidAmount else if (isPiutang) paidAmount else totalAmount,
            changeAmount = changeAmount,
            timestamp = System.currentTimeMillis(),
            notes = notes,
            itemsJson = itemsArray.toString(),
            isSynced = false
        )

        val txId = posDao.insertTransaction(transaction)

        // Deduct product stock based on base units (e.g. 1 box of 24 = 24 base units)
        for (item in cartItems) {
            posDao.deductStock(item.product.id, item.totalBaseUnits)
        }

        // Update active shift stats
        val cashReceived = if (isCash) totalAmount else if (isPiutang) paidAmount else 0L
        val nonCashReceived = if (!isCash && !isPiutang) totalAmount else 0L

        val updatedShift = active.copy(
            totalTransactions = active.totalTransactions + 1,
            totalSales = active.totalSales + totalAmount,
            totalCash = active.totalCash + cashReceived,
            totalNonCash = active.totalNonCash + nonCashReceived,
            expectedCash = active.expectedCash + cashReceived
        )
        posDao.updateShift(updatedShift)

        // Handle Member Points
        if (member != null) {
            val pointSettings = licenseManager.getPointSettings()
            val newPointsEarned = if (pointSettings.spendPerPoint > 0) {
                (totalAmount / pointSettings.spendPerPoint).toInt()
            } else 0

            // Deduct redeemed points
            if (pointsRedeemed > 0) {
                posDao.deductMemberPoints(member.id, pointsRedeemed)
            }
            // Add earned points and record spend
            posDao.updateMemberPointsAndSpend(member.id, newPointsEarned, totalAmount)
        }

        // Handle Piutang (Receivables)
        if (isPiutang) {
            val remaining = (totalAmount - paidAmount).coerceAtLeast(0L)
            val dueMillis = System.currentTimeMillis() + (dueDateDays.toLong() * 24 * 60 * 60 * 1000L)
            val receivable = ReceivableRecord(
                receiptNumber = receiptNo,
                customerName = customerName.ifBlank { "Pelanggan Bon" },
                customerPhone = customerPhone,
                totalAmount = totalAmount,
                paidAmount = paidAmount,
                remainingAmount = remaining,
                status = if (remaining <= 0) "LUNAS" else "BELUM_LUNAS",
                dueDate = dueMillis,
                notes = notes
            )
            posDao.insertReceivable(receivable)
        }

        // Count for license tracking
        licenseManager.incrementTransactionCount()

        Result.success(transaction.copy(id = txId))
    }

    // --- Pending Carts ---
    val allPendingCarts: Flow<List<PendingCart>> = posDao.getAllPendingCarts()
    val pendingCartCount: Flow<Int> = posDao.getPendingCartCount()

    suspend fun savePendingCart(
        label: String,
        cashierName: String,
        items: List<CartItem>,
        member: MemberRecord? = null
    ): Long = withContext(Dispatchers.IO) {
        val itemsArray = JSONArray()
        for (item in items) {
            val obj = JSONObject().apply {
                put("id", item.product.id)
                put("name", item.product.name)
                put("category", item.product.category)
                put("price", item.product.sellPrice)
                put("costPrice", item.product.costPrice)
                put("quantity", item.quantity)
                put("unit", item.product.unit)
                put("stock", item.product.stock)
                put("sku", item.product.sku)
                put("subtotal", item.subtotal)
                if (item.note.isNotBlank()) put("note", item.note)
            }
            itemsArray.put(obj)
        }

        val pending = PendingCart(
            label = label.ifBlank { "Pending Transaksi" },
            cashierName = cashierName,
            timestamp = System.currentTimeMillis(),
            itemsJson = itemsArray.toString(),
            totalAmount = items.sumOf { it.subtotal },
            itemCount = items.sumOf { it.quantity },
            memberId = member?.id,
            memberName = member?.name,
            cartCode = "PC-${System.currentTimeMillis()}-${(1000..9999).random()}"
        )
        posDao.insertPendingCart(pending)
    }

    suspend fun deletePendingCart(id: Long) = withContext(Dispatchers.IO) {
        posDao.deletePendingCartById(id)
    }

    suspend fun deletePendingCartByCode(cartCode: String) = withContext(Dispatchers.IO) {
        posDao.deletePendingCartByCode(cartCode)
    }

    // --- Employees ---
    val allEmployees: Flow<List<Employee>> = posDao.getAllEmployees()

    suspend fun ensureDefaultEmployees() = withContext(Dispatchers.IO) {
        val count = posDao.getEmployeesCountSync()
        if (count == 0) {
            val defaultEmployees = listOf(
                Employee(
                    name = "Pak Hendra",
                    username = "hendra",
                    pin = "1234",
                    role = "OWNER",
                    canAccessCashier = true,
                    canVoidAndCancel = true,
                    canVoid = true,
                    canCancelCart = true,
                    canDeletePendingCart = true,
                    canOpenShift = true,
                    canStockOpname = true,
                    canSupplierPurchase = true,
                    canManageReceivables = true,
                    canViewReports = true,
                    canAccessSettings = true,
                    canManagePrinter = true,
                    canAddMember = true
                ),
                Employee(
                    name = "Siti Kasir",
                    username = "siti",
                    pin = "1111",
                    role = "KASIR",
                    canAccessCashier = true,
                    canVoidAndCancel = false,
                    canVoid = false,
                    canCancelCart = false,
                    canDeletePendingCart = false,
                    canOpenShift = true,
                    canStockOpname = false,
                    canSupplierPurchase = false,
                    canManageReceivables = false,
                    canViewReports = false,
                    canAccessSettings = false,
                    canManagePrinter = false,
                    canAddMember = false
                ),
                Employee(
                    name = "Budi Santoso",
                    username = "budi",
                    pin = "2222",
                    role = "SUPERVISOR",
                    canAccessCashier = true,
                    canVoidAndCancel = true,
                    canVoid = true,
                    canCancelCart = true,
                    canDeletePendingCart = true,
                    canOpenShift = true,
                    canStockOpname = true,
                    canSupplierPurchase = true,
                    canManageReceivables = true,
                    canViewReports = true,
                    canAccessSettings = false,
                    canManagePrinter = true,
                    canAddMember = true
                )
            )
            posDao.insertEmployees(defaultEmployees)
        }
    }

    suspend fun voidTransaction(
        transactionId: Long,
        reason: String,
        voidByEmployeeName: String
    ): Result<TransactionRecord> = withContext(Dispatchers.IO) {
        val tx = posDao.getTransactionById(transactionId)
            ?: return@withContext Result.failure(Exception("Transaksi #$transactionId tidak ditemukan."))

        if (tx.isVoid) {
            return@withContext Result.failure(Exception("Transaksi ${tx.receiptNumber} sudah pernah dibatalkan (VOID)."))
        }

        // 1. Restore product inventory stock
        try {
            val itemsArray = JSONArray(tx.itemsJson)
            for (i in 0 until itemsArray.length()) {
                val itemObj = itemsArray.getJSONObject(i)
                val productId = itemObj.optLong("id", 0L)
                val qty = itemObj.optInt("quantity", itemObj.optInt("qty", 1))
                val unitMultiplier = itemObj.optInt("unitMultiplier", 1)
                val totalBaseQty = qty * unitMultiplier
                if (productId > 0 && totalBaseQty > 0) {
                    posDao.addStock(productId, totalBaseQty)
                }
            }
        } catch (e: Exception) {
            // Safe fallback
        }

        // 2. Adjust active shift stats if this transaction is within active shift
        val activeShift = posDao.getActiveShiftSync()
        if (activeShift != null && activeShift.id == tx.shiftId) {
            val isCash = tx.paymentMethod == "TUNAI"
            val cashDeduct = if (isCash) tx.totalAmount else 0L
            val nonCashDeduct = if (!isCash && tx.paymentMethod != "PIUTANG") tx.totalAmount else 0L

            val updatedShift = activeShift.copy(
                totalSales = (activeShift.totalSales - tx.totalAmount).coerceAtLeast(0L),
                totalCash = (activeShift.totalCash - cashDeduct).coerceAtLeast(0L),
                totalNonCash = (activeShift.totalNonCash - nonCashDeduct).coerceAtLeast(0L),
                expectedCash = (activeShift.expectedCash - cashDeduct).coerceAtLeast(0L)
            )
            posDao.updateShift(updatedShift)
        }

        // 3. Mark transaction as VOID
        val updatedTx = tx.copy(
            status = "VOID",
            voidReason = reason.ifBlank { "Dibatalkan oleh kasir/supervisor" },
            voidBy = voidByEmployeeName,
            voidTimestamp = System.currentTimeMillis()
        )
        posDao.updateTransaction(updatedTx)

        Result.success(updatedTx)
    }

    suspend fun getEmployeeByPin(pin: String): Employee? = withContext(Dispatchers.IO) {
        posDao.getEmployeeByPin(pin)
    }

    suspend fun saveEmployee(employee: Employee): Long = withContext(Dispatchers.IO) {
        if (employee.id == 0L) {
            posDao.insertEmployee(employee)
        } else {
            posDao.updateEmployee(employee)
            employee.id
        }
    }

    suspend fun deleteEmployee(employee: Employee) = withContext(Dispatchers.IO) {
        posDao.deleteEmployee(employee)
    }

    // --- Members & Points ---
    val allMembers: Flow<List<MemberRecord>> = posDao.getAllMembers()

    suspend fun findMember(query: String): MemberRecord? = withContext(Dispatchers.IO) {
        posDao.getMemberByPhoneOrNumber(query.trim())
    }

    suspend fun saveMember(member: MemberRecord): Long = withContext(Dispatchers.IO) {
        if (member.id == 0L) {
            posDao.insertMember(member)
        } else {
            posDao.updateMember(member)
            member.id
        }
    }

    suspend fun deleteMember(member: MemberRecord) = withContext(Dispatchers.IO) {
        posDao.deleteMember(member)
    }

    fun getPointSettings(): PointSettings = licenseManager.getPointSettings()

    fun updatePointSettings(settings: PointSettings) = licenseManager.updatePointSettings(settings)

    // --- Receivables (Piutang) ---
    val allReceivables: Flow<List<ReceivableRecord>> = posDao.getAllReceivables()

    suspend fun payReceivable(id: Long, paymentAmount: Long, cashierName: String): Result<ReceivableRecord> = withContext(Dispatchers.IO) {
        val existing = posDao.getReceivableById(id)
            ?: return@withContext Result.failure(Exception("Data piutang tidak ditemukan."))

        val newPaid = existing.paidAmount + paymentAmount
        val newRemaining = (existing.totalAmount - newPaid).coerceAtLeast(0L)
        val newStatus = if (newRemaining <= 0) "LUNAS" else "BELUM_LUNAS"

        val updated = existing.copy(
            paidAmount = newPaid,
            remainingAmount = newRemaining,
            status = newStatus
        )
        posDao.updateReceivable(updated)

        // Add to active shift cash if shift is open
        val activeShift = posDao.getActiveShiftSync()
        if (activeShift != null) {
            val shiftUpdated = activeShift.copy(
                totalCash = activeShift.totalCash + paymentAmount,
                expectedCash = activeShift.expectedCash + paymentAmount
            )
            posDao.updateShift(shiftUpdated)
        }

        Result.success(updated)
    }

    // --- Stock Opname (SO) ---
    val allStockOpname: Flow<List<StockOpnameRecord>> = posDao.getAllStockOpname()
    val allStockOpnameTasks: Flow<List<StockOpnameTask>> = posDao.getAllStockOpnameTasks()

    fun getStockOpnameByTask(taskCode: String): Flow<List<StockOpnameRecord>> {
        return posDao.getStockOpnameByTask(taskCode)
    }

    suspend fun saveStockOpname(
        productId: Long,
        productName: String,
        sku: String,
        systemStock: Int,
        physicalStock: Int,
        reason: String,
        conductedBy: String,
        notes: String
    ): Result<Long> = withContext(Dispatchers.IO) {
        val diff = physicalStock - systemStock
        val record = StockOpnameRecord(
            productId = productId,
            productName = productName,
            sku = sku,
            systemStock = systemStock,
            physicalStock = physicalStock,
            difference = diff,
            reason = reason,
            conductedBy = conductedBy,
            notes = notes
        )
        val id = posDao.insertStockOpname(record)
        // Automatically adjust product inventory stock to physical count
        posDao.updateStock(productId, physicalStock)
        Result.success(id)
    }

    suspend fun finalizeStockOpnameBatch(
        taskCode: String,
        title: String,
        conductedBy: String,
        notes: String,
        items: List<StockOpnameRecord>
    ): Result<StockOpnameTask> = withContext(Dispatchers.IO) {
        try {
            val discrepancyItems = items.filter { it.difference != 0 }
            val totalDiscrepancyQty = items.sumOf { Math.abs(it.difference) }
            
            // Build snapshot JSON
            val snapshotArray = JSONArray()
            for (rec in items) {
                val obj = JSONObject().apply {
                    put("productId", rec.productId)
                    put("productName", rec.productName)
                    put("sku", rec.sku)
                    put("systemStock", rec.systemStock)
                    put("physicalStock", rec.physicalStock)
                    put("difference", rec.difference)
                    put("reason", rec.reason)
                    put("notes", rec.notes)
                }
                snapshotArray.put(obj)
            }

            val task = StockOpnameTask(
                taskCode = taskCode,
                title = title.ifBlank { "Stok Opname Toko" },
                createdAt = System.currentTimeMillis(),
                completedAt = System.currentTimeMillis(),
                conductedBy = conductedBy,
                status = "COMPLETED",
                totalItems = items.size,
                discrepancyCount = discrepancyItems.size,
                discrepancyQty = totalDiscrepancyQty,
                notes = notes,
                itemsSnapshotJson = snapshotArray.toString()
            )

            val taskId = posDao.insertStockOpnameTask(task)

            // Save individual stock opname records
            val recordsToInsert = items.map { it.copy(taskCode = taskCode, conductedBy = conductedBy) }
            posDao.insertStockOpnames(recordsToInsert)

            // Update physical inventory for all items
            for (item in items) {
                posDao.updateStock(item.productId, item.physicalStock)
            }

            Result.success(task.copy(id = taskId))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // --- Purchases (Pembelian Supplier) ---
    val allPurchases: Flow<List<PurchaseRecord>> = posDao.getAllPurchases()

    suspend fun savePurchase(
        invoiceNumber: String,
        supplierName: String,
        supplierPhone: String,
        paymentType: String,
        totalAmount: Long,
        itemsJson: String,
        itemsList: List<Triple<Long, Int, Long>>, // productId, qty, buyPrice
        notes: String,
        receivedBy: String
    ): Result<Long> = withContext(Dispatchers.IO) {
        val purchase = PurchaseRecord(
            invoiceNumber = invoiceNumber,
            supplierName = supplierName,
            supplierPhone = supplierPhone,
            paymentType = paymentType,
            totalAmount = totalAmount,
            itemsJson = itemsJson,
            notes = notes,
            receivedBy = receivedBy
        )
        val id = posDao.insertPurchase(purchase)

        // Add stock and update buy/cost price for each purchased item
        for (item in itemsList) {
            val prodId = item.first
            val qty = item.second
            val buyPrice = item.third
            posDao.addStock(prodId, qty)
            val currentProd = posDao.getProductById(prodId)
            if (currentProd != null) {
                posDao.updateProduct(currentProd.copy(costPrice = buyPrice))
            }
        }

        Result.success(id)
    }

    suspend fun addStock(productId: Long, qty: Int): Result<Unit> = withContext(Dispatchers.IO) {
        posDao.addStock(productId, qty)
        Result.success(Unit)
    }

    suspend fun deductStock(productId: Long, qty: Int): Result<Unit> = withContext(Dispatchers.IO) {
        posDao.deductStock(productId, qty)
        Result.success(Unit)
    }

    // --- Product Returns (Retur Barang) ---
    val allProductReturns: Flow<List<com.example.data.model.ProductReturnRecord>> = posDao.getAllProductReturns()

    suspend fun saveProductReturn(
        productId: Long,
        productName: String,
        qty: Int,
        returnType: String,
        reason: String,
        customerOrSupplier: String,
        notes: String
    ): Result<Long> = withContext(Dispatchers.IO) {
        if (returnType == "MASUK_STOK") {
            posDao.addStock(productId, qty)
        } else {
            posDao.deductStock(productId, qty)
        }
        val record = com.example.data.model.ProductReturnRecord(
            productId = productId,
            productName = productName,
            qty = qty,
            returnType = returnType,
            reason = reason,
            customerOrSupplier = customerOrSupplier,
            notes = notes,
            timestamp = System.currentTimeMillis()
        )
        val id = posDao.insertProductReturn(record)
        Result.success(id)
    }

    // --- License Access ---
    fun getLicenseInfo(): LicenseInfo = licenseManager.getLicenseInfo()

    fun getPrinterSettings(): com.example.data.model.PrinterSettings = licenseManager.getPrinterSettings()

    fun updatePrinterSettings(settings: com.example.data.model.PrinterSettings) = licenseManager.updatePrinterSettings(settings)

    fun updateStoreInfo(name: String, address: String, phone: String, footer: String, logoUri: String? = null) =
        licenseManager.updateStoreInfo(name, address, phone, footer, logoUri)

    fun updateStoreLogo(logoUri: String) = licenseManager.updateStoreLogo(logoUri)

    fun updateQrisSettings(imageUri: String, merchantName: String, nmid: String) =
        licenseManager.updateQrisSettings(imageUri, merchantName, nmid)

    fun activateLicense(key: String): Result<String> = licenseManager.activateLicense(key)

    fun generateLicenseKey(targetDeviceId: String, tier: String): String =
        licenseManager.generateLicenseKey(targetDeviceId, tier)

    companion object {
        fun formatRupiah(amount: Long): String {
            val formatter = NumberFormat.getNumberInstance(Locale("id", "ID"))
            return "Rp " + formatter.format(amount)
        }

        fun formatDate(timestamp: Long): String {
            val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("id", "ID"))
            return sdf.format(Date(timestamp))
        }

        fun formatTime(timestamp: Long): String {
            val sdf = SimpleDateFormat("HH:mm", Locale("id", "ID"))
            return sdf.format(Date(timestamp))
        }
    }
}

