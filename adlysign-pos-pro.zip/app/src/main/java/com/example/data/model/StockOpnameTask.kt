package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stock_opname_tasks")
data class StockOpnameTask(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val taskCode: String,
    val title: String = "Stok Opname Toko",
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null,
    val conductedBy: String = "Admin / Supervisor",
    val status: String = "DRAFT", // "DRAFT", "REVIEW", "COMPLETED"
    val totalItems: Int = 0,
    val discrepancyCount: Int = 0,
    val discrepancyQty: Int = 0,
    val discrepancyValue: Long = 0L,
    val notes: String = "",
    val itemsSnapshotJson: String = ""
)
