package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.Employee
import com.example.data.model.MemberRecord
import com.example.data.model.PendingCart
import com.example.data.model.Product
import com.example.data.model.ProductReturnRecord
import com.example.data.model.PurchaseRecord
import com.example.data.model.ReceivableRecord
import com.example.data.model.ShiftRecord
import com.example.data.model.StockOpnameRecord
import com.example.data.model.StockOpnameTask
import com.example.data.model.TransactionRecord
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        Product::class,
        ShiftRecord::class,
        TransactionRecord::class,
        Employee::class,
        PendingCart::class,
        MemberRecord::class,
        ReceivableRecord::class,
        StockOpnameRecord::class,
        StockOpnameTask::class,
        PurchaseRecord::class,
        ProductReturnRecord::class
    ],
    version = 6,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun posDao(): PosDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        private val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE pending_carts ADD COLUMN cartCode TEXT NOT NULL DEFAULT ''")
            }
        }

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "pos_database.db"
                )
                    .addMigrations(MIGRATION_5_6)
                    .fallbackToDestructiveMigration()
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database.posDao())
                    }
                }
            }

            private suspend fun populateInitialData(dao: PosDao) {
                // Seed Default Employees
                val defaultEmployees = listOf(
                    Employee(
                        name = "Pak Hendra",
                        username = "hendra",
                        pin = "1234",
                        role = "OWNER",
                        canAccessCashier = true,
                        canVoidAndCancel = true,
                        canVoid = true,
                        canCancelCart = true,
                        canDeletePendingCart = true,
                        canOpenShift = true,
                        canStockOpname = true,
                        canSupplierPurchase = true,
                        canManageReceivables = true,
                        canViewReports = true,
                        canAccessSettings = true,
                        canManagePrinter = true,
                        canAddMember = true
                    ),
                    Employee(
                        name = "Siti Kasir",
                        username = "siti",
                        pin = "1111",
                        role = "KASIR",
                        canAccessCashier = true,
                        canVoidAndCancel = false,
                        canVoid = false,
                        canCancelCart = false,
                        canDeletePendingCart = false,
                        canOpenShift = true,
                        canStockOpname = false,
                        canSupplierPurchase = false,
                        canManageReceivables = false,
                        canViewReports = false,
                        canAccessSettings = false,
                        canManagePrinter = false,
                        canAddMember = false
                    ),
                    Employee(
                        name = "Budi Santoso",
                        username = "budi",
                        pin = "2222",
                        role = "SUPERVISOR",
                        canAccessCashier = true,
                        canVoidAndCancel = true,
                        canVoid = true,
                        canCancelCart = true,
                        canDeletePendingCart = true,
                        canOpenShift = true,
                        canStockOpname = true,
                        canSupplierPurchase = true,
                        canManageReceivables = true,
                        canViewReports = true,
                        canAccessSettings = false,
                        canManagePrinter = true,
                        canAddMember = true
                    )
                )
                dao.insertEmployees(defaultEmployees)

                // Seed Default Members
                val defaultMembers = listOf(
                    MemberRecord(
                        memberNumber = "MBR-1001",
                        name = "Bpk. Andi Prasetyo",
                        phone = "081234567890",
                        points = 250,
                        totalSpend = 1500000L
                    ),
                    MemberRecord(
                        memberNumber = "MBR-1002",
                        name = "Ibu Dewi Lestari",
                        phone = "085712345678",
                        points = 180,
                        totalSpend = 980000L
                    ),
                    MemberRecord(
                        memberNumber = "MBR-1003",
                        name = "Sdr. Kevin Sanjaya",
                        phone = "082198765432",
                        points = 80,
                        totalSpend = 420000L
                    )
                )
                dao.insertMembers(defaultMembers)

                // Prepopulate realistic Indonesian retail & F&B catalog
                val defaultProducts = listOf(
                    Product(
                        name = "Kopi Susu Aren",
                        sku = "KOP-001",
                        category = "Minuman",
                        sellPrice = 18000,
                        costPrice = 9000,
                        stock = 85,
                        unit = "cup"
                    ),
                    Product(
                        name = "Teh Tarik Ice",
                        sku = "TEH-002",
                        category = "Minuman",
                        sellPrice = 12000,
                        costPrice = 5000,
                        stock = 120,
                        unit = "cup"
                    ),
                    Product(
                        name = "Matcha Latte",
                        sku = "MAT-003",
                        category = "Minuman",
                        sellPrice = 22000,
                        costPrice = 11000,
                        stock = 60,
                        unit = "cup"
                    ),
                    Product(
                        name = "Mie Goreng Spesial",
                        sku = "MIE-004",
                        category = "Makanan",
                        sellPrice = 20000,
                        costPrice = 11000,
                        stock = 50,
                        unit = "porsi"
                    ),
                    Product(
                        name = "Nasi Goreng Ayam",
                        sku = "NAS-005",
                        category = "Makanan",
                        sellPrice = 25000,
                        costPrice = 14000,
                        stock = 45,
                        unit = "porsi"
                    ),
                    Product(
                        name = "Ayam Geprek Sambal Bawang",
                        sku = "AYM-006",
                        category = "Makanan",
                        sellPrice = 23000,
                        costPrice = 13000,
                        stock = 40,
                        unit = "porsi"
                    ),
                    Product(
                        name = "Roti Bakar Cokelat Keju",
                        sku = "ROT-007",
                        category = "Snack",
                        sellPrice = 16000,
                        costPrice = 8000,
                        stock = 70,
                        unit = "porsi"
                    ),
                    Product(
                        name = "Kentang Goreng (French Fries)",
                        sku = "FRY-008",
                        category = "Snack",
                        sellPrice = 15000,
                        costPrice = 7500,
                        stock = 90,
                        unit = "porsi"
                    ),
                    Product(
                        name = "Air Mineral 600ml",
                        sku = "AIR-009",
                        category = "Minuman",
                        sellPrice = 5000,
                        costPrice = 2800,
                        stock = 150,
                        unit = "botol"
                    ),
                    Product(
                        name = "Keripik Singkong Balado",
                        sku = "KRP-010",
                        category = "Snack",
                        sellPrice = 10000,
                        costPrice = 6000,
                        stock = 35,
                        unit = "bungkus"
                    ),
                    Product(
                        name = "Minyak Goreng 1L",
                        sku = "MYK-011",
                        category = "Sembako",
                        sellPrice = 18500,
                        costPrice = 16500,
                        stock = 25,
                        unit = "pouch"
                    ),
                    Product(
                        name = "Beras Premium 5kg",
                        sku = "BRS-012",
                        category = "Sembako",
                        sellPrice = 74000,
                        costPrice = 68000,
                        stock = 15,
                        unit = "karung"
                    )
                )
                dao.insertProducts(defaultProducts)

                // Start default Shift 1 (Pagi) so cashier is immediately ready
                val initialShift = ShiftRecord(
                    shiftNumber = 1,
                    shiftName = "Shift 1 - Pagi (07:00 - 15:00)",
                    cashierName = "Kasir Utama",
                    openingCash = 200000L,
                    expectedCash = 200000L,
                    notes = "Shift pertama awal pembukaan toko",
                    status = "ACTIVE"
                )
                dao.insertShift(initialShift)

                // Initial sample purchase record
                dao.insertPurchase(
                    PurchaseRecord(
                        invoiceNumber = "INV-SUP-001",
                        supplierName = "PT Indomarco Distribusi",
                        supplierPhone = "08123456789",
                        date = System.currentTimeMillis() - 86400000L,
                        paymentType = "TUNAI",
                        totalAmount = 650000L,
                        itemsJson = """[{"productId":1,"name":"Kopi Susu Gula Aren","buyPrice":10000,"qty":20,"subtotal":200000},{"productId":4,"name":"Indomie Goreng Original","buyPrice":2600,"qty":100,"subtotal":260000},{"productId":11,"name":"Minyak Goreng 1L","buyPrice":16500,"qty":10,"subtotal":165000}]""",
                        notes = "Kulakan mingguan sembako & kopi",
                        receivedBy = "Kasir Utama"
                    )
                )

                // Initial sample stock opname
                dao.insertStockOpname(
                    StockOpnameRecord(
                        date = System.currentTimeMillis() - 43200000L,
                        productId = 4,
                        productName = "Indomie Goreng Original",
                        sku = "IND-004",
                        systemStock = 60,
                        physicalStock = 58,
                        difference = -2,
                        reason = "Rusak / Basi",
                        conductedBy = "Supervisor",
                        notes = "Kemasan rusak saat display"
                    )
                )

                // Initial sample product return
                dao.insertProductReturn(
                    ProductReturnRecord(
                        productId = 2,
                        productName = "Teh Melati Wangi",
                        qty = 1,
                        returnType = "MASUK_STOK",
                        reason = "Salah Beli / Ukuran",
                        customerOrSupplier = "Ibu Sri",
                        notes = "Tukar varian teh",
                        timestamp = System.currentTimeMillis() - 36000000L
                    )
                )

                // Initial sample receivable (piutang)
                dao.insertReceivable(
                    ReceivableRecord(
                        receiptNumber = "BON-2026-001",
                        customerName = "Pak Haji Rahmat",
                        customerPhone = "08198765432",
                        totalAmount = 150000L,
                        paidAmount = 50000L,
                        remainingAmount = 100000L,
                        status = "BELUM_LUNAS",
                        dueDate = System.currentTimeMillis() + (7 * 86400000L),
                        createdAt = System.currentTimeMillis() - 86400000L,
                        notes = "Sembako beras dan minyak goreng"
                    )
                )
            }
        }
    }
}
