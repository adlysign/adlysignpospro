package com.example.data.model

data class LicenseInfo(
    val deviceId: String,
    val storeName: String = "Toko Modern Kasir",
    val storeAddress: String = "Jl. Nusantara No. 88",
    val storePhone: String = "0812-3456-7890",
    val receiptFooter: String = "Terima kasih atas kunjungan Anda!",
    val storeLogoUri: String = "",
    val qrisImageUri: String = "",
    val qrisMerchantName: String = "",
    val qrisNmid: String = "",
    val licenseKey: String = "",
    val licenseTier: String = "TRIAL", // "TRIAL", "PRO", "ENTERPRISE"
    val isActivated: Boolean = false,
    val isLifetime: Boolean = true,
    val maxTrialTransactions: Int = 50,
    val currentTransactionsCount: Int = 0,
    val activationDate: Long = 0L,
    val expiryDate: Long = 0L
) {
    val remainingTrialTransactions: Int
        get() = (maxTrialTransactions - currentTransactionsCount).coerceAtLeast(0)

    val canTransact: Boolean
        get() = isActivated || remainingTrialTransactions > 0
}
