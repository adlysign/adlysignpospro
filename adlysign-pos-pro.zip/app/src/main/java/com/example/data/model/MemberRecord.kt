package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "members")
data class MemberRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val memberNumber: String = "", // e.g. "MBR-1001"
    val name: String,
    val phone: String,
    val points: Int = 0,
    val totalSpend: Long = 0L,
    val joinDate: Long = System.currentTimeMillis()
)
