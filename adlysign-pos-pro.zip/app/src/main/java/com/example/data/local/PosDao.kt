package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Product
import com.example.data.model.ShiftRecord
import com.example.data.model.TransactionRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface PosDao {

    // --- Products ---
    @Query("SELECT * FROM products ORDER BY name ASC")
    fun getAllProducts(): Flow<List<Product>>

    @Query("SELECT * FROM products ORDER BY name ASC")
    suspend fun getAllProductsSync(): List<Product>

    @Query("SELECT * FROM products WHERE id = :id")
    suspend fun getProductById(id: Long): Product?

    @Query("SELECT * FROM products WHERE sku = :sku LIMIT 1")
    suspend fun getProductBySku(sku: String): Product?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: Product): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<Product>)

    @Update
    suspend fun updateProduct(product: Product)

    @Delete
    suspend fun deleteProduct(product: Product)

    @Query("UPDATE products SET stock = stock - :quantity, updatedAt = :timestamp WHERE id = :productId")
    suspend fun deductStock(productId: Long, quantity: Int, timestamp: Long = System.currentTimeMillis())

    @Query("UPDATE products SET stock = stock + :quantity, updatedAt = :timestamp WHERE id = :productId")
    suspend fun addStock(productId: Long, quantity: Int, timestamp: Long = System.currentTimeMillis())

    @Query("UPDATE products SET stock = :newStock, updatedAt = :timestamp WHERE id = :productId")
    suspend fun updateStock(productId: Long, newStock: Int, timestamp: Long = System.currentTimeMillis())

    // --- Shifts ---
    @Query("SELECT * FROM shifts ORDER BY id DESC")
    fun getAllShifts(): Flow<List<ShiftRecord>>

    @Query("SELECT * FROM shifts WHERE status = 'ACTIVE' LIMIT 1")
    fun getActiveShift(): Flow<ShiftRecord?>

    @Query("SELECT * FROM shifts WHERE status = 'ACTIVE' LIMIT 1")
    suspend fun getActiveShiftSync(): ShiftRecord?

    @Query("SELECT * FROM shifts WHERE id = :id")
    suspend fun getShiftById(id: Long): ShiftRecord?

    @Query("SELECT * FROM shifts WHERE startTime >= :startOfDay ORDER BY shiftNumber ASC")
    fun getShiftsToday(startOfDay: Long): Flow<List<ShiftRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShift(shift: ShiftRecord): Long

    @Update
    suspend fun updateShift(shift: ShiftRecord)

    // --- Transactions ---
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<TransactionRecord>>

    @Query("SELECT * FROM transactions WHERE shiftId = :shiftId ORDER BY timestamp DESC")
    fun getTransactionsByShift(shiftId: Long): Flow<List<TransactionRecord>>

    @Query("SELECT * FROM transactions WHERE shiftId = :shiftId")
    suspend fun getTransactionsByShiftSync(shiftId: Long): List<TransactionRecord>

    @Query("SELECT * FROM transactions WHERE isSynced = 0")
    suspend fun getUnsyncedTransactions(): List<TransactionRecord>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(tx: TransactionRecord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransactions(txList: List<TransactionRecord>)

    @Query("UPDATE transactions SET isSynced = 1 WHERE id IN (:ids)")
    suspend fun markTransactionsSynced(ids: List<Long>)

    @Query("SELECT COUNT(*) FROM transactions")
    fun getTotalTransactionsCountFlow(): Flow<Int>

    @Query("SELECT COUNT(*) FROM transactions")
    suspend fun getTotalTransactionsCount(): Int

    // --- Employees ---
    @Query("SELECT COUNT(*) FROM employees")
    suspend fun getEmployeesCountSync(): Int

    @Query("SELECT * FROM employees ORDER BY id ASC")
    fun getAllEmployees(): Flow<List<com.example.data.model.Employee>>

    @Query("SELECT * FROM employees WHERE pin = :pin AND isActive = 1 LIMIT 1")
    suspend fun getEmployeeByPin(pin: String): com.example.data.model.Employee?

    @Query("SELECT * FROM employees WHERE id = :id LIMIT 1")
    suspend fun getEmployeeById(id: Long): com.example.data.model.Employee?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEmployee(employee: com.example.data.model.Employee): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEmployees(employees: List<com.example.data.model.Employee>)

    @Update
    suspend fun updateEmployee(employee: com.example.data.model.Employee)

    @Delete
    suspend fun deleteEmployee(employee: com.example.data.model.Employee)

    // --- Pending Carts ---
    @Query("SELECT * FROM pending_carts ORDER BY timestamp DESC")
    fun getAllPendingCarts(): Flow<List<com.example.data.model.PendingCart>>

    @Query("SELECT COUNT(*) FROM pending_carts")
    fun getPendingCartCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM pending_carts")
    suspend fun getPendingCartCountSync(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPendingCart(pendingCart: com.example.data.model.PendingCart): Long

    @Delete
    suspend fun deletePendingCart(pendingCart: com.example.data.model.PendingCart)

    @Query("DELETE FROM pending_carts WHERE id = :id")
    suspend fun deletePendingCartById(id: Long)

    // --- Members ---
    @Query("SELECT * FROM members ORDER BY name ASC")
    fun getAllMembers(): Flow<List<com.example.data.model.MemberRecord>>

    @Query("SELECT * FROM members WHERE id = :id LIMIT 1")
    suspend fun getMemberById(id: Long): com.example.data.model.MemberRecord?

    @Query("SELECT * FROM members WHERE phone = :phone OR memberNumber = :phone LIMIT 1")
    suspend fun getMemberByPhoneOrNumber(phone: String): com.example.data.model.MemberRecord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMember(member: com.example.data.model.MemberRecord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMembers(members: List<com.example.data.model.MemberRecord>)

    @Update
    suspend fun updateMember(member: com.example.data.model.MemberRecord)

    @Delete
    suspend fun deleteMember(member: com.example.data.model.MemberRecord)

    @Query("UPDATE members SET points = points + :pointsToAdd, totalSpend = totalSpend + :spendToAdd WHERE id = :memberId")
    suspend fun updateMemberPointsAndSpend(memberId: Long, pointsToAdd: Int, spendToAdd: Long)

    @Query("UPDATE members SET points = points - :pointsToDeduct WHERE id = :memberId")
    suspend fun deductMemberPoints(memberId: Long, pointsToDeduct: Int)

    // --- Receivables (Piutang) ---
    @Query("SELECT * FROM receivables ORDER BY createdAt DESC")
    fun getAllReceivables(): Flow<List<com.example.data.model.ReceivableRecord>>

    @Query("SELECT * FROM receivables WHERE id = :id LIMIT 1")
    suspend fun getReceivableById(id: Long): com.example.data.model.ReceivableRecord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReceivable(receivable: com.example.data.model.ReceivableRecord): Long

    @Update
    suspend fun updateReceivable(receivable: com.example.data.model.ReceivableRecord)

    @Delete
    suspend fun deleteReceivable(receivable: com.example.data.model.ReceivableRecord)

    // --- Stock Opname ---
    @Query("SELECT * FROM stock_opname ORDER BY date DESC")
    fun getAllStockOpname(): Flow<List<com.example.data.model.StockOpnameRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStockOpname(record: com.example.data.model.StockOpnameRecord): Long

    // --- Purchases (Pembelian Supplier) ---
    @Query("SELECT * FROM purchases ORDER BY date DESC")
    fun getAllPurchases(): Flow<List<com.example.data.model.PurchaseRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPurchase(purchase: com.example.data.model.PurchaseRecord): Long
}
