package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Product
import com.example.data.model.ShiftRecord
import com.example.data.model.TransactionRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface PosDao {
    // --- Products ---
    @Query("SELECT * FROM products ORDER BY name ASC")
    fun getAllProducts(): Flow<List<Product>>

    @Query("SELECT * FROM products ORDER BY name ASC")
    suspend fun getAllProductsSync(): List<Product>

    @Query("SELECT * FROM products WHERE id = :id")
    suspend fun getProductById(id: Long): Product?

    @Query("SELECT * FROM products WHERE sku = :sku LIMIT 1")
    suspend fun getProductBySku(sku: String): Product?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: Product): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<Product>)

    @Update
    suspend fun updateProduct(product: Product)

    @Delete
    suspend fun deleteProduct(product: Product)

    @Query("UPDATE products SET stock = stock - :quantity, updatedAt = :timestamp WHERE id = :productId")
    suspend fun deductStock(productId: Long, quantity: Int, timestamp: Long = System.currentTimeMillis())

    @Query("UPDATE products SET stock = stock + :quantity, updatedAt = :timestamp WHERE id = :productId")
    suspend fun addStock(productId: Long, quantity: Int, timestamp: Long = System.currentTimeMillis())

    @Query("UPDATE products SET stock = :newStock, updatedAt = :timestamp WHERE id = :productId")
    suspend fun updateStock(productId: Long, newStock: Int, timestamp: Long = System.currentTimeMillis())

    @Query("DELETE FROM products")
    suspend fun clearAllProducts()

    // --- Shifts ---
    @Query("SELECT * FROM shifts ORDER BY id ASC")
    suspend fun getAllShiftsSync(): List<ShiftRecord>

    @Query("SELECT * FROM shifts ORDER BY id DESC")
    fun getAllShifts(): Flow<List<ShiftRecord>>

    @Query("SELECT * FROM shifts WHERE status = 'ACTIVE' LIMIT 1")
    fun getActiveShift(): Flow<ShiftRecord?>

    @Query("SELECT * FROM shifts WHERE status = 'ACTIVE' LIMIT 1")
    suspend fun getActiveShiftSync(): ShiftRecord?

    @Query("SELECT * FROM shifts WHERE id = :id")
    suspend fun getShiftById(id: Long): ShiftRecord?

    @Query("SELECT * FROM shifts WHERE startTime >= :startOfDay ORDER BY shiftNumber ASC")
    fun getShiftsToday(startOfDay: Long): Flow<List<ShiftRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShift(shift: ShiftRecord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShifts(shifts: List<ShiftRecord>)

    @Update
    suspend fun updateShift(shift: ShiftRecord)

    @Query("DELETE FROM shifts")
    suspend fun clearAllShifts()

    // --- Transactions ---
    @Query("SELECT * FROM transactions ORDER BY id ASC")
    suspend fun getAllTransactionsSync(): List<TransactionRecord>

    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<TransactionRecord>>

    @Query("SELECT * FROM transactions WHERE shiftId = :shiftId ORDER BY timestamp DESC")
    fun getTransactionsByShift(shiftId: Long): Flow<List<TransactionRecord>>

    @Query("SELECT * FROM transactions WHERE shiftId = :shiftId")
    suspend fun getTransactionsByShiftSync(shiftId: Long): List<TransactionRecord>

    @Query("SELECT * FROM transactions WHERE isSynced = 0")
    suspend fun getUnsyncedTransactions(): List<TransactionRecord>

    @Query("SELECT * FROM transactions WHERE id = :id LIMIT 1")
    suspend fun getTransactionById(id: Long): TransactionRecord?

    @Query("SELECT * FROM transactions WHERE receiptNumber = :receiptNumber LIMIT 1")
    suspend fun getTransactionByReceiptNumber(receiptNumber: String): TransactionRecord?

    @Query("SELECT * FROM transactions ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecentTransactionsSync(limit: Int = 300): List<TransactionRecord>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(tx: TransactionRecord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransactions(txList: List<TransactionRecord>)

    @Update
    suspend fun updateTransaction(tx: TransactionRecord)

    @Query("UPDATE transactions SET isSynced = 1 WHERE id IN (:ids)")
    suspend fun markTransactionsSynced(ids: List<Long>)

    @Query("SELECT COUNT(*) FROM transactions")
    fun getTotalTransactionsCountFlow(): Flow<Int>

    @Query("SELECT COUNT(*) FROM transactions")
    suspend fun getTotalTransactionsCount(): Int

    @Query("DELETE FROM transactions")
    suspend fun clearAllTransactions()

    // --- Employees ---
    @Query("SELECT COUNT(*) FROM employees")
    suspend fun getEmployeesCountSync(): Int

    @Query("SELECT * FROM employees ORDER BY id ASC")
    fun getAllEmployees(): Flow<List<com.example.data.model.Employee>>

    @Query("SELECT * FROM employees ORDER BY id ASC")
    suspend fun getAllEmployeesSync(): List<com.example.data.model.Employee>

    @Query("SELECT * FROM employees WHERE pin = :pin AND isActive = 1 LIMIT 1")
    suspend fun getEmployeeByPin(pin: String): com.example.data.model.Employee?

    @Query("SELECT * FROM employees WHERE id = :id LIMIT 1")
    suspend fun getEmployeeById(id: Long): com.example.data.model.Employee?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEmployee(employee: com.example.data.model.Employee): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEmployees(employees: List<com.example.data.model.Employee>)

    @Update
    suspend fun updateEmployee(employee: com.example.data.model.Employee)

    @Delete
    suspend fun deleteEmployee(employee: com.example.data.model.Employee)

    @Query("DELETE FROM employees")
    suspend fun clearAllEmployees()

    // --- Pending Carts ---
    @Query("SELECT * FROM pending_carts ORDER BY timestamp DESC")
    fun getAllPendingCarts(): Flow<List<com.example.data.model.PendingCart>>

    @Query("SELECT * FROM pending_carts ORDER BY timestamp DESC")
    suspend fun getAllPendingCartsSync(): List<com.example.data.model.PendingCart>

    @Query("SELECT COUNT(*) FROM pending_carts")
    fun getPendingCartCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM pending_carts")
    suspend fun getPendingCartCountSync(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPendingCart(pendingCart: com.example.data.model.PendingCart): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPendingCarts(pendingCarts: List<com.example.data.model.PendingCart>)

    @Delete
    suspend fun deletePendingCart(pendingCart: com.example.data.model.PendingCart)

    @Query("DELETE FROM pending_carts WHERE id = :id")
    suspend fun deletePendingCartById(id: Long)

    @Query("SELECT * FROM pending_carts WHERE cartCode = :cartCode LIMIT 1")
    suspend fun getPendingCartByCode(cartCode: String): com.example.data.model.PendingCart?

    @Query("DELETE FROM pending_carts WHERE cartCode = :cartCode")
    suspend fun deletePendingCartByCode(cartCode: String)

    @Query("DELETE FROM pending_carts")
    suspend fun clearAllPendingCarts()

    // --- Members ---
    @Query("SELECT * FROM members ORDER BY name ASC")
    fun getAllMembers(): Flow<List<com.example.data.model.MemberRecord>>

    @Query("SELECT * FROM members ORDER BY id ASC")
    suspend fun getAllMembersSync(): List<com.example.data.model.MemberRecord>

    @Query("SELECT * FROM members WHERE id = :id LIMIT 1")
    suspend fun getMemberById(id: Long): com.example.data.model.MemberRecord?

    @Query("SELECT * FROM members WHERE phone = :phone OR memberNumber = :phone LIMIT 1")
    suspend fun getMemberByPhoneOrNumber(phone: String): com.example.data.model.MemberRecord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMember(member: com.example.data.model.MemberRecord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMembers(members: List<com.example.data.model.MemberRecord>)

    @Update
    suspend fun updateMember(member: com.example.data.model.MemberRecord)

    @Delete
    suspend fun deleteMember(member: com.example.data.model.MemberRecord)

    @Query("DELETE FROM members")
    suspend fun clearAllMembers()

    @Query("UPDATE members SET points = points + :pointsToAdd, totalSpend = totalSpend + :spendToAdd WHERE id = :memberId")
    suspend fun updateMemberPointsAndSpend(memberId: Long, pointsToAdd: Int, spendToAdd: Long)

    @Query("UPDATE members SET points = points - :pointsToDeduct WHERE id = :memberId")
    suspend fun deductMemberPoints(memberId: Long, pointsToDeduct: Int)

    // --- Receivables (Piutang) ---
    @Query("SELECT * FROM receivables ORDER BY createdAt DESC")
    fun getAllReceivables(): Flow<List<com.example.data.model.ReceivableRecord>>

    @Query("SELECT * FROM receivables ORDER BY createdAt DESC")
    suspend fun getAllReceivablesSync(): List<com.example.data.model.ReceivableRecord>

    @Query("SELECT * FROM receivables WHERE id = :id LIMIT 1")
    suspend fun getReceivableById(id: Long): com.example.data.model.ReceivableRecord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReceivable(receivable: com.example.data.model.ReceivableRecord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReceivables(receivables: List<com.example.data.model.ReceivableRecord>)

    @Update
    suspend fun updateReceivable(receivable: com.example.data.model.ReceivableRecord)

    @Delete
    suspend fun deleteReceivable(receivable: com.example.data.model.ReceivableRecord)

    @Query("DELETE FROM receivables")
    suspend fun clearAllReceivables()

    // --- Stock Opname ---
    @Query("SELECT * FROM stock_opname ORDER BY date DESC")
    fun getAllStockOpname(): Flow<List<com.example.data.model.StockOpnameRecord>>

    @Query("SELECT * FROM stock_opname ORDER BY date DESC")
    suspend fun getAllStockOpnameSync(): List<com.example.data.model.StockOpnameRecord>

    @Query("SELECT * FROM stock_opname WHERE taskCode = :taskCode ORDER BY id ASC")
    fun getStockOpnameByTask(taskCode: String): Flow<List<com.example.data.model.StockOpnameRecord>>

    @Query("SELECT * FROM stock_opname WHERE taskCode = :taskCode ORDER BY id ASC")
    suspend fun getStockOpnameByTaskSync(taskCode: String): List<com.example.data.model.StockOpnameRecord>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStockOpname(record: com.example.data.model.StockOpnameRecord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStockOpnames(records: List<com.example.data.model.StockOpnameRecord>)

    @Query("DELETE FROM stock_opname")
    suspend fun clearAllStockOpname()

    // --- Stock Opname Tasks ---
    @Query("SELECT * FROM stock_opname_tasks ORDER BY createdAt DESC")
    fun getAllStockOpnameTasks(): Flow<List<com.example.data.model.StockOpnameTask>>

    @Query("SELECT * FROM stock_opname_tasks ORDER BY createdAt DESC")
    suspend fun getAllStockOpnameTasksSync(): List<com.example.data.model.StockOpnameTask>

    @Query("SELECT * FROM stock_opname_tasks WHERE taskCode = :taskCode LIMIT 1")
    suspend fun getStockOpnameTaskByCode(taskCode: String): com.example.data.model.StockOpnameTask?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStockOpnameTask(task: com.example.data.model.StockOpnameTask): Long

    @Update
    suspend fun updateStockOpnameTask(task: com.example.data.model.StockOpnameTask)

    @Query("DELETE FROM stock_opname_tasks WHERE id = :id")
    suspend fun deleteStockOpnameTask(id: Long)

    // --- Purchases (Pembelian Supplier) ---
    @Query("SELECT * FROM purchases ORDER BY date DESC")
    fun getAllPurchases(): Flow<List<com.example.data.model.PurchaseRecord>>

    @Query("SELECT * FROM purchases ORDER BY date DESC")
    suspend fun getAllPurchasesSync(): List<com.example.data.model.PurchaseRecord>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPurchase(purchase: com.example.data.model.PurchaseRecord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPurchases(purchases: List<com.example.data.model.PurchaseRecord>)

    @Query("DELETE FROM purchases")
    suspend fun clearAllPurchases()

    // --- Product Returns (Retur Barang) ---
    @Query("SELECT * FROM product_returns ORDER BY timestamp DESC")
    fun getAllProductReturns(): Flow<List<com.example.data.model.ProductReturnRecord>>

    @Query("SELECT * FROM product_returns ORDER BY timestamp DESC")
    suspend fun getAllProductReturnsSync(): List<com.example.data.model.ProductReturnRecord>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProductReturn(returnRecord: com.example.data.model.ProductReturnRecord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProductReturns(returns: List<com.example.data.model.ProductReturnRecord>)

    @Query("DELETE FROM product_returns")
    suspend fun clearAllProductReturns()
}
