package com.example.data.model

data class ShortcutConfig(
    val keyName: String, // "F1", "F2", ... "F12"
    val action: PosShortcutAction,
    val isEnabled: Boolean = true
)

enum class PosShortcutAction(val label: String, val description: String) {
    DISABLED("Nonaktif", "Tombol dinonaktifkan (tidak melakukan aksi)"),
    BAYAR("Bayar Transaksi", "Buka dialog pembayaran kasir & cetak struk"),
    SCAN_BARCODE("Scan / Cari Barcode", "Fokus otomatis ke kolom scan barcode/pencarian"),
    PRODUK_CEPAT("Menu Produk Cepat", "Buka tab / menu pemilihan produk cepat"),
    GALERI_PRODUK("Galeri Produk", "Buka katalog & galeri produk"),
    PENDING_CART("Pending Transaksi", "Simpan keranjang aktif ke antrean pending"),
    MEMBER("Member & Poin", "Pilih data member atau tukar poin belanja"),
    VOID_LAST("Void Item Terakhir", "Batalkan / hapus 1 barang terakhir dari keranjang"),
    KUNCI_KASIR("Kunci Layar Kasir", "Kunci layar kasir sementara"),
    START_SHIFT("Buka Shift", "Mulai shift kerja kasir baru"),
    CLOSE_SHIFT("Tutup Shift", "Rekap dan tutup shift kasir"),
    STOK_OPNAME("Stok Opname", "Buka modul stock opname fisik"),
    PEMBELIAN("Pembelian & Belanja", "Buka modul pembelian supplier & belanja toko"),
    PIUTANG("Buku Piutang", "Buka pencatatan & pelunasan piutang pelanggan"),
    BATAL_KERANJANG("Kosongkan Keranjang", "Hapus semua barang dari keranjang"),
    BANTUAN_SHORTCUT("Panduan Shortcut", "Tampilkan daftar panduan keyboard F1-F12");

    val displayName: String get() = label
}

val DEFAULT_SHORTCUT_CONFIGS = listOf(
    ShortcutConfig("F1", PosShortcutAction.SCAN_BARCODE, true),
    ShortcutConfig("F2", PosShortcutAction.PRODUK_CEPAT, true),
    ShortcutConfig("F3", PosShortcutAction.MEMBER, true),
    ShortcutConfig("F4", PosShortcutAction.PENDING_CART, true),
    ShortcutConfig("F5", PosShortcutAction.VOID_LAST, true),
    ShortcutConfig("F6", PosShortcutAction.BATAL_KERANJANG, true),
    ShortcutConfig("F7", PosShortcutAction.START_SHIFT, true),
    ShortcutConfig("F8", PosShortcutAction.CLOSE_SHIFT, true),
    ShortcutConfig("F9", PosShortcutAction.PEMBELIAN, true),
    ShortcutConfig("F10", PosShortcutAction.PIUTANG, true),
    ShortcutConfig("F11", PosShortcutAction.KUNCI_KASIR, true),
    ShortcutConfig("F12", PosShortcutAction.BAYAR, true)
)
