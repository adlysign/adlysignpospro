package com.example.data.model

data class ShortcutActionDef(
    val actionId: String,
    val title: String,
    val description: String
) {
    val id: String get() = actionId
}

object ShortcutRegistry {
    val AVAILABLE_ACTIONS = listOf(
        ShortcutActionDef("CARI_BARANG", "Fokus Cari Barang / Barcode", "Mengaktifkan kolom ketik/scan barcode kasir"),
        ShortcutActionDef("GANTI_QTY", "Ubah Kuantitas (Qty) Item", "Membuka modal edit jumlah/satuan barang terakhir"),
        ShortcutActionDef("TAHAN_TRANSAKSI", "Tahan / Pending Struk", "Menahan transaksi belanja saat ini ke daftar pending"),
        ShortcutActionDef("DAFTAR_PENDING", "Buka Daftar Antrean Pending", "Melihat dan melanjutkan nota transaksi yang ditahan"),
        ShortcutActionDef("VOID_STRUK", "Void Struk Terbayar", "Membatalkan struk nota transaksi yang sudah dibayar"),
        ShortcutActionDef("STOK_OPNAME", "Menu Stok Opname (SO)", "Melakukan pemeriksaan fisik stok toko"),
        ShortcutActionDef("BUKA_SHIFT", "Buka Shift Kasir", "Membuka modal pembukaan shift kasir baru"),
        ShortcutActionDef("TUTUP_SHIFT", "Tutup Shift Kasir", "Menutup shift kasir aktif dan rekonsiliasi uang fisik"),
        ShortcutActionDef("PEMBELIAN_SUPPLIER", "Pembelian Barang Supplier", "Mencatat faktur belanja barang masuk dari supplier"),
        ShortcutActionDef("PIUTANG", "Buku Piutang / Kasbon", "Mencatat atau menerima cicilan kasbon pelanggan"),
        ShortcutActionDef("KUNCI_KASIR", "Kunci Layar Kasir", "Mengunci kasir sementara (otomatis simpan pending)"),
        ShortcutActionDef("BAYAR", "Bayar Transaksi (Checkout)", "Membuka dialog pembayaran kasir"),
        ShortcutActionDef("MEMBER", "Member & Poin Belanja", "Pencarian pelanggan atau penukaran poin loyalti"),
        ShortcutActionDef("BATAL_KERANJANG", "Batal / Kosongkan Keranjang", "Menghapus seluruh isi keranjang belanja"),
        ShortcutActionDef("KAMERA_SCANNER", "Scan Barcode Kamera", "Membuka scanner kamera untuk barcode produk"),
        ShortcutActionDef("PRINTER_STRUK", "Pengaturan Printer Struk", "Membuka konfigurasi printer Bluetooth & nota"),
        ShortcutActionDef("RETUR_BARANG", "Retur Barang", "Mencatat retur barang dari pelanggan atau ke supplier")
    )

    val DEFAULT_MAPPINGS: Map<String, String> = mapOf(
        "F1" to "CARI_BARANG",
        "F2" to "GANTI_QTY",
        "F3" to "TAHAN_TRANSAKSI",
        "F4" to "DAFTAR_PENDING",
        "F5" to "VOID_STRUK",
        "F6" to "STOK_OPNAME",
        "F7" to "BUKA_SHIFT",
        "F8" to "TUTUP_SHIFT",
        "F9" to "PEMBELIAN_SUPPLIER",
        "F10" to "PIUTANG",
        "F11" to "KUNCI_KASIR",
        "F12" to "BAYAR"
    )

    fun getActionLabel(actionId: String): String {
        return AVAILABLE_ACTIONS.find { it.actionId == actionId || it.id == actionId }?.title ?: actionId
    }
}
