package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "product_returns")
data class ProductReturnRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val productId: Long,
    val productName: String,
    val qty: Int,
    val returnType: String, // "MASUK_STOK" (Retur dari Konsumen / Tambah Stok) or "KELUAR_STOK" (Retur Rusak / Pengembalian ke Supplier)
    val reason: String,
    val customerOrSupplier: String,
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
