package com.example.data.model

data class CartItem(
    val product: Product,
    val quantity: Int,
    val note: String = ""
) {
    val subtotal: Long
        get() = product.sellPrice * quantity

    val totalCost: Long
        get() = product.costPrice * quantity
}
