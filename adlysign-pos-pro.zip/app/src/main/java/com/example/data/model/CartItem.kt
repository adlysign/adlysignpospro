package com.example.data.model

data class CartItem(
    val product: Product,
    val quantity: Int,
    val selectedUnit: String = product.unit,
    val unitMultiplier: Int = 1,
    val customUnitPrice: Long = product.sellPrice,
    val note: String = ""
) {
    val totalBaseUnits: Int
        get() = quantity * unitMultiplier

    val subtotal: Long
        get() = customUnitPrice * quantity

    val effectiveUnitPrice: Long
        get() = customUnitPrice

    val totalCost: Long
        get() = (product.costPrice * unitMultiplier) * quantity
}
