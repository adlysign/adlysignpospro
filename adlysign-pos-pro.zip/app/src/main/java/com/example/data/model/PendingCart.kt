package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "pending_carts")
data class PendingCart(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val label: String, // Label e.g. "Bapak Baju Biru", "Ibu ambil barang"
    val cashierName: String,
    val timestamp: Long = System.currentTimeMillis(),
    val itemsJson: String, // JSON array of cart items
    val totalAmount: Long,
    val itemCount: Int,
    val memberId: Long? = null,
    val memberName: String? = null,
    val cartCode: String = "" // Kode unik transaksi antar-perangkat
) {
    val effectiveCartCode: String
        get() = if (cartCode.isNotBlank()) cartCode else "PC-$timestamp-$id"
}
