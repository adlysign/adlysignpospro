package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "shifts")
data class ShiftRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val shiftNumber: Int, // 1 = Shift Pagi, 2 = Shift Siang/Sore, 3 = Shift Malam
    val shiftName: String,
    val cashierName: String,
    val startTime: Long = System.currentTimeMillis(),
    val endTime: Long? = null,
    val openingCash: Long = 0L, // Modal Awal
    val closingCash: Long? = null, // Uang Fisik Kasir saat tutup
    val expectedCash: Long = 0L, // Modal Awal + Total Penjualan Tunai
    val difference: Long = 0L, // closingCash - expectedCash (0 = Pas, >0 = Lebih, <0 = Kurang)
    val notes: String = "",
    val status: String = "ACTIVE", // "ACTIVE" or "CLOSED"
    val totalTransactions: Int = 0,
    val totalSales: Long = 0L,
    val totalCash: Long = 0L,
    val totalNonCash: Long = 0L
) {
    val startingCash: Long get() = openingCash
    val totalCashSales: Long get() = totalCash
    val totalNonCashSales: Long get() = totalNonCash
    val transactionCount: Int get() = totalTransactions
}
