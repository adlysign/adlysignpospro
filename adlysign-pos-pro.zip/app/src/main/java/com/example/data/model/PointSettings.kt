package com.example.data.model

data class PointSettings(
    val isEnabled: Boolean = true,
    val minSpendForPoints: Long = 10000L,
    val spendPerPoint: Long = 10000L, // Belanja setiap Rp 10.000 dapat 1 poin
    val pointValueInRupiah: Long = 100L, // 1 poin bernilai potongan Rp 100
    val maxRedeemPercentage: Int = 100, // Maksimal potongan belanja: 100% (Full) atau misal 50%
    val minPointsToRedeem: Int = 10 // Minimal poin untuk dapat ditukarkan
)
