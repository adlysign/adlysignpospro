package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class TransactionRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val receiptNumber: String,
    val shiftId: Long,
    val shiftNumber: Int,
    val cashierName: String,
    val customerName: String = "Pelanggan Umum",
    val customerPhone: String = "",
    val subtotal: Long,
    val discount: Long = 0L,
    val tax: Long = 0L,
    val totalAmount: Long,
    val totalCost: Long = 0L,
    val paymentMethod: String, // "TUNAI", "QRIS", "TRANSFER", "DEBIT", "PIUTANG", "CAMPURAN"
    val paidAmount: Long,
    val changeAmount: Long = 0L,
    val timestamp: Long = System.currentTimeMillis(),
    val notes: String = "",
    val itemsJson: String, // JSON array of items
    val isSynced: Boolean = false,
    val status: String = "SUCCESS", // "SUCCESS" or "VOID"
    val voidReason: String = "",
    val voidBy: String = "",
    val voidTimestamp: Long = 0L
) {
    val isVoid: Boolean get() = status == "VOID"
    val invoiceNumber: String get() = receiptNumber
    val date: Long get() = timestamp
    val profit: Long get() = (totalAmount - totalCost).coerceAtLeast(0L)
}
