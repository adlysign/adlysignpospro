package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class TransactionRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val receiptNumber: String,
    val shiftId: Long,
    val shiftNumber: Int,
    val cashierName: String,
    val customerName: String = "Pelanggan Umum",
    val subtotal: Long,
    val discount: Long = 0L,
    val tax: Long = 0L,
    val totalAmount: Long,
    val totalCost: Long = 0L,
    val paymentMethod: String, // "TUNAI", "QRIS", "TRANSFER", "DEBIT"
    val paidAmount: Long,
    val changeAmount: Long = 0L,
    val timestamp: Long = System.currentTimeMillis(),
    val notes: String = "",
    val itemsJson: String, // JSON array of items: [{"name":"...", "qty":1, "price":15000, "costPrice":10000, "subtotal":15000}]
    val isSynced: Boolean = false
)
