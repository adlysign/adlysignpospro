package com.example.data.model

data class PrinterSettings(
    val selectedDeviceAddress: String = "",
    val selectedDeviceName: String = "",
    val paperSize: String = "58mm", // "58mm" or "80mm"
    val autoPrintOnCheckout: Boolean = false,
    val printLogo: Boolean = true,
    val printHeader: Boolean = true,
    val printFooter: Boolean = true,
    val printCashier: Boolean = true,
    val printShift: Boolean = true,
    val printCustomer: Boolean = true,
    val printNotes: Boolean = true,
    val cutPaper: Boolean = true, // Auto cut thermal paper
    val receiptTemplate: String = "KLASIK", // "KLASIK", "MODERN", "KOMPAK", "RINCI", "ELEGAN"
    val fontFamilyType: String = "MONOSPACE", // "MONOSPACE", "SANS_SERIF", "SERIF", "DEFAULT"
    val fontSizePreset: String = "SEDANG", // "KECIL", "SEDANG", "BESAR"
    val fontWeightPreset: String = "NORMAL", // "NORMAL", "MEDIUM", "BOLD"
    val lineSpacingPreset: String = "STANDAR", // "RAPAT", "STANDAR", "RENGGANG"
    val feedLines: Int = 3,
    val customHeader: String = "Selamat Datang & Terima Kasih",
    val customFooter: String = "Barang yang sudah dibeli tidak dapat ditukar/dikembalikan.\nTerima kasih atas kunjungan Anda!"
)
