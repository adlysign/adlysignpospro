package com.example.data.model

data class PrinterSettings(
    val selectedDeviceAddress: String = "",
    val selectedDeviceName: String = "",
    val paperSize: String = "58mm", // "58mm" or "80mm"
    val autoPrintOnCheckout: Boolean = false,
    val printLogo: Boolean = true,
    val printHeader: Boolean = true,
    val printFooter: Boolean = true,
    val printCashier: Boolean = true,
    val cutPaper: Boolean = false,
    val customHeader: String = "Selamat Datang & Terima Kasih",
    val customFooter: String = "Barang yang sudah dibeli tidak dapat ditukar/dikembalikan.\nTerima kasih atas kunjungan Anda!"
)
