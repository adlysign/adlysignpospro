package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "employees")
data class Employee(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val username: String,
    val pin: String, // 4-digit PIN for quick login
    val role: String, // "OWNER", "SUPERVISOR", "KASIR"
    val canAccessCashier: Boolean = true,
    val canVoidAndCancel: Boolean = true,
    val canOpenShift: Boolean = true,
    val canStockOpname: Boolean = true,
    val canSupplierPurchase: Boolean = true,
    val canManageReceivables: Boolean = true,
    val canViewReports: Boolean = true,
    val canAccessSettings: Boolean = true,
    val isActive: Boolean = true
) {
    val canVoid: Boolean get() = canVoidAndCancel
    val canDiscount: Boolean get() = canVoidAndCancel
}
