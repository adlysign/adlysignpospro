package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "employees")
data class Employee(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val username: String,
    val pin: String, // 4-digit PIN for quick login
    val role: String, // "OWNER", "SUPERVISOR", "KASIR"
    val canAccessCashier: Boolean = true,
    val canVoidAndCancel: Boolean = false, // legacy
    val canVoid: Boolean = false, // void struk pembelian yang sudah dibayar
    val canCancelCart: Boolean = false, // batal transaksi / kosongkan keranjang
    val canDeletePendingCart: Boolean = false, // hapus item dalam antrean pending
    val canOpenShift: Boolean = true, // buka / tutup shift
    val canStockOpname: Boolean = false, // akses menu stok opname
    val canSupplierPurchase: Boolean = false, // akses menu pembelian barang
    val canManageReceivables: Boolean = false, // akses menu piutang
    val canViewReports: Boolean = false, // akses menu laporan
    val canAccessSettings: Boolean = false, // akses menu pengaturan
    val canManagePrinter: Boolean = false, // akses menu pengaturan printer
    val canAddMember: Boolean = false, // tambah member di menu member
    val isActive: Boolean = true
) {
    val canDiscount: Boolean get() = canVoidAndCancel || canVoid
}
