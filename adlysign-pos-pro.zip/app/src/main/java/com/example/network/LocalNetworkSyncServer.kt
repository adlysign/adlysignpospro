package com.example.network

import android.content.Context
import android.util.Log
import com.example.data.local.PosDao
import com.example.data.model.PendingCart
import com.example.data.model.Product
import com.example.data.model.TransactionRecord
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.TimeUnit

data class SyncServerState(
    val isRunning: Boolean = false,
    val localIp: String = "127.0.0.1",
    val port: Int = 8888,
    val lastSyncMessage: String = "Server belum berjalan",
    val totalSyncedTransactions: Int = 0,
    val totalSyncedPendingCarts: Int = 0
)

data class ClientSyncState(
    val isAutoSyncRunning: Boolean = false,
    val hostIp: String = "",
    val statusText: String = "Auto-Sync Siap",
    val isConnected: Boolean = false,
    val lastSyncTimestamp: Long = 0L,
    val totalTransactionsSynced: Int = 0,
    val totalPendingCartsSynced: Int = 0
)

class LocalNetworkSyncManager(
    private val context: Context,
    private val posDao: PosDao,
    private val scope: CoroutineScope
) {
    private val prefs = context.getSharedPreferences("pos_local_sync_prefs", Context.MODE_PRIVATE)

    private val _serverState = MutableStateFlow(SyncServerState())
    val serverState: StateFlow<SyncServerState> = _serverState.asStateFlow()

    private val _clientState = MutableStateFlow(
        ClientSyncState(
            hostIp = getSavedHostIp(),
            isAutoSyncRunning = isAutoSyncSaved()
        )
    )
    val clientState: StateFlow<ClientSyncState> = _clientState.asStateFlow()

    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null
    private var autoSyncJob: Job? = null

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .writeTimeout(8, TimeUnit.SECONDS)
        .build()

    init {
        updateLocalIp()
        val savedIp = getSavedHostIp()
        val autoSync = isAutoSyncSaved()
        val serverEnabled = isServerEnabledSaved()
        if (serverEnabled) {
            startSyncServer(8888)
        } else if (autoSync && savedIp.isNotBlank()) {
            startAutoSync(savedIp, 8888)
        }
    }

    fun getSavedHostIp(): String = prefs.getString("saved_host_ip", "") ?: ""
    fun isAutoSyncSaved(): Boolean = prefs.getBoolean("saved_auto_sync_enabled", false)
    fun isServerEnabledSaved(): Boolean = prefs.getBoolean("saved_server_enabled", false)

    fun saveSyncPreferences(autoSync: Boolean? = null, hostIp: String? = null, serverEnabled: Boolean? = null) {
        prefs.edit().apply {
            autoSync?.let { putBoolean("saved_auto_sync_enabled", it) }
            hostIp?.let { putString("saved_host_ip", it) }
            serverEnabled?.let { putBoolean("saved_server_enabled", it) }
            apply()
        }
    }

    fun getDeviceLocalIp(): String {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val networkInterface = interfaces.nextElement()
                if (networkInterface.isLoopback || !networkInterface.isUp) continue
                val addresses = networkInterface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (addr is Inet4Address && !addr.isLoopbackAddress) {
                        val host = addr.hostAddress ?: ""
                        if (host.isNotBlank() && !host.startsWith("127.")) {
                            return host
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("SyncManager", "Error detecting IP", e)
        }
        return "127.0.0.1"
    }

    fun updateLocalIp() {
        val ip = getDeviceLocalIp()
        _serverState.value = _serverState.value.copy(localIp = ip)
    }

    fun startSyncServer(port: Int = 8888) {
        if (_serverState.value.isRunning) return
        saveSyncPreferences(serverEnabled = true)
        serverJob = scope.launch(Dispatchers.IO) {
            try {
                serverSocket = ServerSocket(port)
                val ip = getDeviceLocalIp()
                _serverState.value = _serverState.value.copy(
                    isRunning = true,
                    localIp = ip,
                    port = port,
                    lastSyncMessage = "Server aktif di http://$ip:$port"
                )
                while (isActive && serverSocket?.isClosed == false) {
                    try {
                        val clientSocket = serverSocket?.accept() ?: break
                        handleClientConnection(clientSocket)
                    } catch (e: Exception) {
                        if (serverSocket?.isClosed == true) break
                    }
                }
            } catch (e: Exception) {
                _serverState.value = _serverState.value.copy(
                    isRunning = false,
                    lastSyncMessage = "Gagal memulai server: ${e.message}"
                )
            }
        }
    }

    fun stopSyncServer() {
        saveSyncPreferences(serverEnabled = false)
        try {
            serverSocket?.close()
            serverSocket = null
            serverJob?.cancel()
            _serverState.value = _serverState.value.copy(
                isRunning = false,
                lastSyncMessage = "Server dihentikan"
            )
        } catch (e: Exception) {
            Log.e("SyncManager", "Error stopping server", e)
        }
    }

    private fun handleClientConnection(socket: Socket) {
        scope.launch(Dispatchers.IO) {
            try {
                val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
                val writer = PrintWriter(socket.getOutputStream(), true)
                val requestLine = reader.readLine() ?: return@launch
                val parts = requestLine.split(" ")
                if (parts.size < 2) return@launch
                val method = parts[0].uppercase()
                val fullPath = parts[1]
                val path = fullPath.substringBefore("?")

                var contentLength = 0
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    if (line.isNullOrEmpty()) break
                    val lower = line?.lowercase() ?: ""
                    if (lower.startsWith("content-length:")) {
                        contentLength = line?.substringAfter(":")?.trim()?.toIntOrNull() ?: 0
                    }
                }

                val bodyBuilder = StringBuilder()
                if (contentLength > 0) {
                    val charArray = CharArray(contentLength)
                    var readSoFar = 0
                    while (readSoFar < contentLength) {
                        val count = reader.read(charArray, readSoFar, contentLength - readSoFar)
                        if (count == -1) break
                        readSoFar += count
                    }
                    bodyBuilder.append(charArray, 0, readSoFar)
                }
                val body = bodyBuilder.toString()

                when {
                    path == "/api/ping" && method == "GET" -> {
                        val resp = JSONObject().apply {
                            put("status", "ONLINE")
                            put("name", "Kasir POS Host")
                            put("timestamp", System.currentTimeMillis())
                        }.toString()
                        sendHttpResponse(writer, 200, resp)
                    }
                    path == "/api/products" && method == "GET" -> {
                        val products = posDao.getAllProductsSync()
                        val array = JSONArray()
                        for (p in products) {
                            val obj = JSONObject().apply {
                                put("id", p.id)
                                put("name", p.name)
                                put("sku", p.sku)
                                put("category", p.category)
                                put("sellPrice", p.sellPrice)
                                put("costPrice", p.costPrice)
                                put("stock", p.stock)
                                put("unit", p.unit)
                                put("repackUnitsJson", p.repackUnitsJson)
                                put("tieredPricesJson", p.tieredPricesJson)
                                put("updatedAt", p.updatedAt)
                            }
                            array.put(obj)
                        }
                        sendHttpResponse(writer, 200, array.toString())
                    }
                    path == "/api/sync_transactions" && method == "POST" -> {
                        val array = JSONArray(body)
                        var newCount = 0
                        for (i in 0 until array.length()) {
                            val obj = array.getJSONObject(i)
                            val receiptNumber = obj.optString("receiptNumber")
                            if (receiptNumber.isBlank()) continue
                            val existing = posDao.getTransactionByReceiptNumber(receiptNumber)
                            if (existing == null) {
                                val tx = TransactionRecord(
                                    receiptNumber = receiptNumber,
                                    shiftId = obj.optLong("shiftId", 1L),
                                    shiftNumber = obj.optInt("shiftNumber", 1),
                                    cashierName = obj.optString("cashierName", "Kasir"),
                                    customerName = obj.optString("customerName", "Pelanggan"),
                                    subtotal = obj.optLong("subtotal", 0L),
                                    discount = obj.optLong("discount", 0L),
                                    tax = obj.optLong("tax", 0L),
                                    totalAmount = obj.optLong("totalAmount", 0L),
                                    totalCost = obj.optLong("totalCost", 0L),
                                    paymentMethod = obj.optString("paymentMethod", "TUNAI"),
                                    paidAmount = obj.optLong("paidAmount", 0L),
                                    changeAmount = obj.optLong("changeAmount", 0L),
                                    timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                                    notes = obj.optString("notes", ""),
                                    itemsJson = obj.optString("itemsJson", "[]"),
                                    isSynced = true,
                                    status = obj.optString("status", "SUCCESS"),
                                    voidReason = obj.optString("voidReason", ""),
                                    voidBy = obj.optString("voidBy", ""),
                                    voidTimestamp = obj.optLong("voidTimestamp", 0L)
                                )
                                posDao.insertTransaction(tx)
                                newCount++
                            }
                        }
                        _serverState.value = _serverState.value.copy(
                            totalSyncedTransactions = _serverState.value.totalSyncedTransactions + newCount,
                            lastSyncMessage = "Menerima $newCount transaksi baru"
                        )
                        sendHttpResponse(writer, 200, "{\"success\":true,\"received\":$newCount}")
                    }
                    path == "/api/sync_pending_carts" && method == "POST" -> {
                        val activeCarts = posDao.getAllPendingCartsSync()
                        val responseArr = JSONArray()
                        for (c in activeCarts) {
                            val obj = JSONObject().apply {
                                put("id", c.id)
                                put("cartCode", c.effectiveCartCode)
                                put("label", c.label)
                                put("cashierName", c.cashierName)
                                put("timestamp", c.timestamp)
                                put("itemsJson", c.itemsJson)
                                put("totalAmount", c.totalAmount)
                                put("itemCount", c.itemCount)
                            }
                            responseArr.put(obj)
                        }
                        sendHttpResponse(writer, 200, responseArr.toString())
                    }
                    else -> {
                        sendHttpResponse(writer, 404, "{\"error\":\"Not Found\"}")
                    }
                }
                socket.close()
            } catch (e: Exception) {
                Log.e("SyncManager", "Server connection handling error", e)
            }
        }
    }

    private fun sendHttpResponse(writer: PrintWriter, statusCode: Int, body: String) {
        val statusText = if (statusCode == 200) "OK" else "Not Found"
        writer.print("HTTP/1.1 $statusCode $statusText\r\n")
        writer.print("Content-Type: application/json; charset=UTF-8\r\n")
        writer.print("Content-Length: ${body.toByteArray(Charsets.UTF_8).size}\r\n")
        writer.print("Access-Control-Allow-Origin: *\r\n")
        writer.print("Connection: close\r\n\r\n")
        writer.print(body)
        writer.flush()
    }

    fun startAutoSync(hostIp: String, port: Int = 8888) {
        val cleanHost = hostIp.trim().removePrefix("http://").removeSuffix("/")
        if (cleanHost.isBlank()) return
        saveSyncPreferences(autoSync = true, hostIp = cleanHost)
        _clientState.value = _clientState.value.copy(
            isAutoSyncRunning = true,
            hostIp = cleanHost,
            statusText = "Menghubungkan ke Kasir Utama..."
        )
        autoSyncJob?.cancel()
        autoSyncJob = scope.launch(Dispatchers.IO) {
            while (isActive && _clientState.value.isAutoSyncRunning) {
                try {
                    doFullSync(cleanHost, port)
                } catch (e: Exception) {
                    _clientState.value = _clientState.value.copy(
                        isConnected = false,
                        statusText = "Menghubungkan kembali (${e.localizedMessage ?: "Terputus"})..."
                    )
                }
                delay(3000)
            }
        }
    }

    fun stopAutoSync() {
        saveSyncPreferences(autoSync = false)
        autoSyncJob?.cancel()
        autoSyncJob = null
        _clientState.value = _clientState.value.copy(
            isAutoSyncRunning = false,
            isConnected = false,
            statusText = "Auto-Sync Non-Aktif"
        )
    }

    fun triggerImmediateSync(hostIp: String? = null, port: Int = 8888) {
        val targetIp = hostIp?.trim()?.ifBlank { null } ?: getSavedHostIp().trim()
        if (targetIp.isBlank()) return
        scope.launch(Dispatchers.IO) {
            try {
                doFullSync(targetIp, port)
            } catch (e: Exception) {
                Log.e("SyncManager", "Immediate sync error", e)
            }
        }
    }

    suspend fun doFullSync(hostIp: String, port: Int = 8888): Result<String> {
        return withContext(Dispatchers.IO) {
            val cleanHost = hostIp.trim().removePrefix("http://").removeSuffix("/")
            if (cleanHost.isBlank()) return@withContext Result.failure(Exception("Alamat IP Host kosong"))
            try {
                pushTransactionsToHost(cleanHost, port)
                pullProductsFromHost(cleanHost, port)
                _clientState.value = _clientState.value.copy(
                    isConnected = true,
                    hostIp = cleanHost,
                    statusText = "Terhubung (Auto-Sync Aktif)",
                    lastSyncTimestamp = System.currentTimeMillis()
                )
                Result.success("Sinkronisasi berhasil!")
            } catch (e: Exception) {
                _clientState.value = _clientState.value.copy(
                    isConnected = false,
                    statusText = "Koneksi terputus: ${e.localizedMessage ?: "Tidak dapat menjangkau host"}"
                )
                Result.failure(e)
            }
        }
    }

    suspend fun testServerConnection(hostIp: String, port: Int = 8888): Result<String> {
        return withContext(Dispatchers.IO) {
            try {
                val cleanHost = hostIp.trim().removePrefix("http://").removeSuffix("/")
                val url = "http://$cleanHost:$port/api/ping"
                val request = Request.Builder().url(url).get().build()
                val response = httpClient.newCall(request).execute()
                if (response.isSuccessful) {
                    Result.success("Terhubung! Kasir POS Host aktif")
                } else {
                    Result.failure(Exception("Server mengembalikan status: ${response.code}"))
                }
            } catch (e: Exception) {
                Result.failure(Exception("Koneksi gagal: ${e.localizedMessage ?: "Tidak dapat menjangkau server"}"))
            }
        }
    }

    suspend fun pullProductsFromHost(hostIp: String, port: Int = 8888): Result<Int> {
        return withContext(Dispatchers.IO) {
            try {
                val cleanHost = hostIp.trim().removePrefix("http://").removeSuffix("/")
                val url = "http://$cleanHost:$port/api/products"
                val request = Request.Builder().url(url).get().build()
                val response = httpClient.newCall(request).execute()
                if (!response.isSuccessful) return@withContext Result.failure(Exception("HTTP ${response.code}"))
                val body = response.body?.string() ?: "[]"
                val array = JSONArray(body)
                val productList = mutableListOf<Product>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    productList.add(
                        Product(
                            name = obj.getString("name"),
                            sku = obj.optString("sku", ""),
                            category = obj.getString("category"),
                            sellPrice = obj.getLong("sellPrice"),
                            costPrice = obj.optLong("costPrice", 0L),
                            stock = obj.getInt("stock"),
                            unit = obj.optString("unit", "pcs"),
                            repackUnitsJson = obj.optString("repackUnitsJson", ""),
                            tieredPricesJson = obj.optString("tieredPricesJson", ""),
                            updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                        )
                    )
                }
                if (productList.isNotEmpty()) {
                    posDao.insertProducts(productList)
                }
                Result.success(productList.size)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    suspend fun pushTransactionsToHost(hostIp: String, port: Int = 8888): Result<Int> {
        return withContext(Dispatchers.IO) {
            try {
                val cleanHost = hostIp.trim().removePrefix("http://").removeSuffix("/")
                val unsynced = posDao.getUnsyncedTransactions()
                if (unsynced.isEmpty()) return@withContext Result.success(0)
                val array = JSONArray()
                val ids = mutableListOf<Long>()
                for (tx in unsynced) {
                    ids.add(tx.id)
                    val obj = JSONObject().apply {
                        put("receiptNumber", tx.receiptNumber)
                        put("shiftId", tx.shiftId)
                        put("shiftNumber", tx.shiftNumber)
                        put("cashierName", tx.cashierName)
                        put("customerName", tx.customerName)
                        put("subtotal", tx.subtotal)
                        put("discount", tx.discount)
                        put("tax", tx.tax)
                        put("totalAmount", tx.totalAmount)
                        put("totalCost", tx.totalCost)
                        put("paymentMethod", tx.paymentMethod)
                        put("paidAmount", tx.paidAmount)
                        put("changeAmount", tx.changeAmount)
                        put("timestamp", tx.timestamp)
                        put("notes", tx.notes)
                        put("itemsJson", tx.itemsJson)
                        put("status", tx.status)
                    }
                    array.put(obj)
                }
                val url = "http://$cleanHost:$port/api/sync_transactions"
                val body = array.toString().toRequestBody("application/json".toMediaType())
                val request = Request.Builder().url(url).post(body).build()
                val response = httpClient.newCall(request).execute()
                if (response.isSuccessful) {
                    posDao.markTransactionsSynced(ids)
                    Result.success(unsynced.size)
                } else {
                    Result.failure(Exception("Gagal push transaksi: status ${response.code}"))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    suspend fun claimOrDeletePendingCartOnHost(
        hostIp: String,
        cartCode: String,
        cashierName: String = "Kasir",
        port: Int = 8888
    ): Result<Boolean> {
        return withContext(Dispatchers.IO) {
            try {
                val cleanHost = hostIp.trim().removePrefix("http://").removeSuffix("/")
                val url = "http://$cleanHost:$port/api/claim_pending_cart"
                val json = JSONObject().apply {
                    put("cartCode", cartCode)
                    put("cashierName", cashierName)
                }
                val body = json.toString().toRequestBody("application/json".toMediaType())
                val request = Request.Builder().url(url).post(body).build()
                val response = httpClient.newCall(request).execute()
                Result.success(response.isSuccessful)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }
}
