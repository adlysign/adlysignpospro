package com.example.network

import android.content.Context
import android.net.wifi.WifiManager
import android.util.Log
import com.example.data.local.PosDao
import com.example.data.model.Product
import com.example.data.model.TransactionRecord
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.TimeUnit

data class SyncServerState(
    val isRunning: Boolean = false,
    val localIp: String = "127.0.0.1",
    val port: Int = 8888,
    val lastSyncMessage: String = "Server belum berjalan",
    val connectedClientsCount: Int = 0,
    val totalSyncedTransactions: Int = 0
)

class LocalNetworkSyncManager(
    private val context: Context,
    private val posDao: PosDao,
    private val scope: CoroutineScope
) {
    private val _serverState = MutableStateFlow(SyncServerState())
    val serverState: StateFlow<SyncServerState> = _serverState.asStateFlow()

    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    init {
        updateLocalIp()
    }

    fun getDeviceLocalIp(): String {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val networkInterface = interfaces.nextElement()
                if (networkInterface.isLoopback || !networkInterface.isUp) continue
                val addresses = networkInterface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (addr is Inet4Address && !addr.isLoopbackAddress) {
                        return addr.hostAddress ?: "127.0.0.1"
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("SyncManager", "Error detecting IP", e)
        }
        return "127.0.0.1"
    }

    fun updateLocalIp() {
        val ip = getDeviceLocalIp()
        _serverState.value = _serverState.value.copy(localIp = ip)
    }

    /**
     * Memulai Server Lokal untuk menerima sinkronisasi data dari terminal lain di jaringan Wi-Fi
     */
    fun startSyncServer(port: Int = 8888) {
        if (_serverState.value.isRunning) return

        serverJob = scope.launch(Dispatchers.IO) {
            try {
                serverSocket = ServerSocket(port)
                val ip = getDeviceLocalIp()
                _serverState.value = _serverState.value.copy(
                    isRunning = true,
                    localIp = ip,
                    port = port,
                    lastSyncMessage = "Server berjalan di http://$ip:$port"
                )

                while (serverState.value.isRunning && serverSocket?.isClosed == false) {
                    try {
                        val clientSocket = serverSocket?.accept() ?: break
                        handleClientConnection(clientSocket)
                    } catch (e: Exception) {
                        if (serverSocket?.isClosed == true) break
                    }
                }
            } catch (e: Exception) {
                _serverState.value = _serverState.value.copy(
                    isRunning = false,
                    lastSyncMessage = "Gagal memulai server: ${e.message}"
                )
            }
        }
    }

    fun stopSyncServer() {
        try {
            serverSocket?.close()
            serverSocket = null
            serverJob?.cancel()
            _serverState.value = _serverState.value.copy(
                isRunning = false,
                lastSyncMessage = "Server dihentikan"
            )
        } catch (e: Exception) {
            Log.e("SyncManager", "Error stopping server", e)
        }
    }

    private fun handleClientConnection(socket: Socket) {
        scope.launch(Dispatchers.IO) {
            try {
                val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
                val writer = PrintWriter(socket.getOutputStream(), true)

                // Read HTTP Request line
                val requestLine = reader.readLine() ?: return@launch
                val parts = requestLine.split(" ")
                if (parts.size < 2) return@launch

                val method = parts[0]
                val path = parts[1]

                // Read Headers
                var contentLength = 0
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    if (line.isNullOrEmpty()) break
                    val lower = line?.lowercase() ?: ""
                    if (lower.startsWith("content-length:")) {
                        contentLength = line?.substringAfter(":")?.trim()?.toIntOrNull() ?: 0
                    }
                }

                // Read Body if POST
                val bodyBuilder = StringBuilder()
                if (contentLength > 0) {
                    val charArray = CharArray(contentLength)
                    var readSoFar = 0
                    while (readSoFar < contentLength) {
                        val count = reader.read(charArray, readSoFar, contentLength - readSoFar)
                        if (count == -1) break
                        readSoFar += count
                    }
                    bodyBuilder.append(charArray, 0, readSoFar)
                }

                val body = bodyBuilder.toString()

                when {
                    path == "/api/ping" && method == "GET" -> {
                        val responseJson = JSONObject().apply {
                            put("status", "ONLINE")
                            put("name", "Kasir POS Host")
                            put("timestamp", System.currentTimeMillis())
                        }.toString()
                        sendHttpResponse(writer, 200, responseJson)
                    }

                    path == "/api/products" && method == "GET" -> {
                        val products = posDao.getAllProductsSync()
                        val array = JSONArray()
                        for (p in products) {
                            val obj = JSONObject().apply {
                                put("id", p.id)
                                put("name", p.name)
                                put("sku", p.sku)
                                put("category", p.category)
                                put("sellPrice", p.sellPrice)
                                put("costPrice", p.costPrice)
                                put("stock", p.stock)
                                put("unit", p.unit)
                                put("updatedAt", p.updatedAt)
                            }
                            array.put(obj)
                        }
                        sendHttpResponse(writer, 200, array.toString())
                    }

                    path == "/api/sync_transactions" && method == "POST" -> {
                        val array = JSONArray(body)
                        var syncedCount = 0
                        for (i in 0 until array.length()) {
                            val obj = array.getJSONObject(i)
                            val tx = TransactionRecord(
                                receiptNumber = obj.optString("receiptNumber", "TRX-SYNC-${System.currentTimeMillis()}"),
                                shiftId = obj.optLong("shiftId", 1L),
                                shiftNumber = obj.optInt("shiftNumber", 1),
                                cashierName = obj.optString("cashierName", "Kasir Cabang"),
                                customerName = obj.optString("customerName", "Pelanggan"),
                                subtotal = obj.optLong("subtotal", 0L),
                                discount = obj.optLong("discount", 0L),
                                tax = obj.optLong("tax", 0L),
                                totalAmount = obj.optLong("totalAmount", 0L),
                                totalCost = obj.optLong("totalCost", 0L),
                                paymentMethod = obj.optString("paymentMethod", "TUNAI"),
                                paidAmount = obj.optLong("paidAmount", 0L),
                                changeAmount = obj.optLong("changeAmount", 0L),
                                timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                                notes = obj.optString("notes", ""),
                                itemsJson = obj.optString("itemsJson", "[]"),
                                isSynced = true
                            )
                            posDao.insertTransaction(tx)
                            syncedCount++
                        }

                        _serverState.value = _serverState.value.copy(
                            totalSyncedTransactions = _serverState.value.totalSyncedTransactions + syncedCount,
                            lastSyncMessage = "Berhasil menerima $syncedCount transaksi dari klien"
                        )

                        val resp = JSONObject().apply {
                            put("success", true)
                            put("received", syncedCount)
                        }.toString()
                        sendHttpResponse(writer, 200, resp)
                    }

                    path == "/api/push_products" && method == "POST" -> {
                        val array = JSONArray(body)
                        val products = mutableListOf<Product>()
                        for (i in 0 until array.length()) {
                            val obj = array.getJSONObject(i)
                            products.add(
                                Product(
                                    name = obj.getString("name"),
                                    sku = obj.optString("sku", ""),
                                    category = obj.getString("category"),
                                    sellPrice = obj.getLong("sellPrice"),
                                    costPrice = obj.optLong("costPrice", 0L),
                                    stock = obj.getInt("stock"),
                                    unit = obj.optString("unit", "pcs"),
                                    updatedAt = System.currentTimeMillis()
                                )
                            )
                        }
                        posDao.insertProducts(products)
                        val resp = JSONObject().apply {
                            put("success", true)
                            put("updated", products.size)
                        }.toString()
                        sendHttpResponse(writer, 200, resp)
                    }

                    else -> {
                        sendHttpResponse(writer, 404, "{\"error\":\"Not Found\"}")
                    }
                }
                socket.close()
            } catch (e: Exception) {
                Log.e("SyncManager", "Client error", e)
            }
        }
    }

    private fun sendHttpResponse(writer: PrintWriter, statusCode: Int, body: String) {
        val statusText = if (statusCode == 200) "OK" else "Not Found"
        writer.print("HTTP/1.1 $statusCode $statusText\r\n")
        writer.print("Content-Type: application/json; charset=UTF-8\r\n")
        writer.print("Content-Length: ${body.toByteArray(Charsets.UTF_8).size}\r\n")
        writer.print("Access-Control-Allow-Origin: *\r\n")
        writer.print("Connection: close\r\n\r\n")
        writer.print(body)
        writer.flush()
    }

    // --- CLIENT METHODS ---

    suspend fun testServerConnection(hostIp: String, port: Int = 8888): Result<String> {
        return withContext(Dispatchers.IO) {
            try {
                val cleanHost = hostIp.trim().removePrefix("http://").removeSuffix("/")
                val url = "http://$cleanHost:$port/api/ping"
                val request = Request.Builder().url(url).get().build()
                val response = httpClient.newCall(request).execute()
                if (response.isSuccessful) {
                    val respBody = response.body?.string() ?: ""
                    val json = JSONObject(respBody)
                    Result.success("Terhubung! Host: ${json.optString("name", "Host")}")
                } else {
                    Result.failure(Exception("Server mengembalikan status: ${response.code}"))
                }
            } catch (e: Exception) {
                Result.failure(Exception("Koneksi gagal: ${e.localizedMessage ?: "Tidak dapat menjangkau server"}"))
            }
        }
    }

    /**
     * Menarik katalog produk dari Kasir Utama (Host) ke terminal ini
     */
    suspend fun pullProductsFromHost(hostIp: String, port: Int = 8888): Result<Int> {
        return withContext(Dispatchers.IO) {
            try {
                val cleanHost = hostIp.trim().removePrefix("http://").removeSuffix("/")
                val url = "http://$cleanHost:$port/api/products"
                val request = Request.Builder().url(url).get().build()
                val response = httpClient.newCall(request).execute()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception("HTTP ${response.code}"))
                }
                val body = response.body?.string() ?: "[]"
                val array = JSONArray(body)
                val productList = mutableListOf<Product>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    productList.add(
                        Product(
                            name = obj.getString("name"),
                            sku = obj.optString("sku", ""),
                            category = obj.getString("category"),
                            sellPrice = obj.getLong("sellPrice"),
                            costPrice = obj.optLong("costPrice", 0L),
                            stock = obj.getInt("stock"),
                            unit = obj.optString("unit", "pcs"),
                            updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                        )
                    )
                }
                if (productList.isNotEmpty()) {
                    posDao.insertProducts(productList)
                }
                Result.success(productList.size)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    /**
     * Mengirim transaksi yang belum tersinkron dari terminal ini ke Kasir Utama (Host)
     */
    suspend fun pushTransactionsToHost(hostIp: String, port: Int = 8888): Result<Int> {
        return withContext(Dispatchers.IO) {
            try {
                val cleanHost = hostIp.trim().removePrefix("http://").removeSuffix("/")
                val unsynced = posDao.getUnsyncedTransactions()
                if (unsynced.isEmpty()) {
                    return@withContext Result.success(0)
                }

                val array = JSONArray()
                val ids = mutableListOf<Long>()
                for (tx in unsynced) {
                    ids.add(tx.id)
                    val obj = JSONObject().apply {
                        put("receiptNumber", tx.receiptNumber)
                        put("shiftId", tx.shiftId)
                        put("shiftNumber", tx.shiftNumber)
                        put("cashierName", tx.cashierName)
                        put("customerName", tx.customerName)
                        put("subtotal", tx.subtotal)
                        put("discount", tx.discount)
                        put("tax", tx.tax)
                        put("totalAmount", tx.totalAmount)
                        put("totalCost", tx.totalCost)
                        put("paymentMethod", tx.paymentMethod)
                        put("paidAmount", tx.paidAmount)
                        put("changeAmount", tx.changeAmount)
                        put("timestamp", tx.timestamp)
                        put("notes", tx.notes)
                        put("itemsJson", tx.itemsJson)
                    }
                    array.put(obj)
                }

                val url = "http://$cleanHost:$port/api/sync_transactions"
                val body = array.toString().toRequestBody("application/json".toMediaType())
                val request = Request.Builder().url(url).post(body).build()
                val response = httpClient.newCall(request).execute()

                if (response.isSuccessful) {
                    posDao.markTransactionsSynced(ids)
                    Result.success(unsynced.size)
                } else {
                    Result.failure(Exception("Gagal push transaksi: status ${response.code}"))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }
}
