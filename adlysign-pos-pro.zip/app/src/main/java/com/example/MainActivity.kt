package com.example

import android.content.res.Configuration
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.ui.components.LockCashierDialog
import com.example.ui.components.LoginEmployeeDialog
import com.example.ui.components.ReceiptDialog
import com.example.ui.components.SupervisorAuthDialog
import com.example.ui.screens.CashierScreen
import com.example.ui.screens.ProductsScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.SettingsAndLicenseScreen
import com.example.ui.screens.ShiftScreen
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.SlateDark
import com.example.ui.theme.SlateLight
import com.example.ui.viewmodel.PosViewModel
import com.example.ui.viewmodel.UiEvent

enum class PosNavigationItem(val title: String, val icon: ImageVector, val tag: String) {
    CASHIER("Kasir", Icons.Default.ShoppingCart, "nav_cashier"),
    SHIFT("Shift (3)", Icons.Default.Schedule, "nav_shift"),
    PRODUCTS("Produk", Icons.Default.Inventory2, "nav_products"),
    REPORTS("Laporan", Icons.Default.Assessment, "nav_reports"),
    SETTINGS("Pengaturan", Icons.Default.Settings, "nav_settings")
}

class MainActivity : ComponentActivity() {
    private val viewModel: PosViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Tangani jika aplikasi tiba-tiba crash / terhenti mendadak:
        // Item di keranjang otomatis masuk ke Pending
        val defaultUncaughtHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                viewModel.autoSaveCartToPendingSync("Auto Pending (Aplikasi Terhenti)")
            } catch (_: Exception) {}
            defaultUncaughtHandler?.uncaughtException(thread, throwable)
        }

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT
            ),
            navigationBarStyle = SystemBarStyle.light(
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT
            )
        )
        setContent {
            MyApplicationTheme {
                MainApp(viewModel = viewModel)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.onAppResumed()
    }

    override fun onStop() {
        super.onStop()
        // Otomatis simpan item keranjang ke pending saat aplikasi tertutup / diminimalkan
        viewModel.autoSaveCartToPendingSync()
    }
}

@Composable
fun MainApp(viewModel: PosViewModel) {
    val context = LocalContext.current
    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    val screenWidthDp = configuration.screenWidthDp
    // Use NavigationRail if on tablet (screenWidthDp >= 600) or if in landscape with width >= 480dp
    val isWideScreen = screenWidthDp >= 600 || (isLandscape && screenWidthDp >= 480)

    var currentTab by remember { mutableStateOf(PosNavigationItem.CASHIER) }
    val snackbarHostState = remember { SnackbarHostState() }

    val cartItemCount by viewModel.cartItemCount.collectAsStateWithLifecycle()
    val activeReceiptTx by viewModel.activeReceiptTransaction.collectAsStateWithLifecycle()
    val licenseInfo by viewModel.licenseInfo.collectAsStateWithLifecycle()
    val currentEmployee by viewModel.currentEmployee.collectAsStateWithLifecycle()
    val employees by viewModel.employees.collectAsStateWithLifecycle()
    val printerSettings by viewModel.printerSettings.collectAsStateWithLifecycle()
    val isLocked by viewModel.isLocked.collectAsStateWithLifecycle()
    var showSupervisorAuthForSettings by remember { mutableStateOf(false) }

    // Handle UI events (Toasts & Snackbars)
    LaunchedEffect(Unit) {
        viewModel.uiEvent.collect { event ->
            when (event) {
                is UiEvent.ShowMessage -> {
                    snackbarHostState.showSnackbar(event.message)
                }
                is UiEvent.TransactionSuccess -> {
                    Toast.makeText(context, "Transaksi ${event.transaction.receiptNumber} selesai!", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            if (!isWideScreen) {
                NavigationBar(
                    containerColor = Color.White,
                    tonalElevation = 8.dp,
                    modifier = Modifier.testTag("bottom_navigation_bar")
                ) {
                    PosNavigationItem.values().forEach { item ->
                        val isSelected = currentTab == item
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = {
                                if (item == PosNavigationItem.SETTINGS && currentEmployee?.canAccessSettings == false && currentEmployee?.role != "OWNER") {
                                    showSupervisorAuthForSettings = true
                                } else {
                                    currentTab = item
                                }
                            },
                            icon = {
                                if (item == PosNavigationItem.CASHIER && cartItemCount > 0) {
                                    BadgedBox(badge = {
                                        Badge(containerColor = EmeraldPrimary) {
                                            Text("$cartItemCount", color = Color.White, fontSize = 10.sp)
                                        }
                                    }) {
                                        Icon(item.icon, contentDescription = item.title)
                                    }
                                } else {
                                    Icon(item.icon, contentDescription = item.title)
                                }
                            },
                            label = {
                                Text(
                                    text = item.title,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = EmeraldPrimary,
                                selectedTextColor = EmeraldPrimary,
                                indicatorColor = EmeraldPrimary.copy(alpha = 0.15f),
                                unselectedIconColor = SlateLight,
                                unselectedTextColor = SlateLight
                            ),
                            modifier = Modifier.testTag(item.tag)
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (isWideScreen) {
                NavigationRail(
                    containerColor = Color.White,
                    header = {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF0284C7)),
                                contentAlignment = Alignment.Center
                            ) {
                                if (licenseInfo.storeLogoUri.isNotBlank()) {
                                    AsyncImage(
                                        model = licenseInfo.storeLogoUri,
                                        contentDescription = "Logo",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Icon(
                                        Icons.Default.Storefront,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = licenseInfo.storeName.ifBlank { "BERKAH JAYA" },
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = SlateDark,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(horizontal = 4.dp)
                            )
                        }
                    },
                    modifier = Modifier.testTag("tablet_navigation_rail")
                ) {
                    PosNavigationItem.values().forEach { item ->
                        val isSelected = currentTab == item
                        NavigationRailItem(
                            selected = isSelected,
                            onClick = {
                                if (item == PosNavigationItem.SETTINGS && currentEmployee?.canAccessSettings == false && currentEmployee?.role != "OWNER") {
                                    showSupervisorAuthForSettings = true
                                } else {
                                    currentTab = item
                                }
                            },
                            icon = {
                                if (item == PosNavigationItem.CASHIER && cartItemCount > 0) {
                                    BadgedBox(badge = {
                                        Badge(containerColor = EmeraldPrimary) {
                                            Text("$cartItemCount", color = Color.White, fontSize = 10.sp)
                                        }
                                    }) {
                                        Icon(item.icon, contentDescription = item.title)
                                    }
                                } else {
                                    Icon(item.icon, contentDescription = item.title)
                                }
                            },
                            label = {
                                Text(
                                    text = item.title,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = EmeraldPrimary,
                                selectedTextColor = EmeraldPrimary,
                                indicatorColor = EmeraldPrimary.copy(alpha = 0.15f),
                                unselectedIconColor = SlateLight,
                                unselectedTextColor = SlateLight
                            ),
                            modifier = Modifier.testTag(item.tag)
                        )
                    }
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
            ) {
                Crossfade(targetState = currentTab, label = "screen_transition") { tab ->
                    when (tab) {
                        PosNavigationItem.CASHIER -> CashierScreen(
                            viewModel = viewModel,
                            onNavigateToShift = { currentTab = PosNavigationItem.SHIFT },
                            onNavigateToLicense = { currentTab = PosNavigationItem.SETTINGS }
                        )
                        PosNavigationItem.SHIFT -> ShiftScreen(viewModel = viewModel)
                        PosNavigationItem.PRODUCTS -> ProductsScreen(viewModel = viewModel)
                        PosNavigationItem.REPORTS -> ReportsScreen(viewModel = viewModel)
                        PosNavigationItem.SETTINGS -> SettingsAndLicenseScreen(viewModel = viewModel)
                    }
                }
            }
        }
    }

    // Thermal Receipt Dialog after transaction or from reports
    activeReceiptTx?.let { tx ->
        ReceiptDialog(
            transaction = tx,
            licenseInfo = licenseInfo,
            printerSettings = printerSettings,
            onDismiss = { viewModel.activeReceiptTransaction.value = null },
            onPrintBluetooth = { viewModel.printTransactionReceipt(tx) }
        )
    }

    // Mandatory Login Dialog when no employee is logged in
    if (currentEmployee == null && employees.isNotEmpty()) {
        LoginEmployeeDialog(
            employees = employees,
            isMandatory = true,
            onDismiss = { /* Forced login - user must authenticate */ },
            onLoginSuccess = { emp ->
                viewModel.loginEmployee(emp)
            }
        )
    }

    // Lock Cashier Screen
    if (isLocked) {
        LockCashierDialog(
            currentEmployee = currentEmployee,
            onUnlock = { pin -> viewModel.unlockCashier(pin) },
            onLogout = { viewModel.logoutEmployee() }
        )
    }

    // Supervisor Auth Dialog for Locked Settings
    if (showSupervisorAuthForSettings) {
        SupervisorAuthDialog(
            title = "Menu Pengaturan Terkunci",
            description = "Akun Kasir (${currentEmployee?.name ?: "Kasir"}) tidak memiliki hak akses ke Menu Pengaturan. Masukkan PIN Supervisor / Pemilik Toko untuk membuka.",
            employees = employees,
            requiredRoleOrPermission = { it.canAccessSettings || it.role == "OWNER" || it.role == "SUPERVISOR" },
            onAuthorized = {
                showSupervisorAuthForSettings = false
                currentTab = PosNavigationItem.SETTINGS
            },
            onDismiss = {
                showSupervisorAuthForSettings = false
            }
        )
    }
}
