package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CardMembership
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.CashierScreen
import com.example.ui.screens.MembersScreen
import com.example.ui.screens.ProductScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.ShiftScreen
import com.example.ui.screens.StockOpnameScreen
import com.example.ui.screens.SupplierPurchaseScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.PosViewModel

enum class PosNavDestination(val label: String, val icon: ImageVector) {
    CASHIER("Kasir", Icons.Default.ShoppingCart), // Changed from "Kasir Cepat" to "Kasir"
    PRODUCT("Produk", Icons.Default.Inventory),   // Changed from "Galeri Produk" to "Produk"
    PURCHASE("Pembelian", Icons.Default.LocalShipping),
    STOCK_OPNAME("Stok Opname", Icons.Default.Assessment),
    REPORTS("Laporan", Icons.Default.Description),
    MEMBERS("Member", Icons.Default.CardMembership),
    SHIFT("Shift", Icons.Default.LockOpen),
    SETTINGS("Pengaturan", Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {

    private var posViewModelRef: PosViewModel? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        // Permissions handled
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        requestAppPermissions()

        setContent {
            val viewModel: PosViewModel = viewModel()
            posViewModelRef = viewModel

            MyApplicationTheme {
                MainAppContent(viewModel = viewModel)
            }
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            val keyString = when (event.keyCode) {
                KeyEvent.KEYCODE_F1 -> "F1"
                KeyEvent.KEYCODE_F2 -> "F2"
                KeyEvent.KEYCODE_F3 -> "F3"
                KeyEvent.KEYCODE_F4 -> "F4"
                KeyEvent.KEYCODE_F5 -> "F5"
                KeyEvent.KEYCODE_F6 -> "F6"
                KeyEvent.KEYCODE_F7 -> "F7"
                KeyEvent.KEYCODE_F8 -> "F8"
                KeyEvent.KEYCODE_F9 -> "F9"
                KeyEvent.KEYCODE_F10 -> "F10"
                KeyEvent.KEYCODE_F11 -> "F11"
                KeyEvent.KEYCODE_F12 -> "F12"
                else -> null
            }
            if (keyString != null) {
                posViewModelRef?.let { vm ->
                    val handled = vm.handlePhysicalShortcut(keyString)
                    if (handled) return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun requestAppPermissions() {
        val permissions = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.CAMERA)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.BLUETOOTH_CONNECT)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.BLUETOOTH_SCAN)
            }
        }
        if (permissions.isNotEmpty()) {
            permissionLauncher.launch(permissions.toTypedArray())
        }
    }
}

@Composable
fun MainAppContent(viewModel: PosViewModel) {
    var currentDestination by remember { mutableStateOf(PosNavDestination.CASHIER) }
    val snackbarHostState = remember { SnackbarHostState() }
    val uiMessage by viewModel.uiMessage.collectAsState()
    val cartCount by viewModel.cartItemCount.collectAsState()
    val configuration = LocalConfiguration.current
    val isTabletLandscape = configuration.screenWidthDp >= 720

    // React to UI messages
    LaunchedEffect(uiMessage) {
        uiMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearUiMessage()
        }
    }

    if (isTabletLandscape) {
        // Landscape / Tablet POS Layout with NavigationRail
        Row(modifier = Modifier.fillMaxSize()) {
            NavigationRail(
                modifier = Modifier.fillMaxHeight(),
                containerColor = Color(0xFF0F172A),
                contentColor = Color.White,
                header = {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(top = 16.dp, bottom = 12.dp)
                    ) {
                        Surface(
                            color = Color(0xFF059669),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PointOfSale,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier
                                    .padding(8.dp)
                                    .size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "POS PRO",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF34D399)
                        )
                    }
                }
            ) {
                PosNavDestination.values().forEach { destination ->
                    val isSelected = currentDestination == destination
                    NavigationRailItem(
                        selected = isSelected,
                        onClick = { currentDestination = destination },
                        icon = {
                            if (destination == PosNavDestination.CASHIER && cartCount > 0) {
                                BadgedBox(
                                    badge = {
                                        Badge(containerColor = Color(0xFF059669)) {
                                            Text("$cartCount", color = Color.White, fontSize = 10.sp)
                                        }
                                    }
                                ) {
                                    Icon(imageVector = destination.icon, contentDescription = destination.label)
                                }
                            } else {
                                Icon(imageVector = destination.icon, contentDescription = destination.label)
                            }
                        },
                        label = {
                            Text(
                                destination.label,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationRailItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = Color(0xFF34D399),
                            indicatorColor = Color(0xFF059669),
                            unselectedIconColor = Color(0xFF94A3B8),
                            unselectedTextColor = Color(0xFF94A3B8)
                        )
                    )
                }
            }

            Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                ScreenContent(
                    destination = currentDestination,
                    viewModel = viewModel,
                    onNavigateToShift = { currentDestination = PosNavDestination.SHIFT }
                )
                SnackbarHost(
                    hostState = snackbarHostState,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp)
                )
            }
        }
    } else {
        // Handheld / Compact Layout with Bottom Navigation Bar
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                NavigationBar(
                    containerColor = Color(0xFF0F172A),
                    contentColor = Color.White,
                    tonalElevation = 8.dp
                ) {
                    // Show primary 5 tabs in bottom bar, others accessible
                    val bottomItems = listOf(
                        PosNavDestination.CASHIER,
                        PosNavDestination.PRODUCT,
                        PosNavDestination.PURCHASE,
                        PosNavDestination.REPORTS,
                        PosNavDestination.SETTINGS
                    )
                    bottomItems.forEach { destination ->
                        val isSelected = currentDestination == destination
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { currentDestination = destination },
                            icon = {
                                if (destination == PosNavDestination.CASHIER && cartCount > 0) {
                                    BadgedBox(
                                        badge = {
                                            Badge(containerColor = Color(0xFF059669)) {
                                                Text("$cartCount", color = Color.White, fontSize = 10.sp)
                                            }
                                        }
                                    ) {
                                        Icon(imageVector = destination.icon, contentDescription = destination.label)
                                    }
                                } else {
                                    Icon(imageVector = destination.icon, contentDescription = destination.label)
                                }
                            },
                            label = {
                                Text(
                                    destination.label,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White,
                                selectedTextColor = Color(0xFF34D399),
                                indicatorColor = Color(0xFF059669),
                                unselectedIconColor = Color(0xFF94A3B8),
                                unselectedTextColor = Color(0xFF94A3B8)
                            )
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                ScreenContent(
                    destination = currentDestination,
                    viewModel = viewModel,
                    onNavigateToShift = { currentDestination = PosNavDestination.SHIFT }
                )
            }
        }
    }
}

@Composable
fun ScreenContent(
    destination: PosNavDestination,
    viewModel: PosViewModel,
    onNavigateToShift: () -> Unit
) {
    when (destination) {
        PosNavDestination.CASHIER -> CashierScreen(viewModel = viewModel, onNavigateToShift = onNavigateToShift)
        PosNavDestination.PRODUCT -> ProductScreen(viewModel = viewModel)
        PosNavDestination.PURCHASE -> SupplierPurchaseScreen(viewModel = viewModel)
        PosNavDestination.STOCK_OPNAME -> StockOpnameScreen(viewModel = viewModel)
        PosNavDestination.REPORTS -> ReportsScreen(viewModel = viewModel)
        PosNavDestination.MEMBERS -> MembersScreen(viewModel = viewModel)
        PosNavDestination.SHIFT -> ShiftScreen(viewModel = viewModel)
        PosNavDestination.SETTINGS -> SettingsScreen(viewModel = viewModel)
    }
}
