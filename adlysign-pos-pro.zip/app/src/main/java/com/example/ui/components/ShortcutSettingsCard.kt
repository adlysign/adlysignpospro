package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PosShortcutAction
import com.example.data.model.ShortcutConfig
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SlateDark
import com.example.ui.theme.SlateLight
import com.example.ui.theme.SlateMedium
import com.example.ui.theme.posOutlinedTextFieldColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShortcutSettingsCard(
    shortcuts: List<ShortcutConfig>,
    onUpdateShortcut: (String, PosShortcutAction, Boolean) -> Unit,
    onResetDefaults: () -> Unit
) {
    val context = LocalContext.current

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(16.dp))
            .testTag("shortcut_settings_card")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color(0xFFE0E7FF), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Keyboard,
                            contentDescription = null,
                            tint = Color(0xFF4338CA),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Custom Tombol Shortcut (F1 - F12)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = SlateDark
                        )
                        Text(
                            text = "Atur fungsi tombol cepat keyboard fisik atau matikan fungsi yang tidak digunakan",
                            fontSize = 11.sp,
                            color = SlateMedium
                        )
                    }
                }

                OutlinedButton(
                    onClick = {
                        onResetDefaults()
                        Toast.makeText(context, "Shortcut keyboard dikembalikan ke default!", Toast.LENGTH_SHORT).show()
                    },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF4338CA))
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Reset Default", fontSize = 11.sp)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // List of F1 to F12 Shortcuts
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                shortcuts.forEach { config ->
                    ShortcutItemRow(
                        config = config,
                        onUpdate = { action, enabled ->
                            onUpdateShortcut(config.keyName, action, enabled)
                        }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ShortcutItemRow(
    config: ShortcutConfig,
    onUpdate: (PosShortcutAction, Boolean) -> Unit
) {
    var expandedDropdown by remember { mutableStateOf(false) }

    Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (config.isEnabled) Color(0xFFF8FAFC) else Color(0xFFF1F5F9),
        border = BorderStroke(1.dp, if (config.isEnabled) Color(0xFFCBD5E1) else Color(0xFFE2E8F0)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Key Badge e.g. [F1]
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (config.isEnabled) Color(0xFF4338CA) else Color(0xFF94A3B8),
                    modifier = Modifier.size(width = 44.dp, height = 32.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = config.keyName,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Action Dropdown Box
                ExposedDropdownMenuBox(
                    expanded = expandedDropdown,
                    onExpandedChange = { if (config.isEnabled) expandedDropdown = it },
                    modifier = Modifier.weight(1f)
                ) {
                    OutlinedTextField(
                        value = config.action.label,
                        onValueChange = {},
                        readOnly = true,
                        enabled = config.isEnabled,
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedDropdown)
                        },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = posOutlinedTextFieldColors(),
                        singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (config.isEnabled) SlateDark else SlateLight
                        )
                    )

                    ExposedDropdownMenu(
                        expanded = expandedDropdown,
                        onDismissRequest = { expandedDropdown = false }
                    ) {
                        PosShortcutAction.entries.forEach { act ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(act.label, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                        Text(act.description, fontSize = 10.sp, color = SlateMedium)
                                    }
                                },
                                onClick = {
                                    onUpdate(act, config.isEnabled)
                                    expandedDropdown = false
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Switch (Enable / Disable)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Switch(
                    checked = config.isEnabled,
                    onCheckedChange = { checked ->
                        onUpdate(config.action, checked)
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = EmeraldPrimary,
                        uncheckedThumbColor = Color.White,
                        uncheckedTrackColor = Color(0xFFCBD5E1)
                    ),
                    modifier = Modifier.testTag("switch_shortcut_${config.keyName}")
                )
                Text(
                    text = if (config.isEnabled) "Aktif" else "Nonaktif",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (config.isEnabled) EmeraldPrimary else SlateMedium
                )
            }
        }
    }
}
