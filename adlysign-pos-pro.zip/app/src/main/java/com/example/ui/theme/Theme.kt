package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.TextFieldDefaults

private val PosColorScheme =
  lightColorScheme(
    primary = EmeraldPrimary,
    onPrimary = Color.White,
    primaryContainer = EmeraldContainer,
    onPrimaryContainer = EmeraldDark,
    secondary = SlateMedium,
    tertiary = AmberShift1,
    background = SurfaceLight,
    surface = Color.White,
    onBackground = SlateDark,
    onSurface = SlateDark,
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = SlateDark
  )

@Composable
fun posOutlinedTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Color(0xFF0F172A),
    unfocusedTextColor = Color(0xFF0F172A),
    focusedLabelColor = EmeraldPrimary,
    unfocusedLabelColor = Color(0xFF475569),
    focusedBorderColor = EmeraldPrimary,
    unfocusedBorderColor = Color(0xFF94A3B8),
    cursorColor = EmeraldPrimary,
    focusedContainerColor = Color.White,
    unfocusedContainerColor = Color.White,
    focusedPlaceholderColor = Color(0xFF94A3B8),
    unfocusedPlaceholderColor = Color(0xFF94A3B8),
    focusedLeadingIconColor = Color(0xFF0284C7),
    unfocusedLeadingIconColor = Color(0xFF64748B),
    focusedTrailingIconColor = Color(0xFF0284C7),
    unfocusedTrailingIconColor = Color(0xFF64748B)
)

@Composable
fun posTextFieldColors() = TextFieldDefaults.colors(
    focusedTextColor = Color(0xFF0F172A),
    unfocusedTextColor = Color(0xFF0F172A),
    focusedLabelColor = EmeraldPrimary,
    unfocusedLabelColor = Color(0xFF475569),
    cursorColor = EmeraldPrimary,
    focusedContainerColor = Color.White,
    unfocusedContainerColor = Color.White,
    focusedPlaceholderColor = Color(0xFF94A3B8),
    unfocusedPlaceholderColor = Color(0xFF94A3B8)
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = false,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  MaterialTheme(colorScheme = PosColorScheme, typography = Typography, content = content)
}
