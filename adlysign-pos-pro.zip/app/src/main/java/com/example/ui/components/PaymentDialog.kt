package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Loyalty
import androidx.compose.material.icons.filled.Money
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.MemberRecord
import com.example.data.repository.PosRepository

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PaymentDialog(
    totalBill: Long,
    member: MemberRecord? = null,
    pointDiscount: Long = 0L,
    onDismissRequest: () -> Unit,
    onConfirmPayment: (
        method: String,
        paidAmount: Long,
        customerName: String,
        customerPhone: String,
        discount: Long,
        notes: String,
        shouldPrint: Boolean,
        splitCashAmount: Long,
        splitNonCashAmount: Long,
        splitNonCashMethod: String
    ) -> Unit
) {
    val finalTotal = (totalBill - pointDiscount).coerceAtLeast(0L)

    var selectedMethod by remember { mutableStateOf("TUNAI") } // TUNAI, QRIS, TRANSFER, CAMPURAN, PIUTANG
    var paidAmountText by remember { mutableStateOf("") }
    var customerName by remember { mutableStateOf(member?.name ?: "Pelanggan Umum") }
    var customerPhone by remember { mutableStateOf(member?.phone ?: "") }
    var manualDiscountText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var shouldPrint by remember { mutableStateOf(true) }

    // Mixed payment states
    var splitCashText by remember { mutableStateOf("") }
    var splitNonCashText by remember { mutableStateOf("") }
    var splitNonCashMethod by remember { mutableStateOf("QRIS") } // QRIS, Transfer Bank, Debit EDC

    // Auto focus requester for instant typing
    val cashFocusRequester = remember { FocusRequester() }
    val mixedCashFocusRequester = remember { FocusRequester() }
    val keyboardController = LocalSoftwareKeyboardController.current

    LaunchedEffect(selectedMethod) {
        if (selectedMethod == "TUNAI") {
            cashFocusRequester.requestFocus()
            keyboardController?.show()
        } else if (selectedMethod == "CAMPURAN") {
            mixedCashFocusRequester.requestFocus()
            keyboardController?.show()
        }
    }

    val manualDiscount = manualDiscountText.toLongOrNull() ?: 0L
    val effectiveTotal = (finalTotal - manualDiscount).coerceAtLeast(0L)

    // Calculate amounts
    val paidAmount = paidAmountText.toLongOrNull() ?: 0L
    val splitCash = splitCashText.toLongOrNull() ?: 0L
    val splitNonCash = splitNonCashText.toLongOrNull() ?: 0L

    val isFormValid by remember(selectedMethod, paidAmount, splitCash, splitNonCash, effectiveTotal, customerName) {
        derivedStateOf {
            when (selectedMethod) {
                "TUNAI" -> paidAmount >= effectiveTotal
                "QRIS", "TRANSFER" -> true
                "CAMPURAN" -> (splitCash + splitNonCash) >= effectiveTotal && splitCash > 0 && splitNonCash > 0
                "PIUTANG" -> customerName.isNotBlank() && customerName != "Pelanggan Umum"
                else -> false
            }
        }
    }

    val changeAmount by remember(selectedMethod, paidAmount, splitCash, splitNonCash, effectiveTotal) {
        derivedStateOf {
            when (selectedMethod) {
                "TUNAI" -> (paidAmount - effectiveTotal).coerceAtLeast(0L)
                "CAMPURAN" -> ((splitCash + splitNonCash) - effectiveTotal).coerceAtLeast(0L)
                else -> 0L
            }
        }
    }

    val quickNominals = remember(effectiveTotal) {
        val list = mutableListOf<Long>()
        list.add(effectiveTotal) // Uang pas
        val round5k = ((effectiveTotal + 4999) / 5000) * 5000
        if (round5k > effectiveTotal && !list.contains(round5k)) list.add(round5k)
        val round10k = ((effectiveTotal + 9999) / 10000) * 10000
        if (round10k > effectiveTotal && !list.contains(round10k)) list.add(round10k)
        val round20k = ((effectiveTotal + 19999) / 20000) * 20000
        if (round20k > effectiveTotal && !list.contains(round20k)) list.add(round20k)
        val round50k = ((effectiveTotal + 49999) / 50000) * 50000
        if (round50k > effectiveTotal && !list.contains(round50k)) list.add(round50k)
        val round100k = ((effectiveTotal + 99999) / 100000) * 100000
        if (round100k > effectiveTotal && !list.contains(round100k)) list.add(round100k)
        list.take(6)
    }

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Pembayaran Kasir",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Pilih metode pembayaran dan masukkan nominal",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                    }
                    IconButton(onClick = onDismissRequest) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Tutup")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Total Tagihan Banner
                Surface(
                    color = Color(0xFF059669).copy(alpha = 0.08f),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF059669).copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "TOTAL TAGIHAN",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF065F46)
                        )
                        Text(
                            text = PosRepository.formatRupiah(effectiveTotal),
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF059669)
                        )
                        if (pointDiscount > 0 || manualDiscount > 0) {
                            val discountsText = buildList {
                                if (pointDiscount > 0) add("Poin: -${PosRepository.formatRupiah(pointDiscount)}")
                                if (manualDiscount > 0) add("Diskon: -${PosRepository.formatRupiah(manualDiscount)}")
                            }.joinToString(" | ")
                            Text(
                                text = "Potongan: $discountsText",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF047857)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Payment Method Selector Tabs
                Text(
                    text = "Metode Pembayaran",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PaymentMethodChip(
                        label = "Tunai",
                        icon = Icons.Default.Money,
                        selected = selectedMethod == "TUNAI",
                        onClick = {
                            selectedMethod = "TUNAI"
                            paidAmountText = ""
                        }
                    )
                    PaymentMethodChip(
                        label = "QRIS",
                        icon = Icons.Default.QrCode,
                        selected = selectedMethod == "QRIS",
                        onClick = {
                            selectedMethod = "QRIS"
                            paidAmountText = effectiveTotal.toString()
                        }
                    )
                    PaymentMethodChip(
                        label = "Transfer",
                        icon = Icons.Default.AccountBalance,
                        selected = selectedMethod == "TRANSFER",
                        onClick = {
                            selectedMethod = "TRANSFER"
                            paidAmountText = effectiveTotal.toString()
                        }
                    )
                    PaymentMethodChip(
                        label = "Campuran",
                        icon = Icons.Default.Payments,
                        selected = selectedMethod == "CAMPURAN",
                        onClick = {
                            selectedMethod = "CAMPURAN"
                            splitCashText = ""
                            splitNonCashText = ""
                        }
                    )
                    PaymentMethodChip(
                        label = "Piutang (Bon)",
                        icon = Icons.Default.CreditCard,
                        selected = selectedMethod == "PIUTANG",
                        onClick = {
                            selectedMethod = "PIUTANG"
                            paidAmountText = "0"
                        }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Conditional Input Based on Method
                when (selectedMethod) {
                    "TUNAI" -> {
                        Column {
                            OutlinedTextField(
                                value = paidAmountText,
                                onValueChange = { paidAmountText = it.filter { c -> c.isDigit() } },
                                label = { Text("Nominal Uang Tunai Diterima *") },
                                placeholder = { Text("Contoh: 50000") },
                                prefix = { Text("Rp ", fontWeight = FontWeight.Bold) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Number,
                                    imeAction = ImeAction.Done
                                ),
                                keyboardActions = KeyboardActions(onDone = {
                                    if (isFormValid) {
                                        onConfirmPayment(
                                            selectedMethod,
                                            paidAmount,
                                            customerName,
                                            customerPhone,
                                            manualDiscount,
                                            notes,
                                            shouldPrint,
                                            0L,
                                            0L,
                                            ""
                                        )
                                    }
                                }),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .focusRequester(cashFocusRequester)
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // Quick Money Buttons
                            Text(
                                text = "Pilihan Cepat Nominal Uang:",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.Gray
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            FlowRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                quickNominals.forEach { amount ->
                                    val isExact = amount == effectiveTotal
                                    Surface(
                                        color = if (isExact) Color(0xFF059669).copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant,
                                        shape = RoundedCornerShape(8.dp),
                                        border = androidx.compose.foundation.BorderStroke(
                                            1.dp,
                                            if (isExact) Color(0xFF059669) else Color(0xFFCBD5E1)
                                        ),
                                        modifier = Modifier.clickable {
                                            paidAmountText = amount.toString()
                                        }
                                    ) {
                                        Text(
                                            text = if (isExact) "Uang Pas (${PosRepository.formatRupiah(amount)})" else PosRepository.formatRupiah(amount),
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = if (isExact) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isExact) Color(0xFF065F46) else Color.Unspecified,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Kembalian Info
                            if (paidAmount >= effectiveTotal) {
                                Surface(
                                    color = Color(0xFFEFF6FF),
                                    shape = RoundedCornerShape(10.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBFDBFE)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("Kembalian Uang:", fontWeight = FontWeight.SemiBold, color = Color(0xFF1E3A8A))
                                        Text(
                                            text = PosRepository.formatRupiah(changeAmount),
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 18.sp,
                                            color = Color(0xFF1D4ED8)
                                        )
                                    }
                                }
                            } else if (paidAmount > 0) {
                                val remaining = effectiveTotal - paidAmount
                                Text(
                                    text = "Kurang bayar: ${PosRepository.formatRupiah(remaining)}",
                                    color = Color.Red,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    "CAMPURAN" -> {
                        // Fitur Pembayaran Campuran: Tunai sekian, Non-Tunai sekian
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFFF8FAFC), RoundedCornerShape(12.dp))
                                .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = "Pembayaran Campuran (Sebagian Tunai + Sebagian Non-Tunai)",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A)
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            // 1. Porsi Tunai
                            OutlinedTextField(
                                value = splitCashText,
                                onValueChange = {
                                    val digits = it.filter { c -> c.isDigit() }
                                    splitCashText = digits
                                    val cVal = digits.toLongOrNull() ?: 0L
                                    if (cVal < effectiveTotal && cVal > 0) {
                                        splitNonCashText = (effectiveTotal - cVal).toString()
                                    }
                                },
                                label = { Text("Nominal Tunai (Cash) *") },
                                prefix = { Text("Rp ", fontWeight = FontWeight.Bold) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .focusRequester(mixedCashFocusRequester)
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // 2. Pilihan Non-Tunai
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Metode Kedua:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
                                listOf("QRIS", "Transfer Bank", "Debit EDC").forEach { m ->
                                    val isSel = splitNonCashMethod == m
                                    Surface(
                                        color = if (isSel) Color(0xFF059669).copy(alpha = 0.15f) else Color.White,
                                        shape = RoundedCornerShape(6.dp),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSel) Color(0xFF059669) else Color(0xFFCBD5E1)),
                                        modifier = Modifier.clickable { splitNonCashMethod = m }
                                    ) {
                                        Text(
                                            text = m,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSel) Color(0xFF065F46) else Color.DarkGray,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // 3. Porsi Non-Tunai
                            OutlinedTextField(
                                value = splitNonCashText,
                                onValueChange = { splitNonCashText = it.filter { c -> c.isDigit() } },
                                label = { Text("Nominal $splitNonCashMethod *") },
                                prefix = { Text("Rp ", fontWeight = FontWeight.Bold) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            val totalMixedPaid = splitCash + splitNonCash
                            val diff = totalMixedPaid - effectiveTotal
                            Surface(
                                color = if (diff >= 0) Color(0xFFEFF6FF) else Color(0xFFFEF2F2),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Total Bayar (${PosRepository.formatRupiah(totalMixedPaid)})",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = if (diff >= 0) "Kembalian: ${PosRepository.formatRupiah(diff)}" else "Kurang: ${PosRepository.formatRupiah(-diff)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (diff >= 0) Color(0xFF1D4ED8) else Color(0xFFDC2626)
                                    )
                                }
                            }
                        }
                    }

                    "QRIS" -> {
                        Surface(
                            color = Color(0xFFF8FAFC),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.QrCode,
                                    contentDescription = null,
                                    modifier = Modifier.size(48.dp),
                                    tint = Color(0xFF0284C7)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Pembayaran via QRIS Dinamis / Statis",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    text = "Pastikan dana sebesar ${PosRepository.formatRupiah(effectiveTotal)} telah diterima di notifikasi merchant Anda sebelum konfirmasi.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.Gray,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    "TRANSFER" -> {
                        Surface(
                            color = Color(0xFFF8FAFC),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AccountBalance,
                                    contentDescription = null,
                                    modifier = Modifier.size(48.dp),
                                    tint = Color(0xFF7C3AED)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Transfer Bank / Rekening Toko",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    text = "Nominal transfer: ${PosRepository.formatRupiah(effectiveTotal)}. Periksa mutasi rekening sebelum menyelesaikan transaksi.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.Gray,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    "PIUTANG" -> {
                        Column {
                            OutlinedTextField(
                                value = customerName,
                                onValueChange = { customerName = it },
                                label = { Text("Nama Pelanggan (Wajib) *") },
                                placeholder = { Text("Masukkan nama penghutang") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = customerPhone,
                                onValueChange = { customerPhone = it },
                                label = { Text("Nomor HP / WhatsApp") },
                                placeholder = { Text("08xxxxxxxx") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = paidAmountText,
                                onValueChange = { paidAmountText = it.filter { c -> c.isDigit() } },
                                label = { Text("DP / Uang Muka (Opsional)") },
                                placeholder = { Text("0") },
                                prefix = { Text("Rp ") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Customer Info (Collapsible / Compact)
                if (selectedMethod != "PIUTANG") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = customerName,
                            onValueChange = { customerName = it },
                            label = { Text("Nama Pelanggan") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = manualDiscountText,
                            onValueChange = { manualDiscountText = it.filter { c -> c.isDigit() } },
                            label = { Text("Diskon (Rp)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(0.8f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Catatan Struk (Opsional)") },
                    placeholder = { Text("Contoh: Titipan meja 4 / No. Ref") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Print Option
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { shouldPrint = !shouldPrint },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = shouldPrint,
                        onCheckedChange = { shouldPrint = it }
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Cetak struk nota otomatis ke printer Bluetooth",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismissRequest,
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Batal")
                    }

                    Button(
                        onClick = {
                            val finalPaid = when (selectedMethod) {
                                "TUNAI" -> paidAmount
                                "CAMPURAN" -> splitCash
                                "PIUTANG" -> paidAmount
                                else -> effectiveTotal
                            }
                            onConfirmPayment(
                                selectedMethod,
                                finalPaid,
                                customerName,
                                customerPhone,
                                manualDiscount,
                                notes,
                                shouldPrint,
                                splitCash,
                                splitNonCash,
                                splitNonCashMethod
                            )
                        },
                        enabled = isFormValid,
                        modifier = Modifier
                            .weight(1.8f)
                            .height(52.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669))
                    ) {
                        Icon(imageVector = Icons.Default.Payments, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Konfirmasi & Bayar",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PaymentMethodChip(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        color = if (selected) Color(0xFF059669) else MaterialTheme.colorScheme.surfaceVariant,
        contentColor = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (selected) Color(0xFF059669) else Color(0xFFCBD5E1)
        ),
        modifier = Modifier.clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
            )
        }
    }
}
