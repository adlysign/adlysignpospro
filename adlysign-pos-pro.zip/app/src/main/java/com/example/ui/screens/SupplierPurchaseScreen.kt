package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardReturn
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.data.model.Product
import com.example.data.model.PurchaseRecord
import com.example.data.model.StorePartnerData
import com.example.data.model.SupplierData
import com.example.data.repository.PosRepository
import com.example.ui.components.AddEditProductDialog
import com.example.ui.components.BarcodeScannerDialog
import com.example.ui.viewmodel.PosViewModel
import com.example.util.ReportExportHelper
import org.json.JSONArray
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class PurchaseDraftItem(
    var product: Product,
    var quantity: Int,
    var buyPrice: Long
) {
    val subtotal: Long get() = quantity * buyPrice
}

@Composable
fun SupplierPurchaseScreen(viewModel: PosViewModel) {
    val context = LocalContext.current
    val allProducts by viewModel.allProducts.collectAsState()
    val allPurchases by viewModel.purchaseRecords.collectAsState()
    val licenseInfo by viewModel.licenseInfo.collectAsState()
    val currentEmployee by viewModel.currentEmployee.collectAsState()
    val activeShift by viewModel.activeShift.collectAsState()

    val masterSuppliers by viewModel.masterSuppliers.collectAsState()
    val masterStores by viewModel.masterStores.collectAsState()

    // Active User
    val activeUserName = currentEmployee?.name ?: activeShift?.cashierName ?: "Kasir"

    // Top Tabs: 0: Pembelian Supplier, 1: Belanja Toko, 2: Riwayat Belanja
    var selectedTab by remember { mutableStateOf(0) }

    // Dialog for editing product directly from cart
    var productToEdit by remember { mutableStateOf<Product?>(null) }
    if (productToEdit != null) {
        val prod = productToEdit!!
        AddEditProductDialog(
            product = prod,
            onDismiss = { productToEdit = null },
            onSave = { id, name, sku, category, sellPrice, costPrice, stock, unit, repackUnitsJson, tieredPricesJson ->
                viewModel.saveProduct(
                    id = id,
                    name = name,
                    sku = sku,
                    category = category,
                    sellPrice = sellPrice,
                    costPrice = costPrice,
                    stock = stock,
                    unit = unit,
                    repackUnitsJson = repackUnitsJson,
                    tieredPricesJson = tieredPricesJson
                )
                productToEdit = null
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        // Top Header Banner
        Surface(
            color = Color.White,
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(
                                    when (selectedTab) {
                                        0 -> Color(0xFF059669)
                                        1 -> Color(0xFF0284C7)
                                        else -> Color(0xFF475569)
                                    },
                                    RoundedCornerShape(10.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = when (selectedTab) {
                                    0 -> Icons.Default.LocalShipping
                                    1 -> Icons.Default.ShoppingBag
                                    else -> Icons.Default.History
                                },
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = when (selectedTab) {
                                    0 -> "Pembelian Supplier"
                                    1 -> "Belanja Toko (Kulakan)"
                                    else -> "Riwayat Belanja & Pembelian"
                                },
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp,
                                color = Color(0xFF0F172A)
                            )
                            Text(
                                text = "Petugas Aktif: $activeUserName",
                                fontSize = 12.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                }

                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color.White,
                    contentColor = Color(0xFF059669)
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.LocalShipping, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Pembelian Supplier", fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal)
                            }
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.ShoppingBag, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Belanja Toko", fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal)
                            }
                        }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Riwayat & Dokumen", fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal)
                            }
                        }
                    )
                }
            }
        }

        when (selectedTab) {
            0 -> {
                // Pembelian Supplier Tab
                PurchaseInputContent(
                    isBelanjaToko = false,
                    allProducts = allProducts,
                    masterSuppliers = masterSuppliers,
                    masterStores = masterStores,
                    activeUserName = activeUserName,
                    onEditProduct = { p -> productToEdit = p },
                    onAddSupplier = { name, phone, address, notes ->
                        viewModel.addSupplier(name, phone, address, notes)
                    },
                    onAddStore = { name, phone, address, notes ->
                        viewModel.addStore(name, phone, address, notes)
                    },
                    onSubmitPurchase = { invoiceNo, partnerName, phone, payType, items, notes ->
                        viewModel.submitSupplierPurchase(
                            invoiceNumber = invoiceNo,
                            supplierName = partnerName,
                            supplierPhone = phone,
                            paymentType = payType,
                            items = items,
                            notes = notes,
                            purchaseType = "SUPPLIER"
                        )
                    }
                )
            }
            1 -> {
                // Belanja Toko Tab
                PurchaseInputContent(
                    isBelanjaToko = true,
                    allProducts = allProducts,
                    masterSuppliers = masterSuppliers,
                    masterStores = masterStores,
                    activeUserName = activeUserName,
                    onEditProduct = { p -> productToEdit = p },
                    onAddSupplier = { name, phone, address, notes ->
                        viewModel.addSupplier(name, phone, address, notes)
                    },
                    onAddStore = { name, phone, address, notes ->
                        viewModel.addStore(name, phone, address, notes)
                    },
                    onSubmitPurchase = { invoiceNo, partnerName, phone, payType, items, notes ->
                        viewModel.submitSupplierPurchase(
                            invoiceNumber = invoiceNo,
                            supplierName = partnerName,
                            supplierPhone = phone,
                            paymentType = payType,
                            items = items,
                            notes = notes,
                            purchaseType = "STORE"
                        )
                    }
                )
            }
            2 -> {
                // Riwayat Belanja & Dokumen Tab
                PurchaseHistoryContent(
                    purchases = allPurchases,
                    licenseInfo = licenseInfo,
                    context = context
                )
            }
        }
    }
}

/**
 * Unified Purchase Input Screen for both "Pembelian Supplier" and "Belanja Toko"
 */
@Composable
private fun PurchaseInputContent(
    isBelanjaToko: Boolean,
    allProducts: List<Product>,
    masterSuppliers: List<SupplierData>,
    masterStores: List<StorePartnerData>,
    activeUserName: String,
    onEditProduct: (Product) -> Unit,
    onAddSupplier: (String, String, String, String) -> Unit,
    onAddStore: (String, String, String, String) -> Unit,
    onSubmitPurchase: (
        invoiceNumber: String,
        partnerName: String,
        partnerPhone: String,
        paymentType: String,
        items: List<Triple<Product, Int, Long>>,
        notes: String
    ) -> Unit
) {
    val context = LocalContext.current

    // Header fields
    val defaultPrefix = if (isBelanjaToko) "STRUK" else "PO"
    var invoiceNumber by remember(isBelanjaToko) {
        val dateStr = SimpleDateFormat("yyyyMMdd-HHmm", Locale.getDefault()).format(Date())
        mutableStateOf("$defaultPrefix-$dateStr")
    }
    var partnerName by remember { mutableStateOf("") }
    var partnerPhone by remember { mutableStateOf("") }
    var paymentType by remember { mutableStateOf("TUNAI") } // TUNAI, TEMPO, TRANSFER
    var notes by remember { mutableStateOf("") }

    // Barcode input and controls
    var barcodeInput by remember { mutableStateOf("") }
    var showBarcodeScanner by remember { mutableStateOf(false) }
    var showProductPicker by remember { mutableStateOf(false) }

    // Master Partner Selection Dialog
    var showPartnerSelectDialog by remember { mutableStateOf(false) }
    var showAddPartnerDialog by remember { mutableStateOf(false) }

    // Cart Items
    val draftItems = remember { mutableStateListOf<PurchaseDraftItem>() }

    // Function to process barcode or SKU
    fun processBarcode(query: String) {
        val clean = query.trim()
        if (clean.isBlank()) return

        val matched = allProducts.find {
            it.sku.equals(clean, ignoreCase = true) ||
            it.name.equals(clean, ignoreCase = true)
        } ?: allProducts.find {
            it.name.contains(clean, ignoreCase = true) ||
            it.sku.contains(clean, ignoreCase = true)
        }

        if (matched != null) {
            val existing = draftItems.find { it.product.id == matched.id }
            if (existing != null) {
                existing.quantity += 1
            } else {
                draftItems.add(
                    PurchaseDraftItem(
                        product = matched,
                        quantity = 1,
                        buyPrice = matched.costPrice
                    )
                )
            }
            barcodeInput = ""
            Toast.makeText(context, "${matched.name} ditambahkan ke keranjang", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Produk dengan barcode/kode \"$clean\" tidak ditemukan!", Toast.LENGTH_SHORT).show()
        }
    }

    // Camera Barcode Scanner
    if (showBarcodeScanner) {
        BarcodeScannerDialog(
            onDismissRequest = { showBarcodeScanner = false },
            onBarcodeScanned = { scannedCode ->
                processBarcode(scannedCode)
            }
        )
    }

    // Product Picker Dialog
    if (showProductPicker) {
        ProductMultiPickerDialog(
            allProducts = allProducts,
            alreadySelectedIds = draftItems.map { it.product.id },
            onProductsSelected = { selectedList ->
                selectedList.forEach { p ->
                    draftItems.add(
                        PurchaseDraftItem(
                            product = p,
                            quantity = 1,
                            buyPrice = p.costPrice
                        )
                    )
                }
                showProductPicker = false
            },
            onDismiss = { showProductPicker = false }
        )
    }

    // Partner (Supplier/Store) Selection Dialog
    if (showPartnerSelectDialog) {
        PartnerPickerDialog(
            isBelanjaToko = isBelanjaToko,
            suppliers = masterSuppliers,
            stores = masterStores,
            onSelect = { name, phone ->
                partnerName = name
                partnerPhone = phone
                showPartnerSelectDialog = false
            },
            onOpenAddNew = {
                showPartnerSelectDialog = false
                showAddPartnerDialog = true
            },
            onDismiss = { showPartnerSelectDialog = false }
        )
    }

    // Add New Partner (Supplier/Store) Dialog
    if (showAddPartnerDialog) {
        AddNewPartnerDialog(
            isBelanjaToko = isBelanjaToko,
            onSave = { name, phone, address, newNotes ->
                if (isBelanjaToko) {
                    onAddStore(name, phone, address, newNotes)
                } else {
                    onAddSupplier(name, phone, address, newNotes)
                }
                partnerName = name
                partnerPhone = phone
                showAddPartnerDialog = false
            },
            onDismiss = { showAddPartnerDialog = false }
        )
    }

    Column(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Section 1: Header Form (No Faktur/Struk & Nama Supplier/Toko)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = if (isBelanjaToko) "Data Belanja Toko" else "Data Faktur Pembelian Supplier",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = if (isBelanjaToko) Color(0xFF0284C7) else Color(0xFF059669)
                        )

                        // Row 1: Nomor Faktur / Struk & Tombol Pilih Partner
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = invoiceNumber,
                                onValueChange = { invoiceNumber = it },
                                label = { Text(if (isBelanjaToko) "Nomor Struk *" else "Nomor Faktur *") },
                                singleLine = true,
                                modifier = Modifier.weight(1.1f)
                            )

                            OutlinedButton(
                                onClick = { showPartnerSelectDialog = true },
                                modifier = Modifier
                                    .weight(0.9f)
                                    .padding(top = 8.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = if (isBelanjaToko) Color(0xFF0284C7) else Color(0xFF059669)
                                )
                            ) {
                                Icon(
                                    imageVector = if (isBelanjaToko) Icons.Default.Store else Icons.Default.LocalShipping,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isBelanjaToko) "Pilih Toko" else "Pilih Supplier",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Row 2: Nama Supplier / Toko & No Kontak
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = partnerName,
                                onValueChange = { partnerName = it },
                                label = { Text(if (isBelanjaToko) "Nama Toko / Tempat Belanja *" else "Nama Supplier *") },
                                placeholder = { Text(if (isBelanjaToko) "Cth: Agen Sembako Makmur" else "Cth: PT Indomarco Distribusi") },
                                singleLine = true,
                                modifier = Modifier.weight(1.3f)
                            )
                            OutlinedTextField(
                                value = partnerPhone,
                                onValueChange = { partnerPhone = it },
                                label = { Text("No. HP (Opsional)") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Section 2: Controls Row
            // "tepat dibawahnya terdapat kolom scan barcode , tombol kamera dengan icon kamera saja, tombol produk, dan tombol enter."
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Input Produk Masuk",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF334155)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // 1. Kolom scan barcode
                            OutlinedTextField(
                                value = barcodeInput,
                                onValueChange = { barcodeInput = it },
                                placeholder = { Text("Scan / Ketik barcode atau nama...", fontSize = 13.sp) },
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                keyboardActions = KeyboardActions(onDone = { processBarcode(barcodeInput) }),
                                trailingIcon = if (barcodeInput.isNotEmpty()) {
                                    {
                                        IconButton(onClick = { barcodeInput = "" }) {
                                            Icon(Icons.Default.Clear, contentDescription = "Hapus", modifier = Modifier.size(18.dp))
                                        }
                                    }
                                } else null
                            )

                            // 2. Tombol kamera dengan icon kamera saja
                            IconButton(
                                onClick = { showBarcodeScanner = true },
                                modifier = Modifier
                                    .size(48.dp)
                                    .background(
                                        if (isBelanjaToko) Color(0xFF0284C7) else Color(0xFF059669),
                                        RoundedCornerShape(10.dp)
                                    )
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CameraAlt,
                                    contentDescription = "Scan Barcode Kamera",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            // 3. Tombol produk
                            Button(
                                onClick = { showProductPicker = true },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6)),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 12.dp),
                                modifier = Modifier.height(48.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Inventory, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Produk", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }

                            // 4. Tombol enter
                            Button(
                                onClick = { processBarcode(barcodeInput) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F172A)),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
                                modifier = Modifier.height(48.dp)
                            ) {
                                Icon(imageVector = Icons.AutoMirrored.Filled.KeyboardReturn, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(2.dp))
                                Text("Enter", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }

            // Section 3: Cart Header & Item List
            // "di bawahnya keranjang belanja untuk memasukkan produk sama persis seperti layar kasir.
            // namun ketika nama produk yang sudah di input kita klik akan melanjutkan ke menu edit produk sesuai dengan nama produk tersebut sehingga kita menjadi selalu update ketika mungkin ada perubahan harga dan lainnya."
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Keranjang Belanja Masuk (${draftItems.size} Item)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color(0xFF0F172A)
                    )
                    if (draftItems.isNotEmpty()) {
                        Text(
                            text = "💡 Klik nama produk untuk edit harga/detail",
                            fontSize = 11.sp,
                            color = Color(0xFF0284C7),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            if (draftItems.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(36.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.ShoppingBag,
                                contentDescription = null,
                                tint = Color(0xFFCBD5E1),
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Keranjang masih kosong",
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF64748B)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Scan barcode, gunakan kamera, atau tekan tombol Produk di atas untuk memasukkan barang yang dibeli.",
                                fontSize = 12.sp,
                                color = Color(0xFF94A3B8),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                itemsIndexed(draftItems) { index, draft ->
                    PurchaseCartItemCard(
                        item = draft,
                        onProductClick = { onEditProduct(draft.product) },
                        onQtyChange = { newQty ->
                            if (newQty <= 0) {
                                draftItems.removeAt(index)
                            } else {
                                draft.quantity = newQty
                            }
                        },
                        onPriceChange = { newPrice ->
                            draft.buyPrice = newPrice
                        },
                        onDelete = {
                            draftItems.removeAt(index)
                        }
                    )
                }
            }

            // Section 4: Catatan & Pembayaran
            if (draftItems.isNotEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(12.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "Metode Pembayaran & Catatan",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("TUNAI", "TEMPO", "TRANSFER").forEach { type ->
                                    val isSel = paymentType == type
                                    FilterChip(
                                        selected = isSel,
                                        onClick = { paymentType = type },
                                        label = { Text(type, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }

                            OutlinedTextField(
                                value = notes,
                                onValueChange = { notes = it },
                                label = { Text("Catatan Tambahan (Opsional)") },
                                placeholder = { Text("Cth: Barang promo, diskon khusus, jatuh tempo 14 hari") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }

        // Bottom Summary & Save Button
        // "dibawah keranjang belanja tombol tambahkan produk pembelian & simpan maka produk akan otomatis masuk ke stok barang."
        Surface(
            color = Color.White,
            shadowElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            val totalAmount = draftItems.sumOf { it.subtotal }
            val totalItems = draftItems.sumOf { it.quantity }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Total $totalItems Barang Masuk",
                            fontSize = 12.sp,
                            color = Color(0xFF64748B)
                        )
                        Text(
                            text = PosRepository.formatRupiah(totalAmount),
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = if (isBelanjaToko) Color(0xFF0284C7) else Color(0xFF059669)
                        )
                    }

                    Text(
                        text = "Petugas: $activeUserName",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF475569)
                    )
                }

                Button(
                    onClick = {
                        if (partnerName.isBlank()) {
                            Toast.makeText(
                                context,
                                if (isBelanjaToko) "Mohon isi Nama Toko!" else "Mohon isi Nama Supplier!",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@Button
                        }
                        if (draftItems.isEmpty()) {
                            Toast.makeText(context, "Keranjang belanja masih kosong!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        val itemsPayload = draftItems.map {
                            Triple(it.product, it.quantity, it.buyPrice)
                        }

                        onSubmitPurchase(
                            invoiceNumber,
                            partnerName,
                            partnerPhone,
                            paymentType,
                            itemsPayload,
                            notes
                        )

                        // Reset form
                        val dateStr = SimpleDateFormat("yyyyMMdd-HHmm", Locale.getDefault()).format(Date())
                        invoiceNumber = "$defaultPrefix-$dateStr"
                        partnerName = ""
                        partnerPhone = ""
                        notes = ""
                        draftItems.clear()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isBelanjaToko) Color(0xFF0284C7) else Color(0xFF059669)
                    ),
                    enabled = draftItems.isNotEmpty() && partnerName.isNotBlank()
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isBelanjaToko) "Tambahkan Produk Belanja & Simpan" else "Tambahkan Produk Pembelian & Simpan",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

/**
 * Individual Cart Item Card identical to Cashier layout, with click on product name to edit product!
 */
@Composable
private fun PurchaseCartItemCard(
    item: PurchaseDraftItem,
    onProductClick: () -> Unit,
    onQtyChange: (Int) -> Unit,
    onPriceChange: (Long) -> Unit,
    onDelete: () -> Unit
) {
    var showEditPriceDialog by remember { mutableStateOf(false) }

    if (showEditPriceDialog) {
        var priceInput by remember { mutableStateOf(item.buyPrice.toString()) }
        AlertDialog(
            onDismissRequest = { showEditPriceDialog = false },
            title = { Text("Ubah Harga Beli Faktur") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(item.product.name, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = priceInput,
                        onValueChange = { priceInput = it.filter { c -> c.isDigit() } },
                        label = { Text("Harga Beli Satuan (Rp)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val p = priceInput.toLongOrNull() ?: 0L
                        onPriceChange(p)
                        showEditPriceDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669))
                ) {
                    Text("Simpan")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showEditPriceDialog = false }) {
                    Text("Batal")
                }
            }
        )
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(10.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Row 1: Clickable Product Name (to edit product details) + Delete button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onProductClick() }
                        .padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = item.product.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color(0xFF0F172A)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit Produk",
                                tint = Color(0xFF0284C7),
                                modifier = Modifier.size(15.dp)
                            )
                        }
                        if (item.product.sku.isNotBlank()) {
                            Text(
                                text = "SKU: ${item.product.sku} | Satuan: ${item.product.unit}",
                                fontSize = 11.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Hapus",
                        tint = Color(0xFFEF4444),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Divider(color = Color(0xFFF1F5F9))

            // Row 2: Price adjustment, Qty +/- controls, Subtotal
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Buy Price Clickable badge
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFF0FDF4),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBBF7D0)),
                    modifier = Modifier.clickable { showEditPriceDialog = true }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Beli: ${PosRepository.formatRupiah(item.buyPrice)}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF166534)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            Icons.Default.Edit,
                            contentDescription = null,
                            modifier = Modifier.size(11.dp),
                            tint = Color(0xFF166534)
                        )
                    }
                }

                // Qty Stepper
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    OutlinedButton(
                        onClick = { onQtyChange(item.quantity - 1) },
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier.size(32.dp),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text("-", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }

                    Text(
                        text = "${item.quantity}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )

                    OutlinedButton(
                        onClick = { onQtyChange(item.quantity + 1) },
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier.size(32.dp),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text("+", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }

                // Subtotal
                Text(
                    text = PosRepository.formatRupiah(item.subtotal),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Color(0xFF0F172A)
                )
            }
        }
    }
}

/**
 * Partner (Supplier or Store) Picker Dialog
 */
@Composable
private fun PartnerPickerDialog(
    isBelanjaToko: Boolean,
    suppliers: List<SupplierData>,
    stores: List<StorePartnerData>,
    onSelect: (name: String, phone: String) -> Unit,
    onOpenAddNew: () -> Unit,
    onDismiss: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isBelanjaToko) "Pilih Toko Belanja" else "Pilih Data Supplier",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Clear, contentDescription = "Tutup")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(380.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Cari nama...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Button(
                    onClick = onOpenAddNew,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isBelanjaToko) Color(0xFF0284C7) else Color(0xFF059669)
                    )
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isBelanjaToko) "+ Tambah Data Toko Baru" else "+ Tambah Data Supplier Baru",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                Divider()

                if (isBelanjaToko) {
                    val filteredStores = stores.filter {
                        it.name.contains(searchQuery, ignoreCase = true) ||
                        it.address.contains(searchQuery, ignoreCase = true)
                    }
                    if (filteredStores.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("Tidak ada data toko yang cocok", color = Color.Gray)
                        }
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(filteredStores) { store ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onSelect(store.name, store.phone) },
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text(store.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        if (store.phone.isNotBlank()) {
                                            Text("HP: ${store.phone}", fontSize = 12.sp, color = Color(0xFF64748B))
                                        }
                                        if (store.address.isNotBlank()) {
                                            Text(store.address, fontSize = 11.sp, color = Color(0xFF94A3B8))
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    val filteredSuppliers = suppliers.filter {
                        it.name.contains(searchQuery, ignoreCase = true) ||
                        it.address.contains(searchQuery, ignoreCase = true)
                    }
                    if (filteredSuppliers.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("Tidak ada supplier yang cocok", color = Color.Gray)
                        }
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(filteredSuppliers) { supplier ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onSelect(supplier.name, supplier.phone) },
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text(supplier.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        if (supplier.phone.isNotBlank()) {
                                            Text("HP: ${supplier.phone}", fontSize = 12.sp, color = Color(0xFF64748B))
                                        }
                                        if (supplier.address.isNotBlank()) {
                                            Text(supplier.address, fontSize = 11.sp, color = Color(0xFF94A3B8))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {}
    )
}

/**
 * Add New Partner (Supplier or Store) Dialog
 */
@Composable
private fun AddNewPartnerDialog(
    isBelanjaToko: Boolean,
    onSave: (name: String, phone: String, address: String, notes: String) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isBelanjaToko) "Tambah Data Toko Baru" else "Tambah Data Supplier Baru",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(if (isBelanjaToko) "Nama Toko *" else "Nama Supplier *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("No. HP / Telepon") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Alamat (Opsional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Catatan / Keterangan") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onSave(name.trim(), phone.trim(), address.trim(), notes.trim())
                    }
                },
                enabled = name.isNotBlank(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isBelanjaToko) Color(0xFF0284C7) else Color(0xFF059669)
                )
            ) {
                Text("Simpan Data", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}

/**
 * Riwayat Belanja & Pembelian with full active user logging and document export (.doc & .pdf)
 */
@Composable
private fun PurchaseHistoryContent(
    purchases: List<PurchaseRecord>,
    licenseInfo: com.example.data.model.LicenseInfo,
    context: Context
) {
    var filterType by remember { mutableStateOf("SEMUA") } // SEMUA, SUPPLIER, TOKO
    var searchQuery by remember { mutableStateOf("") }
    var selectedPurchaseDetail by remember { mutableStateOf<PurchaseRecord?>(null) }

    val filteredPurchases = remember(purchases, filterType, searchQuery) {
        purchases.filter { p ->
            val isStore = p.notes.contains("[Belanja Toko]") || p.invoiceNumber.startsWith("STRUK")
            val matchesType = when (filterType) {
                "SUPPLIER" -> !isStore
                "TOKO" -> isStore
                else -> true
            }
            val matchesQuery = searchQuery.isBlank() ||
                p.invoiceNumber.contains(searchQuery, ignoreCase = true) ||
                p.supplierName.contains(searchQuery, ignoreCase = true) ||
                p.receivedBy.contains(searchQuery, ignoreCase = true)

            matchesType && matchesQuery
        }
    }

    // Detail & Export Dialog
    if (selectedPurchaseDetail != null) {
        val purchase = selectedPurchaseDetail!!
        val isStore = purchase.notes.contains("[Belanja Toko]") || purchase.invoiceNumber.startsWith("STRUK")
        val cleanNotes = purchase.notes.replace("[Belanja Toko]", "").trim()

        val parsedItems = remember(purchase.itemsJson) {
            val list = mutableListOf<Triple<String, Int, Long>>()
            try {
                val arr = JSONArray(purchase.itemsJson)
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val name = obj.optString("name", "Produk")
                    val qty = obj.optInt("qty", 1)
                    val price = obj.optLong("buyPrice", 0L)
                    list.add(Triple(name, qty, price))
                }
            } catch (_: Exception) {}
            list
        }

        AlertDialog(
            onDismissRequest = { selectedPurchaseDetail = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isStore) Icons.Default.ShoppingBag else Icons.Default.Receipt,
                        contentDescription = null,
                        tint = if (isStore) Color(0xFF0284C7) else Color(0xFF059669)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isStore) "Struk Belanja Toko: ${purchase.invoiceNumber}" else "Faktur Beli: ${purchase.invoiceNumber}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = Color(0xFFF8FAFC),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "${if (isStore) "Toko Mitra:" else "Supplier:"} ${purchase.supplierName}",
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A)
                            )
                            if (purchase.supplierPhone.isNotBlank()) {
                                Text("Kontak: ${purchase.supplierPhone}", fontSize = 12.sp, color = Color(0xFF64748B))
                            }
                            Text("Tanggal: ${PosRepository.formatDate(purchase.date)}", fontSize = 12.sp)
                            Text("Pembayaran: ${purchase.paymentType}", fontSize = 12.sp)
                            Text(
                                text = "Petugas / User Aktif: ${purchase.receivedBy}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF059669)
                            )
                            if (cleanNotes.isNotBlank()) {
                                Text("Catatan: $cleanNotes", fontSize = 12.sp, color = Color(0xFF475569))
                            }
                        }
                    }

                    Text("Rincian Produk Masuk:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    parsedItems.forEach { (name, qty, price) ->
                        val subtotal = qty * price
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text("$qty x ${PosRepository.formatRupiah(price)}", fontSize = 11.sp, color = Color.Gray)
                            }
                            Text(PosRepository.formatRupiah(subtotal), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Divider(color = Color(0xFFF1F5F9), modifier = Modifier.padding(vertical = 2.dp))
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("TOTAL TRANSAKSI:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            text = PosRepository.formatRupiah(purchase.totalAmount),
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = if (isStore) Color(0xFF0284C7) else Color(0xFF059669)
                        )
                    }

                    Divider(modifier = Modifier.padding(vertical = 6.dp))

                    Text("Simpan / Ekspor Dokumen:", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                    // Export Word (.doc)
                    Button(
                        onClick = {
                            try {
                                val file = ReportExportHelper.generateSingleSupplierPurchaseInvoiceDoc(context, licenseInfo, purchase)
                                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "application/msword"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    putExtra(Intent.EXTRA_SUBJECT, "Dokumen ${purchase.invoiceNumber}")
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(intent, "Simpan / Bagikan Dokumen Word"))
                                Toast.makeText(context, "Dokumen Word berhasil dibuat!", Toast.LENGTH_SHORT).show()
                            } catch (e: Exception) {
                                Toast.makeText(context, "Gagal ekspor: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Simpan Dokumen Word (.doc)")
                    }

                    // Export PDF (.pdf)
                    Button(
                        onClick = {
                            try {
                                val file = ReportExportHelper.generatePurchasePdf(context, licenseInfo, purchase)
                                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "application/pdf"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    putExtra(Intent.EXTRA_SUBJECT, "Dokumen PDF ${purchase.invoiceNumber}")
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(intent, "Simpan / Cetak Dokumen PDF"))
                                Toast.makeText(context, "Dokumen PDF berhasil dibuat!", Toast.LENGTH_SHORT).show()
                            } catch (e: Exception) {
                                Toast.makeText(context, "Gagal ekspor PDF: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Simpan Dokumen PDF (.pdf)")
                    }
                }
            },
            confirmButton = {
                OutlinedButton(onClick = { selectedPurchaseDetail = null }) {
                    Text("Tutup")
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Search & Filter
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Cari no faktur/struk, nama, atau user kasir...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = filterType == "SEMUA",
                onClick = { filterType = "SEMUA" },
                label = { Text("Semua (${purchases.size})") },
                modifier = Modifier.weight(1f)
            )
            FilterChip(
                selected = filterType == "SUPPLIER",
                onClick = { filterType = "SUPPLIER" },
                label = { Text("Supplier") },
                modifier = Modifier.weight(1f)
            )
            FilterChip(
                selected = filterType == "TOKO",
                onClick = { filterType = "TOKO" },
                label = { Text("Belanja Toko") },
                modifier = Modifier.weight(1f)
            )
        }

        if (filteredPurchases.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        modifier = Modifier.size(54.dp),
                        tint = Color(0xFFCBD5E1)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Belum ada riwayat transaksi",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF64748B)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredPurchases) { p ->
                    val isStore = p.notes.contains("[Belanja Toko]") || p.invoiceNumber.startsWith("STRUK")
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedPurchaseDetail = p },
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(10.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(
                                            if (isStore) Color(0xFFE0F2FE) else Color(0xFFDCFCE7),
                                            RoundedCornerShape(8.dp)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isStore) Icons.Default.ShoppingBag else Icons.Default.LocalShipping,
                                        contentDescription = null,
                                        tint = if (isStore) Color(0xFF0284C7) else Color(0xFF059669),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = p.supplierName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = Color(0xFF0F172A)
                                    )
                                    Text(
                                        text = "${p.invoiceNumber} • ${PosRepository.formatDate(p.date)}",
                                        fontSize = 11.sp,
                                        color = Color(0xFF64748B)
                                    )
                                    Text(
                                        text = "Input: ${p.receivedBy} (${p.paymentType})",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = Color(0xFF059669)
                                    )
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = PosRepository.formatRupiah(p.totalAmount),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = if (isStore) Color(0xFF0284C7) else Color(0xFF059669)
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Lihat & Dokumen >",
                                    fontSize = 11.sp,
                                    color = Color(0xFF3B82F6),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Product Multi-Picker Dialog for catalog selection
 */
@Composable
private fun ProductMultiPickerDialog(
    allProducts: List<Product>,
    alreadySelectedIds: List<Long>,
    onProductsSelected: (List<Product>) -> Unit,
    onDismiss: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Semua") }
    val chosenProducts = remember { mutableStateListOf<Product>() }

    val categories = remember(allProducts) {
        val list = mutableListOf("Semua")
        list.addAll(allProducts.map { it.category }.distinct().filter { it.isNotBlank() })
        list
    }

    val availableProducts = remember(allProducts, alreadySelectedIds) {
        allProducts.filter { it.id !in alreadySelectedIds }
    }

    val filteredProducts = remember(availableProducts, searchQuery, selectedCategory) {
        availableProducts.filter { p ->
            val matchCat = selectedCategory == "Semua" || p.category.equals(selectedCategory, ignoreCase = true)
            val matchQuery = searchQuery.isBlank() ||
                p.name.contains(searchQuery, ignoreCase = true) ||
                p.sku.contains(searchQuery, ignoreCase = true)
            matchCat && matchQuery
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Pilih Produk Masuk (${chosenProducts.size} Dipilih)",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(420.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Cari nama produk atau barcode...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Category chips
                androidx.compose.foundation.lazy.LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(categories) { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat, fontSize = 11.sp) }
                        )
                    }
                }

                Divider()

                if (filteredProducts.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Tidak ada produk tersedia", color = Color.Gray)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(filteredProducts) { product ->
                            val isChecked = chosenProducts.any { it.id == product.id }
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (isChecked) {
                                            chosenProducts.removeAll { it.id == product.id }
                                        } else {
                                            chosenProducts.add(product)
                                        }
                                    },
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isChecked) Color(0xFFDCFCE7) else Color(0xFFF8FAFC)
                                ),
                                shape = RoundedCornerShape(8.dp),
                                border = if (isChecked) androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF059669)) else null
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(product.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(
                                            "SKU: ${product.sku.ifBlank { "-" }} • Stok Saat Ini: ${product.stock} ${product.unit}",
                                            fontSize = 11.sp,
                                            color = Color.Gray
                                        )
                                        Text(
                                            "HPP Terakhir: ${PosRepository.formatRupiah(product.costPrice)} | Jual: ${PosRepository.formatRupiah(product.sellPrice)}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = Color(0xFF059669)
                                        )
                                    }
                                    androidx.compose.material3.Checkbox(
                                        checked = isChecked,
                                        onCheckedChange = { checked ->
                                            if (checked) chosenProducts.add(product)
                                            else chosenProducts.removeAll { it.id == product.id }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onProductsSelected(chosenProducts.toList()) },
                enabled = chosenProducts.isNotEmpty(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669))
            ) {
                Text("Tambahkan (${chosenProducts.size})", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}
