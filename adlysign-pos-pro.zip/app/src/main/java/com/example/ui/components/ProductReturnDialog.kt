package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.AssignmentReturn
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Product
import com.example.data.model.TransactionRecord
import com.example.data.repository.PosRepository
import com.example.ui.theme.posOutlinedTextFieldColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductReturnDialog(
    products: List<Product>,
    transactions: List<TransactionRecord>,
    onDismiss: () -> Unit,
    onSubmitReturn: (
        productId: Long,
        productName: String,
        qty: Int,
        returnType: String,
        reason: String,
        customerOrSupplier: String,
        notes: String
    ) -> Unit,
    onVoidTransactionForReturn: (TransactionRecord, String) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }

    // Tab 0: Return manual product
    var selectedProduct by remember { mutableStateOf<Product?>(products.firstOrNull()) }
    var expandedDropdown by remember { mutableStateOf(false) }
    var returnQtyText by remember { mutableStateOf("1") }
    var returnType by remember { mutableStateOf("MASUK_STOK") } // MASUK_STOK or KELUAR_STOK
    var reason by remember { mutableStateOf("Barang Rusak / Cacat") }
    var customerName by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    val reasons = listOf(
        "Barang Rusak / Cacat",
        "Salah Beli / Ukuran",
        "Kadaluarsa / Expired",
        "Kemasan Rusak",
        "Komplain Pelanggan"
    )

    // Tab 1: Return from Receipt
    var txSearchQuery by remember { mutableStateOf("") }
    val filteredTx = remember(txSearchQuery, transactions) {
        if (txSearchQuery.isBlank()) {
            transactions.take(20)
        } else {
            transactions.filter {
                it.receiptNumber.contains(txSearchQuery, ignoreCase = true) ||
                        it.customerName.contains(txSearchQuery, ignoreCase = true)
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(vertical = 16.dp)
                .testTag("product_return_dialog")
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Header
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(Color(0xFFEDE9FE), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.AssignmentReturn,
                                contentDescription = null,
                                tint = Color(0xFF6D28D9)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Menu Retur Barang & Transaksi",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color(0xFF0F172A)
                            )
                            Text(
                                text = "Pengembalian Barang Pelanggan atau Barang Rusak",
                                fontSize = 12.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color(0xFFF1F5F9),
                    modifier = Modifier.background(Color(0xFFF1F5F9), RoundedCornerShape(10.dp))
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("Retur Barang Produk", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Retur dari Struk Nota", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (selectedTab == 0) {
                    // TAB 0: Retur Produk Manual
                    LazyColumn(
                        modifier = Modifier.weight(1f, fill = false),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            Text(
                                text = "Tipe Alur Retur:",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF475569)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = returnType == "MASUK_STOK",
                                    onClick = { returnType = "MASUK_STOK" },
                                    label = { Text("Retur Pembeli (+Stok)", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Color(0xFF10B981),
                                        selectedLabelColor = Color.White
                                    )
                                )
                                FilterChip(
                                    selected = returnType == "KELUAR_STOK",
                                    onClick = { returnType = "KELUAR_STOK" },
                                    label = { Text("Barang Rusak/Supplier (-Stok)", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Color(0xFFEF4444),
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }

                        item {
                            Text(
                                text = "Pilih Produk:",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF475569)
                            )
                            Spacer(modifier = Modifier.height(4.dp))

                            ExposedDropdownMenuBox(
                                expanded = expandedDropdown,
                                onExpandedChange = { expandedDropdown = it },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                OutlinedTextField(
                                    value = selectedProduct?.let { "${it.name} (Stok: ${it.stock} ${it.unit})" } ?: "Pilih Produk",
                                    onValueChange = {},
                                    readOnly = true,
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedDropdown) },
                                    modifier = Modifier
                                        .menuAnchor()
                                        .fillMaxWidth(),
                                    colors = posOutlinedTextFieldColors(),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                ExposedDropdownMenu(
                                    expanded = expandedDropdown,
                                    onDismissRequest = { expandedDropdown = false }
                                ) {
                                    products.forEach { prod ->
                                        DropdownMenuItem(
                                            text = { Text("${prod.name} (Stok: ${prod.stock} ${prod.unit} - ${PosRepository.formatRupiah(prod.sellPrice)})") },
                                            onClick = {
                                                selectedProduct = prod
                                                expandedDropdown = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = returnQtyText,
                                    onValueChange = { returnQtyText = it.filter { ch -> ch.isDigit() } },
                                    label = { Text("Jumlah Retur (Qty)") },
                                    colors = posOutlinedTextFieldColors(),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                )

                                OutlinedTextField(
                                    value = customerName,
                                    onValueChange = { customerName = it },
                                    label = { Text(if (returnType == "MASUK_STOK") "Nama Pelanggan" else "Supplier / Petugas") },
                                    placeholder = { Text("Opsional") },
                                    colors = posOutlinedTextFieldColors(),
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1.3f)
                                )
                            }
                        }

                        item {
                            Text(
                                text = "Alasan Retur:",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF475569)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                reasons.take(3).forEach { r ->
                                    FilterChip(
                                        selected = reason == r,
                                        onClick = { reason = r },
                                        label = { Text(r, fontSize = 11.sp) }
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                reasons.drop(3).forEach { r ->
                                    FilterChip(
                                        selected = reason == r,
                                        onClick = { reason = r },
                                        label = { Text(r, fontSize = 11.sp) }
                                    )
                                }
                            }
                        }

                        item {
                            OutlinedTextField(
                                value = notes,
                                onValueChange = { notes = it },
                                label = { Text("Catatan Tambahan Retur") },
                                placeholder = { Text("Contoh: Dus sobek, diganti produk baru, dll.") },
                                colors = posOutlinedTextFieldColors(),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = onDismiss,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f).height(48.dp)
                        ) {
                            Text("Batal", color = Color(0xFF475569), fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                val prod = selectedProduct
                                val qty = returnQtyText.toIntOrNull() ?: 1
                                if (prod != null && qty > 0) {
                                    onSubmitReturn(
                                        prod.id,
                                        prod.name,
                                        qty,
                                        returnType,
                                        reason,
                                        customerName,
                                        notes
                                    )
                                    onDismiss()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (returnType == "MASUK_STOK") Color(0xFF10B981) else Color(0xFFEF4444)
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1.4f).height(48.dp)
                        ) {
                            Text(
                                text = if (returnType == "MASUK_STOK") "Proses Retur Pelanggan" else "Catat Barang Rusak",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                } else {
                    // TAB 1: Retur dari Nota Transaksi
                    Column(modifier = Modifier.weight(1f, fill = false)) {
                        OutlinedTextField(
                            value = txSearchQuery,
                            onValueChange = { txSearchQuery = it },
                            placeholder = { Text("Cari no. struk atau nama pelanggan...") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                            colors = posOutlinedTextFieldColors(),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().height(52.dp)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        if (filteredTx.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(150.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("Tidak ada transaksi yang cocok", color = Color(0xFF94A3B8), fontSize = 13.sp)
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.height(280.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(filteredTx, key = { it.id }) { tx ->
                                    Card(
                                        shape = RoundedCornerShape(10.dp),
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (tx.isVoid) Color(0xFFFEF2F2) else Color(0xFFF8FAFC)
                                        ),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = tx.receiptNumber,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 13.sp,
                                                    color = Color(0xFF0F172A)
                                                )
                                                Text(
                                                    text = "${PosRepository.formatDate(tx.timestamp)} • ${tx.customerName}",
                                                    fontSize = 11.sp,
                                                    color = Color(0xFF64748B)
                                                )
                                                Text(
                                                    text = "Total: ${PosRepository.formatRupiah(tx.totalAmount)} (${tx.paymentMethod})",
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = Color(0xFF10B981)
                                                )
                                                if (tx.isVoid) {
                                                    Text(
                                                        text = "Status: Sudah Diretur / Void",
                                                        fontSize = 11.sp,
                                                        color = Color(0xFFDC2626),
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }

                                            if (!tx.isVoid) {
                                                Button(
                                                    onClick = {
                                                        onVoidTransactionForReturn(tx, "Retur Transaksi Pelanggan")
                                                        onDismiss()
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                                                    shape = RoundedCornerShape(8.dp)
                                                ) {
                                                    Text("Retur Struk", fontSize = 11.sp)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF64748B))
                    ) {
                        Text("Tutup", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
