package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.Product
import com.example.data.model.RepackUnit
import com.example.data.repository.PosRepository
import org.json.JSONArray
import org.json.JSONObject

@Composable
fun AddEditProductDialog(
    product: Product?,
    onDismiss: () -> Unit,
    onSave: (
        id: Long,
        name: String,
        sku: String,
        category: String,
        sellPrice: Long,
        costPrice: Long,
        stock: Int,
        unit: String,
        repackUnitsJson: String,
        tieredPricesJson: String
    ) -> Unit
) {
    var name by remember { mutableStateOf(product?.name ?: "") }
    var sku by remember { mutableStateOf(product?.sku ?: "") }
    var category by remember { mutableStateOf(product?.category ?: "Umum") }
    var sellPriceText by remember { mutableStateOf(product?.sellPrice?.toString() ?: "") }
    var costPriceText by remember { mutableStateOf(product?.costPrice?.toString() ?: "") }
    var stockText by remember { mutableStateOf(product?.stock?.toString() ?: "0") }
    var unit by remember { mutableStateOf(product?.unit ?: "pcs") }
    var showBarcodeScanner by remember { mutableStateOf(false) }

    // Multi-satuan repack
    var repackUnitName by remember { mutableStateOf("") }
    var repackMultiplierText by remember { mutableStateOf("") }
    var repackPriceText by remember { mutableStateOf("") }
    val repackList = remember {
        val list = mutableListOf<RepackUnit>()
        product?.getRepackUnits()?.let { list.addAll(it) }
        mutableStateOf(list)
    }

    if (showBarcodeScanner) {
        BarcodeScannerDialog(
            onDismissRequest = { showBarcodeScanner = false },
            onBarcodeScanned = { code ->
                sku = code
            }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (product == null) "Tambah Produk Baru" else "Ubah Data Produk \"${product.name}\"",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nama Produk *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = sku,
                        onValueChange = { sku = it },
                        label = { Text("Barcode / SKU") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = { showBarcodeScanner = true },
                        modifier = Modifier.size(50.dp)
                    ) {
                        Icon(imageVector = Icons.Default.QrCodeScanner, contentDescription = "Scan", tint = Color(0xFF059669))
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it },
                        label = { Text("Kategori") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = unit,
                        onValueChange = { unit = it },
                        label = { Text("Satuan Dasar") },
                        placeholder = { Text("pcs/kg/ltr") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = sellPriceText,
                        onValueChange = { sellPriceText = it.filter { c -> c.isDigit() } },
                        label = { Text("Harga Jual *") },
                        prefix = { Text("Rp ") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = costPriceText,
                        onValueChange = { costPriceText = it.filter { c -> c.isDigit() } },
                        label = { Text("Harga Modal (HPP)") },
                        prefix = { Text("Rp ") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = stockText,
                    onValueChange = { stockText = it.filter { c -> c.isDigit() } },
                    label = { Text("Jumlah Stok *") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Divider(modifier = Modifier.padding(vertical = 4.dp))

                // Repack / Multi Kemasan Section
                Text(
                    text = "Konversi Satuan Kemasan (Opsional):",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0284C7)
                )

                if (repackList.value.isNotEmpty()) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        repackList.value.forEachIndexed { idx, ru ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFFF1F5F9), RoundedCornerShape(8.dp))
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "1 ${ru.unitName} = ${ru.multiplier} $unit | Jual: ${PosRepository.formatRupiah(ru.sellPrice)}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                IconButton(
                                    onClick = {
                                        val cur = repackList.value.toMutableList()
                                        cur.removeAt(idx)
                                        repackList.value = cur
                                    },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Clear, contentDescription = "Hapus", tint = Color.Red, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = repackUnitName,
                        onValueChange = { repackUnitName = it },
                        label = { Text("Nama Satuan") },
                        placeholder = { Text("Dus/Lusin") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = repackMultiplierText,
                        onValueChange = { repackMultiplierText = it.filter { c -> c.isDigit() } },
                        label = { Text("Isi ($unit)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(0.8f)
                    )
                    OutlinedTextField(
                        value = repackPriceText,
                        onValueChange = { repackPriceText = it.filter { c -> c.isDigit() } },
                        label = { Text("Harga") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = {
                            val mult = repackMultiplierText.toIntOrNull() ?: 1
                            val pPrice = repackPriceText.toLongOrNull() ?: 0L
                            if (repackUnitName.isNotBlank() && mult > 1) {
                                val cur = repackList.value.toMutableList()
                                cur.add(RepackUnit(repackUnitName.trim(), mult, pPrice))
                                repackList.value = cur
                                repackUnitName = ""
                                repackMultiplierText = ""
                                repackPriceText = ""
                            }
                        },
                        modifier = Modifier.padding(top = 8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Tambah Satuan", tint = Color(0xFF059669))
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val sPrice = sellPriceText.toLongOrNull() ?: 0L
                    val cPrice = costPriceText.toLongOrNull() ?: 0L
                    val stk = stockText.toIntOrNull() ?: 0
                    val repackJson = if (repackList.value.isNotEmpty()) {
                        val arr = JSONArray()
                        for (r in repackList.value) {
                            arr.put(JSONObject().apply {
                                put("unitName", r.unitName)
                                put("multiplier", r.multiplier)
                                put("sellPrice", r.sellPrice)
                            })
                        }
                        arr.toString()
                    } else ""

                    onSave(
                        product?.id ?: 0L,
                        name,
                        sku,
                        category,
                        sPrice,
                        cPrice,
                        stk,
                        unit,
                        repackJson,
                        product?.tieredPricesJson ?: ""
                    )
                },
                enabled = name.isNotBlank() && sellPriceText.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669))
            ) {
                Text("Simpan Produk", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}
