package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Stars
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.repository.PosRepository
import com.example.license.LicenseManager
import com.example.ui.components.BackupRestoreSection
import com.example.ui.components.EmployeeManagementDialog
import com.example.ui.components.PointSettingsDialog
import com.example.ui.theme.AmberShift1
import com.example.ui.theme.BlueShift2
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.PurpleShift3
import com.example.ui.theme.SlateDark
import com.example.ui.theme.SlateLight
import com.example.ui.theme.SlateMedium
import com.example.ui.theme.SuccessGreen
import com.example.ui.viewmodel.PosViewModel

@Composable
fun SettingsAndLicenseScreen(viewModel: PosViewModel) {
    val context = LocalContext.current
    val licenseInfo by viewModel.licenseInfo.collectAsStateWithLifecycle()
    val syncServerState by viewModel.syncServerState.collectAsStateWithLifecycle()
    val syncClientHostIp by viewModel.syncClientHostIp.collectAsStateWithLifecycle()
    val syncStatusText by viewModel.syncStatusText.collectAsStateWithLifecycle()
    val isSyncing by viewModel.isSyncing.collectAsStateWithLifecycle()

    // Store Info & Logo state
    var storeName by remember { mutableStateOf(licenseInfo.storeName) }
    var storeAddress by remember { mutableStateOf(licenseInfo.storeAddress) }
    var storePhone by remember { mutableStateOf(licenseInfo.storePhone) }
    var receiptFooter by remember { mutableStateOf(licenseInfo.receiptFooter) }
    var storeLogoUri by remember { mutableStateOf(licenseInfo.storeLogoUri) }

    // Payment & QRIS state
    var qrisImageUri by remember { mutableStateOf(licenseInfo.qrisImageUri) }
    var qrisMerchantName by remember { mutableStateOf(licenseInfo.qrisMerchantName) }
    var qrisNmid by remember { mutableStateOf(licenseInfo.qrisNmid) }

    androidx.compose.runtime.LaunchedEffect(licenseInfo) {
        storeName = licenseInfo.storeName
        storeAddress = licenseInfo.storeAddress
        storePhone = licenseInfo.storePhone
        receiptFooter = licenseInfo.receiptFooter
        storeLogoUri = licenseInfo.storeLogoUri
        qrisImageUri = licenseInfo.qrisImageUri
        qrisMerchantName = licenseInfo.qrisMerchantName.ifBlank { licenseInfo.storeName }
        qrisNmid = licenseInfo.qrisNmid
    }

    // Image Picker for Store Logo
    val storeLogoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val savedPath = copyUriToInternalStorage(context, uri, "store_logo")
            if (savedPath != null) {
                storeLogoUri = savedPath
                viewModel.updateStoreLogo(savedPath)
                Toast.makeText(context, "Logo toko berhasil diperbarui!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Image Picker for QRIS Barcode
    val qrisPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val savedPath = copyUriToInternalStorage(context, uri, "qris_barcode")
            if (savedPath != null) {
                qrisImageUri = savedPath
                viewModel.updateQrisSettings(savedPath, qrisMerchantName, qrisNmid)
                Toast.makeText(context, "Gambar QRIS berhasil diunggah!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // License Activation form
    var inputLicenseKey by remember { mutableStateOf("") }

    // Employee & Points
    val currentEmployee by viewModel.currentEmployee.collectAsStateWithLifecycle()
    val employees by viewModel.employees.collectAsStateWithLifecycle()
    val pointSettings by viewModel.pointSettings.collectAsStateWithLifecycle()
    var showEmployeeDialog by remember { mutableStateOf(false) }
    var showPointSettingsDialog by remember { mutableStateOf(false) }

    // Locked for Cashier
    if (currentEmployee?.role == "KASIR") {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF8FAFC))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(16.dp))
            ) {
                Column(
                    modifier = Modifier.padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFFFEF2F2),
                        modifier = Modifier.size(72.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Default.Lock,
                                contentDescription = null,
                                tint = ErrorRed,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Menu Pengaturan Terkunci",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SlateDark
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Akun Kasir (${currentEmployee?.name}) tidak memiliki hak akses untuk membuka Menu Pengaturan. Silakan hubungi Supervisor atau Pemilik Toko.",
                        fontSize = 13.sp,
                        color = SlateMedium,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- Header ---
        item {
            Text(
                text = "Pengaturan, Sinkronisasi & Lisensi",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = SlateDark
            )
            Text(
                text = "Konfigurasi toko, sinkronisasi jaringan lokal LAN/Wi-Fi, dan manajemen lisensi perangkat.",
                style = MaterialTheme.typography.bodySmall,
                color = SlateLight
            )
        }

        // ==========================================
        // SECTION 1: SISTEM LISENSI KOMERSIAL
        // ==========================================
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(16.dp))
                    .testTag("license_section_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Status Lisensi Aplikasi",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }

                        // Badge
                        val tierColor = if (licenseInfo.isActivated) EmeraldPrimary else AmberShift1
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = tierColor.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = if (licenseInfo.isActivated) "AKTIF: ${licenseInfo.licenseTier}" else "MASA UJI COBA",
                                color = tierColor,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Device ID Box (Hardware Fingerprint)
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFF1F5F9),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Device ID Perangkat Ini:", fontSize = 11.sp, color = SlateLight)
                                Text(
                                    text = licenseInfo.deviceId,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = SlateDark
                                )
                            }
                            IconButton(onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("Device ID", licenseInfo.deviceId)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "Device ID disalin ke clipboard!", Toast.LENGTH_SHORT).show()
                            }) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Salin ID", tint = SlateMedium)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (!licenseInfo.isActivated) {
                        Text(
                            text = "Masa Uji Coba: ${licenseInfo.currentTransactionsCount} dari ${licenseInfo.maxTrialTransactions} transaksi telah digunakan (${licenseInfo.remainingTrialTransactions} transaksi tersisa).",
                            fontSize = 12.sp,
                            color = AmberShift1
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        // Activation Form
                        OutlinedTextField(
                            value = inputLicenseKey,
                            onValueChange = { inputLicenseKey = it.uppercase() },
                            label = { Text("Masukkan Kunci Lisensi (License Key)") },
                            placeholder = { Text("Contoh: KPOS-PRO-XXXX-XXXX") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("license_key_input")
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Button(
                            onClick = {
                                viewModel.activateLicenseKey(inputLicenseKey)
                                inputLicenseKey = ""
                            },
                            enabled = inputLicenseKey.isNotBlank(),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("activate_license_button")
                        ) {
                            Icon(Icons.Default.Key, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Aktivasi Lisensi Permanen", fontWeight = FontWeight.Bold)
                        }
                    } else {
                        // Already Activated
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Lisensi Resmi Aktif Seumur Hidup (Lifetime) untuk perangkat ini.",
                                fontSize = 12.sp,
                                color = SuccessGreen,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        if (licenseInfo.licenseKey.isNotBlank()) {
                            Text(
                                text = "Kunci: ${licenseInfo.licenseKey}",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = SlateLight,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }
                }
            }
        }

        // ==========================================
        // SECTION 2: SINKRONISASI JARINGAN LOKAL (LAN/WIFI)
        // ==========================================
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(16.dp))
                    .testTag("sync_section_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Wifi, contentDescription = null, tint = BlueShift2, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Sinkronisasi Jaringan Lokal (LAN/Wi-Fi)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Sinkronkan produk & transaksi antar kasir di jaringan Wi-Fi / Hotspot yang sama tanpa internet.",
                        fontSize = 12.sp,
                        color = SlateLight
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // IP Info Box
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFEFF6FF),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("IP Jaringan Perangkat Ini:", fontSize = 11.sp, color = SlateLight)
                                Text(
                                    text = "${syncServerState.localIp}:${syncServerState.port}",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SlateDark
                                )
                            }
                            IconButton(onClick = { viewModel.syncManager.updateLocalIp() }) {
                                Icon(Icons.Default.Refresh, contentDescription = "Refresh IP", tint = BlueShift2)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // MODE 1: SERVER (Kasir Utama / Host)
                    Text("1. Mode Host (Kasir Utama / Server):", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (syncServerState.isRunning) "Server Sinkronisasi Aktif" else "Server Non-Aktif",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp,
                                color = if (syncServerState.isRunning) SuccessGreen else SlateMedium
                            )
                            Text(
                                text = syncServerState.lastSyncMessage,
                                fontSize = 11.sp,
                                color = SlateLight
                            )
                        }

                        Switch(
                            checked = syncServerState.isRunning,
                            onCheckedChange = { viewModel.toggleSyncServer() },
                            colors = SwitchDefaults.colors(checkedThumbColor = EmeraldPrimary, checkedTrackColor = EmeraldPrimary.copy(alpha = 0.5f)),
                            modifier = Modifier.testTag("toggle_sync_server_switch")
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = Color(0xFFF1F5F9))

                    // MODE 2: CLIENT (Kasir Terminal / Cabang)
                    Text("2. Mode Terminal (Kasir Cabang / Klien):", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Masukkan IP Kasir Utama untuk menarik katalog atau mengirim transaksi lokal:",
                        fontSize = 11.sp,
                        color = SlateLight
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = syncClientHostIp,
                        onValueChange = { viewModel.syncClientHostIp.value = it },
                        label = { Text("IP Kasir Utama (Host)") },
                        placeholder = { Text("Contoh: 192.168.1.50") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("sync_host_ip_input")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.testConnectionToHost(syncClientHostIp) },
                            enabled = syncClientHostIp.isNotBlank() && !isSyncing,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("test_sync_conn_button")
                        ) {
                            Text("Tes Koneksi", fontSize = 12.sp)
                        }

                        Button(
                            onClick = { viewModel.pullProductsFromHost(syncClientHostIp) },
                            enabled = syncClientHostIp.isNotBlank() && !isSyncing,
                            colors = ButtonDefaults.buttonColors(containerColor = BlueShift2),
                            modifier = Modifier
                                .weight(1.3f)
                                .testTag("pull_products_sync_button")
                        ) {
                            Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Tarik Produk", fontSize = 12.sp)
                        }

                        Button(
                            onClick = { viewModel.pushTransactionsToHost(syncClientHostIp) },
                            enabled = syncClientHostIp.isNotBlank() && !isSyncing,
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            modifier = Modifier
                                .weight(1.3f)
                                .testTag("push_tx_sync_button")
                        ) {
                            Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Kirim Data", fontSize = 12.sp)
                        }
                    }

                    if (isSyncing) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(top = 8.dp)
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Sedang menyinkronkan data...", fontSize = 12.sp, color = SlateMedium)
                        }
                    }

                    if (syncStatusText.isNotBlank()) {
                        Text(
                            text = syncStatusText,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = SlateDark,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                }
            }
        }

        // ==========================================
        // SECTION 3: PROFIL TOKO, LOGO & CATATAN STRUK
        // ==========================================
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Store, contentDescription = null, tint = EmeraldPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Profil Usaha, Logo & Identitas Struk",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = SlateDark
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // --- STORE LOGO SECTION ---
                    Text(
                        text = "Logo Toko / Usaha:",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        color = SlateDark
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFF8FAFC), RoundedCornerShape(12.dp))
                            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color.White)
                                .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (storeLogoUri.isNotBlank()) {
                                AsyncImage(
                                    model = storeLogoUri,
                                    contentDescription = "Logo Toko",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Icon(
                                    Icons.Default.Image,
                                    contentDescription = null,
                                    tint = SlateLight,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (storeLogoUri.isNotBlank()) "Logo toko aktif terpasang" else "Belum ada logo toko",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (storeLogoUri.isNotBlank()) Color(0xFF16A34A) else SlateMedium
                            )
                            Text(
                                text = "Tampil di pojok atas kasir dan cetakan struk pembayaran",
                                fontSize = 11.sp,
                                color = SlateLight
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Button(
                                    onClick = {
                                        storeLogoPicker.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.height(34.dp)
                                ) {
                                    Icon(Icons.Default.PhotoCamera, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(if (storeLogoUri.isNotBlank()) "Ganti Logo" else "Pilih Logo", fontSize = 11.sp)
                                }

                                if (storeLogoUri.isNotBlank()) {
                                    OutlinedButton(
                                        onClick = {
                                            storeLogoUri = ""
                                            viewModel.updateStoreLogo("")
                                            Toast.makeText(context, "Logo toko dihapus", Toast.LENGTH_SHORT).show()
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.height(34.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Hapus", fontSize = 11.sp, color = Color(0xFFDC2626))
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = storeName,
                        onValueChange = { storeName = it },
                        label = { Text("Nama Toko / Usaha") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = storeAddress,
                        onValueChange = { storeAddress = it },
                        label = { Text("Alamat Toko") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = storePhone,
                        onValueChange = { storePhone = it },
                        label = { Text("No. Telepon / WhatsApp") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = receiptFooter,
                        onValueChange = { receiptFooter = it },
                        label = { Text("Pesan Penutup Struk (Footer)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            viewModel.updateStoreProfile(storeName, storeAddress, storePhone, receiptFooter)
                            viewModel.updateStoreLogo(storeLogoUri)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Simpan Informasi & Logo Toko", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // ==========================================
        // SECTION 4B: PENGATURAN PEMBAYARAN & QRIS
        // ==========================================
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Payment, contentDescription = null, tint = Color(0xFF0284C7))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Pengaturan Pembayaran & QRIS",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = SlateDark
                                )
                                Text(
                                    text = "Upload gambar barcode QRIS statis / dinamis toko",
                                    fontSize = 12.sp,
                                    color = SlateLight
                                )
                            }
                        }

                        Surface(
                            color = Color(0xFFE0F2FE),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "QRIS",
                                color = Color(0xFF0284C7),
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // QRIS Image Preview Card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            if (qrisImageUri.isNotBlank()) {
                                Box(
                                    modifier = Modifier
                                        .size(160.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color.White)
                                        .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    AsyncImage(
                                        model = qrisImageUri,
                                        contentDescription = "Preview Barcode QRIS",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Fit
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Gambar QRIS Aktif Terpasang",
                                    color = Color(0xFF16A34A),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(120.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color.White)
                                        .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.QrCode,
                                        contentDescription = null,
                                        tint = Color(0xFF94A3B8),
                                        modifier = Modifier.size(72.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Belum Ada Gambar QRIS",
                                    color = SlateDark,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = "Silakan klik tombol di bawah untuk memilih gambar QRIS dari galeri Anda",
                                    color = SlateMedium,
                                    fontSize = 11.sp,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Button(
                                    onClick = {
                                        qrisPicker.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.PhotoCamera, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        if (qrisImageUri.isNotBlank()) "Ganti Gambar QRIS" else "Upload Gambar QRIS",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }

                                if (qrisImageUri.isNotBlank()) {
                                    OutlinedButton(
                                        onClick = {
                                            qrisImageUri = ""
                                            viewModel.updateQrisSettings("", qrisMerchantName, qrisNmid)
                                            Toast.makeText(context, "Gambar QRIS telah dihapus", Toast.LENGTH_SHORT).show()
                                        },
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Hapus", color = Color(0xFFDC2626), fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = qrisMerchantName,
                        onValueChange = { qrisMerchantName = it },
                        label = { Text("Nama Merchant QRIS") },
                        placeholder = { Text("Contoh: TOKO BERKAH JAYA") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = qrisNmid,
                        onValueChange = { qrisNmid = it },
                        label = { Text("NMID QRIS (Opsional)") },
                        placeholder = { Text("Contoh: ID1020304050607") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            viewModel.updateQrisSettings(qrisImageUri, qrisMerchantName, qrisNmid)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Simpan Pengaturan QRIS", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // ==========================================
        // SECTION 5: MANAJEMEN KARYAWAN & HAK AKSES
        // ==========================================
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.People, contentDescription = null, tint = EmeraldPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Karyawan & Hak Akses",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "${employees.size} karyawan terdaftar",
                                    fontSize = 12.sp,
                                    color = SlateLight
                                )
                            }
                        }

                        Button(
                            onClick = { showEmployeeDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                        ) {
                            Text("Kelola Karyawan")
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Brief preview of registered employees
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        employees.take(3).forEach { emp ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFFF8FAFC),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(emp.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = SlateDark)
                                        Text("Role: ${emp.role} • Akses: " + listOfNotNull(
                                            if (emp.canVoid) "Void" else null,
                                            if (emp.canDiscount) "Diskon" else null,
                                            if (emp.canStockOpname) "SO" else null,
                                            if (emp.canViewReports) "Laporan" else null
                                        ).joinToString(", "), fontSize = 11.sp, color = SlateMedium)
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = when (emp.role) {
                                            "SUPERVISOR" -> PurpleShift3.copy(alpha = 0.15f)
                                            "GUDANG" -> AmberShift1.copy(alpha = 0.15f)
                                            else -> BlueShift2.copy(alpha = 0.15f)
                                        }
                                    ) {
                                        Text(
                                            emp.role,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = when (emp.role) {
                                                "SUPERVISOR" -> PurpleShift3
                                                "GUDANG" -> AmberShift1
                                                else -> BlueShift2
                                            },
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // SECTION 6: PENGATURAN POIN MEMBER & DISKON
        // ==========================================
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Stars, contentDescription = null, tint = Color(0xFFD97706))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Poin Member & Potongan Belanja",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = if (pointSettings.isEnabled) "Sistem Poin Aktif (1 Poin = ${PosRepository.formatRupiah(pointSettings.pointValueInRupiah)})" else "Sistem Poin Dinonaktifkan",
                                    fontSize = 12.sp,
                                    color = if (pointSettings.isEnabled) Color(0xFF16A34A) else SlateLight
                                )
                            }
                        }

                        Button(
                            onClick = { showPointSettingsDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706))
                        ) {
                            Text("Atur Poin")
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFFEF3C7),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                "Aturan Loyalty Member Ala Alfamart:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = Color(0xFF92400E)
                            )
                            Text(
                                "• Belanja ${PosRepository.formatRupiah(pointSettings.spendPerPoint)} = 1 Poin\n" +
                                "• Nilai 1 Poin = ${PosRepository.formatRupiah(pointSettings.pointValueInRupiah)} diskon transaksi\n" +
                                "• Maksimal potongan dari poin = ${pointSettings.maxRedeemPercentage}% total transaksi",
                                fontSize = 11.sp,
                                color = Color(0xFFB45309)
                            )
                        }
                    }
                }
            }
        }

        // ==========================================
        // SECTION 7: CADANGAN & PEMULIHAN DATA (BACKUP & RESTORE)
        // ==========================================
        item {
            BackupRestoreSection(viewModel = viewModel)
        }
    }

    // Dialogs
    if (showEmployeeDialog) {
        EmployeeManagementDialog(
            employees = employees,
            onDismiss = { showEmployeeDialog = false },
            onSaveEmployee = { emp ->
                viewModel.saveEmployee(emp)
            },
            onDeleteEmployee = { emp ->
                viewModel.deleteEmployee(emp)
            }
        )
    }

    if (showPointSettingsDialog) {
        PointSettingsDialog(
            initialSettings = pointSettings,
            onDismiss = { showPointSettingsDialog = false },
            onSaveSettings = { newSettings ->
                viewModel.savePointSettings(newSettings)
                showPointSettingsDialog = false
            }
        )
    }
}

private fun copyUriToInternalStorage(context: Context, uri: Uri, prefix: String): String? {
    return try {
        val inputStream = context.contentResolver.openInputStream(uri) ?: return null
        val file = java.io.File(context.filesDir, "${prefix}_${System.currentTimeMillis()}.jpg")
        file.outputStream().use { out ->
            inputStream.copyTo(out)
        }
        file.absolutePath
    } catch (e: Exception) {
        null
    }
}

