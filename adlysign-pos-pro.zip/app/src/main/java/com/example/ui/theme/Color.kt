package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val EmeraldPrimary = Color(0xFF00875A)
val EmeraldDark = Color(0xFF005238)
val EmeraldLight = Color(0xFFE8F5E9)
val EmeraldContainer = Color(0xFFC8E6C9)

val SlateDark = Color(0xFF0F172A)
val SlateMedium = Color(0xFF1E293B)
val SlateLight = Color(0xFF475569)
val SlateSubtle = Color(0xFF64748B)

val AmberShift1 = Color(0xFFD97706)
val BlueShift2 = Color(0xFF2563EB)
val PurpleShift3 = Color(0xFF7C3AED)

val SurfaceLight = Color(0xFFF8FAFC)
val CardBackground = Color(0xFFFFFFFF)
val SuccessGreen = Color(0xFF16A34A)
val ErrorRed = Color(0xFFDC2626)

