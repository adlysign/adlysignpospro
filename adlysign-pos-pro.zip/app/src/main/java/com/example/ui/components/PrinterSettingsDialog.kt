package com.example.ui.components

import android.bluetooth.BluetoothDevice
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.FormatPaint
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.PrinterSettings
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.SlateDark
import com.example.ui.theme.SlateLight
import com.example.ui.theme.SlateMedium
import com.example.ui.theme.posOutlinedTextFieldColors

@Composable
fun PrinterSettingsDialog(
    initialSettings: PrinterSettings,
    pairedDevices: List<BluetoothDevice>,
    isPrinting: Boolean,
    onDismiss: () -> Unit,
    onTestPrint: (PrinterSettings) -> Unit = {},
    onSaveSettings: (PrinterSettings) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }

    // Connectivity state
    var selectedAddress by remember { mutableStateOf(initialSettings.selectedDeviceAddress) }
    var selectedName by remember { mutableStateOf(initialSettings.selectedDeviceName) }
    var paperSize by remember { mutableStateOf(initialSettings.paperSize) }
    var autoPrint by remember { mutableStateOf(initialSettings.autoPrintOnCheckout) }

    // Receipt Template & Typography state
    var receiptTemplate by remember { mutableStateOf(initialSettings.receiptTemplate) }
    var fontFamilyType by remember { mutableStateOf(initialSettings.fontFamilyType) }
    var fontSizePreset by remember { mutableStateOf(initialSettings.fontSizePreset) }
    var fontWeightPreset by remember { mutableStateOf(initialSettings.fontWeightPreset) }
    var lineSpacingPreset by remember { mutableStateOf(initialSettings.lineSpacingPreset) }

    // Receipt Content & Auto-Cut state
    var cutPaper by remember { mutableStateOf(initialSettings.cutPaper) }
    var printCashier by remember { mutableStateOf(initialSettings.printCashier) }
    var printShift by remember { mutableStateOf(initialSettings.printShift) }
    var printCustomer by remember { mutableStateOf(initialSettings.printCustomer) }
    var printNotes by remember { mutableStateOf(initialSettings.printNotes) }
    var printHeader by remember { mutableStateOf(initialSettings.printHeader) }
    var printFooter by remember { mutableStateOf(initialSettings.printFooter) }
    var printLogo by remember { mutableStateOf(initialSettings.printLogo) }
    var feedLines by remember { mutableIntStateOf(initialSettings.feedLines) }
    var customHeader by remember { mutableStateOf(initialSettings.customHeader) }
    var customFooter by remember { mutableStateOf(initialSettings.customFooter) }

    fun buildCurrentSettings(): PrinterSettings {
        return initialSettings.copy(
            selectedDeviceAddress = selectedAddress.trim(),
            selectedDeviceName = selectedName.trim(),
            paperSize = paperSize,
            autoPrintOnCheckout = autoPrint,
            receiptTemplate = receiptTemplate,
            fontFamilyType = fontFamilyType,
            fontSizePreset = fontSizePreset,
            fontWeightPreset = fontWeightPreset,
            lineSpacingPreset = lineSpacingPreset,
            cutPaper = cutPaper,
            printCashier = printCashier,
            printShift = printShift,
            printCustomer = printCustomer,
            printNotes = printNotes,
            printHeader = printHeader,
            printFooter = printFooter,
            printLogo = printLogo,
            feedLines = feedLines,
            customHeader = customHeader.trim(),
            customFooter = customFooter.trim()
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(0.96f)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(Color(0xFFE0F2FE), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Print,
                                contentDescription = null,
                                tint = Color(0xFF0284C7)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Pengaturan Printer & Struk",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = SlateDark
                            )
                            Text(
                                text = "Koneksi Bluetooth, Desain Template & Auto-Cut",
                                fontSize = 11.sp,
                                color = SlateLight
                            )
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup", tint = SlateLight)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // 4 Tabs: 0 = Bluetooth, 1 = Template & Font, 2 = Konten & Auto-Cut, 3 = Pratinjau
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color(0xFFF1F5F9),
                    modifier = Modifier.background(Color(0xFFF1F5F9), RoundedCornerShape(10.dp))
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("Koneksi", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Desain & Font", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = { Text("Konten & Cut", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        text = { Text("Pratinjau", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(390.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // ==========================================
                    // TAB 0: KONEKSI BLUETOOTH & UJI CETAK
                    // ==========================================
                    if (selectedTab == 0) {
                        item {
                            Text(
                                text = "Pilih Printer Bluetooth Thermal:",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp,
                                color = SlateDark
                            )
                        }

                        if (pairedDevices.isEmpty()) {
                            item {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                                    border = CardDefaults.outlinedCardBorder(),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            "Tidak ada printer Bluetooth yang terpasang (paired).",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = SlateDark
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            "Pastikan Bluetooth HP aktif dan printer thermal sudah di-pair di Pengaturan Bluetooth HP (PIN biasanya 0000 atau 1234).",
                                            fontSize = 11.sp,
                                            color = Color(0xFF64748B),
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            }
                        } else {
                            items(pairedDevices.size) { index ->
                                val dev = pairedDevices[index]
                                val devName = try { dev.name ?: "Unknown Device" } catch (e: Exception) { "Unknown" }
                                val devAddress = try { dev.address ?: "" } catch (e: Exception) { "" }
                                val isSelected = devAddress == selectedAddress

                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isSelected) Color(0xFFEFF6FF) else Color(0xFFF8FAFC)
                                    ),
                                    border = androidx.compose.foundation.BorderStroke(
                                        width = if (isSelected) 1.5.dp else 1.dp,
                                        color = if (isSelected) Color(0xFF3B82F6) else Color(0xFFE2E8F0)
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            selectedAddress = devAddress
                                            selectedName = devName
                                        }
                                        .testTag("printer_device_item_$index")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column {
                                            Text(
                                                text = devName,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = SlateDark
                                            )
                                            Text(
                                                text = devAddress,
                                                fontSize = 11.sp,
                                                color = SlateLight
                                            )
                                        }
                                        if (isSelected) {
                                            Box(
                                                modifier = Modifier
                                                    .background(Color(0xFF3B82F6), CircleShape)
                                                    .size(24.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    Icons.Default.Check,
                                                    contentDescription = null,
                                                    tint = Color.White,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Manual Entry
                        item {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Atau Masukkan MAC Address / Nama Printer Manual:",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = SlateLight
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = selectedName,
                                    onValueChange = { selectedName = it },
                                    label = { Text("Nama Printer") },
                                    placeholder = { Text("mis. RPP02N / Iware") },
                                    colors = posOutlinedTextFieldColors(),
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = selectedAddress,
                                    onValueChange = { selectedAddress = it },
                                    label = { Text("MAC Address") },
                                    placeholder = { Text("66:22:33:44:55:66") },
                                    colors = posOutlinedTextFieldColors(),
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1.2f)
                                )
                            }
                        }

                        // Test Print & Cut Button
                        item {
                            Spacer(modifier = Modifier.height(6.dp))
                            Button(
                                onClick = { onTestPrint(buildCurrentSettings()) },
                                enabled = selectedAddress.isNotBlank() && !isPrinting,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(46.dp)
                                    .testTag("test_print_button")
                            ) {
                                if (isPrinting) {
                                    CircularProgressIndicator(
                                        color = Color.White,
                                        modifier = Modifier.size(18.dp),
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Mengirim ke Printer...", fontSize = 13.sp)
                                } else {
                                    Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Uji Cetak Nota ${if (cutPaper) "& Auto-Cut" else ""}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // ==========================================
                    // TAB 1: DESAIN, TEMPLATE & KUSTOMISASI FONT
                    // ==========================================
                    if (selectedTab == 1) {
                        // 1. Template Struk Selection
                        item {
                            Text(
                                text = "Pilihan Template Struk:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = SlateDark
                            )
                            Text(
                                text = "Pilih gaya visual dan format tata letak cetak nota",
                                fontSize = 11.sp,
                                color = SlateLight
                            )
                        }

                        val templates = listOf(
                            Triple("KLASIK", "Klasik Standar POS", "Garis putus-putus dobel, monospace retro, format umum minimarket"),
                            Triple("MODERN", "Modern Minimalis", "Garis tipis halus, tampilan bersih rapi, cocok untuk kafe & butik"),
                            Triple("KOMPAK", "Kompak (Hemat Kertas)", "Jarak padat 1 baris, hemat kertas thermal roll hingga 40%"),
                            Triple("RINCI", "Rinci / Komprehensif", "Informasi lengkap dengan shift, kasir, pelanggan & rincian pajak"),
                            Triple("ELEGAN", "Elegan Resto & Kafe", "Bingkai dekoratif mewah, ucapan santun untuk resto & hospitality")
                        )

                        items(templates.size) { idx ->
                            val (key, title, desc) = templates[idx]
                            val isChosen = receiptTemplate == key
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isChosen) Color(0xFFF0FDF4) else Color(0xFFF8FAFC)
                                ),
                                border = androidx.compose.foundation.BorderStroke(
                                    width = if (isChosen) 1.5.dp else 1.dp,
                                    color = if (isChosen) EmeraldPrimary else Color(0xFFE2E8F0)
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { receiptTemplate = key }
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .background(
                                                if (isChosen) EmeraldPrimary else Color(0xFFE2E8F0),
                                                CircleShape
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            Icons.Default.Receipt,
                                            contentDescription = null,
                                            tint = if (isChosen) Color.White else SlateMedium,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = title,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.5.sp,
                                            color = if (isChosen) Color(0xFF065F46) else SlateDark
                                        )
                                        Text(
                                            text = desc,
                                            fontSize = 10.5.sp,
                                            color = SlateMedium
                                        )
                                    }
                                    if (isChosen) {
                                        Icon(
                                            Icons.Default.Check,
                                            contentDescription = null,
                                            tint = EmeraldPrimary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // 2. Kustomisasi Jenis Font (Font Family)
                        item {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Jenis Font Struk:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = SlateDark
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                val fonts = listOf(
                                    "MONOSPACE" to "Monospace (Retro)",
                                    "SANS_SERIF" to "Sans-Serif (Modern)",
                                    "SERIF" to "Serif (Elegan)",
                                    "DEFAULT" to "Default"
                                )
                                for ((fKey, fLabel) in fonts) {
                                    val isSelectedFont = fontFamilyType == fKey
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isSelectedFont) Color(0xFFEFF6FF) else Color(0xFFF1F5F9),
                                        border = androidx.compose.foundation.BorderStroke(
                                            1.dp,
                                            if (isSelectedFont) Color(0xFF3B82F6) else Color(0xFFCBD5E1)
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { fontFamilyType = fKey }
                                    ) {
                                        Text(
                                            text = fLabel,
                                            fontSize = 10.5.sp,
                                            fontWeight = if (isSelectedFont) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSelectedFont) Color(0xFF1D4ED8) else SlateDark,
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier.padding(vertical = 8.dp, horizontal = 2.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // 3. Ukuran Font (Font Size)
                        item {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Ukuran Font Nota:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = SlateDark
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                val sizes = listOf(
                                    "KECIL" to "Kecil (Ringkas)",
                                    "SEDANG" to "Sedang (Standar)",
                                    "BESAR" to "Besar (Jelas)"
                                )
                                for ((sKey, sLabel) in sizes) {
                                    val isSelectedSize = fontSizePreset == sKey
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isSelectedSize) Color(0xFFEFF6FF) else Color(0xFFF1F5F9),
                                        border = androidx.compose.foundation.BorderStroke(
                                            1.dp,
                                            if (isSelectedSize) Color(0xFF3B82F6) else Color(0xFFCBD5E1)
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { fontSizePreset = sKey }
                                    ) {
                                        Text(
                                            text = sLabel,
                                            fontSize = 11.sp,
                                            fontWeight = if (isSelectedSize) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSelectedSize) Color(0xFF1D4ED8) else SlateDark,
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier.padding(vertical = 8.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // 4. Ketebalan Font (Font Weight)
                        item {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Ketebalan Tulisan (Font Weight):",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = SlateDark
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                val weights = listOf(
                                    "NORMAL" to "Normal",
                                    "MEDIUM" to "Semi-Tebal",
                                    "BOLD" to "Tebal (Bold)"
                                )
                                for ((wKey, wLabel) in weights) {
                                    val isSelectedWeight = fontWeightPreset == wKey
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isSelectedWeight) Color(0xFFEFF6FF) else Color(0xFFF1F5F9),
                                        border = androidx.compose.foundation.BorderStroke(
                                            1.dp,
                                            if (isSelectedWeight) Color(0xFF3B82F6) else Color(0xFFCBD5E1)
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { fontWeightPreset = wKey }
                                    ) {
                                        Text(
                                            text = wLabel,
                                            fontSize = 11.sp,
                                            fontWeight = if (isSelectedWeight) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSelectedWeight) Color(0xFF1D4ED8) else SlateDark,
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier.padding(vertical = 8.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // 5. Jarak Baris (Line Spacing)
                        item {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Jarak Antar Baris (Line Spacing):",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = SlateDark
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                val spacings = listOf(
                                    "RAPAT" to "Rapat (Padat)",
                                    "STANDAR" to "Standar",
                                    "RENGGANG" to "Renggang (Lega)"
                                )
                                for ((spKey, spLabel) in spacings) {
                                    val isSelectedSpacing = lineSpacingPreset == spKey
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isSelectedSpacing) Color(0xFFEFF6FF) else Color(0xFFF1F5F9),
                                        border = androidx.compose.foundation.BorderStroke(
                                            1.dp,
                                            if (isSelectedSpacing) Color(0xFF3B82F6) else Color(0xFFCBD5E1)
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { lineSpacingPreset = spKey }
                                    ) {
                                        Text(
                                            text = spLabel,
                                            fontSize = 11.sp,
                                            fontWeight = if (isSelectedSpacing) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSelectedSpacing) Color(0xFF1D4ED8) else SlateDark,
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier.padding(vertical = 8.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // 6. Lebar Kertas Thermal
                        item {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Ukuran Kertas Thermal:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = SlateDark
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                val is58 = paperSize == "58mm"
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (is58) Color(0xFFEFF6FF) else Color(0xFFF1F5F9),
                                    border = androidx.compose.foundation.BorderStroke(
                                        1.dp,
                                        if (is58) Color(0xFF3B82F6) else Color(0xFFCBD5E1)
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { paperSize = "58mm" }
                                ) {
                                    Column(
                                        modifier = Modifier.padding(8.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            "58 mm",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = if (is58) Color(0xFF1D4ED8) else SlateDark
                                        )
                                        Text("Standar POS Kasir (32 Kolom)", fontSize = 10.sp, color = SlateLight)
                                    }
                                }

                                val is80 = paperSize == "80mm"
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (is80) Color(0xFFEFF6FF) else Color(0xFFF1F5F9),
                                    border = androidx.compose.foundation.BorderStroke(
                                        1.dp,
                                        if (is80) Color(0xFF3B82F6) else Color(0xFFCBD5E1)
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { paperSize = "80mm" }
                                ) {
                                    Column(
                                        modifier = Modifier.padding(8.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            "80 mm",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = if (is80) Color(0xFF1D4ED8) else SlateDark
                                        )
                                        Text("Lebar Restoran (48 Kolom)", fontSize = 10.sp, color = SlateLight)
                                    }
                                }
                            }
                        }
                    }

                    // ==========================================
                    // TAB 2: KONTEN NOTA & FITUR AUTO-CUT
                    // ==========================================
                    if (selectedTab == 2) {
                        // 1. AUTO CUT KERTAS
                        item {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = if (cutPaper) Color(0xFFF0FDF4) else Color(0xFFF8FAFC)),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (cutPaper) EmeraldPrimary else Color(0xFFE2E8F0)
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .background(if (cutPaper) Color(0xFFCCFBF1) else Color(0xFFE2E8F0), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                Icons.Default.ContentCut,
                                                contentDescription = null,
                                                tint = if (cutPaper) Color(0xFF0F766E) else SlateMedium,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = "Auto-Cut Kertas Struk",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.5.sp,
                                                color = SlateDark
                                            )
                                            Text(
                                                text = "Kirim sinyal potong kertas otomatis ke pemotong printer thermal saat nota selesai dicetak",
                                                fontSize = 10.5.sp,
                                                color = SlateMedium
                                            )
                                        }
                                    }
                                    Switch(
                                        checked = cutPaper,
                                        onCheckedChange = { cutPaper = it },
                                        colors = SwitchDefaults.colors(checkedThumbColor = EmeraldPrimary)
                                    )
                                }
                            }
                        }

                        // 2. TOGGLES: Kasir, Shift, Pelanggan, Catatan, Logo, dll
                        item {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                                border = CardDefaults.outlinedCardBorder(),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    // Tampilkan Kasir
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text("Tampilkan Nama Kasir", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = SlateDark)
                                            Text("Cetak nama kasir yang bertugas pada nota transaksi", fontSize = 11.sp, color = SlateLight)
                                        }
                                        Switch(
                                            checked = printCashier,
                                            onCheckedChange = { printCashier = it },
                                            colors = SwitchDefaults.colors(checkedThumbColor = EmeraldPrimary)
                                        )
                                    }

                                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = Color(0xFFE2E8F0))

                                    // Tampilkan Shift
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text("Tampilkan Shift Kasir", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = SlateDark)
                                            Text("Cetak nomor shift operasional aktif", fontSize = 11.sp, color = SlateLight)
                                        }
                                        Switch(
                                            checked = printShift,
                                            onCheckedChange = { printShift = it },
                                            colors = SwitchDefaults.colors(checkedThumbColor = EmeraldPrimary)
                                        )
                                    }

                                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = Color(0xFFE2E8F0))

                                    // Tampilkan Pelanggan
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text("Tampilkan Nama Pelanggan", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = SlateDark)
                                            Text("Cetak nama pembeli / member pada struk", fontSize = 11.sp, color = SlateLight)
                                        }
                                        Switch(
                                            checked = printCustomer,
                                            onCheckedChange = { printCustomer = it },
                                            colors = SwitchDefaults.colors(checkedThumbColor = EmeraldPrimary)
                                        )
                                    }

                                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = Color(0xFFE2E8F0))

                                    // Tampilkan Catatan
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text("Tampilkan Catatan Transaksi", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = SlateDark)
                                            Text("Cetak keterangan tambahan pada struk", fontSize = 11.sp, color = SlateLight)
                                        }
                                        Switch(
                                            checked = printNotes,
                                            onCheckedChange = { printNotes = it },
                                            colors = SwitchDefaults.colors(checkedThumbColor = EmeraldPrimary)
                                        )
                                    }

                                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = Color(0xFFE2E8F0))

                                    // Cetak Otomatis saat Bayar
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text("Cetak Otomatis saat Bayar", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = SlateDark)
                                            Text("Langsung kirim ke printer Bluetooth ketika transaksi selesai", fontSize = 11.sp, color = SlateLight)
                                        }
                                        Switch(
                                            checked = autoPrint,
                                            onCheckedChange = { autoPrint = it },
                                            colors = SwitchDefaults.colors(checkedThumbColor = EmeraldPrimary)
                                        )
                                    }
                                }
                            }
                        }

                        // Feed lines selector
                        item {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Baris Kosong Akhir Sebelum Potong Kertas:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.5.sp,
                                color = SlateDark
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                for (num in 1..5) {
                                    val isChosenNum = feedLines == num
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isChosenNum) Color(0xFFEFF6FF) else Color(0xFFF1F5F9),
                                        border = androidx.compose.foundation.BorderStroke(
                                            1.dp,
                                            if (isChosenNum) Color(0xFF3B82F6) else Color(0xFFCBD5E1)
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { feedLines = num }
                                    ) {
                                        Text(
                                            text = "$num Baris",
                                            fontSize = 11.sp,
                                            fontWeight = if (isChosenNum) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isChosenNum) Color(0xFF1D4ED8) else SlateDark,
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier.padding(vertical = 6.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // Custom Header & Footer Text
                        item {
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedTextField(
                                value = customHeader,
                                onValueChange = { customHeader = it },
                                label = { Text("Teks Sambutan Header") },
                                placeholder = { Text("Selamat Datang & Terima Kasih") },
                                colors = posOutlinedTextFieldColors(),
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        item {
                            OutlinedTextField(
                                value = customFooter,
                                onValueChange = { customFooter = it },
                                label = { Text("Teks Ucapan / Kebijakan Toko (Footer)") },
                                placeholder = { Text("Barang yang sudah dibeli tidak dapat ditukar.") },
                                colors = posOutlinedTextFieldColors(),
                                maxLines = 3,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    // ==========================================
                    // TAB 3: PRATINJAU LANGSUNG (LIVE PREVIEW)
                    // ==========================================
                    if (selectedTab == 3) {
                        item {
                            Text(
                                text = "Pratinjau Nota Sesuai Pengaturan:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = SlateDark
                            )
                            Text(
                                text = "Perubahan font, ukuran, kasir, dan template langsung terlihat di sini",
                                fontSize = 11.sp,
                                color = SlateLight
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                        }

                        item {
                            val curSettings = buildCurrentSettings()
                            val liveFontFamily = when (curSettings.fontFamilyType) {
                                "SANS_SERIF" -> FontFamily.SansSerif
                                "SERIF" -> FontFamily.Serif
                                "DEFAULT" -> FontFamily.Default
                                else -> FontFamily.Monospace
                            }
                            val liveScale = when (curSettings.fontSizePreset) {
                                "KECIL" -> 0.85f
                                "BESAR" -> 1.18f
                                else -> 1.0f
                            }
                            val liveWeight = when (curSettings.fontWeightPreset) {
                                "MEDIUM" -> FontWeight.Medium
                                "BOLD" -> FontWeight.Bold
                                else -> FontWeight.Normal
                            }
                            val livePadding = when (curSettings.lineSpacingPreset) {
                                "RAPAT" -> 1.dp
                                "RENGGANG" -> 4.dp
                                else -> 2.dp
                            }

                            Card(
                                shape = RoundedCornerShape(8.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFFBFBFA)),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = "TOKO SERBA ADA",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = (15f * liveScale).sp,
                                        fontFamily = liveFontFamily,
                                        color = SlateDark
                                    )
                                    Text(
                                        text = "Jl. Contoh Pengaturan Kasir No. 12",
                                        fontSize = (10f * liveScale).sp,
                                        fontFamily = liveFontFamily,
                                        color = SlateMedium
                                    )
                                    if (curSettings.customHeader.isNotBlank()) {
                                        Text(
                                            text = curSettings.customHeader,
                                            fontSize = (10f * liveScale).sp,
                                            fontFamily = liveFontFamily,
                                            color = SlateDark,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }

                                    Text(
                                        text = "================================",
                                        fontSize = (10f * liveScale).sp,
                                        fontFamily = liveFontFamily,
                                        color = Color.Gray,
                                        modifier = Modifier.padding(vertical = 2.dp)
                                    )

                                    // Sample metadata
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = livePadding),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("No. Struk", fontSize = (10.5f * liveScale).sp, fontFamily = liveFontFamily, color = SlateMedium)
                                        Text("TRX-20260921-001", fontSize = (10.5f * liveScale).sp, fontFamily = liveFontFamily, color = SlateDark)
                                    }

                                    // CASHIER ROW CONDITIONAL
                                    if (curSettings.printCashier) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(vertical = livePadding),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text("Kasir", fontSize = (10.5f * liveScale).sp, fontFamily = liveFontFamily, color = SlateMedium)
                                            Text("Budi Santoso", fontSize = (10.5f * liveScale).sp, fontFamily = liveFontFamily, fontWeight = FontWeight.SemiBold, color = SlateDark)
                                        }
                                    }

                                    if (curSettings.printShift) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(vertical = livePadding),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text("Shift", fontSize = (10.5f * liveScale).sp, fontFamily = liveFontFamily, color = SlateMedium)
                                            Text("Shift 1 - Pagi", fontSize = (10.5f * liveScale).sp, fontFamily = liveFontFamily, color = SlateDark)
                                        }
                                    }

                                    if (curSettings.printCustomer) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(vertical = livePadding),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text("Pelanggan", fontSize = (10.5f * liveScale).sp, fontFamily = liveFontFamily, color = SlateMedium)
                                            Text("Ahmad Yani", fontSize = (10.5f * liveScale).sp, fontFamily = liveFontFamily, color = SlateDark)
                                        }
                                    }

                                    Text(
                                        text = "--------------------------------",
                                        fontSize = (10f * liveScale).sp,
                                        fontFamily = liveFontFamily,
                                        color = Color.Gray,
                                        modifier = Modifier.padding(vertical = 2.dp)
                                    )

                                    // Sample items
                                    if (curSettings.receiptTemplate == "KOMPAK") {
                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(vertical = livePadding),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text("2x Kopi Susu Aren", fontSize = (11f * liveScale).sp, fontFamily = liveFontFamily, fontWeight = liveWeight, color = SlateDark)
                                            Text("Rp 36.000", fontSize = (11f * liveScale).sp, fontFamily = liveFontFamily, fontWeight = FontWeight.SemiBold, color = SlateDark)
                                        }
                                    } else {
                                        Column(modifier = Modifier.fillMaxWidth().padding(vertical = livePadding)) {
                                            Text("Kopi Susu Aren", fontSize = (11.5f * liveScale).sp, fontFamily = liveFontFamily, fontWeight = FontWeight.SemiBold, color = SlateDark)
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("  2 x Rp 18.000", fontSize = (10f * liveScale).sp, fontFamily = liveFontFamily, color = SlateMedium)
                                                Text("Rp 36.000", fontSize = (11f * liveScale).sp, fontFamily = liveFontFamily, fontWeight = liveWeight, color = SlateDark)
                                            }
                                        }
                                    }

                                    Text(
                                        text = "================================",
                                        fontSize = (10f * liveScale).sp,
                                        fontFamily = liveFontFamily,
                                        color = Color.Gray,
                                        modifier = Modifier.padding(vertical = 2.dp)
                                    )

                                    // Total
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = livePadding + 2.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("TOTAL", fontSize = (13f * liveScale).sp, fontWeight = FontWeight.Bold, fontFamily = liveFontFamily, color = SlateDark)
                                        Text("Rp 36.000", fontSize = (13f * liveScale).sp, fontWeight = FontWeight.Bold, fontFamily = liveFontFamily, color = SlateDark)
                                    }

                                    // Footer
                                    if (curSettings.printFooter) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = curSettings.customFooter,
                                            fontSize = (10f * liveScale).sp,
                                            fontFamily = liveFontFamily,
                                            color = SlateMedium,
                                            textAlign = TextAlign.Center
                                        )
                                    }

                                    // Auto Cut
                                    if (curSettings.cutPaper) {
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(Color(0xFFF1F5F9), RoundedCornerShape(4.dp))
                                                .padding(vertical = 3.dp),
                                            horizontalArrangement = Arrangement.Center,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(Icons.Default.ContentCut, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(13.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("- - - AUTO-CUT DIAKTIFKAN - - -", fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = Color(0xFF0F766E))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Action buttons: Tutup & Simpan
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp)
                    ) {
                        Text("Tutup", color = SlateDark)
                    }

                    Button(
                        onClick = {
                            val updated = buildCurrentSettings()
                            onSaveSettings(updated)
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1.3f)
                            .height(46.dp)
                            .testTag("save_printer_settings_button")
                    ) {
                        Text("Simpan Pengaturan", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}
