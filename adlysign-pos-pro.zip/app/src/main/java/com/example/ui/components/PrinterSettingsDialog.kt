package com.example.ui.components

import android.bluetooth.BluetoothDevice
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.PrinterSettings
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.SlateDark
import com.example.ui.theme.SlateLight
import com.example.ui.theme.posOutlinedTextFieldColors

@Composable
fun PrinterSettingsDialog(
    initialSettings: PrinterSettings,
    pairedDevices: List<BluetoothDevice>,
    isPrinting: Boolean,
    onDismiss: () -> Unit,
    onTestPrint: () -> Unit,
    onSaveSettings: (PrinterSettings) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }

    var selectedAddress by remember { mutableStateOf(initialSettings.selectedDeviceAddress) }
    var selectedName by remember { mutableStateOf(initialSettings.selectedDeviceName) }
    var paperSize by remember { mutableStateOf(initialSettings.paperSize) }
    var autoPrint by remember { mutableStateOf(initialSettings.autoPrintOnCheckout) }
    var printCashier by remember { mutableStateOf(initialSettings.printCashier) }
    var printFooter by remember { mutableStateOf(initialSettings.printFooter) }
    var customHeader by remember { mutableStateOf(initialSettings.customHeader) }
    var customFooter by remember { mutableStateOf(initialSettings.customFooter) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(0.95f)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(Color(0xFFE0F2FE), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Print,
                                contentDescription = null,
                                tint = Color(0xFF0284C7)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Pengaturan Printer & Struk",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = SlateDark
                            )
                            Text(
                                text = "Printer Bluetooth Thermal & Format Nota",
                                fontSize = 12.sp,
                                color = SlateLight
                            )
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup", tint = SlateLight)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Tabs: 0 = Perangkat Bluetooth, 1 = Format Struk
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color(0xFFF1F5F9),
                    modifier = Modifier.background(Color(0xFFF1F5F9), RoundedCornerShape(10.dp))
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("Printer Bluetooth", fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Pengaturan Struk", fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(340.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (selectedTab == 0) {
                        // TAB 1: BLUETOOTH PRINTER
                        item {
                            Text(
                                text = "Daftar Perangkat Bluetooth Terhubung:",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp,
                                color = SlateDark
                            )
                        }

                        if (pairedDevices.isEmpty()) {
                            item {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                                    border = CardDefaults.outlinedCardBorder(),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            "Tidak ada printer Bluetooth yang terpasang (paired).",
                                            fontSize = 12.sp,
                                            color = SlateLight
                                        )
                                        Text(
                                            "Pastikan Bluetooth HP aktif dan printer thermal sudah di-pairing di menu Pengaturan Bluetooth Android.",
                                            fontSize = 11.sp,
                                            color = Color(0xFF64748B)
                                        )
                                    }
                                }
                            }
                        } else {
                            items(pairedDevices.size) { index ->
                                val dev = pairedDevices[index]
                                val devName = try { dev.name ?: "Unknown Device" } catch (e: Exception) { "Unknown" }
                                val devAddress = try { dev.address ?: "" } catch (e: Exception) { "" }
                                val isSelected = devAddress == selectedAddress

                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isSelected) Color(0xFFEFF6FF) else Color(0xFFF8FAFC)
                                    ),
                                    border = androidx.compose.foundation.BorderStroke(
                                        width = if (isSelected) 1.5.dp else 1.dp,
                                        color = if (isSelected) Color(0xFF3B82F6) else Color(0xFFE2E8F0)
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            selectedAddress = devAddress
                                            selectedName = devName
                                        }
                                        .testTag("printer_device_item_$index")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column {
                                            Text(
                                                text = devName,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = SlateDark
                                            )
                                            Text(
                                                text = devAddress,
                                                fontSize = 11.sp,
                                                color = SlateLight
                                            )
                                        }
                                        if (isSelected) {
                                            Box(
                                                modifier = Modifier
                                                    .background(Color(0xFF3B82F6), CircleShape)
                                                    .size(22.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    Icons.Default.Check,
                                                    contentDescription = null,
                                                    tint = Color.White,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Manual Address Override (if needed)
                        item {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Atau Masukkan MAC Address / Nama Printer Manual:",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = SlateLight
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = selectedName,
                                    onValueChange = { selectedName = it },
                                    label = { Text("Nama Printer") },
                                    placeholder = { Text("mis. RPP02N / Iware") },
                                    colors = posOutlinedTextFieldColors(),
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = selectedAddress,
                                    onValueChange = { selectedAddress = it },
                                    label = { Text("MAC Address") },
                                    placeholder = { Text("66:22:33:44:55:66") },
                                    colors = posOutlinedTextFieldColors(),
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1.2f)
                                )
                            }
                        }

                        // Test Print Button
                        item {
                            Spacer(modifier = Modifier.height(6.dp))
                            Button(
                                onClick = onTestPrint,
                                enabled = selectedAddress.isNotBlank() && !isPrinting,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(44.dp)
                                    .testTag("test_print_button")
                            ) {
                                if (isPrinting) {
                                    CircularProgressIndicator(
                                        color = Color.White,
                                        modifier = Modifier.size(18.dp),
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Mengirim ke Printer...", fontSize = 13.sp)
                                } else {
                                    Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Uji Cetak (Test Print Nota)", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                    } else {
                        // TAB 2: RECEIPT CONFIGURATION
                        item {
                            Text(
                                text = "Ukuran Kertas Thermal:",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp,
                                color = SlateDark
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                val is58 = paperSize == "58mm"
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (is58) Color(0xFFEFF6FF) else Color(0xFFF1F5F9),
                                    border = androidx.compose.foundation.BorderStroke(
                                        1.dp,
                                        if (is58) Color(0xFF3B82F6) else Color(0xFFCBD5E1)
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { paperSize = "58mm" }
                                ) {
                                    Column(
                                        modifier = Modifier.padding(10.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            "58 mm",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = if (is58) Color(0xFF1D4ED8) else SlateDark
                                        )
                                        Text("Standar POS Kasir (32 Karakter)", fontSize = 10.sp, color = SlateLight)
                                    }
                                }

                                val is80 = paperSize == "80mm"
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (is80) Color(0xFFEFF6FF) else Color(0xFFF1F5F9),
                                    border = androidx.compose.foundation.BorderStroke(
                                        1.dp,
                                        if (is80) Color(0xFF3B82F6) else Color(0xFFCBD5E1)
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { paperSize = "80mm" }
                                ) {
                                    Column(
                                        modifier = Modifier.padding(10.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            "80 mm",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = if (is80) Color(0xFF1D4ED8) else SlateDark
                                        )
                                        Text("Lebar Restoran (48 Karakter)", fontSize = 10.sp, color = SlateLight)
                                    }
                                }
                            }
                        }

                        // Toggles
                        item {
                            Spacer(modifier = Modifier.height(6.dp))
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                                border = CardDefaults.outlinedCardBorder(),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text("Cetak Otomatis saat Bayar", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = SlateDark)
                                            Text("Langsung kirim ke printer Bluetooth saat transaksi selesai", fontSize = 11.sp, color = SlateLight)
                                        }
                                        Switch(
                                            checked = autoPrint,
                                            onCheckedChange = { autoPrint = it },
                                            colors = SwitchDefaults.colors(checkedThumbColor = EmeraldPrimary)
                                        )
                                    }

                                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = Color(0xFFE2E8F0))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text("Tampilkan Nama Kasir", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = SlateDark)
                                            Text("Cetak nama kasir yang bertugas di nota", fontSize = 11.sp, color = SlateLight)
                                        }
                                        Switch(
                                            checked = printCashier,
                                            onCheckedChange = { printCashier = it },
                                            colors = SwitchDefaults.colors(checkedThumbColor = EmeraldPrimary)
                                        )
                                    }

                                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = Color(0xFFE2E8F0))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text("Tampilkan Catatan Kaki (Footer)", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = SlateDark)
                                            Text("Cetak teks ucapan terima kasih di bawah nota", fontSize = 11.sp, color = SlateLight)
                                        }
                                        Switch(
                                            checked = printFooter,
                                            onCheckedChange = { printFooter = it },
                                            colors = SwitchDefaults.colors(checkedThumbColor = EmeraldPrimary)
                                        )
                                    }
                                }
                            }
                        }

                        // Custom Header & Footer
                        item {
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedTextField(
                                value = customHeader,
                                onValueChange = { customHeader = it },
                                label = { Text("Teks Sambutan Header Struk") },
                                colors = posOutlinedTextFieldColors(),
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        item {
                            OutlinedTextField(
                                value = customFooter,
                                onValueChange = { customFooter = it },
                                label = { Text("Teks Ucapan / Kebijakan Toko (Footer)") },
                                colors = posOutlinedTextFieldColors(),
                                maxLines = 3,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Bottom Action Buttons: Batal & Simpan
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp)
                    ) {
                        Text("Tutup", color = SlateDark)
                    }

                    Button(
                        onClick = {
                            val updated = initialSettings.copy(
                                selectedDeviceAddress = selectedAddress.trim(),
                                selectedDeviceName = selectedName.trim(),
                                paperSize = paperSize,
                                autoPrintOnCheckout = autoPrint,
                                printCashier = printCashier,
                                printFooter = printFooter,
                                customHeader = customHeader.trim(),
                                customFooter = customFooter.trim()
                            )
                            onSaveSettings(updated)
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1.3f)
                            .height(46.dp)
                            .testTag("save_printer_settings_button")
                    ) {
                        Text("Simpan Pengaturan", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}
