package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

data class ShortcutItem(
    val key: String,
    val title: String,
    val description: String,
    val color: Color = Color(0xFF0284C7)
)

@Composable
fun ShortcutCheatsheetDialog(onDismiss: () -> Unit) {
    val shortcuts = listOf(
        ShortcutItem("F1", "Cari Barang / Galeri", "Pencarian katalog produk dan kategori toko", Color(0xFF0284C7)),
        ShortcutItem("F2", "Scan Barcode Cepat", "Fokus otomatis ke kolom scan barcode kasir", Color(0xFF0284C7)),
        ShortcutItem("F3", "Ganti Kuantitas (Qty)", "Mengubah jumlah item barang terpilih", Color(0xFF0D9488)),
        ShortcutItem("F4", "Buka / Tutup Shift", "Buka modal informasi shift kasir aktif", Color(0xFFF59E0B)),
        ShortcutItem("F5", "Void Item Terakhir", "Membatalkan / menghapus 1 item barang terakhir", Color(0xFFEF4444)),
        ShortcutItem("F6", "Stock Opname (SO)", "Pemeriksaan fisik stok dan penyesuaian selisih", Color(0xFF6366F1)),
        ShortcutItem("F7", "Tahan / Pending Struk", "Tahan keranjang dengan label identifikasi pelanggan", Color(0xFFD97706)),
        ShortcutItem("F8", "Member & Poin", "Input member atau tukar poin belanja", Color(0xFF10B981)),
        ShortcutItem("F9", "Pembelian Supplier", "Penerimaan faktur belanja barang masuk dari supplier", Color(0xFF8B5CF6)),
        ShortcutItem("F10", "Piutang / Kasbon", "Pencatatan dan pelunasan transaksi piutang pelanggan", Color(0xFFEC4899)),
        ShortcutItem("F11", "Kunci Layar Kasir", "Mengunci kasir sementara (Auto Pending keranjang)", Color(0xFF475569)),
        ShortcutItem("F12", "Bayar Transaksi", "Lanjut pembayaran tunai/qris/piutang dan cetak struk", Color(0xFF16A34A))
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("shortcut_cheatsheet_dialog")
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Header
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(Color(0xFFE2E8F0), RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Keyboard, contentDescription = null, tint = Color(0xFF334155))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Panduan Keyboard F1 - F12",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color(0xFF0F172A)
                            )
                            Text(
                                text = "Standar Operasional Keyboard Ala Alfamart",
                                fontSize = 12.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(380.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(shortcuts) { item ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFFF8FAFC), RoundedCornerShape(10.dp))
                                .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(10.dp))
                                .padding(10.dp)
                        ) {
                            // Badge Key
                            Box(
                                modifier = Modifier
                                    .size(width = 46.dp, height = 34.dp)
                                    .background(item.color, RoundedCornerShape(8.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = item.key,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 14.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color.White
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = Color(0xFF1E293B)
                                )
                                Text(
                                    text = item.description,
                                    fontSize = 11.sp,
                                    color = Color(0xFF64748B)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                OutlinedButton(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Tutup Panduan")
                }
            }
        }
    }
}
