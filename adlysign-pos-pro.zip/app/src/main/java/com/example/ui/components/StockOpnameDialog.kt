package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.LicenseInfo
import com.example.data.model.Product
import com.example.data.model.StockOpnameRecord
import com.example.data.model.StockOpnameTask
import com.example.data.repository.PosRepository
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SlateDark
import com.example.ui.theme.SlateLight
import com.example.ui.theme.SlateMedium
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.posOutlinedTextFieldColors
import com.example.util.ReportExportHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun StockOpnameDialog(
    products: List<Product>,
    history: List<StockOpnameRecord>,
    tasks: List<StockOpnameTask> = emptyList(),
    storeInfo: LicenseInfo,
    onDismiss: () -> Unit,
    onFinalizeTask: (
        taskCode: String,
        title: String,
        notes: String,
        items: List<StockOpnameRecord>,
        onSuccess: (StockOpnameTask) -> Unit
    ) -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Penyesuaian Massal, 1: Cetak Selisih & Koreksi, 2: Riwayat Tugas

    // Task Metadata
    val initialTaskCode = remember {
        val stamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.getDefault()).format(Date())
        "SO-$stamp"
    }
    var taskCode by remember { mutableStateOf(initialTaskCode) }
    var taskTitle by remember { mutableStateOf("Stok Opname Toko Periode Ini") }
    var conductedBy by remember { mutableStateOf("Petugas Gudang / Admin") }
    var taskNotes by remember { mutableStateOf("") }

    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Semua") }

    val categories = remember(products) {
        listOf("Semua") + products.map { it.category }.distinct().filter { it.isNotBlank() }
    }

    // Physical stock mapping: productId -> count Int
    val physicalStockMap = remember(products) {
        mutableStateMapOf<Long, Int>().apply {
            products.forEach { prod ->
                this[prod.id] = prod.stock
            }
        }
    }

    // Reason mapping: productId -> reason String
    val reasonMap = remember(products) {
        mutableStateMapOf<Long, String>().apply {
            products.forEach { prod ->
                this[prod.id] = "PENYESUAIAN"
            }
        }
    }

    // Item note mapping: productId -> note String
    val noteMap = remember(products) {
        mutableStateMapOf<Long, String>()
    }

    val reasons = listOf("PENYESUAIAN", "RUSAK", "HILANG", "KADALUARSA", "SALAH_HITUNG")

    // Filtered products for Tab 0
    val filteredProducts = remember(products, searchQuery, selectedCategory) {
        products.filter { prod ->
            val matchesCategory = (selectedCategory == "Semua" || prod.category.equals(selectedCategory, ignoreCase = true))
            val matchesQuery = searchQuery.isBlank() ||
                    prod.name.contains(searchQuery, ignoreCase = true) ||
                    prod.sku.contains(searchQuery, ignoreCase = true)
            matchesCategory && matchesQuery
        }
    }

    // Compute list of current records across all products
    fun buildCurrentRecords(): List<StockOpnameRecord> {
        return products.map { prod ->
            val phys = physicalStockMap[prod.id] ?: prod.stock
            val diff = phys - prod.stock
            val reas = reasonMap[prod.id] ?: "PENYESUAIAN"
            val nts = noteMap[prod.id] ?: ""
            StockOpnameRecord(
                taskCode = taskCode,
                date = System.currentTimeMillis(),
                productId = prod.id,
                productName = prod.name,
                sku = prod.sku,
                systemStock = prod.stock,
                physicalStock = phys,
                difference = diff,
                reason = reas,
                conductedBy = conductedBy,
                notes = nts,
                unit = prod.unit
            )
        }
    }

    // Discrepancy items (only items with difference != 0)
    val discrepancyRecords = remember(physicalStockMap.toMap(), reasonMap.toMap(), noteMap.toMap()) {
        buildCurrentRecords().filter { it.difference != 0 }
    }

    var showFinalizeConfirmDialog by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.94f)
                .testTag("stock_opname_dialog")
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header Dialog
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 3.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(Color(0xFFE0E7FF), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Inventory, contentDescription = null, tint = Color(0xFF4F46E5))
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Tugas Stok Opname Massal",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 17.sp,
                                        color = SlateDark
                                    )
                                    Text(
                                        text = "Kode Tugas: $taskCode • Penyesuaian stok serentak & cetak selisih",
                                        fontSize = 11.sp,
                                        color = SlateMedium
                                    )
                                }
                            }
                            IconButton(onClick = onDismiss) {
                                Icon(Icons.Default.Close, contentDescription = "Tutup")
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Tab Navigation
                        TabRow(
                            selectedTabIndex = selectedTab,
                            containerColor = Color.Transparent,
                            divider = {}
                        ) {
                            Tab(
                                selected = selectedTab == 0,
                                onClick = { selectedTab = 0 },
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Assignment, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("1. Penyesuaian Semua Produk (${products.size})", fontSize = 12.sp, fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal)
                                    }
                                }
                            )
                            Tab(
                                selected = selectedTab == 1,
                                onClick = { selectedTab = 1 },
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            "2. Cetak Selisih (${discrepancyRecords.size})",
                                            fontSize = 12.sp,
                                            fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                                            color = if (discrepancyRecords.isNotEmpty()) Color(0xFFDC2626) else Color.Unspecified
                                        )
                                    }
                                }
                            )
                            Tab(
                                selected = selectedTab == 2,
                                onClick = { selectedTab = 2 },
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("3. Riwayat Tugas & Dokumen", fontSize = 12.sp, fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal)
                                    }
                                }
                            )
                        }
                    }
                }

                // Body content based on tab
                Box(modifier = Modifier.weight(1f)) {
                    when (selectedTab) {
                        0 -> {
                            // TAB 0: SEMUA PRODUK & PENYESUAIAN FISIK MASSAL
                            Column(modifier = Modifier.fillMaxSize()) {
                                // Task Metadata & Filter bar
                                Surface(
                                    color = Color(0xFFF1F5F9),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            OutlinedTextField(
                                                value = taskTitle,
                                                onValueChange = { taskTitle = it },
                                                label = { Text("Nama/Judul Kegiatan SO") },
                                                singleLine = true,
                                                colors = posOutlinedTextFieldColors(),
                                                modifier = Modifier.weight(1.3f)
                                            )
                                            OutlinedTextField(
                                                value = conductedBy,
                                                onValueChange = { conductedBy = it },
                                                label = { Text("Petugas Penghitung") },
                                                singleLine = true,
                                                colors = posOutlinedTextFieldColors(),
                                                modifier = Modifier.weight(1f)
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(8.dp))

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            // Search bar
                                            OutlinedTextField(
                                                value = searchQuery,
                                                onValueChange = { searchQuery = it },
                                                placeholder = { Text("Cari produk atau SKU...", fontSize = 12.sp) },
                                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                                                singleLine = true,
                                                colors = posOutlinedTextFieldColors(),
                                                modifier = Modifier.weight(1f).height(48.dp)
                                            )

                                            Spacer(modifier = Modifier.width(8.dp))

                                            // Quick button to match all physical to system
                                            OutlinedButton(
                                                onClick = {
                                                    products.forEach { prod ->
                                                        physicalStockMap[prod.id] = prod.stock
                                                    }
                                                    Toast.makeText(context, "Seluruh fisik diset sama dengan stok sistem komputer", Toast.LENGTH_SHORT).show()
                                                },
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.height(48.dp)
                                            ) {
                                                Icon(Icons.Default.DoneAll, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Set Semua Sesuai", fontSize = 11.sp)
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(6.dp))

                                        // Category Chips
                                        FlowRow(
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            verticalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            categories.forEach { cat ->
                                                FilterChip(
                                                    selected = selectedCategory == cat,
                                                    onClick = { selectedCategory = cat },
                                                    label = { Text(cat, fontSize = 11.sp) },
                                                    colors = FilterChipDefaults.filterChipColors(
                                                        selectedContainerColor = EmeraldPrimary,
                                                        selectedLabelColor = Color.White
                                                    )
                                                )
                                            }
                                        }
                                    }
                                }

                                // Products List with Steppers & Quick inputs
                                LazyColumn(
                                    modifier = Modifier.weight(1f).padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    items(filteredProducts, key = { it.id }) { product ->
                                        val currentPhys = physicalStockMap[product.id] ?: product.stock
                                        val diff = currentPhys - product.stock
                                        val currentReason = reasonMap[product.id] ?: "PENYESUAIAN"

                                        Card(
                                            shape = RoundedCornerShape(12.dp),
                                            colors = CardDefaults.cardColors(containerColor = Color.White),
                                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(modifier = Modifier.padding(12.dp)) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Text(
                                                            text = product.name,
                                                            fontWeight = FontWeight.Bold,
                                                            fontSize = 14.sp,
                                                            color = SlateDark
                                                        )
                                                        Text(
                                                            text = "${product.category} • SKU: ${product.sku.ifBlank { "-" }}",
                                                            fontSize = 11.sp,
                                                            color = SlateMedium
                                                        )
                                                    }

                                                    // System stock badge
                                                    Surface(
                                                        shape = RoundedCornerShape(8.dp),
                                                        color = Color(0xFFF1F5F9),
                                                        modifier = Modifier.padding(horizontal = 6.dp)
                                                    ) {
                                                        Text(
                                                            text = "Sistem: ${product.stock} ${product.unit}",
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.SemiBold,
                                                            color = SlateDark,
                                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                        )
                                                    }
                                                }

                                                Spacer(modifier = Modifier.height(8.dp))

                                                // Stepper & Physical Input row
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        Text("Hitung Fisik: ", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)

                                                        // Minus Button
                                                        IconButton(
                                                            onClick = {
                                                                val nextVal = (currentPhys - 1).coerceAtLeast(0)
                                                                physicalStockMap[product.id] = nextVal
                                                            },
                                                            modifier = Modifier
                                                                .size(32.dp)
                                                                .background(Color(0xFFF1F5F9), RoundedCornerShape(6.dp))
                                                        ) {
                                                            Icon(Icons.Default.Remove, contentDescription = "Kurang", modifier = Modifier.size(16.dp))
                                                        }

                                                        // Direct Number Box
                                                        Box(
                                                            modifier = Modifier
                                                                .width(60.dp)
                                                                .height(36.dp)
                                                                .padding(horizontal = 4.dp)
                                                                .background(Color.White, RoundedCornerShape(6.dp))
                                                                .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(6.dp)),
                                                            contentAlignment = Alignment.Center
                                                        ) {
                                                            Text(
                                                                text = "$currentPhys",
                                                                fontWeight = FontWeight.Bold,
                                                                fontSize = 14.sp
                                                            )
                                                        }

                                                        // Plus Button
                                                        IconButton(
                                                            onClick = {
                                                                physicalStockMap[product.id] = currentPhys + 1
                                                            },
                                                            modifier = Modifier
                                                                .size(32.dp)
                                                                .background(Color(0xFFF1F5F9), RoundedCornerShape(6.dp))
                                                        ) {
                                                            Icon(Icons.Default.Add, contentDescription = "Tambah", modifier = Modifier.size(16.dp))
                                                        }

                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Text(product.unit, fontSize = 11.sp, color = SlateMedium)
                                                    }

                                                    // Difference Badge
                                                    val diffBg = when {
                                                        diff == 0 -> Color(0xFFDCFCE7)
                                                        diff > 0 -> Color(0xFFFEF3C7)
                                                        else -> Color(0xFFFEE2E2)
                                                    }
                                                    val diffColor = when {
                                                        diff == 0 -> Color(0xFF15803D)
                                                        diff > 0 -> Color(0xFFB45309)
                                                        else -> Color(0xFFB91C1C)
                                                    }
                                                    val diffLabel = when {
                                                        diff == 0 -> "✓ Cocok"
                                                        diff > 0 -> "+$diff (Lebih)"
                                                        else -> "$diff (Kurang)"
                                                    }

                                                    Surface(
                                                        shape = RoundedCornerShape(6.dp),
                                                        color = diffBg,
                                                        modifier = Modifier.padding(2.dp)
                                                    ) {
                                                        Text(
                                                            text = diffLabel,
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = diffColor,
                                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                        )
                                                    }
                                                }

                                                // If difference != 0, show reason picker
                                                if (diff != 0) {
                                                    Spacer(modifier = Modifier.height(8.dp))
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text("Alasan: ", fontSize = 11.sp, color = SlateMedium)
                                                        FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                            reasons.forEach { r ->
                                                                FilterChip(
                                                                    selected = currentReason == r,
                                                                    onClick = { reasonMap[product.id] = r },
                                                                    label = { Text(r, fontSize = 9.5.sp) },
                                                                    modifier = Modifier.height(26.dp)
                                                                )
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                // Bottom summary & action
                                Surface(
                                    color = MaterialTheme.colorScheme.surface,
                                    tonalElevation = 4.dp,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(16.dp).fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(
                                                text = "Total: ${products.size} Produk • Berselisih: ${discrepancyRecords.size} Produk",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = if (discrepancyRecords.isNotEmpty()) Color(0xFFDC2626) else Color(0xFF15803D)
                                            )
                                            Text(
                                                text = if (discrepancyRecords.isNotEmpty())
                                                    "Periksa dan cetak selisih untuk verifikasi fisik sebelum penyelesaian akhir."
                                                else
                                                    "Semua stok fisik telah cocok dengan sistem komputer.",
                                                fontSize = 11.sp,
                                                color = SlateMedium
                                            )
                                        }

                                        Button(
                                            onClick = { selectedTab = 1 },
                                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.height(44.dp).testTag("go_to_discrepancy_tab_button")
                                        ) {
                                            Text("Cetak & Tinjau Selisih (${discrepancyRecords.size}) 👉", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }

                        1 -> {
                            // TAB 1: CETAK SELISIH & PENYESUAIAN KEMBALI
                            // (MANDATORY REQUIREMENT: Only products with difference != 0 appear here!
                            // Already matched items DO NOT appear! User can readjust until resolved,
                            // or finalize with whatever results and export documents.)
                            Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                                // Action banner for Document Generation
                                Card(
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                                Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(28.dp))
                                                Spacer(modifier = Modifier.width(10.dp))
                                                Column {
                                                    Text(
                                                        text = "Daftar Selisih Stok Opname (Checklist)",
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 14.sp,
                                                        color = Color(0xFF92400E)
                                                    )
                                                    Text(
                                                        text = "Hanya menampilkan barang yang berselisih (${discrepancyRecords.size} SKU). Penyesuaian yang sudah pas tidak akan muncul di sini.",
                                                        fontSize = 11.sp,
                                                        color = Color(0xFFB45309)
                                                    )
                                                }
                                            }

                                            // Document Button
                                            Button(
                                                onClick = {
                                                    val file = ReportExportHelper.generateStockOpnameDiscrepancyDoc(
                                                        context = context,
                                                        storeInfo = storeInfo,
                                                        taskCode = taskCode,
                                                        taskTitle = taskTitle,
                                                        conductedBy = conductedBy,
                                                        discrepancyItems = discrepancyRecords
                                                    )
                                                    ReportExportHelper.openDocument(context, file, "application/msword")
                                                    Toast.makeText(context, "Dokumen selisih berhasil disimpan: ${file.name}", Toast.LENGTH_LONG).show()
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.height(40.dp).testTag("export_discrepancy_doc_button")
                                            ) {
                                                Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Simpan Dokumen Selisih (.doc)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                if (discrepancyRecords.isEmpty()) {
                                    // Empty state: All products match!
                                    Box(
                                        modifier = Modifier.weight(1f).fillMaxWidth(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(64.dp))
                                            Spacer(modifier = Modifier.height(12.dp))
                                            Text(
                                                text = "Luar Biasa! Tidak Ada Selisih Stok",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 16.sp,
                                                color = SlateDark
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "Seluruh hitungan fisik telah sesuai persis dengan stok di komputer.",
                                                fontSize = 12.sp,
                                                color = SlateMedium,
                                                textAlign = TextAlign.Center
                                            )
                                        }
                                    }
                                } else {
                                    // List of Discrepancies with direct re-adjustment controls
                                    LazyColumn(
                                        modifier = Modifier.weight(1f),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        items(discrepancyRecords, key = { it.productId }) { item ->
                                            val currentPhys = physicalStockMap[item.productId] ?: item.systemStock
                                            val diff = currentPhys - item.systemStock

                                            Card(
                                                shape = RoundedCornerShape(10.dp),
                                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFECACA)),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Column(modifier = Modifier.padding(12.dp)) {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Column(modifier = Modifier.weight(1f)) {
                                                            Text(item.productName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                                            Text("SKU: ${item.sku.ifBlank { "-" }} • Alasan: ${item.reason}", fontSize = 11.sp, color = SlateMedium)
                                                        }

                                                        // Difference indicator
                                                        val badgeColor = if (diff > 0) Color(0xFFD97706) else Color(0xFFDC2626)
                                                        val badgeText = if (diff > 0) "+$diff ${item.unit} (Surplus)" else "$diff ${item.unit} (Defisit)"
                                                        Surface(
                                                            shape = RoundedCornerShape(6.dp),
                                                            color = if (diff > 0) Color(0xFFFEF3C7) else Color(0xFFFEE2E2)
                                                        ) {
                                                            Text(
                                                                text = badgeText,
                                                                fontWeight = FontWeight.Bold,
                                                                fontSize = 11.sp,
                                                                color = badgeColor,
                                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                            )
                                                        }
                                                    }

                                                    Spacer(modifier = Modifier.height(8.dp))

                                                    // Re-adjustment Stepper
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = "Sistem: ${item.systemStock} ${item.unit}",
                                                            fontSize = 12.sp,
                                                            color = SlateMedium
                                                        )

                                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                                            Text("Koreksi Ulang: ", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                                            IconButton(
                                                                onClick = {
                                                                    val next = (currentPhys - 1).coerceAtLeast(0)
                                                                    physicalStockMap[item.productId] = next
                                                                },
                                                                modifier = Modifier.size(28.dp).background(Color(0xFFF1F5F9), RoundedCornerShape(4.dp))
                                                            ) {
                                                                Icon(Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(14.dp))
                                                            }

                                                            Text(
                                                                text = "$currentPhys",
                                                                fontWeight = FontWeight.Bold,
                                                                fontSize = 13.sp,
                                                                modifier = Modifier.padding(horizontal = 8.dp)
                                                            )

                                                            IconButton(
                                                                onClick = {
                                                                    physicalStockMap[item.productId] = currentPhys + 1
                                                                },
                                                                modifier = Modifier.size(28.dp).background(Color(0xFFF1F5F9), RoundedCornerShape(4.dp))
                                                            ) {
                                                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                                                            }

                                                            Spacer(modifier = Modifier.width(8.dp))

                                                            // Quick reset to system stock (to mark as matched)
                                                            OutlinedButton(
                                                                onClick = {
                                                                    physicalStockMap[item.productId] = item.systemStock
                                                                    Toast.makeText(context, "${item.productName} disesuaikan cocok dengan sistem", Toast.LENGTH_SHORT).show()
                                                                },
                                                                shape = RoundedCornerShape(6.dp),
                                                                modifier = Modifier.height(30.dp)
                                                            ) {
                                                                Text("Set Cocok", fontSize = 10.sp)
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                // Finalization Footer
                                Surface(
                                    color = Color.White,
                                    shape = RoundedCornerShape(12.dp),
                                    tonalElevation = 2.dp,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(14.dp).fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        OutlinedButton(
                                            onClick = { selectedTab = 0 },
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text("👈 Kembali Hitung Ulang")
                                        }

                                        Button(
                                            onClick = { showFinalizeConfirmDialog = true },
                                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.height(44.dp).testTag("finalize_stock_opname_button")
                                        ) {
                                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Tahap Penyelesaian: Selesaikan Stok Opname", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }

                        2 -> {
                            // TAB 2: RIWAYAT TUGAS & DOKUMEN BERITA ACARA
                            Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                                Text(
                                    text = "Riwayat Tugas Stok Opname & Dokumen Berita Acara",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = SlateDark
                                )
                                Text(
                                    text = "Semua pelaksanaan stok opname yang telah diselesaikan dapat diunduh kembali sebagai dokumen resmi.",
                                    fontSize = 11.sp,
                                    color = SlateMedium
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                if (tasks.isEmpty() && history.isEmpty()) {
                                    Box(
                                        modifier = Modifier.weight(1f).fillMaxWidth(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("Belum ada tugas stok opname yang diselesaikan.", color = SlateMedium)
                                    }
                                } else {
                                    val dateFormat = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("id", "ID"))

                                    LazyColumn(
                                        modifier = Modifier.weight(1f),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        items(tasks, key = { it.id }) { task ->
                                            Card(
                                                shape = RoundedCornerShape(12.dp),
                                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Column(modifier = Modifier.padding(14.dp)) {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Column {
                                                            Text(
                                                                text = task.taskCode,
                                                                fontWeight = FontWeight.Bold,
                                                                fontSize = 15.sp,
                                                                color = Color(0xFF4F46E5)
                                                            )
                                                            Text(
                                                                text = "${task.title} • ${dateFormat.format(Date(task.completedAt ?: task.createdAt))}",
                                                                fontSize = 11.sp,
                                                                color = SlateMedium
                                                            )
                                                        }

                                                        Surface(
                                                            shape = RoundedCornerShape(6.dp),
                                                            color = Color(0xFFDCFCE7)
                                                        ) {
                                                            Text(
                                                                text = "SELESAI",
                                                                fontWeight = FontWeight.Bold,
                                                                fontSize = 10.sp,
                                                                color = Color(0xFF15803D),
                                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                            )
                                                        }
                                                    }

                                                    Spacer(modifier = Modifier.height(8.dp))

                                                    Text(
                                                        text = "Petugas: ${task.conductedBy} • Total SKU: ${task.totalItems} • Selisih: ${task.discrepancyCount} SKU (${task.discrepancyQty} unit)",
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.SemiBold,
                                                        color = SlateDark
                                                    )

                                                    if (task.notes.isNotBlank()) {
                                                        Text(
                                                            text = "Catatan: ${task.notes}",
                                                            fontSize = 11.sp,
                                                            color = SlateMedium
                                                        )
                                                    }

                                                    Spacer(modifier = Modifier.height(10.dp))

                                                    // Export Documents for this task
                                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                        Button(
                                                            onClick = {
                                                                // Filter history records for this task
                                                                val taskItems = history.filter { it.taskCode == task.taskCode }
                                                                val itemsToExport = if (taskItems.isNotEmpty()) taskItems else buildCurrentRecords()
                                                                val file = ReportExportHelper.generateStockOpnameFinalDoc(
                                                                    context = context,
                                                                    storeInfo = storeInfo,
                                                                    taskCode = task.taskCode,
                                                                    taskTitle = task.title,
                                                                    conductedBy = task.conductedBy,
                                                                    allItems = itemsToExport,
                                                                    notes = task.notes
                                                                )
                                                                ReportExportHelper.openDocument(context, file, "application/msword")
                                                            },
                                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5)),
                                                            shape = RoundedCornerShape(8.dp),
                                                            modifier = Modifier.height(34.dp)
                                                        ) {
                                                            Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(14.dp))
                                                            Spacer(modifier = Modifier.width(4.dp))
                                                            Text("Berita Acara (.doc)", fontSize = 11.sp)
                                                        }

                                                        OutlinedButton(
                                                            onClick = {
                                                                val taskItems = history.filter { it.taskCode == task.taskCode }
                                                                val itemsToExport = (if (taskItems.isNotEmpty()) taskItems else buildCurrentRecords())
                                                                    .filter { it.difference != 0 }
                                                                val file = ReportExportHelper.generateStockOpnameDiscrepancyDoc(
                                                                    context = context,
                                                                    storeInfo = storeInfo,
                                                                    taskCode = task.taskCode,
                                                                    taskTitle = task.title,
                                                                    conductedBy = task.conductedBy,
                                                                    discrepancyItems = itemsToExport
                                                                )
                                                                ReportExportHelper.openDocument(context, file, "application/msword")
                                                            },
                                                            shape = RoundedCornerShape(8.dp),
                                                            modifier = Modifier.height(34.dp)
                                                        ) {
                                                            Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(14.dp))
                                                            Spacer(modifier = Modifier.width(4.dp))
                                                            Text("Dokumen Selisih (.doc)", fontSize = 11.sp)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Confirmation Dialog before finalizing
    if (showFinalizeConfirmDialog) {
        Dialog(onDismissRequest = { showFinalizeConfirmDialog = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Konfirmasi Penyelesaian Stok Opname",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = SlateDark
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Apakah Anda yakin ingin menyelesaikan tugas Stok Opname \"$taskCode\"?\n\n" +
                                "• Total Produk: ${products.size} SKU\n" +
                                "• Produk Berselisih: ${discrepancyRecords.size} SKU\n" +
                                "• Stok fisik yang baru akan segera diterapkan ke seluruh katalog sistem POS.",
                        fontSize = 13.sp,
                        color = SlateDark,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = taskNotes,
                        onValueChange = { taskNotes = it },
                        label = { Text("Catatan Penyelesaian (Opsional)") },
                        colors = posOutlinedTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(
                            onClick = { showFinalizeConfirmDialog = false },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Batal")
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Button(
                            onClick = {
                                showFinalizeConfirmDialog = false
                                val allRecords = buildCurrentRecords()
                                onFinalizeTask(taskCode, taskTitle, taskNotes, allRecords) { completedTask ->
                                    // Generate and open formal Berita Acara document
                                    val docFile = ReportExportHelper.generateStockOpnameFinalDoc(
                                        context = context,
                                        storeInfo = storeInfo,
                                        taskCode = completedTask.taskCode,
                                        taskTitle = completedTask.title,
                                        conductedBy = completedTask.conductedBy,
                                        allItems = allRecords,
                                        notes = completedTask.notes
                                    )
                                    ReportExportHelper.openDocument(context, docFile, "application/msword")
                                    selectedTab = 2 // Switch to history tab
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Ya, Selesaikan & Terapkan", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
