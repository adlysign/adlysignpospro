package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.CartItem
import com.example.data.repository.PosRepository
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.posOutlinedTextFieldColors

@Composable
fun ItemQuantityDialog(
    item: CartItem,
    onDismiss: () -> Unit,
    onConfirmQuantity: (Int) -> Unit = {},
    onConfirmQuantityAndUnit: ((Int, String) -> Unit)? = null
) {
    var qtyText by remember { mutableStateOf(item.quantity.toString()) }
    val currentQty = (qtyText.toIntOrNull() ?: 1).coerceAtLeast(1)

    var selectedUnit by remember { mutableStateOf(item.selectedUnit) }
    val repacks = remember(item.product.repackUnitsJson) { item.product.getRepackUnits() }
    val tiers = remember(item.product.tieredPricesJson) { item.product.getTieredPrices() }

    val matchedRepack = repacks.find { it.unitName.equals(selectedUnit, ignoreCase = true) }
    val multiplier = matchedRepack?.multiplier ?: 1
    val totalBaseUnitsNeeded = currentQty * multiplier
    val isStockExceeded = totalBaseUnitsNeeded > item.product.stock

    val unitPrice = item.product.calculateUnitPrice(currentQty, selectedUnit)
    val subtotal = currentQty * unitPrice
    val isTierApplied = selectedUnit.equals(item.product.unit, ignoreCase = true) && unitPrice < item.product.sellPrice

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("item_quantity_dialog")
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "Ubah Jumlah & Satuan Barang",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 17.sp,
                    color = Color(0xFF0F172A)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = item.product.name,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp,
                    color = Color(0xFF1E293B)
                )
                Text(
                    text = "Stok toko: ${item.product.stock} ${item.product.unit} | SKU: ${item.product.sku.ifBlank { "-" }}",
                    fontSize = 12.sp,
                    color = Color(0xFF475569)
                )

                // Repack Unit Selector
                if (repacks.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Pilih Satuan Penjualan (Repack):",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0369A1)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Base unit
                        FilterChip(
                            selected = selectedUnit.equals(item.product.unit, ignoreCase = true),
                            onClick = { selectedUnit = item.product.unit },
                            label = { Text(item.product.unit, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                        // Repack units
                        repacks.forEach { rep ->
                            FilterChip(
                                selected = selectedUnit.equals(rep.unitName, ignoreCase = true),
                                onClick = { selectedUnit = rep.unitName },
                                label = { Text("${rep.unitName.uppercase()} (${rep.multiplier} ${item.product.unit})", fontSize = 11.sp) }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Stepper + Large Center Input
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Big Minus Button
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .background(Color(0xFFF1F5F9), RoundedCornerShape(12.dp))
                            .border(1.5.dp, Color(0xFFCBD5E1), RoundedCornerShape(12.dp))
                            .clickable {
                                val next = (currentQty - 1).coerceAtLeast(1)
                                qtyText = next.toString()
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Remove,
                            contentDescription = "Kurangi Qty",
                            tint = Color(0xFF0F172A),
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    // Input Field (Bold & High Contrast Dark Text)
                    OutlinedTextField(
                        value = qtyText,
                        onValueChange = { input ->
                            val clean = input.filter { it.isDigit() }
                            qtyText = clean
                        },
                        label = {
                            Text(
                                text = "Jumlah ($selectedUnit)",
                                color = Color(0xFF334155),
                                fontWeight = FontWeight.Bold
                            )
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = posOutlinedTextFieldColors(),
                        textStyle = LocalTextStyle.current.copy(
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A),
                            textAlign = TextAlign.Center
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("item_quantity_input")
                    )

                    // Big Plus Button
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .background(Color(0xFFE0F2FE), RoundedCornerShape(12.dp))
                            .border(1.5.dp, Color(0xFF0284C7), RoundedCornerShape(12.dp))
                            .clickable {
                                val next = currentQty + 1
                                qtyText = next.toString()
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Tambah Qty",
                            tint = Color(0xFF0284C7),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Quick Preset Pills: [+1], [+5], [+10], [+20]
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(1, 5, 10, 20).forEach { addAmount ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(Color(0xFFF8FAFC), RoundedCornerShape(8.dp))
                                .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(8.dp))
                                .clickable {
                                    val next = currentQty + addAmount
                                    qtyText = next.toString()
                                }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "+$addAmount",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color(0xFF0F172A)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Price and stock calculation card
                Card(
                    colors = CardDefaults.cardColors(containerColor = if (isStockExceeded) Color(0xFFFEF2F2) else Color(0xFFF1F5F9)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Harga Satuan ($selectedUnit):", fontSize = 12.sp, color = Color(0xFF475569))
                            Text(
                                PosRepository.formatRupiah(unitPrice),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isTierApplied) Color(0xFFD97706) else Color(0xFF0F172A)
                            )
                        }

                        if (isTierApplied) {
                            Text(
                                text = "🏷️ Harga Grosir Otomatis Aktif! (Hemat ${PosRepository.formatRupiah(item.product.sellPrice - unitPrice)}/$selectedUnit)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFD97706)
                            )
                        }

                        if (multiplier > 1) {
                            Text(
                                text = "Isi per $selectedUnit: $multiplier ${item.product.unit} (Total memotong: $totalBaseUnitsNeeded ${item.product.unit})",
                                fontSize = 11.sp,
                                color = Color(0xFF0369A1)
                            )
                        }

                        if (isStockExceeded) {
                            Text(
                                text = "⚠️ Total melebihi stok toko (${item.product.stock} ${item.product.unit})",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = ErrorRed
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Total Subtotal:", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(
                                PosRepository.formatRupiah(subtotal),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = EmeraldPrimary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Text(
                            text = "Batal",
                            color = Color(0xFF475569),
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                    Button(
                        onClick = {
                            val finalQty = (qtyText.toIntOrNull() ?: 1).coerceAtLeast(1)
                            if (onConfirmQuantityAndUnit != null) {
                                onConfirmQuantityAndUnit(finalQty, selectedUnit)
                            } else {
                                onConfirmQuantity(finalQty)
                            }
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("confirm_quantity_button")
                    ) {
                        Text(
                            text = "Terapkan",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }
}
