package com.example.ui.components

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/**
 * Ultra-clear high-visibility battery status indicator for POS cashier header.
 * Draws a prominent horizontal battery cell with dynamic fill level, charging bolt,
 * and exact battery percentage with high contrast borders and text.
 */
@Composable
fun BatteryStatusIndicator(
    modifier: Modifier = Modifier,
    backgroundColor: Color = Color(0x4D000000),
    textColor: Color = Color.White
) {
    val context = LocalContext.current
    var batteryPct by remember { mutableIntStateOf(100) }
    var isCharging by remember { mutableStateOf(false) }

    fun updateBatteryDirectly() {
        try {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            if (bm != null) {
                val propCapacity = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                if (propCapacity in 0..100) {
                    batteryPct = propCapacity
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    isCharging = bm.isCharging
                }
            }
        } catch (_: Exception) {}
    }

    // Direct read & periodic check fallback
    LaunchedEffect(Unit) {
        while (true) {
            updateBatteryDirectly()
            delay(15000)
        }
    }

    DisposableEffect(context) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                if (intent != null && intent.action == Intent.ACTION_BATTERY_CHANGED) {
                    val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                    val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                    val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)

                    if (level >= 0 && scale > 0) {
                        batteryPct = (level * 100) / scale
                    }
                    isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                            status == BatteryManager.BATTERY_STATUS_FULL
                }
            }
        }

        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        try {
            val initialIntent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                context.registerReceiver(receiver, filter)
            }
            if (initialIntent != null) {
                val level = initialIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = initialIntent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                val status = initialIntent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                if (level >= 0 && scale > 0) {
                    batteryPct = (level * 100) / scale
                }
                isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                        status == BatteryManager.BATTERY_STATUS_FULL
            }
        } catch (_: Exception) {
            updateBatteryDirectly()
        }

        onDispose {
            try {
                context.unregisterReceiver(receiver)
            } catch (_: Exception) {}
        }
    }

    // Determine color based on battery state
    val barColor = when {
        isCharging -> Color(0xFFFACC15) // Vivid Yellow
        batteryPct <= 20 -> Color(0xFFEF4444) // Bright Red
        batteryPct <= 50 -> Color(0xFFF59E0B) // Amber
        else -> Color(0xFF22C55E) // Bright Emerald Green
    }

    Box(
        modifier = modifier
            .background(backgroundColor, RoundedCornerShape(8.dp))
            .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.4f)), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            // Crisp custom horizontal battery canvas (always visible & sharp)
            Canvas(modifier = Modifier.size(width = 24.dp, height = 13.dp)) {
                val strokeWidth = 1.5.dp.toPx()
                val cornerRadius = CornerRadius(2.5.dp.toPx(), 2.5.dp.toPx())
                val knobWidth = 2.dp.toPx()
                val knobHeight = 6.dp.toPx()
                val bodyWidth = size.width - knobWidth - 1.5.dp.toPx()
                val bodyHeight = size.height

                // 1. Battery Body Outer Border (White for maximum contrast)
                drawRoundRect(
                    color = Color.White,
                    topLeft = Offset(0f, 0f),
                    size = Size(bodyWidth, bodyHeight),
                    cornerRadius = cornerRadius,
                    style = Stroke(width = strokeWidth)
                )

                // 2. Battery Terminal Knob on Right
                drawRoundRect(
                    color = Color.White,
                    topLeft = Offset(bodyWidth + 0.8.dp.toPx(), (bodyHeight - knobHeight) / 2f),
                    size = Size(knobWidth, knobHeight),
                    cornerRadius = CornerRadius(1.dp.toPx(), 1.dp.toPx())
                )

                // 3. Inner Fill Bar (Indicates actual battery percentage)
                val innerPadding = strokeWidth + 1.dp.toPx()
                val maxFillWidth = bodyWidth - (innerPadding * 2)
                val currentFillWidth = (maxFillWidth * (batteryPct.coerceIn(5, 100) / 100f)).coerceAtLeast(1.5.dp.toPx())
                val innerHeight = bodyHeight - (innerPadding * 2)

                drawRoundRect(
                    color = barColor,
                    topLeft = Offset(innerPadding, innerPadding),
                    size = Size(currentFillWidth, innerHeight),
                    cornerRadius = CornerRadius(1.5.dp.toPx(), 1.5.dp.toPx())
                )
            }

            Spacer(modifier = Modifier.width(5.dp))

            // Percentage & Charging Bolt
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isCharging) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = "Sedang Mengisi Daya",
                        tint = Color(0xFFFACC15),
                        modifier = Modifier.size(14.dp)
                    )
                }
                Text(
                    text = "$batteryPct%",
                    color = textColor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.3.sp
                )
            }
        }
    }
}

