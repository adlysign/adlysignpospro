package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Product
import com.example.data.repository.PosRepository
import com.example.ui.viewmodel.PosViewModel
import com.example.util.ReportExportHelper

@Composable
fun StockOpnameScreen(viewModel: PosViewModel) {
    val context = LocalContext.current
    val allProducts by viewModel.allProducts.collectAsState()
    val licenseInfo by viewModel.licenseInfo.collectAsState()
    val currentEmployee by viewModel.currentEmployee.collectAsState()

    var search by remember { mutableStateOf("") }
    var selectedProductForOpname by remember { mutableStateOf<Product?>(null) }
    var physicalCountText by remember { mutableStateOf("") }
    var reasonText by remember { mutableStateOf("") }

    val filtered = remember(allProducts, search) {
        allProducts.filter {
            search.isBlank() || it.name.contains(search, ignoreCase = true) || it.sku.contains(search, ignoreCase = true)
        }
    }

    if (selectedProductForOpname != null) {
        val prod = selectedProductForOpname!!
        val physicalCount = physicalCountText.toIntOrNull() ?: prod.stock
        val diff = physicalCount - prod.stock

        AlertDialog(
            onDismissRequest = { selectedProductForOpname = null },
            title = { Text("Stok Opname: ${prod.name}", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Stok Buku Sistem: ${prod.stock} ${prod.unit}", fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(
                        value = physicalCountText,
                        onValueChange = { physicalCountText = it.filter { c -> c.isDigit() } },
                        label = { Text("Jumlah Fisik Aktual di Toko / Gudang *") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Surface(
                        color = if (diff == 0) Color(0xFFEFF6FF) else if (diff > 0) Color(0xFFECFDF5) else Color(0xFFFEF2F2),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = when {
                                diff == 0 -> "Stok Sesuai (Selisih 0)"
                                diff > 0 -> "Selisih Lebih: +$diff ${prod.unit}"
                                else -> "Selisih Kurang: $diff ${prod.unit} (Hilang/Rusak)"
                            },
                            fontWeight = FontWeight.Bold,
                            color = if (diff >= 0) Color(0xFF065F46) else Color(0xFF991B1B),
                            modifier = Modifier.padding(10.dp)
                        )
                    }

                    OutlinedTextField(
                        value = reasonText,
                        onValueChange = { reasonText = it },
                        label = { Text("Alasan Selisih / Catatan") },
                        placeholder = { Text("Contoh: Barang kadaluarsa / selisih hitung") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.submitStockAdjustment(
                            product = prod,
                            actualPhysicalCount = physicalCount,
                            reason = reasonText.ifBlank { "Audit Stok Opname" }
                        )
                        selectedProductForOpname = null
                        physicalCountText = ""
                        reasonText = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669))
                ) {
                    Text("Terapkan Penyesuaian Stok")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { selectedProductForOpname = null }) {
                    Text("Batal")
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Audit Stok Opname Toko",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A)
                )
                Text(
                    text = "Cocokkan stok fisik di rak/gudang dengan data sistem kasir untuk mencegah kebocoran barang.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
            }

            Button(
                onClick = {
                    val file = ReportExportHelper.generateStockReportDoc(
                        context = context,
                        storeInfo = licenseInfo,
                        products = allProducts
                    )
                    ReportExportHelper.saveToDownloads(context, file, "Laporan_Stok_${System.currentTimeMillis()}.doc")
                    ReportExportHelper.openDocument(context, file, "application/msword")
                    Toast.makeText(context, "Dokumen laporan stok berhasil dibuat!", Toast.LENGTH_SHORT).show()
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F172A)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(imageVector = Icons.Default.Description, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Cetak / Simpan Dokumen")
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
            value = search,
            onValueChange = { search = it },
            placeholder = { Text("Cari produk untuk diopname...") },
            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = Color.Gray) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(filtered) { p ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            selectedProductForOpname = p
                            physicalCountText = p.stock.toString()
                        },
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(p.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                            Text("Kategori: ${p.category} | SKU: ${p.sku}", fontSize = 11.sp, color = Color.Gray)
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Stok Sistem", fontSize = 10.sp, color = Color.Gray)
                                Text(
                                    text = "${p.stock} ${p.unit}",
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (p.stock <= 5) Color.Red else Color(0xFF059669)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Button(
                                onClick = {
                                    selectedProductForOpname = p
                                    physicalCountText = p.stock.toString()
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                            ) {
                                Text("Opname")
                            }
                        }
                    }
                }
            }
        }
    }
}
