package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.PointSettings
import com.example.data.repository.PosRepository

@Composable
fun PointSettingsDialog(
    initialSettings: PointSettings,
    onDismiss: () -> Unit,
    onSaveSettings: (PointSettings) -> Unit
) {
    var minSpendText by remember { mutableStateOf(initialSettings.minSpendForPoints.toString()) }
    var spendPerPointText by remember { mutableStateOf(initialSettings.spendPerPoint.toString()) }
    var pointValueText by remember { mutableStateOf(initialSettings.pointValueInRupiah.toString()) }
    var maxPercentage by remember { mutableStateOf(initialSettings.maxRedeemPercentage.toFloat()) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("point_settings_dialog")
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Header
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(Color(0xFFFEF3C7), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Stars, contentDescription = null, tint = Color(0xFFD97706))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Pengaturan Poin & Diskon Belanja",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color(0xFF0F172A)
                            )
                            Text(
                                text = "Mekanisme Perolehan & Potongan Poin Member",
                                fontSize = 11.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup", tint = Color(0xFF475569))
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Input Minimal Belanja
                OutlinedTextField(
                    value = minSpendText,
                    onValueChange = { minSpendText = it.filter { c -> c.isDigit() } },
                    label = { Text("Minimal Belanja untuk Dapat Poin (Rp)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Input Kelipatan Belanja
                OutlinedTextField(
                    value = spendPerPointText,
                    onValueChange = { spendPerPointText = it.filter { c -> c.isDigit() } },
                    label = { Text("Kelipatan Belanja Tiap 1 Poin (Rp)") },
                    supportingText = { Text("Misal: Rp 10.000 = Dapat 1 Poin") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Nilai 1 Poin dalam Rupiah
                OutlinedTextField(
                    value = pointValueText,
                    onValueChange = { pointValueText = it.filter { c -> c.isDigit() } },
                    label = { Text("Nilai 1 Poin sebagai Potongan Belanja (Rp)") },
                    supportingText = { Text("Misal: 1 Poin = Rp 100 potongan") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(10.dp))

                // Batas Maksimal Potongan Poin (Full 100% atau persentase)
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Batas Maksimal Potongan:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                            Text(
                                if (maxPercentage >= 100f) "FULL (100%)" else "${maxPercentage.toInt()}% dari Total",
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFFD97706),
                                fontSize = 12.sp
                            )
                        }

                        Slider(
                            value = maxPercentage,
                            onValueChange = { maxPercentage = it },
                            valueRange = 10f..100f,
                            steps = 8,
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFFD97706),
                                activeTrackColor = Color(0xFFD97706)
                            )
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(25, 50, 75, 100).forEach { pct ->
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(
                                            if (maxPercentage.toInt() == pct) Color(0xFFD97706) else Color(0xFFE2E8F0),
                                            RoundedCornerShape(6.dp)
                                        )
                                        .clickable { maxPercentage = pct.toFloat() }
                                        .padding(vertical = 4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        if (pct == 100) "Full (100%)" else "$pct%",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (maxPercentage.toInt() == pct) Color.White else Color(0xFF334155)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Batal", color = Color(0xFF334155), fontWeight = FontWeight.SemiBold)
                    }
                    Button(
                        onClick = {
                            val minSpend = minSpendText.toLongOrNull() ?: 10000L
                            val perPoint = spendPerPointText.toLongOrNull() ?: 10000L
                            val ptVal = pointValueText.toLongOrNull() ?: 100L
                            val newSettings = PointSettings(
                                minSpendForPoints = minSpend,
                                spendPerPoint = perPoint,
                                pointValueInRupiah = ptVal,
                                maxRedeemPercentage = maxPercentage.toInt()
                            )
                            onSaveSettings(newSettings)
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("save_point_settings_button")
                    ) {
                        Text("Simpan Pengaturan", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}
