package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sell
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Style
import androidx.compose.material.icons.filled.ViewCarousel
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import com.example.data.model.LicenseInfo
import com.example.data.model.Product
import com.example.data.repository.PosRepository
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.posOutlinedTextFieldColors
import com.example.util.ReportExportHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Model layout / template for price tags
 */
enum class PriceLabelModel(val displayName: String, val badge: String, val desc: String) {
    SHELF_STANDAR("Standar Rak", "Minimarket", "Ukuran standar selipan rel rak minimarket"),
    BARCODE_STICKER("Stiker Barcode", "40x30 mm", "Barcode besar rapat untuk stiker kemasan"),
    PROMO_GROSIR("Promo / Grosir", "Spesial", "Badge promo kuning/merah & harga bertingkat"),
    MINIMALIS("Minimalis", "Elegan", "Desain monokrom modern untuk butik / cafe")
}

/**
 * Selection mode: Print All Products vs Pick Specific Products
 */
enum class PriceLabelSelectionMode(val title: String) {
    SELECTIVE("Pilih Beberapa Produk"),
    ALL("Cetak Semua Produk")
}

@Composable
fun PriceTagLabelDialog(
    products: List<Product>,
    storeInfo: LicenseInfo,
    initialSelectedProduct: Product? = null,
    onDismiss: () -> Unit,
    onPrintBluetooth: (List<Pair<Product, Int>>, String) -> Unit = { _, _ -> }
) {
    val context = LocalContext.current

    // Selection Mode: ALL vs SELECTIVE
    var selectionMode by remember {
        mutableStateOf(
            if (initialSelectedProduct != null) PriceLabelSelectionMode.SELECTIVE
            else PriceLabelSelectionMode.SELECTIVE
        )
    }

    // Selected Model Template
    var selectedModel by remember { mutableStateOf(PriceLabelModel.SHELF_STANDAR) }

    // Copies per product when in "ALL" mode
    var allCopiesPerProduct by remember { mutableIntStateOf(1) }

    // Map of Product ID to copy count in "SELECTIVE" mode
    val selectedCopiesMap = remember {
        mutableStateMapOf<Long, Int>().apply {
            if (initialSelectedProduct != null) {
                put(initialSelectedProduct.id, 1)
            } else {
                // By default select top 10 products
                products.take(10).forEach { put(it.id, 1) }
            }
        }
    }

    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Semua") }

    val categories = remember(products) {
        listOf("Semua") + products.map { it.category }.distinct().filter { it.isNotBlank() }
    }

    val filteredProducts = remember(products, searchQuery, selectedCategory) {
        products.filter { p ->
            val matchCategory = selectedCategory == "Semua" || p.category.equals(selectedCategory, ignoreCase = true)
            val matchQuery = searchQuery.isBlank() ||
                    p.name.contains(searchQuery, ignoreCase = true) ||
                    p.sku.contains(searchQuery, ignoreCase = true)
            matchCategory && matchQuery
        }
    }

    // Final list of products to print based on active mode
    val effectiveSelectedItems: List<Pair<Product, Int>> = remember(
        selectionMode,
        allCopiesPerProduct,
        selectedCopiesMap.toMap(),
        products
    ) {
        if (selectionMode == PriceLabelSelectionMode.ALL) {
            products.map { it to allCopiesPerProduct }
        } else {
            selectedCopiesMap.filter { it.value > 0 }.mapNotNull { entry ->
                products.find { it.id == entry.key }?.let { it to entry.value }
            }
        }
    }

    val totalLabelCount = effectiveSelectedItems.sumOf { it.second }
    val totalProductCount = effectiveSelectedItems.size

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
                .testTag("price_tag_label_dialog")
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // 1. Header Bar
                Surface(
                    color = EmeraldPrimary,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(Color.White.copy(alpha = 0.2f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.Sell,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Cetak Label Harga Rak & Barcode",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                Text(
                                    text = "Pilih cetak semua/beberapa dan sesuaikan model tampilan label",
                                    color = Color(0xFFD1FAE5),
                                    fontSize = 11.sp
                                )
                            }
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(32.dp)
                                .background(Color.White.copy(alpha = 0.2f), CircleShape)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Tutup", tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                    }
                }

                // 2. Main Content Split: Left (Selection Controls) & Right (Model Selector + Live Preview + Actions)
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // LEFT COLUMN: Selection (All vs Selective) & Products
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        modifier = Modifier
                            .weight(1.25f)
                            .fillMaxHeight()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(12.dp)
                        ) {
                            // Mode Switch Tabs: Pilih Beberapa vs Cetak Semua
                            TabRow(
                                selectedTabIndex = if (selectionMode == PriceLabelSelectionMode.SELECTIVE) 0 else 1,
                                containerColor = Color(0xFFF1F5F9),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                            ) {
                                Tab(
                                    selected = selectionMode == PriceLabelSelectionMode.SELECTIVE,
                                    onClick = { selectionMode = PriceLabelSelectionMode.SELECTIVE },
                                    text = {
                                        Text(
                                            "Pilih Beberapa",
                                            fontSize = 12.sp,
                                            fontWeight = if (selectionMode == PriceLabelSelectionMode.SELECTIVE) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    modifier = Modifier.testTag("tab_mode_selective")
                                )
                                Tab(
                                    selected = selectionMode == PriceLabelSelectionMode.ALL,
                                    onClick = { selectionMode = PriceLabelSelectionMode.ALL },
                                    text = {
                                        Text(
                                            "Cetak Semua (${products.size})",
                                            fontSize = 12.sp,
                                            fontWeight = if (selectionMode == PriceLabelSelectionMode.ALL) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    modifier = Modifier.testTag("tab_mode_all")
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            if (selectionMode == PriceLabelSelectionMode.ALL) {
                                // MODE: CETAK SEMUA PRODUK
                                Card(
                                    shape = RoundedCornerShape(10.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFFECFDF5)),
                                    border = BorderStroke(1.dp, Color(0xFF10B981)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Layers, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(20.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "Mode Cetak Massal Seluruh Katalog",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = Color(0xFF065F46)
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = "Akan mencetak label untuk seluruh ${products.size} produk dalam database.",
                                            fontSize = 11.sp,
                                            color = Color(0xFF047857)
                                        )
                                        Spacer(modifier = Modifier.height(10.dp))

                                        // Setting: Copies per product
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("Jumlah salinan per produk:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1F2937))
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                IconButton(
                                                    onClick = { if (allCopiesPerProduct > 1) allCopiesPerProduct-- },
                                                    modifier = Modifier.size(28.dp).background(Color.White, CircleShape)
                                                ) {
                                                    Icon(Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(16.dp))
                                                }
                                                Text(
                                                    text = "$allCopiesPerProduct",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 14.sp,
                                                    modifier = Modifier.padding(horizontal = 12.dp)
                                                )
                                                IconButton(
                                                    onClick = { allCopiesPerProduct++ },
                                                    modifier = Modifier.size(28.dp).background(Color.White, CircleShape)
                                                ) {
                                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(8.dp))
                                        // Quick Presets
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            listOf(1, 2, 3, 5).forEach { qty ->
                                                Surface(
                                                    shape = RoundedCornerShape(6.dp),
                                                    color = if (allCopiesPerProduct == qty) EmeraldPrimary else Color.White,
                                                    border = BorderStroke(1.dp, EmeraldPrimary),
                                                    modifier = Modifier.clickable { allCopiesPerProduct = qty }.padding(horizontal = 10.dp, vertical = 4.dp)
                                                ) {
                                                    Text(
                                                        text = "$qty Lembar",
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = if (allCopiesPerProduct == qty) Color.White else EmeraldPrimary
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Daftar Produk yang akan Dicetak (${products.size}):",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF475569)
                                )
                                Spacer(modifier = Modifier.height(6.dp))

                                LazyColumn(
                                    modifier = Modifier.weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    items(products, key = { it.id }) { product ->
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = Color(0xFFF8FAFC),
                                            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(product.name, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                    Text("SKU: ${product.sku.ifBlank { "-" }} • ${product.category}", fontSize = 9.sp, color = Color(0xFF64748B))
                                                }
                                                Text(
                                                    PosRepository.formatRupiah(product.sellPrice),
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFF0F172A)
                                                )
                                            }
                                        }
                                    }
                                }
                            } else {
                                // MODE: PILIH BEBERAPA PRODUK (SELECTIVE)
                                // Search Input
                                OutlinedTextField(
                                    value = searchQuery,
                                    onValueChange = { searchQuery = it },
                                    placeholder = { Text("Cari nama atau barcode SKU...", fontSize = 11.sp) },
                                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF64748B), modifier = Modifier.size(16.dp)) },
                                    trailingIcon = {
                                        if (searchQuery.isNotBlank()) {
                                            IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(20.dp)) {
                                                Icon(Icons.Default.Clear, contentDescription = null, modifier = Modifier.size(14.dp))
                                            }
                                        }
                                    },
                                    singleLine = true,
                                    colors = posOutlinedTextFieldColors(),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(44.dp)
                                )

                                Spacer(modifier = Modifier.height(6.dp))

                                // Bulk Actions
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${selectedCopiesMap.count { it.value > 0 }} produk dipilih",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = EmeraldPrimary
                                    )

                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = Color(0xFFE0F2FE),
                                            modifier = Modifier
                                                .clickable {
                                                    filteredProducts.forEach { selectedCopiesMap[it.id] = 1 }
                                                }
                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text("Pilih Semua", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0369A1))
                                        }

                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = Color(0xFFFEE2E2),
                                            modifier = Modifier
                                                .clickable { selectedCopiesMap.clear() }
                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text("Kosongkan", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB91C1C))
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))
                                HorizontalDivider(color = Color(0xFFF1F5F9))
                                Spacer(modifier = Modifier.height(4.dp))

                                // Product List with Checkbox & Stepper
                                LazyColumn(
                                    modifier = Modifier.weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    items(filteredProducts, key = { it.id }) { product ->
                                        val copies = selectedCopiesMap[product.id] ?: 0
                                        val isSelected = copies > 0

                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = if (isSelected) Color(0xFFECFDF5) else Color(0xFFF8FAFC),
                                            border = BorderStroke(1.dp, if (isSelected) EmeraldPrimary else Color(0xFFE2E8F0)),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(horizontal = 6.dp, vertical = 4.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Checkbox(
                                                    checked = isSelected,
                                                    onCheckedChange = { checked ->
                                                        if (checked) {
                                                            selectedCopiesMap[product.id] = 1
                                                        } else {
                                                            selectedCopiesMap.remove(product.id)
                                                        }
                                                    },
                                                    colors = CheckboxDefaults.colors(checkedColor = EmeraldPrimary),
                                                    modifier = Modifier.size(24.dp)
                                                )

                                                Spacer(modifier = Modifier.width(6.dp))

                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = product.name,
                                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                                                        fontSize = 11.sp,
                                                        color = Color(0xFF0F172A),
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                    Text(
                                                        text = "${PosRepository.formatRupiah(product.sellPrice)} • SKU: ${product.sku.ifBlank { "-" }}",
                                                        fontSize = 9.sp,
                                                        color = Color(0xFF64748B)
                                                    )
                                                }

                                                // Copy Stepper
                                                if (isSelected) {
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        IconButton(
                                                            onClick = {
                                                                if (copies > 1) {
                                                                    selectedCopiesMap[product.id] = copies - 1
                                                                } else {
                                                                    selectedCopiesMap.remove(product.id)
                                                                }
                                                            },
                                                            modifier = Modifier.size(24.dp).background(Color.White, CircleShape)
                                                        ) {
                                                            Icon(Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(14.dp))
                                                        }
                                                        Text(
                                                            text = "$copies",
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            modifier = Modifier.padding(horizontal = 6.dp)
                                                        )
                                                        IconButton(
                                                            onClick = { selectedCopiesMap[product.id] = copies + 1 },
                                                            modifier = Modifier.size(24.dp).background(Color.White, CircleShape)
                                                        ) {
                                                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // RIGHT COLUMN: Model Selector, Dynamic Live Preview, & Print Actions
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                // Model Header
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.Style, contentDescription = null, tint = Color(0xFF0284C7), modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Model Tampilan Label:",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF1E293B)
                                    )
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                // Model Selection Buttons (4 Models)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    PriceLabelModel.values().forEach { model ->
                                        val isChosen = selectedModel == model
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = if (isChosen) Color(0xFF0284C7) else Color(0xFFF1F5F9),
                                            border = BorderStroke(1.dp, if (isChosen) Color(0xFF0284C7) else Color(0xFFCBD5E1)),
                                            modifier = Modifier
                                                .weight(1f)
                                                .clickable { selectedModel = model }
                                                .testTag("model_${model.name.lowercase()}")
                                        ) {
                                            Column(
                                                modifier = Modifier.padding(vertical = 6.dp, horizontal = 2.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally
                                            ) {
                                                Text(
                                                    text = model.displayName,
                                                    fontSize = 9.5.sp,
                                                    fontWeight = if (isChosen) FontWeight.Bold else FontWeight.Medium,
                                                    color = if (isChosen) Color.White else Color(0xFF334155),
                                                    maxLines = 1,
                                                    textAlign = TextAlign.Center
                                                )
                                                Text(
                                                    text = model.badge,
                                                    fontSize = 8.sp,
                                                    color = if (isChosen) Color(0xFFE0F2FE) else Color(0xFF64748B)
                                                )
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Live Tag Preview Container
                                Text(
                                    text = "PRATINJAU MODEL: ${selectedModel.displayName.uppercase()}",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFF64748B),
                                    letterSpacing = 0.5.sp
                                )

                                Spacer(modifier = Modifier.height(6.dp))

                                val sampleProduct = effectiveSelectedItems.firstOrNull()?.first ?: products.firstOrNull()
                                if (sampleProduct != null) {
                                    when (selectedModel) {
                                        PriceLabelModel.SHELF_STANDAR -> {
                                            // Model 1: Standar Rak Minimarket
                                            Card(
                                                shape = RoundedCornerShape(8.dp),
                                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                                border = BorderStroke(2.dp, Color(0xFF0F172A)),
                                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Column {
                                                    Row(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .background(Color(0xFF0284C7))
                                                            .padding(horizontal = 8.dp, vertical = 4.dp),
                                                        horizontalArrangement = Arrangement.SpaceBetween
                                                    ) {
                                                        Text(storeInfo.storeName.ifBlank { "MINIMARKET POS" }, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                        Text(SimpleDateFormat("dd/MM/yy", Locale.getDefault()).format(Date()), color = Color(0xFFE0F2FE), fontSize = 9.sp)
                                                    }
                                                    Column(modifier = Modifier.padding(8.dp)) {
                                                        Text(sampleProduct.name, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF0F172A), maxLines = 1)
                                                        Text("SKU: ${sampleProduct.sku.ifBlank { "-" }} • ${sampleProduct.category}", fontSize = 9.sp, color = Color(0xFF64748B))
                                                        Spacer(modifier = Modifier.height(4.dp))
                                                        Surface(
                                                            shape = RoundedCornerShape(6.dp),
                                                            color = Color(0xFFF8FAFC),
                                                            border = BorderStroke(1.dp, Color(0xFFCBD5E1)),
                                                            modifier = Modifier.fillMaxWidth()
                                                        ) {
                                                            Column(modifier = Modifier.padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                                                Text(PosRepository.formatRupiah(sampleProduct.sellPrice), fontSize = 18.sp, fontWeight = FontWeight.Black, color = Color(0xFFDC2626))
                                                                Text("per ${sampleProduct.unit.ifBlank { "PCS" }.uppercase()}", fontSize = 9.sp, color = Color(0xFF475569))
                                                            }
                                                        }
                                                        Spacer(modifier = Modifier.height(4.dp))
                                                        Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                                                            Text("|||| ||| ||||| || |||||||", fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                                                            Text(sampleProduct.sku.ifBlank { "PROD-${sampleProduct.id}" }, fontSize = 8.sp, color = Color(0xFF64748B))
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        PriceLabelModel.BARCODE_STICKER -> {
                                            // Model 2: Stiker Barcode Kompak
                                            Card(
                                                shape = RoundedCornerShape(6.dp),
                                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                                border = BorderStroke(1.5.dp, Color(0xFF334155)),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Column(
                                                    modifier = Modifier.padding(8.dp),
                                                    horizontalAlignment = Alignment.CenterHorizontally
                                                ) {
                                                    Text(sampleProduct.name, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                    Text(
                                                        text = "${PosRepository.formatRupiah(sampleProduct.sellPrice)} / ${sampleProduct.unit.ifBlank { "PCS" }}",
                                                        fontSize = 15.sp,
                                                        fontWeight = FontWeight.ExtraBold,
                                                        color = Color(0xFF0F172A)
                                                    )
                                                    Spacer(modifier = Modifier.height(4.dp))
                                                    Text("|||||| |||| ||||| |||||||", fontFamily = FontFamily.Monospace, fontSize = 14.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                                                    Text(sampleProduct.sku.ifBlank { "PROD-${sampleProduct.id}" }, fontSize = 9.sp, color = Color(0xFF475569))
                                                }
                                            }
                                        }
                                        PriceLabelModel.PROMO_GROSIR -> {
                                            // Model 3: Label Promo & Grosir
                                            Card(
                                                shape = RoundedCornerShape(8.dp),
                                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                                border = BorderStroke(2.dp, Color(0xFFDC2626)),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Column {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth().background(Color(0xFFDC2626)).padding(horizontal = 8.dp, vertical = 3.dp),
                                                        horizontalArrangement = Arrangement.SpaceBetween
                                                    ) {
                                                        Text("★ SPESIAL PROMO / GROSIR ★", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                                        Text("DISKON", color = Color(0xFFFEF08A), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                                    }
                                                    Column(modifier = Modifier.padding(8.dp)) {
                                                        Text(sampleProduct.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                                        Spacer(modifier = Modifier.height(2.dp))
                                                        Surface(
                                                            shape = RoundedCornerShape(6.dp),
                                                            color = Color(0xFFFEF2F2),
                                                            border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                                                            modifier = Modifier.fillMaxWidth()
                                                        ) {
                                                            Column(modifier = Modifier.padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                                                Text(PosRepository.formatRupiah(sampleProduct.sellPrice), fontSize = 18.sp, fontWeight = FontWeight.Black, color = Color(0xFFDC2626))
                                                                Text("HEMAT • per ${sampleProduct.unit.ifBlank { "PCS" }}", fontSize = 8.sp, color = Color(0xFFB91C1C), fontWeight = FontWeight.Bold)
                                                            }
                                                        }
                                                        Spacer(modifier = Modifier.height(4.dp))
                                                        Text("|||| ||| ||||| || • ${sampleProduct.sku.ifBlank { "-" }}", fontFamily = FontFamily.Monospace, fontSize = 9.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                                                    }
                                                }
                                            }
                                        }
                                        PriceLabelModel.MINIMALIS -> {
                                            // Model 4: Minimalis Monokrom
                                            Card(
                                                shape = RoundedCornerShape(4.dp),
                                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                                border = BorderStroke(1.dp, Color(0xFF94A3B8)),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Column(modifier = Modifier.padding(8.dp)) {
                                                    Text(storeInfo.storeName.ifBlank { "POS PRO" }.uppercase(), fontSize = 8.sp, color = Color(0xFF64748B))
                                                    Text(sampleProduct.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E293B), maxLines = 1)
                                                    Text(PosRepository.formatRupiah(sampleProduct.sellPrice), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                                                    Text("Satuan: ${sampleProduct.unit.ifBlank { "PCS" }}", fontSize = 8.sp, color = Color(0xFF64748B))
                                                    Spacer(modifier = Modifier.height(4.dp))
                                                    HorizontalDivider(color = Color(0xFFE2E8F0))
                                                    Spacer(modifier = Modifier.height(2.dp))
                                                    Text("||| |||| |||| || • ${sampleProduct.sku.ifBlank { "PROD-${sampleProduct.id}" }}", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = Color(0xFF334155))
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Actions Area
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                // 1. Bluetooth Thermal Printer Button
                                Button(
                                    onClick = {
                                        if (effectiveSelectedItems.isEmpty()) {
                                            Toast.makeText(context, "Pilih minimal 1 produk untuk dicetak!", Toast.LENGTH_SHORT).show()
                                        } else {
                                            onPrintBluetooth(effectiveSelectedItems, selectedModel.name)
                                        }
                                    },
                                    enabled = effectiveSelectedItems.isNotEmpty(),
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(42.dp)
                                        .testTag("btn_print_bluetooth_labels")
                                ) {
                                    Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Cetak Bluetooth ($totalLabelCount Label)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }

                                // 2. Export / Print PDF/A4 Sheet Button
                                OutlinedButton(
                                    onClick = {
                                        if (effectiveSelectedItems.isEmpty()) {
                                            Toast.makeText(context, "Pilih minimal 1 produk untuk dicetak!", Toast.LENGTH_SHORT).show()
                                        } else {
                                            try {
                                                val file = ReportExportHelper.exportPriceLabelsHtml(
                                                    context = context,
                                                    items = effectiveSelectedItems,
                                                    storeInfo = storeInfo,
                                                    labelType = selectedModel.name
                                                )
                                                val uri = FileProvider.getUriForFile(
                                                    context,
                                                    "${context.packageName}.fileprovider",
                                                    file
                                                )
                                                val intent = Intent(Intent.ACTION_VIEW).apply {
                                                    setDataAndType(uri, "text/html")
                                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                }
                                                context.startActivity(Intent.createChooser(intent, "Buka & Cetak Lembar Label"))
                                            } catch (e: Exception) {
                                                Toast.makeText(context, "Gagal ekspor label: ${e.message}", Toast.LENGTH_LONG).show()
                                            }
                                        }
                                    },
                                    enabled = effectiveSelectedItems.isNotEmpty(),
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, Color(0xFF0284C7)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(38.dp)
                                        .testTag("btn_export_label_sheet")
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, tint = Color(0xFF0284C7), modifier = Modifier.size(15.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Cetak Lembar A4 (${selectedModel.displayName})", color = Color(0xFF0284C7), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
