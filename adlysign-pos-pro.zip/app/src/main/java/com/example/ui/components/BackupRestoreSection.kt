package com.example.ui.components

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.AmberShift1
import com.example.ui.theme.BlueShift2
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SlateDark
import com.example.ui.theme.SlateLight
import com.example.ui.theme.SlateMedium
import com.example.ui.theme.SuccessGreen
import com.example.ui.viewmodel.PosViewModel
import com.example.util.BackupMetadata
import com.example.util.BackupRestoreHelper
import com.example.util.LocalBackupItem
import com.example.util.RestoreMode
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BackupRestoreSection(viewModel: PosViewModel) {
    val context = LocalContext.current
    val lastBackupTs by viewModel.lastBackupTimestamp.collectAsStateWithLifecycle()
    val localBackups by viewModel.localBackups.collectAsStateWithLifecycle()
    val isBackupRunning by viewModel.isBackupRunning.collectAsStateWithLifecycle()
    val isRestoreRunning by viewModel.isRestoreRunning.collectAsStateWithLifecycle()

    // State for Pending Restore Dialog
    var pendingRestoreJson by remember { mutableStateOf<String?>(null) }
    var pendingRestoreMetadata by remember { mutableStateOf<BackupMetadata?>(null) }
    var pendingDeleteBackupFile by remember { mutableStateOf<File?>(null) }

    // Launcher to pick a JSON backup file from phone/drive
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val jsonString = BackupRestoreHelper.readBackupFromUri(context, uri)
            if (!jsonString.isNullOrBlank()) {
                val metadata = BackupRestoreHelper.parseBackupMetadata(jsonString)
                if (metadata != null) {
                    pendingRestoreJson = jsonString
                    pendingRestoreMetadata = metadata
                } else {
                    Toast.makeText(context, "Format file tidak dikenali sebagai cadangan POS yang valid.", Toast.LENGTH_LONG).show()
                }
            } else {
                Toast.makeText(context, "Tidak dapat membaca file cadangan.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(16.dp))
            .testTag("backup_restore_section_card")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {

            // --- Header Title ---
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = EmeraldPrimary.copy(alpha = 0.12f),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Default.Save,
                                contentDescription = null,
                                tint = EmeraldPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Cadangan & Pemulihan Data (Backup & Restore)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = SlateDark
                        )
                        Text(
                            text = "Amankan database produk, transaksi, shift, dan piutang.",
                            fontSize = 11.sp,
                            color = SlateLight
                        )
                    }
                }

                IconButton(
                    onClick = { viewModel.loadLocalBackups() },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        Icons.Default.Refresh,
                        contentDescription = "Muat Ulang",
                        tint = SlateMedium,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // --- Status Box ---
            val sdf = SimpleDateFormat("dd MMMM yyyy, HH:mm", Locale("id", "ID"))
            val backupDateText = if (lastBackupTs > 0L) {
                sdf.format(Date(lastBackupTs))
            } else {
                "Belum pernah dicadangkan"
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (lastBackupTs > 0L) Color(0xFFF0FDF4) else Color(0xFFFFFBEB),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        if (lastBackupTs > 0L) Color(0xFFBBF7D0) else Color(0xFFFDE68A),
                        RoundedCornerShape(12.dp)
                    )
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        if (lastBackupTs > 0L) Icons.Default.CheckCircle else Icons.Default.Info,
                        contentDescription = null,
                        tint = if (lastBackupTs > 0L) SuccessGreen else AmberShift1,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Status Cadangan Terakhir:",
                            fontSize = 11.sp,
                            color = SlateMedium,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = backupDateText,
                            fontSize = 13.sp,
                            color = if (lastBackupTs > 0L) SlateDark else AmberShift1,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (lastBackupTs > 0L) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = SuccessGreen.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "AMAN",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = SuccessGreen,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // --- Action Buttons: Backup & Export ---
            Text(
                text = "1. Buat Cadangan Data Baru (Backup):",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = SlateDark
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        viewModel.createQuickBackup { res ->
                            res.onSuccess {
                                Toast.makeText(context, "Cadangan berhasil disimpan di perangkat!", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    enabled = !isBackupRunning && !isRestoreRunning,
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quick_backup_button")
                ) {
                    Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Cadangkan Sekarang", fontSize = 12.sp)
                }

                OutlinedButton(
                    onClick = {
                        viewModel.getBackupJsonData { res ->
                            res.onSuccess { (jsonStr, _) ->
                                try {
                                    val dir = BackupRestoreHelper.getBackupDirectory(context)
                                    val fileDateFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                                    val tempFile = File(dir, "pos_backup_export_$fileDateFormat.json")
                                    tempFile.writeText(jsonStr, Charsets.UTF_8)
                                    BackupRestoreHelper.shareBackupFile(context, tempFile)
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Gagal membagikan: ${e.message}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    },
                    enabled = !isBackupRunning && !isRestoreRunning,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("share_backup_button")
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, tint = BlueShift2, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Ekspor & Bagikan", fontSize = 12.sp, color = BlueShift2)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedButton(
                onClick = {
                    viewModel.createQuickBackup { res ->
                        res.onSuccess { file ->
                            val dest = BackupRestoreHelper.saveBackupToDownloads(context, file)
                            if (dest != null) {
                                Toast.makeText(context, "Tersimpan di Download: ${dest.name}", Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                },
                enabled = !isBackupRunning && !isRestoreRunning,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("save_to_downloads_button")
            ) {
                Icon(Icons.Default.FileDownload, contentDescription = null, tint = SlateDark, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Simpan File ke Folder Download", fontSize = 12.sp, color = SlateDark)
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 14.dp), color = Color(0xFFF1F5F9))

            // --- Action Buttons: Restore ---
            Text(
                text = "2. Pulihkan Data dari Cadangan (Restore):",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = SlateDark
            )
            Text(
                text = "Gunakan file cadangan (.json) untuk memulihkan seluruh data kasir saat pindah HP atau pemulihan darurat.",
                fontSize = 11.sp,
                color = SlateLight
            )

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = {
                    filePickerLauncher.launch("*/*")
                },
                enabled = !isBackupRunning && !isRestoreRunning,
                colors = ButtonDefaults.buttonColors(containerColor = BlueShift2),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("choose_restore_file_button")
            ) {
                Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Pilih File Cadangan dari Memori HP / Drive", fontSize = 12.sp)
            }

            // Progress Indicator
            if (isBackupRunning || isRestoreRunning) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = EmeraldPrimary)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = if (isBackupRunning) "Sedang membuat file cadangan..." else "Sedang memproses pemulihan data...",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = SlateDark
                    )
                }
            }

            // --- Local Backups History ---
            if (localBackups.isNotEmpty()) {
                HorizontalDivider(modifier = Modifier.padding(vertical = 14.dp), color = Color(0xFFF1F5F9))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "File Cadangan Tersimpan di HP (${localBackups.size}):",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = SlateDark
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    localBackups.take(5).forEach { item ->
                        LocalBackupItemCard(
                            item = item,
                            onRestore = {
                                try {
                                    val content = item.file.readText(Charsets.UTF_8)
                                    val meta = item.metadata ?: BackupRestoreHelper.parseBackupMetadata(content)
                                    if (meta != null) {
                                        pendingRestoreJson = content
                                        pendingRestoreMetadata = meta
                                    } else {
                                        Toast.makeText(context, "Data cadangan tidak valid", Toast.LENGTH_SHORT).show()
                                    }
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Gagal membaca file: ${e.message}", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onShare = {
                                BackupRestoreHelper.shareBackupFile(context, item.file)
                            },
                            onSaveDownload = {
                                val dest = BackupRestoreHelper.saveBackupToDownloads(context, item.file)
                                if (dest != null) {
                                    Toast.makeText(context, "Disimpan di Download: ${dest.name}", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onDelete = {
                                pendingDeleteBackupFile = item.file
                            }
                        )
                    }
                }
            }
        }
    }

    // --- DIALOG 1: KONFIRMASI PEMULIHAN (RESTORE CONFIRMATION) ---
    if (pendingRestoreJson != null && pendingRestoreMetadata != null) {
        val meta = pendingRestoreMetadata!!
        var selectedMode by remember { mutableStateOf(RestoreMode.REPLACE) }

        AlertDialog(
            onDismissRequest = {
                if (!isRestoreRunning) {
                    pendingRestoreJson = null
                    pendingRestoreMetadata = null
                }
            },
            icon = {
                Surface(
                    shape = CircleShape,
                    color = BlueShift2.copy(alpha = 0.15f),
                    modifier = Modifier.size(48.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Restore, contentDescription = null, tint = BlueShift2, modifier = Modifier.size(24.dp))
                    }
                }
            },
            title = {
                Text(
                    text = "Konfirmasi Pemulihan Data",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = SlateDark
                )
            },
            text = {
                Column {
                    Text(
                        text = "File cadangan ini berisi data dari:",
                        fontSize = 12.sp,
                        color = SlateMedium
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFF8FAFC),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(8.dp))
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Toko:", fontSize = 12.sp, color = SlateLight)
                                Text(meta.storeName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SlateDark)
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Waktu Cadangan:", fontSize = 12.sp, color = SlateLight)
                                Text(meta.formattedDate, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = SlateDark)
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Ukuran File:", fontSize = 12.sp, color = SlateLight)
                                Text(meta.fileSizeFormatted, fontSize = 12.sp, color = SlateMedium)
                            }

                            HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = Color(0xFFE2E8F0))

                            Text("Rincian Isi Data Cadangan:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SlateDark)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "• ${meta.productsCount} Katalog Produk\n" +
                                "• ${meta.transactionsCount} Riwayat Transaksi Penjualan\n" +
                                "• ${meta.shiftsCount} Catatan Shift Kasir\n" +
                                "• ${meta.employeesCount} Akun Karyawan & Hak Akses\n" +
                                "• ${meta.membersCount} Member Pelanggan\n" +
                                "• ${meta.receivablesCount} Data Kasbon / Piutang\n" +
                                "• ${meta.stockOpnameCount} Rekam Stok Opname\n" +
                                "• ${meta.purchasesCount} Data Kulakan / Pembelian Supplier\n" +
                                "• ${meta.productReturnsCount} Data Retur Barang\n" +
                                "• Pengaturan Toko, QRIS & Printer Struk",
                                fontSize = 11.sp,
                                color = SlateMedium,
                                lineHeight = 16.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Pilih Mode Pemulihan:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = SlateDark)
                    Spacer(modifier = Modifier.height(4.dp))

                    // Option 1: Replace
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (selectedMode == RestoreMode.REPLACE) EmeraldPrimary.copy(alpha = 0.08f) else Color.Transparent,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                1.dp,
                                if (selectedMode == RestoreMode.REPLACE) EmeraldPrimary else Color(0xFFE2E8F0),
                                RoundedCornerShape(8.dp)
                            )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedMode == RestoreMode.REPLACE,
                                onClick = { selectedMode = RestoreMode.REPLACE },
                                colors = RadioButtonDefaults.colors(selectedColor = EmeraldPrimary)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Column {
                                Text("Ganti Seluruh Data (Disarankan)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = SlateDark)
                                Text("Menimpa seluruh database agar persis seperti waktu dicadangkan.", fontSize = 10.sp, color = SlateMedium)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Option 2: Merge
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (selectedMode == RestoreMode.MERGE) BlueShift2.copy(alpha = 0.08f) else Color.Transparent,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                1.dp,
                                if (selectedMode == RestoreMode.MERGE) BlueShift2 else Color(0xFFE2E8F0),
                                RoundedCornerShape(8.dp)
                            )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedMode == RestoreMode.MERGE,
                                onClick = { selectedMode = RestoreMode.MERGE },
                                colors = RadioButtonDefaults.colors(selectedColor = BlueShift2)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Column {
                                Text("Gabungkan Data (Merge)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = SlateDark)
                                Text("Memasukkan data cadangan tanpa menghapus data baru saat ini.", fontSize = 10.sp, color = SlateMedium)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFFEF2F2),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = ErrorRed, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                "Perhatian: Tindakan pemulihan akan memperbarui database kasir.",
                                fontSize = 10.sp,
                                color = ErrorRed,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val json = pendingRestoreJson
                        if (json != null) {
                            viewModel.restoreBackupData(json, selectedMode) { res ->
                                pendingRestoreJson = null
                                pendingRestoreMetadata = null
                                if (res.success) {
                                    Toast.makeText(context, "Pemulihan data berhasil!", Toast.LENGTH_LONG).show()
                                }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = if (selectedMode == RestoreMode.REPLACE) EmeraldPrimary else BlueShift2),
                    enabled = !isRestoreRunning
                ) {
                    if (isRestoreRunning) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Color.White)
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                    Text("Mulai Pulihkan Data")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = {
                        pendingRestoreJson = null
                        pendingRestoreMetadata = null
                    },
                    enabled = !isRestoreRunning
                ) {
                    Text("Batal")
                }
            }
        )
    }

    // --- DIALOG 2: HAPUS CADANGAN LOKAL ---
    if (pendingDeleteBackupFile != null) {
        val fileToDelete = pendingDeleteBackupFile!!
        AlertDialog(
            onDismissRequest = { pendingDeleteBackupFile = null },
            icon = {
                Icon(Icons.Default.Delete, contentDescription = null, tint = ErrorRed)
            },
            title = {
                Text("Hapus File Cadangan?")
            },
            text = {
                Text("File '${fileToDelete.name}' akan dihapus dari memori internal aplikasi.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteLocalBackup(fileToDelete)
                        pendingDeleteBackupFile = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                ) {
                    Text("Hapus")
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingDeleteBackupFile = null }) {
                    Text("Batal")
                }
            }
        )
    }
}

@Composable
private fun LocalBackupItemCard(
    item: LocalBackupItem,
    onRestore: () -> Unit,
    onShare: () -> Unit,
    onSaveDownload: () -> Unit,
    onDelete: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color(0xFFF8FAFC),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(10.dp))
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.fileName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = SlateDark,
                        maxLines = 1
                    )
                    Text(
                        text = "${item.formattedDate} • ${item.fileSizeFormatted}" + (item.metadata?.let { " • ${it.productsCount} Produk, ${it.transactionsCount} Trx" } ?: ""),
                        fontSize = 11.sp,
                        color = SlateMedium
                    )
                }

                Row {
                    IconButton(onClick = onShare, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Share, contentDescription = "Bagikan", tint = BlueShift2, modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = onSaveDownload, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.FileDownload, contentDescription = "Unduh", tint = SlateDark, modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = ErrorRed, modifier = Modifier.size(16.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Button(
                onClick = onRestore,
                colors = ButtonDefaults.buttonColors(containerColor = BlueShift2),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(32.dp)
            ) {
                Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Pulihkan Data dari Cadangan Ini", fontSize = 11.sp)
            }
        }
    }
}
