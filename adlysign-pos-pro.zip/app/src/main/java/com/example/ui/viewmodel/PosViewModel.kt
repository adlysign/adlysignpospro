package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.CartItem
import com.example.data.model.Employee
import com.example.data.model.LicenseInfo
import com.example.data.model.MemberRecord
import com.example.data.model.PendingCart
import com.example.data.model.PointSettings
import com.example.data.model.Product
import com.example.data.model.PurchaseRecord
import com.example.data.model.ReceivableRecord
import com.example.data.model.ShiftRecord
import com.example.data.model.StockOpnameRecord
import com.example.data.model.StockOpnameTask
import com.example.data.model.TransactionRecord
import com.example.data.repository.PosRepository
import com.example.license.LicenseManager
import com.example.network.ClientSyncState
import com.example.network.LocalNetworkSyncManager
import com.example.network.SyncServerState
import com.example.util.BackupMetadata
import com.example.util.BackupRestoreHelper
import com.example.util.LocalBackupItem
import com.example.util.RestoreMode
import com.example.util.RestoreResult
import java.io.File
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed class UiEvent {
    data class ShowMessage(val message: String, val isError: Boolean = false) : UiEvent()
    data class TransactionSuccess(val transaction: TransactionRecord) : UiEvent()
}

class PosViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application, viewModelScope)
    private val licenseManager = LicenseManager(application)
    val repository = PosRepository(database.posDao(), licenseManager)
    val syncManager = LocalNetworkSyncManager(application, database.posDao(), viewModelScope)
    val shortcutManager = com.example.data.local.ShortcutManager(application)

    // --- Keyboard F1-F12 Shortcuts ---
    val shortcutsConfig: StateFlow<List<com.example.data.model.ShortcutConfig>> = shortcutManager.shortcuts

    fun updateShortcut(keyName: String, action: com.example.data.model.PosShortcutAction, isEnabled: Boolean) {
        shortcutManager.updateShortcut(keyName, action, isEnabled)
    }

    fun toggleShortcut(keyName: String, isEnabled: Boolean) {
        shortcutManager.toggleShortcut(keyName, isEnabled)
    }

    fun resetShortcutsToDefault() {
        shortcutManager.resetToDefaults()
        emitMessage("Konfigurasi shortcut F1-F12 berhasil direset ke standar!")
    }

    // --- Suppliers State & Methods ---
    val allSuppliers: StateFlow<List<com.example.data.model.SupplierRecord>> = repository.allSuppliers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun saveSupplier(name: String, phone: String = "", address: String = "", contactPerson: String = "", notes: String = "") {
        if (name.isBlank()) {
            emitMessage("Nama supplier tidak boleh kosong!", isError = true)
            return
        }
        viewModelScope.launch {
            repository.saveSupplier(
                com.example.data.model.SupplierRecord(
                    name = name.trim(),
                    phone = phone.trim(),
                    address = address.trim(),
                    contactPerson = contactPerson.trim(),
                    notes = notes.trim()
                )
            )
            emitMessage("Data supplier \"$name\" berhasil disimpan!")
        }
    }

    fun deleteSupplier(supplier: com.example.data.model.SupplierRecord) {
        viewModelScope.launch {
            repository.deleteSupplier(supplier)
            emitMessage("Supplier \"${supplier.name}\" berhasil dihapus!")
        }
    }

    // --- Store Partners (Belanja Toko) State & Methods ---
    val allStorePartners: StateFlow<List<com.example.data.model.StorePartnerRecord>> = repository.allStorePartners
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun saveStorePartner(name: String, phone: String = "", address: String = "", notes: String = "") {
        if (name.isBlank()) {
            emitMessage("Nama toko tidak boleh kosong!", isError = true)
            return
        }
        viewModelScope.launch {
            repository.saveStorePartner(
                com.example.data.model.StorePartnerRecord(
                    name = name.trim(),
                    phone = phone.trim(),
                    address = address.trim(),
                    notes = notes.trim()
                )
            )
            emitMessage("Data mitra toko \"$name\" berhasil disimpan!")
        }
    }

    fun deleteStorePartner(store: com.example.data.model.StorePartnerRecord) {
        viewModelScope.launch {
            repository.deleteStorePartner(store)
            emitMessage("Mitra toko \"${store.name}\" berhasil dihapus!")
        }
    }

    // --- Employee & Authentication ---
    val allEmployees: StateFlow<List<Employee>> = repository.allEmployees
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentEmployee = MutableStateFlow<Employee?>(null)
    val currentEmployee: StateFlow<Employee?> = _currentEmployee.asStateFlow()

    private val _isLocked = MutableStateFlow(false)
    val isLocked: StateFlow<Boolean> = _isLocked.asStateFlow()

    init {
        // Ensure default employees are available in the database, but do NOT auto-login.
        // User must explicitly login with their PIN.
        viewModelScope.launch {
            repository.ensureDefaultEmployees()
            loadLocalBackups()
        }
    }

    // --- Search & Category Filters ---
    val searchQuery = MutableStateFlow("")
    val selectedCategory = MutableStateFlow("Semua")

    // --- Products ---
    val rawProducts: StateFlow<List<Product>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allProducts: StateFlow<List<Product>> get() = rawProducts
    val members: StateFlow<List<MemberRecord>> get() = allMembers
    val pendingCarts: StateFlow<List<PendingCart>> get() = allPendingCarts
    val employees: StateFlow<List<Employee>> get() = allEmployees
    val lastCompletedTransaction: StateFlow<TransactionRecord?> get() = activeReceiptTransaction

    val filteredProducts: StateFlow<List<Product>> = combine(
        rawProducts,
        searchQuery,
        selectedCategory
    ) { products, query, category ->
        products.filter { p ->
            val matchesCategory = (category == "Semua") || p.category.equals(category, ignoreCase = true)
            val matchesQuery = query.isBlank() ||
                    p.name.contains(query, ignoreCase = true) ||
                    p.sku.contains(query, ignoreCase = true)
            matchesCategory && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val categories: StateFlow<List<String>> = rawProducts.combine(MutableStateFlow(Unit)) { products, _ ->
        val cats = mutableListOf("Semua")
        val unique = products.map { it.category }.distinct().filter { it.isNotBlank() }
        cats.addAll(unique)
        cats
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("Semua"))

    // --- Cart State ---
    private val _cartItems = MutableStateFlow<List<CartItem>>(emptyList())
    val cartItems: StateFlow<List<CartItem>> = _cartItems.asStateFlow()

    val cartTotal: StateFlow<Long> = _cartItems.combine(MutableStateFlow(Unit)) { items, _ ->
        items.sumOf { it.subtotal }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val cartItemCount: StateFlow<Int> = _cartItems.combine(MutableStateFlow(Unit)) { items, _ ->
        items.sumOf { it.quantity }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // --- Member & Loyalty Points ---
    val allMembers: StateFlow<List<MemberRecord>> = repository.allMembers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedMember = MutableStateFlow<MemberRecord?>(null)
    val selectedMember: StateFlow<MemberRecord?> = _selectedMember.asStateFlow()

    private val _pointSettings = MutableStateFlow(repository.getPointSettings())
    val pointSettings: StateFlow<PointSettings> = _pointSettings.asStateFlow()

    private val _pointsToRedeem = MutableStateFlow(0)
    val pointsToRedeem: StateFlow<Int> = _pointsToRedeem.asStateFlow()

    val pointDiscountAmount: StateFlow<Long> = combine(
        _pointsToRedeem,
        _pointSettings,
        cartTotal
    ) { pts, settings, total ->
        if (pts <= 0) return@combine 0L
        val rawDiscount = pts * settings.pointValueInRupiah
        val maxAllowed = (total * settings.maxRedeemPercentage) / 100
        rawDiscount.coerceAtMost(maxAllowed)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    // --- Pending Carts ---
    val allPendingCarts: StateFlow<List<PendingCart>> = repository.allPendingCarts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingCartCount: StateFlow<Int> = repository.pendingCartCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // --- Receivables (Piutang) ---
    val allReceivables: StateFlow<List<ReceivableRecord>> = repository.allReceivables
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val receivables: StateFlow<List<ReceivableRecord>> = allReceivables

    // --- Stock Opname ---
    val allStockOpname: StateFlow<List<StockOpnameRecord>> = repository.allStockOpname
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val stockOpnames: StateFlow<List<StockOpnameRecord>> = allStockOpname

    val allStockOpnameTasks: StateFlow<List<StockOpnameTask>> = repository.allStockOpnameTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val stockOpnameTasks: StateFlow<List<StockOpnameTask>> = allStockOpnameTasks

    // --- Purchases (Pembelian Supplier) ---
    val allPurchases: StateFlow<List<PurchaseRecord>> = repository.allPurchases
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val purchaseRecords: StateFlow<List<PurchaseRecord>> = allPurchases

    // --- Product Returns (Retur Barang) ---
    val allProductReturns: StateFlow<List<com.example.data.model.ProductReturnRecord>> = repository.allProductReturns
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val productReturns: StateFlow<List<com.example.data.model.ProductReturnRecord>> = allProductReturns

    // --- Shifts State ---
    val activeShift: StateFlow<ShiftRecord?> = repository.activeShift
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val todayShifts: StateFlow<List<ShiftRecord>> = repository.getTodayShifts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allShifts: StateFlow<List<ShiftRecord>> = repository.allShifts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Transactions State ---
    val allTransactions: StateFlow<List<TransactionRecord>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- License State ---
    private val _licenseInfo = MutableStateFlow(repository.getLicenseInfo())
    val licenseInfo: StateFlow<LicenseInfo> = _licenseInfo.asStateFlow()

    // --- Sync State ---
    val syncServerState: StateFlow<SyncServerState> = syncManager.serverState
    val clientSyncState: StateFlow<ClientSyncState> = syncManager.clientState
    val syncClientHostIp = MutableStateFlow(syncManager.getSavedHostIp())
    val syncStatusText = MutableStateFlow("")
    val isSyncing = MutableStateFlow(false)

    // --- UI Events ---
    private val _uiEvent = MutableSharedFlow<UiEvent>()
    val uiEvent: SharedFlow<UiEvent> = _uiEvent.asSharedFlow()

    // --- Dialogs & Active Checkout Receipt ---
    val activeReceiptTransaction = MutableStateFlow<TransactionRecord?>(null)

    fun clearActiveReceiptTransaction() {
        activeReceiptTransaction.value = null
    }
    val printerManager = com.example.printer.BluetoothPrinterManager(application)
    private val _printerSettings = MutableStateFlow(repository.getPrinterSettings())
    val printerSettings: StateFlow<com.example.data.model.PrinterSettings> = _printerSettings.asStateFlow()
    val isPrinting = MutableStateFlow(false)

    fun updatePrinterSettings(settings: com.example.data.model.PrinterSettings) {
        repository.updatePrinterSettings(settings)
        _printerSettings.value = settings
        emitMessage("Pengaturan printer Bluetooth & struk disimpan.")
    }

    fun getPairedPrinters(): List<android.bluetooth.BluetoothDevice> {
        return printerManager.getPairedPrinters()
    }

    fun testPrint(customSettings: com.example.data.model.PrinterSettings? = null) {
        viewModelScope.launch {
            val settings = customSettings ?: _printerSettings.value
            if (settings.selectedDeviceAddress.isBlank()) {
                emitMessage("Pilih printer Bluetooth terlebih dahulu di menu Pengaturan.", isError = true)
                return@launch
            }
            isPrinting.value = true
            val res = printerManager.testPrint(
                deviceAddress = settings.selectedDeviceAddress,
                storeName = _licenseInfo.value.storeName,
                paperSize = settings.paperSize,
                autoCut = settings.cutPaper,
                template = settings.receiptTemplate
            )
            isPrinting.value = false
            res.onSuccess {
                emitMessage("Tes cetak berhasil dikirim ke printer: ${settings.selectedDeviceName.ifBlank { settings.selectedDeviceAddress }}")
            }.onFailure {
                emitMessage(it.message ?: "Gagal tes cetak printer Bluetooth", isError = true)
            }
        }
    }

    fun printTransactionReceipt(tx: TransactionRecord) {
        viewModelScope.launch {
            val settings = _printerSettings.value
            if (settings.selectedDeviceAddress.isBlank()) {
                emitMessage("Printer Bluetooth belum dipilih. Silakan atur di menu Pengaturan.", isError = true)
                return@launch
            }
            isPrinting.value = true
            val res = printerManager.printReceipt(tx, _licenseInfo.value, settings)
            isPrinting.value = false
            res.onSuccess {
                emitMessage("Struk ${tx.receiptNumber} berhasil dikirim ke printer Bluetooth!")
            }.onFailure {
                emitMessage(it.message ?: "Gagal mencetak struk Bluetooth", isError = true)
            }
        }
    }

    fun printPriceLabels(items: List<Pair<Product, Int>>, labelType: String = "SHELF_STANDAR") {
        viewModelScope.launch {
            val settings = _printerSettings.value
            if (settings.selectedDeviceAddress.isBlank()) {
                emitMessage("Printer Bluetooth belum dipilih. Silakan atur di menu Pengaturan.", isError = true)
                return@launch
            }
            isPrinting.value = true
            val storeName = _licenseInfo.value.storeName
            val res = printerManager.printPriceLabels(items, storeName, settings, labelType)
            isPrinting.value = false
            res.onSuccess {
                emitMessage("Label harga berhasil dikirim ke printer Bluetooth!")
            }.onFailure {
                emitMessage(it.message ?: "Gagal mencetak label harga Bluetooth", isError = true)
            }
        }
    }

    fun refreshLicenseInfo() {
        _licenseInfo.value = repository.getLicenseInfo()
    }

    // --- Authentication & Lock Logic ---
    fun loginWithPin(pin: String): Boolean {
        val employee = allEmployees.value.find { it.pin == pin && it.isActive }
        return if (employee != null) {
            _currentEmployee.value = employee
            _isLocked.value = false
            emitMessage("Selamat datang, ${employee.name} (${employee.role})")
            true
        } else {
            emitMessage("PIN tidak valid atau pengguna tidak aktif!", isError = true)
            false
        }
    }

    fun selectEmployeeToLogin(employee: Employee) {
        _currentEmployee.value = employee
        _isLocked.value = false
        emitMessage("Login sebagai ${employee.name}")
    }

    fun lockCashier() {
        val empName = _currentEmployee.value?.name ?: "Kasir"
        // Auto-pending cart if has items
        if (_cartItems.value.isNotEmpty()) {
            val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            saveCartToPending("Auto Pending - Kunci Layar ($time)")
        }
        _isLocked.value = true
        emitMessage("Kasir dikunci oleh $empName")
    }

    fun unlockCashier(pin: String): Boolean {
        val current = _currentEmployee.value
        if (current != null && current.pin == pin) {
            _isLocked.value = false
            emitMessage("Kasir berhasil dibuka kembali")
            return true
        }
        // Also allow OWNER or SUPERVISOR pin to unlock
        val supervisor = allEmployees.value.find { (it.role == "OWNER" || it.role == "SUPERVISOR") && it.pin == pin }
        if (supervisor != null) {
            _isLocked.value = false
            emitMessage("Kasir dibuka oleh Supervisor ${supervisor.name}")
            return true
        }
        emitMessage("PIN buka kunci salah!", isError = true)
        return false
    }

    fun logoutCashier() {
        val emp = _currentEmployee.value
        val empName = emp?.name ?: "Kasir"
        // Auto-pending cart if has items
        if (_cartItems.value.isNotEmpty()) {
            val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            saveCartToPending("Auto Pending - Logout $empName ($time)")
        }
        _currentEmployee.value = null
        _isLocked.value = false
        clearSelectedMember()
        emitMessage("Kasir $empName telah logout")
    }

    // --- Cart Actions ---
    fun addToCart(product: Product, requestedUnit: String? = null) {
        // Enforce Shift Requirement
        if (activeShift.value == null) {
            emitMessage("Shift kasir belum dibuka! Silakan buka shift terlebih dahulu.", isError = true)
            return
        }

        val targetUnit = requestedUnit ?: product.unit
        val repacks = product.getRepackUnits()
        val matchedRepack = repacks.find { it.unitName.equals(targetUnit, ignoreCase = true) }
        val multiplier = matchedRepack?.multiplier ?: 1

        val current = _cartItems.value.toMutableList()
        val index = current.indexOfFirst { it.product.id == product.id && it.selectedUnit.equals(targetUnit, ignoreCase = true) }
        if (index >= 0) {
            val existing = current[index]
            val newQty = existing.quantity + 1
            val totalBaseUnitsNeeded = newQty * multiplier
            val otherBaseUnits = current.filterIndexed { i, itm -> i != index && itm.product.id == product.id }
                .sumOf { it.totalBaseUnits }

            if (totalBaseUnitsNeeded + otherBaseUnits <= product.stock) {
                val newPrice = product.calculateUnitPrice(newQty, targetUnit)
                current[index] = existing.copy(quantity = newQty, customUnitPrice = newPrice)
            } else {
                emitMessage("Stok tidak mencukupi (${product.stock} ${product.unit})", isError = true)
                return
            }
        } else {
            val otherBaseUnits = current.filter { it.product.id == product.id }.sumOf { it.totalBaseUnits }
            if (otherBaseUnits + multiplier <= product.stock) {
                val price = product.calculateUnitPrice(1, targetUnit)
                current.add(
                    CartItem(
                        product = product,
                        quantity = 1,
                        selectedUnit = targetUnit,
                        unitMultiplier = multiplier,
                        customUnitPrice = price
                    )
                )
            } else {
                emitMessage("Stok produk tidak mencukupi untuk satuan $targetUnit (butuh $multiplier ${product.unit}, stok: ${product.stock})", isError = true)
                return
            }
        }
        _cartItems.value = current
    }

    fun setCartItemUnit(cartIndex: Int, newUnit: String) {
        val current = _cartItems.value.toMutableList()
        if (cartIndex !in current.indices) return
        val existing = current[cartIndex]
        val product = existing.product
        val repacks = product.getRepackUnits()
        val matchedRepack = repacks.find { it.unitName.equals(newUnit, ignoreCase = true) }
        val multiplier = matchedRepack?.multiplier ?: 1

        val totalBaseUnitsNeeded = existing.quantity * multiplier
        val otherBaseUnits = current.filterIndexed { i, itm -> i != cartIndex && itm.product.id == product.id }
            .sumOf { it.totalBaseUnits }

        if (totalBaseUnitsNeeded + otherBaseUnits > product.stock) {
            emitMessage("Stok tidak mencukupi untuk beralih ke satuan $newUnit (sisa stok: ${product.stock} ${product.unit})", isError = true)
            return
        }

        val newPrice = product.calculateUnitPrice(existing.quantity, newUnit)
        current[cartIndex] = existing.copy(
            selectedUnit = newUnit,
            unitMultiplier = multiplier,
            customUnitPrice = newPrice
        )
        _cartItems.value = current
    }

    fun setItemQuantity(product: Product, quantity: Int) {
        val current = _cartItems.value.toMutableList()
        val index = current.indexOfFirst { it.product.id == product.id }
        if (index >= 0) {
            updateCartItemQuantityAtIndex(index, quantity)
        }
    }

    fun updateCartItemQuantityAtIndex(index: Int, quantity: Int) {
        val current = _cartItems.value.toMutableList()
        if (index !in current.indices) return
        val item = current[index]
        if (quantity <= 0) {
            current.removeAt(index)
            _cartItems.value = current
            return
        }
        val product = item.product
        val totalBaseUnitsNeeded = quantity * item.unitMultiplier
        val otherBaseUnits = current.filterIndexed { i, itm -> i != index && itm.product.id == product.id }
            .sumOf { it.totalBaseUnits }

        if (totalBaseUnitsNeeded + otherBaseUnits > product.stock) {
            emitMessage("Jumlah melebihi stok tersedia (${product.stock} ${product.unit})", isError = true)
            return
        }
        val newPrice = product.calculateUnitPrice(quantity, item.selectedUnit)
        current[index] = item.copy(quantity = quantity, customUnitPrice = newPrice)
        _cartItems.value = current
    }

    fun decreaseQuantity(product: Product) {
        val current = _cartItems.value.toMutableList()
        val index = current.indexOfFirst { it.product.id == product.id }
        if (index >= 0) {
            val existing = current[index]
            if (existing.quantity > 1) {
                updateCartItemQuantityAtIndex(index, existing.quantity - 1)
            } else {
                current.removeAt(index)
                _cartItems.value = current
            }
        }
    }

    fun removeFromCart(product: Product) {
        _cartItems.value = _cartItems.value.filterNot { it.product.id == product.id }
    }

    fun voidLastItem() {
        if (_cartItems.value.isNotEmpty()) {
            val last = _cartItems.value.last()
            _cartItems.value = _cartItems.value.dropLast(1)
            emitMessage("Item \"${last.product.name}\" berhasil di-void")
        }
    }

    fun updateItemQuantity(product: Product, quantity: Int) {
        setItemQuantity(product, quantity)
    }

    fun updateCartItemQuantityAndUnit(product: Product, quantity: Int, unit: String) {
        val current = _cartItems.value.toMutableList()
        val index = current.indexOfFirst { it.product.id == product.id }
        if (index >= 0) {
            if (quantity <= 0) {
                current.removeAt(index)
                _cartItems.value = current
                return
            }
            val repacks = product.getRepackUnits()
            val matchedRepack = repacks.find { it.unitName.equals(unit, ignoreCase = true) }
            val multiplier = matchedRepack?.multiplier ?: 1
            val totalBaseUnitsNeeded = quantity * multiplier
            val otherBaseUnits = current.filterIndexed { i, itm -> i != index && itm.product.id == product.id }
                .sumOf { it.totalBaseUnits }

            if (totalBaseUnitsNeeded + otherBaseUnits > product.stock) {
                emitMessage("Stok tidak mencukupi untuk jumlah ini (sisa stok: ${product.stock} ${product.unit})", isError = true)
                return
            }

            val newPrice = product.calculateUnitPrice(quantity, unit)
            current[index] = current[index].copy(
                quantity = quantity,
                selectedUnit = unit,
                unitMultiplier = multiplier,
                customUnitPrice = newPrice
            )
            _cartItems.value = current
        }
    }

    fun recallPendingCart(id: Long) {
        val pending = allPendingCarts.value.find { it.id == id }
        if (pending != null) {
            recallPendingCart(pending)
        }
    }

    fun addMember(name: String, phone: String) {
        val member = MemberRecord(name = name.trim(), phone = phone.trim(), points = 0)
        saveMember(member)
    }

    fun savePointSettings(settings: PointSettings) {
        updatePointSettings(settings)
    }

    fun loginEmployee(employee: Employee) {
        selectEmployeeToLogin(employee)
    }

    fun logoutEmployee() {
        logoutCashier()
    }

    fun clearCart() {
        _cartItems.value = emptyList()
        _pointsToRedeem.value = 0
    }

    // --- Fast Scan / Search Barcode ---
    fun scanBarcodeOrSearch(code: String) {
        val trimmed = code.trim()
        if (trimmed.isBlank()) return

        viewModelScope.launch {
            val prod = repository.findProductByBarcode(trimmed)
            if (prod != null) {
                addToCart(prod)
                emitMessage("Ditambahkan: ${prod.name}")
            } else {
                // Try finding by name match
                val match = rawProducts.value.find { it.name.contains(trimmed, ignoreCase = true) }
                if (match != null) {
                    addToCart(match)
                    emitMessage("Ditambahkan: ${match.name}")
                } else {
                    emitMessage("Produk barcode/nama \"$trimmed\" tidak ditemukan!", isError = true)
                }
            }
        }
    }

    // ID of cart saved automatically when app stopped or minimized
    private var lastAutoSavedPendingCartId: Long? = null

    /**
     * Auto save cart to pending if the app is suddenly closed, stopped, or terminated.
     * Synchronously inserts into SQLite database via Room.
     */
    fun autoSaveCartToPendingSync(customLabel: String? = null) {
        val currentItems = _cartItems.value
        if (currentItems.isEmpty()) return
        try {
            val time = java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
            val label = customLabel ?: "Auto Pending (Aplikasi Tertutup $time)"
            val empName = _currentEmployee.value?.name ?: "Kasir"
            kotlinx.coroutines.runBlocking(kotlinx.coroutines.Dispatchers.IO) {
                val id = repository.savePendingCart(
                    label = label,
                    cashierName = empName,
                    items = currentItems,
                    member = _selectedMember.value
                )
                lastAutoSavedPendingCartId = id
            }
        } catch (_: Exception) {}
    }

    /**
     * Called when the app resumes. If the memory state was not killed and the cashier
     * is still looking at the active cart, remove the temporary auto-saved record so
     * there are no duplicate pending carts.
     */
    fun onAppResumed() {
        val autoId = lastAutoSavedPendingCartId ?: return
        if (_cartItems.value.isNotEmpty()) {
            viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                try {
                    repository.deletePendingCart(autoId)
                    lastAutoSavedPendingCartId = null
                } catch (_: Exception) {}
            }
        } else {
            lastAutoSavedPendingCartId = null
        }
    }

    // --- Pending Cart Logic ---
    fun saveCartToPending(label: String) {
        if (_cartItems.value.isEmpty()) {
            emitMessage("Keranjang kosong, tidak ada item untuk ditahan.", isError = true)
            return
        }
        val empName = _currentEmployee.value?.name ?: "Kasir"
        viewModelScope.launch {
            repository.savePendingCart(
                label = label.ifBlank { "Pending Transaksi" },
                cashierName = empName,
                items = _cartItems.value,
                member = _selectedMember.value
            )
            clearCart()
            syncManager.triggerImmediateSync(syncClientHostIp.value)
            emitMessage("Keranjang berhasil disimpan ke Pending [\"$label\"]")
        }
    }

    fun recallPendingCart(pending: PendingCart) {
        viewModelScope.launch {
            try {
                val jsonArray = JSONArray(pending.itemsJson)
                val restoredItems = mutableListOf<CartItem>()
                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    val prod = Product(
                        id = obj.optLong("id"),
                        name = obj.optString("name"),
                        category = obj.optString("category"),
                        sellPrice = obj.optLong("price"),
                        costPrice = obj.optLong("costPrice"),
                        stock = obj.optInt("stock", 100),
                        unit = obj.optString("unit", "pcs"),
                        sku = obj.optString("sku", "")
                    )
                    restoredItems.add(
                        CartItem(
                            product = prod,
                            quantity = obj.optInt("quantity", 1),
                            note = obj.optString("note", "")
                        )
                    )
                }
                _cartItems.value = restoredItems
                if (pending.memberId != null) {
                    _selectedMember.value = allMembers.value.find { it.id == pending.memberId }
                }
                repository.deletePendingCart(pending.id)

                // Hapus pending cart dari server Kasir Utama jika terhubung
                val host = syncClientHostIp.value.ifBlank { syncManager.getSavedHostIp() }
                if (host.isNotBlank()) {
                    val empName = _currentEmployee.value?.name ?: "Kasir"
                    syncManager.claimOrDeletePendingCartOnHost(host, pending.effectiveCartCode, empName)
                    syncManager.triggerImmediateSync(host)
                }

                emitMessage("Transaksi pending [\"${pending.label}\"] berhasil dipulihkan ke kasir!")
            } catch (e: Exception) {
                emitMessage("Gagal memulihkan pending cart: ${e.message}", isError = true)
            }
        }
    }

    fun deletePendingCart(id: Long) {
        viewModelScope.launch {
            val pending = allPendingCarts.value.find { it.id == id }
            repository.deletePendingCart(id)
            val host = syncClientHostIp.value.ifBlank { syncManager.getSavedHostIp() }
            if (host.isNotBlank() && pending != null) {
                val empName = _currentEmployee.value?.name ?: "Kasir"
                syncManager.claimOrDeletePendingCartOnHost(host, pending.effectiveCartCode, empName)
                syncManager.triggerImmediateSync(host)
            }
            emitMessage("Transaksi pending dihapus")
        }
    }

    // --- Member & Loyalty Points ---
    fun selectMember(member: MemberRecord) {
        _selectedMember.value = member
        _pointsToRedeem.value = 0
        emitMessage("Member aktif: ${member.name} (${member.points} Poin)")
    }

    fun clearSelectedMember() {
        _selectedMember.value = null
        _pointsToRedeem.value = 0
    }

    fun setPointsToRedeem(points: Int) {
        val member = _selectedMember.value ?: return
        val validPoints = points.coerceIn(0, member.points)
        _pointsToRedeem.value = validPoints
    }

    fun saveMember(member: MemberRecord) {
        viewModelScope.launch {
            repository.saveMember(member)
            emitMessage("Data member \"${member.name}\" berhasil disimpan")
        }
    }

    fun deleteMember(member: MemberRecord) {
        viewModelScope.launch {
            repository.deleteMember(member)
            if (_selectedMember.value?.id == member.id) {
                clearSelectedMember()
            }
            emitMessage("Member \"${member.name}\" dihapus")
        }
    }

    fun updatePointSettings(settings: PointSettings) {
        repository.updatePointSettings(settings)
        _pointSettings.value = settings
        emitMessage("Pengaturan Poin Member berhasil diperbarui")
    }

    // --- Employee Management ---
    fun saveEmployee(employee: Employee) {
        viewModelScope.launch {
            repository.saveEmployee(employee)
            emitMessage("Karyawan \"${employee.name}\" (${employee.role}) disimpan")
        }
    }

    fun deleteEmployee(employee: Employee) {
        viewModelScope.launch {
            repository.deleteEmployee(employee)
            emitMessage("Karyawan \"${employee.name}\" dihapus")
        }
    }

    // --- Receivables (Piutang) Management ---
    fun payReceivable(id: Long, amount: Long) {
        viewModelScope.launch {
            val empName = _currentEmployee.value?.name ?: "Kasir"
            val res = repository.payReceivable(id, amount, empName)
            res.onSuccess { rec ->
                val statusText = if (rec.status == "LUNAS") "LUNAS" else "Sisa: ${PosRepository.formatRupiah(rec.remainingAmount)}"
                emitMessage("Pembayaran piutang Rp ${PosRepository.formatRupiah(amount)} berhasil dicatat! Status: $statusText")
            }.onFailure {
                emitMessage(it.message ?: "Gagal mencatat pembayaran piutang", isError = true)
            }
        }
    }

    // --- Stock Opname (SO) Execution ---
    fun submitStockOpname(
        productId: Long,
        productName: String,
        sku: String,
        systemStock: Int,
        physicalStock: Int,
        reason: String,
        notes: String
    ) {
        viewModelScope.launch {
            val empName = _currentEmployee.value?.name ?: "Kasir"
            val res = repository.saveStockOpname(
                productId = productId,
                productName = productName,
                sku = sku,
                systemStock = systemStock,
                physicalStock = physicalStock,
                reason = reason,
                conductedBy = empName,
                notes = notes
            )
            res.onSuccess {
                val diff = physicalStock - systemStock
                val diffStr = if (diff >= 0) "+$diff" else "$diff"
                emitMessage("Stock Opname \"$productName\" berhasil disimpan! Stok disesuaikan ($diffStr pcs)")
            }.onFailure {
                emitMessage(it.message ?: "Gagal menyimpan SO", isError = true)
            }
        }
    }

    fun finalizeStockOpnameBatch(
        taskCode: String,
        title: String,
        notes: String,
        items: List<StockOpnameRecord>,
        onSuccess: (StockOpnameTask) -> Unit = {}
    ) {
        viewModelScope.launch {
            val empName = _currentEmployee.value?.name ?: "Supervisor"
            val res = repository.finalizeStockOpnameBatch(
                taskCode = taskCode,
                title = title,
                conductedBy = empName,
                notes = notes,
                items = items
            )
            res.onSuccess { task ->
                emitMessage("Tugas Stok Opname \"${task.taskCode}\" selesai! Stok fisik berhasil diselaraskan ke sistem.")
                onSuccess(task)
            }.onFailure { err ->
                emitMessage("Gagal menyelesaikan tugas Stok Opname: ${err.message}", isError = true)
            }
        }
    }

    // --- Product Return (Retur Barang) Execution ---
    fun submitProductReturn(
        productId: Long,
        productName: String,
        qty: Int,
        returnType: String, // "MASUK_STOK" (Retur Konsumen) or "KELUAR_STOK" (Retur Rusak/Supplier)
        reason: String,
        customerOrSupplier: String,
        notes: String
    ) {
        viewModelScope.launch {
            if (qty <= 0) {
                emitMessage("Jumlah retur harus lebih dari 0", isError = true)
                return@launch
            }
            val res = repository.saveProductReturn(
                productId = productId,
                productName = productName,
                qty = qty,
                returnType = returnType,
                reason = reason,
                customerOrSupplier = customerOrSupplier,
                notes = notes
            )
            res.onSuccess {
                if (returnType == "MASUK_STOK") {
                    emitMessage("Retur $qty $productName dari pelanggan berhasil! Stok fisik bertambah (+$qty).")
                } else {
                    emitMessage("Retur $qty $productName (keluar stok/rusak) berhasil! Stok berkurang (-$qty).")
                }
            }.onFailure {
                emitMessage("Gagal memproses retur: ${it.message}", isError = true)
            }
        }
    }

    // --- Supplier Purchase & Store Purchase Execution ---
    fun submitSupplierPurchase(
        invoiceNumber: String,
        supplierName: String,
        supplierPhone: String,
        paymentType: String,
        items: List<Triple<Product, Int, Long>>, // Product, qty, buyPrice
        notes: String,
        purchaseType: String = "SUPPLIER"
    ) {
        viewModelScope.launch {
            val empName = _currentEmployee.value?.name ?: "Kasir"
            val totalAmount = items.sumOf { it.second * it.third }

            val jsonArray = JSONArray()
            val list = mutableListOf<Triple<Long, Int, Long>>()
            for (item in items) {
                val p = item.first
                val qty = item.second
                val price = item.third
                list.add(Triple(p.id, qty, price))

                val obj = org.json.JSONObject().apply {
                    put("productId", p.id)
                    put("name", p.name)
                    put("qty", qty)
                    put("buyPrice", price)
                    put("subtotal", qty * price)
                }
                jsonArray.put(obj)
            }

            val res = repository.savePurchase(
                invoiceNumber = invoiceNumber.trim(),
                supplierName = supplierName.trim(),
                supplierPhone = supplierPhone.trim(),
                paymentType = paymentType,
                totalAmount = totalAmount,
                itemsJson = jsonArray.toString(),
                itemsList = list,
                notes = notes,
                receivedBy = empName,
                purchaseType = purchaseType
            )
            res.onSuccess {
                val label = if (purchaseType == "STORE_PURCHASE") "Belanja toko" else "Faktur pembelian supplier"
                emitMessage("$label \"$invoiceNumber\" ($supplierName) berhasil disimpan! Stok bertambah.")
            }.onFailure {
                emitMessage(it.message ?: "Gagal mencatat transaksi pembelian", isError = true)
            }
        }
    }

    // --- Checkout ---
    fun checkout(
        paymentMethod: String,
        paidAmount: Long,
        customerName: String = "Pelanggan Umum",
        customerPhone: String = "",
        discount: Long = 0L,
        tax: Long = 0L,
        notes: String = "",
        dueDateDays: Int = 14,
        shouldPrint: Boolean = true
    ) {
        viewModelScope.launch {
            val member = _selectedMember.value
            val ptsToRedeem = _pointsToRedeem.value
            val pointDiscount = pointDiscountAmount.value
            val empName = _currentEmployee.value?.name?.ifBlank { null }
                ?: activeShift.value?.cashierName?.ifBlank { null }
                ?: "Kasir"

            val result = repository.checkout(
                cartItems = _cartItems.value,
                paymentMethod = paymentMethod,
                paidAmount = paidAmount,
                customerName = customerName,
                customerPhone = customerPhone,
                discount = discount,
                tax = tax,
                notes = notes,
                member = member,
                pointsRedeemed = ptsToRedeem,
                pointDiscount = pointDiscount,
                dueDateDays = dueDateDays,
                cashierName = empName
            )
            result.onSuccess { tx ->
                clearCart()
                clearSelectedMember()
                refreshLicenseInfo()
                if (shouldPrint) {
                    activeReceiptTransaction.value = tx
                    if (_printerSettings.value.autoPrintOnCheckout && _printerSettings.value.selectedDeviceAddress.isNotBlank()) {
                        printTransactionReceipt(tx)
                    }
                } else {
                    activeReceiptTransaction.value = null
                }
                _uiEvent.emit(UiEvent.TransactionSuccess(tx))
                syncManager.triggerImmediateSync(syncClientHostIp.value)
                val printInfo = if (shouldPrint) "" else " (Cetak struk dilewati)"
                emitMessage("Transaksi ${tx.receiptNumber} berhasil!$printInfo")
            }.onFailure { err ->
                emitMessage(err.message ?: "Transaksi gagal", isError = true)
            }
        }
    }

    fun voidTransaction(
        transaction: TransactionRecord,
        reason: String,
        authorizedByName: String = ""
    ) {
        viewModelScope.launch {
            val voidBy = authorizedByName.ifBlank { _currentEmployee.value?.name ?: "Kasir" }
            val res = repository.voidTransaction(transaction.id, reason, voidBy)
            res.onSuccess { voidedTx ->
                syncManager.triggerImmediateSync(syncClientHostIp.value)
                emitMessage("Transaksi ${voidedTx.receiptNumber} berhasil di-VOID! Stok produk telah dikembalikan.")
                if (_printerSettings.value.selectedDeviceAddress.isNotBlank()) {
                    printTransactionReceipt(voidedTx)
                }
            }.onFailure { err ->
                emitMessage(err.message ?: "Gagal membatalkan transaksi (VOID)", isError = true)
            }
        }
    }

    // --- Shift Actions ---
    fun startShift(
        shiftNumber: Int,
        shiftName: String,
        cashierName: String,
        openingCash: Long,
        notes: String = ""
    ) {
        val validation = com.example.util.ShiftScheduleHelper.validateShiftOpening(shiftNumber)
        if (validation.isFailure) {
            val errMsg = validation.exceptionOrNull()?.message ?: "Shift tidak sesuai jadwal waktu operasional."
            emitMessage(errMsg, isError = true)
            return
        }

        viewModelScope.launch {
            val res = repository.startNewShift(shiftNumber, shiftName, cashierName, openingCash, notes)
            res.onSuccess {
                emitMessage("Shift #$shiftNumber ($cashierName) berhasil dibuka!")
            }.onFailure {
                emitMessage(it.message ?: "Gagal membuka shift", isError = true)
            }
        }
    }

    fun closeShift(closingCash: Long, notes: String) {
        if (allPendingCarts.value.isNotEmpty()) {
            emitMessage("Tidak bisa tutup shift! Masih ada ${allPendingCarts.value.size} transaksi yang ditahan (Pending). Selesaikan atau batalkan terlebih dahulu.", isError = true)
            return
        }
        viewModelScope.launch {
            val res = repository.closeActiveShift(closingCash, notes)
            res.onSuccess { shift ->
                val diffText = when {
                    shift.difference > 0 -> "Lebih ${PosRepository.formatRupiah(shift.difference)}"
                    shift.difference < 0 -> "Kurang ${PosRepository.formatRupiah(-shift.difference)}"
                    else -> "Pas (Sesuai)"
                }
                emitMessage("Shift #${shift.shiftNumber} ditutup! Selisih kas: $diffText")
            }.onFailure {
                emitMessage(it.message ?: "Gagal menutup shift", isError = true)
            }
        }
    }

    // --- Product CRUD ---
    fun saveProduct(
        id: Long = 0,
        name: String,
        sku: String,
        category: String,
        sellPrice: Long,
        costPrice: Long,
        stock: Int,
        unit: String,
        repackUnitsJson: String = "",
        tieredPricesJson: String = ""
    ) {
        viewModelScope.launch {
            val product = Product(
                id = id,
                name = name.trim(),
                sku = sku.trim(),
                category = category.trim(),
                sellPrice = sellPrice,
                costPrice = costPrice,
                stock = stock,
                unit = if (unit.isNotBlank()) unit.trim() else "pcs",
                repackUnitsJson = repackUnitsJson,
                tieredPricesJson = tieredPricesJson,
                updatedAt = System.currentTimeMillis()
            )
            if (id == 0L) {
                repository.insertProduct(product)
                emitMessage("Produk \"${product.name}\" berhasil ditambahkan")
            } else {
                repository.updateProduct(product)
                emitMessage("Produk \"${product.name}\" berhasil diperbarui")
            }
        }
    }

    fun deleteProduct(product: Product) {
        viewModelScope.launch {
            repository.deleteProduct(product)
            emitMessage("Produk \"${product.name}\" dihapus")
        }
    }

    // --- Network Sync Actions ---
    fun toggleSyncServer() {
        if (syncServerState.value.isRunning) {
            syncManager.stopSyncServer()
            emitMessage("Server sinkronisasi dimatikan")
        } else {
            syncManager.startSyncServer(8888)
            emitMessage("Server sinkronisasi aktif di port 8888")
        }
    }

    fun testConnectionToHost(hostIp: String) {
        viewModelScope.launch {
            isSyncing.value = true
            syncStatusText.value = "Menghubungi host $hostIp:8888..."
            val result = syncManager.testServerConnection(hostIp, 8888)
            isSyncing.value = false
            result.onSuccess {
                syncStatusText.value = it
                emitMessage("Berhasil terhubung ke host!")
            }.onFailure {
                syncStatusText.value = "Gagal: ${it.message}"
                emitMessage(it.message ?: "Koneksi gagal", isError = true)
            }
        }
    }

    fun pullProductsFromHost(hostIp: String) {
        viewModelScope.launch {
            isSyncing.value = true
            syncStatusText.value = "Mengunduh katalog produk dari host..."
            val res = syncManager.pullProductsFromHost(hostIp, 8888)
            isSyncing.value = false
            res.onSuccess { count ->
                syncStatusText.value = "Berhasil mengunduh $count produk dari host!"
                emitMessage("Katalog tersinkron: $count produk diperbarui")
            }.onFailure {
                syncStatusText.value = "Gagal mengunduh katalog: ${it.message}"
                emitMessage(it.message ?: "Gagal mengunduh", isError = true)
            }
        }
    }

    fun pushTransactionsToHost(hostIp: String) {
        viewModelScope.launch {
            isSyncing.value = true
            syncStatusText.value = "Mengirim transaksi lokal ke host..."
            val res = syncManager.pushTransactionsToHost(hostIp, 8888)
            isSyncing.value = false
            res.onSuccess { count ->
                syncStatusText.value = "Berhasil mengirim $count transaksi ke host!"
                emitMessage("$count transaksi lokal berhasil disinkronkan ke host")
            }.onFailure {
                syncStatusText.value = "Gagal mengirim transaksi: ${it.message}"
                emitMessage(it.message ?: "Gagal mengirim", isError = true)
            }
        }
    }

    fun toggleAutoSync(hostIp: String) {
        val cleanIp = hostIp.trim()
        if (clientSyncState.value.isAutoSyncRunning) {
            syncManager.stopAutoSync()
            emitMessage("Auto-sync latar belakang dinonaktifkan")
        } else {
            if (cleanIp.isBlank()) {
                emitMessage("Harap masukkan IP Kasir Utama terlebih dahulu", isError = true)
                return
            }
            syncClientHostIp.value = cleanIp
            syncManager.startAutoSync(cleanIp, 8888)
            emitMessage("Auto-sync aktif! Transaksi & antrean pending tersinkron otomatis.")
        }
    }

    fun triggerSyncNow() {
        val targetIp = syncClientHostIp.value.trim().ifBlank { syncManager.getSavedHostIp().trim() }
        if (targetIp.isNotBlank()) {
            viewModelScope.launch {
                isSyncing.value = true
                val res = syncManager.doFullSync(targetIp, 8888)
                isSyncing.value = false
                res.onSuccess {
                    syncStatusText.value = it
                    emitMessage(it)
                }.onFailure {
                    syncStatusText.value = "Gagal: ${it.message}"
                    emitMessage("Sinkronisasi gagal: ${it.message}", isError = true)
                }
            }
        } else if (syncServerState.value.isRunning) {
            emitMessage("Server Kasir Utama aktif menerima koneksi dari perangkat lain.")
        } else {
            emitMessage("Masukkan IP Kasir Utama atau aktifkan Server Host.", isError = true)
        }
    }

    // --- License Actions ---
    fun activateLicenseKey(key: String) {
        val res = repository.activateLicense(key)
        res.onSuccess { msg ->
            refreshLicenseInfo()
            emitMessage(msg)
        }.onFailure { err ->
            emitMessage(err.message ?: "Aktivasi lisensi gagal", isError = true)
        }
    }

    fun generateLicenseKeyForClient(targetDeviceId: String, tier: String): String {
        return repository.generateLicenseKey(targetDeviceId, tier)
    }

    fun updateStoreProfile(name: String, address: String, phone: String, footer: String, logoUri: String? = null) {
        repository.updateStoreInfo(name, address, phone, footer, logoUri)
        refreshLicenseInfo()
        emitMessage("Informasi toko berhasil disimpan")
    }

    fun updateStoreLogo(logoUri: String) {
        repository.updateStoreLogo(logoUri)
        refreshLicenseInfo()
        emitMessage("Logo toko berhasil diperbarui")
    }

    fun updateQrisSettings(imageUri: String, merchantName: String, nmid: String) {
        repository.updateQrisSettings(imageUri, merchantName, nmid)
        refreshLicenseInfo()
        emitMessage("Pengaturan QRIS berhasil disimpan")
    }

    fun emitMessage(msg: String, isError: Boolean = false) {
        viewModelScope.launch {
            _uiEvent.emit(UiEvent.ShowMessage(msg, isError))
        }
    }

    // =========================================================================
    // FITUR BACKUP & RESTORE DATA
    // =========================================================================
    val lastBackupTimestamp = MutableStateFlow(licenseManager.getLastBackupTimestamp())
    val localBackups = MutableStateFlow<List<LocalBackupItem>>(emptyList())
    val isBackupRunning = MutableStateFlow(false)
    val isRestoreRunning = MutableStateFlow(false)

    fun loadLocalBackups() {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val list = BackupRestoreHelper.listLocalBackups(getApplication())
            localBackups.value = list
            lastBackupTimestamp.value = licenseManager.getLastBackupTimestamp()
        }
    }

    fun createQuickBackup(onComplete: (Result<File>) -> Unit = {}) {
        viewModelScope.launch {
            isBackupRunning.value = true
            val result = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                BackupRestoreHelper.createQuickBackup(getApplication(), database.posDao(), licenseManager)
            }
            isBackupRunning.value = false
            result.onSuccess { file ->
                lastBackupTimestamp.value = System.currentTimeMillis()
                loadLocalBackups()
                emitMessage("Cadangan berhasil dibuat: ${file.name}")
                onComplete(Result.success(file))
            }.onFailure { err ->
                emitMessage("Gagal mencadangkan data: ${err.message}", isError = true)
                onComplete(Result.failure(err))
            }
        }
    }

    fun getBackupJsonData(onComplete: (Result<Pair<String, BackupMetadata>>) -> Unit) {
        viewModelScope.launch {
            isBackupRunning.value = true
            try {
                val pair = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    BackupRestoreHelper.createBackupJsonString(database.posDao(), licenseManager)
                }
                isBackupRunning.value = false
                licenseManager.setLastBackupTimestamp(System.currentTimeMillis())
                lastBackupTimestamp.value = System.currentTimeMillis()
                loadLocalBackups()
                onComplete(Result.success(pair))
            } catch (e: Exception) {
                isBackupRunning.value = false
                emitMessage("Gagal mengekspor data cadangan: ${e.message}", isError = true)
                onComplete(Result.failure(e))
            }
        }
    }

    fun deleteLocalBackup(file: File) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val deleted = BackupRestoreHelper.deleteLocalBackup(file)
            if (deleted) {
                loadLocalBackups()
                emitMessage("File cadangan berhasil dihapus")
            } else {
                emitMessage("Gagal menghapus file cadangan", isError = true)
            }
        }
    }

    fun restoreBackupData(
        jsonString: String,
        mode: RestoreMode,
        onComplete: (RestoreResult) -> Unit
    ) {
        viewModelScope.launch {
            isRestoreRunning.value = true
            val res = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                BackupRestoreHelper.restoreFromJson(jsonString, mode, database.posDao(), licenseManager)
            }
            isRestoreRunning.value = false
            if (res.success) {
                refreshLicenseInfo()
                _pointSettings.value = repository.getPointSettings()
                loadLocalBackups()
                emitMessage(res.message)
            } else {
                emitMessage(res.message, isError = true)
            }
            onComplete(res)
        }
    }
}
