package com.example.ui.screens

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Employee
import com.example.data.model.PrinterSettings
import com.example.data.model.ShortcutRegistry
import com.example.data.repository.PosRepository
import com.example.ui.viewmodel.PosViewModel
import com.example.util.BackupRestoreHelper
import com.example.util.RestoreMode

@Composable
fun SettingsScreen(viewModel: PosViewModel) {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(0) }

    val tabs = listOf(
        "Profil Toko",
        "Pintasan F1-F12",
        "Printer Bluetooth",
        "Multi-Kasir Sync",
        "Cadangan Data",
        "Karyawan & PIN",
        "Lisensi POS"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        // Settings Header
        Surface(
            color = Color.White,
            modifier = Modifier.fillMaxWidth(),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Settings, contentDescription = null, tint = Color(0xFF059669))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Pengaturan Sistem POS",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                ScrollableTabRow(
                    selectedTabIndex = selectedTab,
                    edgePadding = 0.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = {
                                Text(
                                    title,
                                    fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 12.5.sp
                                )
                            }
                        )
                    }
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            when (selectedTab) {
                0 -> StoreProfileSection(viewModel)
                1 -> ShortcutF1F12Section(viewModel)
                2 -> BluetoothPrinterSection(viewModel)
                3 -> MultiCashierSyncSection(viewModel)
                4 -> BackupRestoreSection(viewModel)
                5 -> EmployeeManagementSection(viewModel)
                6 -> LicenseSection(viewModel)
            }
        }
    }
}

// -------------------------------------------------------------------------------------
// SECTION 1: PROFIL TOKO
// -------------------------------------------------------------------------------------
@Composable
private fun StoreProfileSection(viewModel: PosViewModel) {
    val licenseInfo by viewModel.licenseInfo.collectAsState()

    var storeName by remember(licenseInfo) { mutableStateOf(licenseInfo.storeName) }
    var storeAddress by remember(licenseInfo) { mutableStateOf(licenseInfo.storeAddress) }
    var storePhone by remember(licenseInfo) { mutableStateOf(licenseInfo.storePhone) }
    var receiptFooter by remember(licenseInfo) { mutableStateOf(licenseInfo.receiptFooter) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SettingsCardHeader(
            title = "Informasi Profil Usaha & Struk",
            description = "Nama, alamat, dan nomor kontak yang akan dicetak di bagian atas dan bawah struk belanja.",
            icon = Icons.Default.Store
        )

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = storeName,
                    onValueChange = { storeName = it },
                    label = { Text("Nama Toko / Usaha *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = storeAddress,
                    onValueChange = { storeAddress = it },
                    label = { Text("Alamat Lengkap Toko") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = storePhone,
                    onValueChange = { storePhone = it },
                    label = { Text("Nomor Telepon / WhatsApp") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = receiptFooter,
                    onValueChange = { receiptFooter = it },
                    label = { Text("Pesan Penutup Struk (Footer)") },
                    placeholder = { Text("Contoh: Terima kasih, barang yang dibeli tidak dapat ditukar.") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(6.dp))

                Button(
                    onClick = {
                        viewModel.updateStoreProfile(
                            name = storeName.trim(),
                            address = storeAddress.trim(),
                            phone = storePhone.trim(),
                            footer = receiptFooter.trim()
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Icon(imageVector = Icons.Default.Save, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Simpan Informasi Toko", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// -------------------------------------------------------------------------------------
// SECTION 2: CUSTOM SHORTCUT F1 - F12
// -------------------------------------------------------------------------------------
@Composable
private fun ShortcutF1F12Section(viewModel: PosViewModel) {
    val shortcuts by viewModel.shortcutMappings.collectAsState()
    var editingKey by remember { mutableStateOf<String?>(null) }

    // Dialog to pick action for key
    if (editingKey != null) {
        val key = editingKey!!
        val currentActionId = shortcuts[key] ?: "NONE"

        AlertDialog(
            onDismissRequest = { editingKey = null },
            title = {
                Text("Ubah Fungsi Tombol Pintasan $key", fontWeight = FontWeight.Bold)
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Pilih perintah kasir saat tombol $key ditekan:",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(4.dp))

                    ShortcutRegistry.AVAILABLE_ACTIONS.forEach { action ->
                        val isSelected = currentActionId == action.id
                        Surface(
                            color = if (isSelected) Color(0xFF059669).copy(alpha = 0.12f) else Color(0xFFF8FAFC),
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) Color(0xFF059669) else Color(0xFFE2E8F0)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.updateShortcutMapping(key, action.id)
                                    editingKey = null
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(action.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    Text(action.description, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                }
                                if (isSelected) {
                                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF059669))
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                OutlinedButton(onClick = { editingKey = null }) {
                    Text("Tutup")
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            SettingsCardHeader(
                title = "Konfigurasi Pintasan Keyboard F1 - F12",
                description = "Sesuaikan fungsi tombol fungsi pada keyboard fisik untuk mempercepat transaksi kasir.",
                icon = Icons.Default.Keyboard
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            OutlinedButton(
                onClick = { viewModel.resetShortcutMappings() },
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Reset ke Bawaan")
            }
        }

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    "F1", "F2", "F3", "F4", "F5", "F6",
                    "F7", "F8", "F9", "F10", "F11", "F12"
                ).forEach { key ->
                    val actionId = shortcuts[key] ?: "NONE"
                    val label = ShortcutRegistry.getActionLabel(actionId)

                    Surface(
                        color = Color(0xFFF8FAFC),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { editingKey = key }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    color = Color(0xFF0F172A),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = key,
                                        color = Color.White,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 13.sp,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = label,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = if (actionId != "NONE") Color(0xFF059669) else Color.Gray
                                    )
                                    Text(
                                        text = "Klik untuk mengubah fungsi pintasan",
                                        fontSize = 10.sp,
                                        color = Color.LightGray
                                    )
                                }
                            }

                            IconButton(onClick = { editingKey = key }) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Edit $key",
                                    tint = Color(0xFF0284C7),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------------------------
// SECTION 3: PRINTER BLUETOOTH THERMAL
// -------------------------------------------------------------------------------------
@SuppressLint("MissingPermission")
@Composable
private fun BluetoothPrinterSection(viewModel: PosViewModel) {
    val printerSettings by viewModel.printerSettings.collectAsState()
    val isPrinting by viewModel.isPrinting.collectAsState()
    var pairedDevices by remember { mutableStateOf<List<BluetoothDevice>>(emptyList()) }

    var paperSize by remember(printerSettings) { mutableStateOf(printerSettings.paperSize) }
    var autoCut by remember(printerSettings) { mutableStateOf(printerSettings.cutPaper) }
    var autoPrint by remember(printerSettings) { mutableStateOf(printerSettings.autoPrintOnCheckout) }
    var printHeader by remember(printerSettings) { mutableStateOf(printerSettings.printHeader) }
    var printFooter by remember(printerSettings) { mutableStateOf(printerSettings.printFooter) }
    var selectedDeviceAddress by remember(printerSettings) { mutableStateOf(printerSettings.selectedDeviceAddress) }
    var selectedDeviceName by remember(printerSettings) { mutableStateOf(printerSettings.selectedDeviceName) }

    remember {
        pairedDevices = viewModel.getPairedPrinters()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SettingsCardHeader(
            title = "Pengaturan Printer Kasir Bluetooth Thermal",
            description = "Pilih printer thermal bluetooth yang sudah terpasang, ukuran kertas (58mm / 80mm), dan opsi potong struk.",
            icon = Icons.Default.Print
        )

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Daftar Printer Bluetooth Terpasang:", fontWeight = FontWeight.Bold)
                    OutlinedButton(
                        onClick = { pairedDevices = viewModel.getPairedPrinters() },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Pindai Ulang")
                    }
                }

                if (pairedDevices.isEmpty()) {
                    Text(
                        text = "Belum ada printer Bluetooth yang di-pair di Pengaturan Android. Silakan sambungkan printer Anda di Pengaturan Bluetooth HP/Tablet terlebih dahulu.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Red
                    )
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        pairedDevices.forEach { device ->
                            val isSelected = selectedDeviceAddress == device.address
                            Surface(
                                color = if (isSelected) Color(0xFF059669).copy(alpha = 0.12f) else Color(0xFFF8FAFC),
                                shape = RoundedCornerShape(8.dp),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isSelected) Color(0xFF059669) else Color(0xFFCBD5E1)
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedDeviceAddress = device.address
                                        selectedDeviceName = device.name ?: "Thermal Printer"
                                    }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(device.name ?: "Unknown Device", fontWeight = FontWeight.Bold)
                                        Text(device.address, fontSize = 11.sp, color = Color.Gray)
                                    }
                                    if (isSelected) {
                                        Text("TERPILIH", fontWeight = FontWeight.Bold, color = Color(0xFF059669), fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                Divider(modifier = Modifier.padding(vertical = 4.dp))

                // Paper Size
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Ukuran Kertas Thermal:", fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("58mm", "80mm").forEach { size ->
                            val isSel = paperSize == size
                            Surface(
                                color = if (isSel) Color(0xFF059669) else Color(0xFFF1F5F9),
                                contentColor = if (isSel) Color.White else Color.DarkGray,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.clickable { paperSize = size }
                            ) {
                                Text(
                                    text = size,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }

                // Switches
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Cetak Struk Otomatis Selesai Bayar")
                    Switch(checked = autoPrint, onCheckedChange = { autoPrint = it })
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Kirim Perintah Auto-Cut Kertas")
                    Switch(checked = autoCut, onCheckedChange = { autoCut = it })
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val temp = printerSettings.copy(
                                selectedDeviceAddress = selectedDeviceAddress,
                                selectedDeviceName = selectedDeviceName,
                                paperSize = paperSize,
                                cutPaper = autoCut
                            )
                            viewModel.testPrint(temp)
                        },
                        modifier = Modifier.weight(1f).height(48.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Print, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Tes Cetak")
                    }

                    Button(
                        onClick = {
                            viewModel.updatePrinterSettings(
                                printerSettings.copy(
                                    selectedDeviceAddress = selectedDeviceAddress,
                                    selectedDeviceName = selectedDeviceName,
                                    paperSize = paperSize,
                                    cutPaper = autoCut,
                                    autoPrintOnCheckout = autoPrint,
                                    printHeader = printHeader,
                                    printFooter = printFooter
                                )
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                        modifier = Modifier.weight(1.2f).height(48.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Simpan Pengaturan Printer", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------------------------
// SECTION 4: SINKRONISASI JARINGAN LOKAL (MULTI-KASIR)
// -------------------------------------------------------------------------------------
@Composable
private fun MultiCashierSyncSection(viewModel: PosViewModel) {
    val serverState by viewModel.syncServerState.collectAsState()
    val clientState by viewModel.clientSyncState.collectAsState()
    val hostIpText by viewModel.syncClientHostIp.collectAsState()
    val syncStatusText by viewModel.syncStatusText.collectAsState()
    val isSyncing by viewModel.isSyncing.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SettingsCardHeader(
            title = "Sinkronisasi Multi-Kasir Jaringan Lokal (LAN / WiFi)",
            description = "Gunakan fitur ini untuk menghubungkan beberapa HP/Tablet kasir tanpa internet secara real-time.",
            icon = Icons.Default.Wifi
        )

        // Card Host Server
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("1. Mode Server (Kasir Utama / Master)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text("Aktifkan jika perangkat ini bertindak sebagai server pusat toko.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    }
                    Switch(
                        checked = serverState.isRunning,
                        onCheckedChange = { viewModel.toggleSyncServer() }
                    )
                }

                if (serverState.isRunning) {
                    Surface(
                        color = Color(0xFF059669).copy(alpha = 0.1f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("SERVER SEDANG BERJALAN!", fontWeight = FontWeight.Bold, color = Color(0xFF065F46))
                            Text("Alamat IP Host: http://${serverState.localIp}:${serverState.port}", fontWeight = FontWeight.ExtraBold, color = Color(0xFF059669), fontSize = 15.sp)
                            Text("Ketikkan alamat IP ini pada perangkat kasir klien untuk menyinkronkan data.", fontSize = 11.sp, color = Color.DarkGray)
                        }
                    }
                }
            }
        }

        // Card Client Sync
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("2. Mode Klien (Kasir Tambahan / Cabang)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text("Hubungkan perangkat ini ke IP Kasir Utama untuk sinkronisasi otomatis.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)

                OutlinedTextField(
                    value = hostIpText,
                    onValueChange = { viewModel.syncClientHostIp.value = it },
                    label = { Text("Alamat IP Kasir Utama") },
                    placeholder = { Text("Contoh: 192.168.1.100") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.testConnectionToHost(hostIpText) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Tes Koneksi")
                    }

                    Button(
                        onClick = { viewModel.toggleAutoSync(hostIpText) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (clientState.isAutoSyncRunning) Color(0xFFDC2626) else Color(0xFF059669)
                        ),
                        modifier = Modifier.weight(1.3f)
                    ) {
                        Text(if (clientState.isAutoSyncRunning) "Stop Auto-Sync" else "Mulai Auto-Sync")
                    }
                }

                if (syncStatusText.isNotBlank()) {
                    Text(syncStatusText, fontSize = 11.sp, color = Color(0xFF0284C7))
                }
            }
        }
    }
}

// -------------------------------------------------------------------------------------
// SECTION 5: CADANGAN & PEMULIHAN DATA (BACKUP & RESTORE)
// -------------------------------------------------------------------------------------
@Composable
private fun BackupRestoreSection(viewModel: PosViewModel) {
    val context = LocalContext.current
    val localBackups by viewModel.localBackups.collectAsState()
    val isBackupRunning by viewModel.isBackupRunning.collectAsState()
    val lastBackupTs by viewModel.lastBackupTimestamp.collectAsState()

    var showRestoreConfirmDialog by remember { mutableStateOf<com.example.util.LocalBackupItem?>(null) }

    if (showRestoreConfirmDialog != null) {
        val item = showRestoreConfirmDialog!!
        AlertDialog(
            onDismissRequest = { showRestoreConfirmDialog = null },
            title = { Text("Pulihkan Database?", fontWeight = FontWeight.Bold) },
            text = {
                Text("Apakah Anda yakin ingin memulihkan database dari cadangan '${item.fileName}'? Data saat ini akan digantikan.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        val json = item.file.bufferedReader().use { it.readText() }
                        viewModel.restoreBackupData(json, RestoreMode.REPLACE) {
                            showRestoreConfirmDialog = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669))
                ) {
                    Text("Pulihkan")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showRestoreConfirmDialog = null }) {
                    Text("Batal")
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SettingsCardHeader(
            title = "Cadangan Data & Pemulihan (Backup & Restore)",
            description = "Simpan seluruh data kasir (produk, stok, transaksi, karyawan, piutang) ke file cadangan JSON yang aman.",
            icon = Icons.Default.Save
        )

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Buat Cadangan Baru:", fontWeight = FontWeight.Bold)
                if (lastBackupTs > 0) {
                    Text("Terakhir dicadangkan: ${PosRepository.formatDate(lastBackupTs)}", fontSize = 11.sp, color = Color.Gray)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { viewModel.createQuickBackup() },
                        enabled = !isBackupRunning,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                        modifier = Modifier.weight(1f).height(48.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.CloudUpload, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (isBackupRunning) "Mencadangkan..." else "Cadangkan Sekarang")
                    }
                }

                Divider(modifier = Modifier.padding(vertical = 4.dp))

                Text("Daftar Cadangan Lokal di Perangkat (${localBackups.size}):", fontWeight = FontWeight.Bold)

                if (localBackups.isEmpty()) {
                    Text("Belum ada file cadangan yang dibuat.", fontSize = 12.sp, color = Color.Gray)
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        localBackups.forEach { item ->
                            Surface(
                                color = Color(0xFFF8FAFC),
                                shape = RoundedCornerShape(10.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(item.fileName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        Text("${item.formattedDate} | ${item.fileSizeFormatted}", fontSize = 11.sp, color = Color.Gray)
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        IconButton(onClick = {
                                            BackupRestoreHelper.shareBackupFile(context, item.file)
                                        }) {
                                            Icon(imageVector = Icons.Default.Share, contentDescription = "Bagikan", tint = Color(0xFF0284C7))
                                        }
                                        Button(
                                            onClick = { showRestoreConfirmDialog = item },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F172A)),
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Text("Pulihkan", fontSize = 11.sp)
                                        }
                                        IconButton(onClick = { viewModel.deleteLocalBackup(item.file) }) {
                                            Icon(imageVector = Icons.Default.Delete, contentDescription = "Hapus", tint = Color.Red)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------------------------
// SECTION 6: MANAJEMEN KARYAWAN & PIN
// -------------------------------------------------------------------------------------
@Composable
private fun EmployeeManagementSection(viewModel: PosViewModel) {
    val employees by viewModel.allEmployees.collectAsState()
    var showAddEmployeeDialog by remember { mutableStateOf(false) }

    if (showAddEmployeeDialog) {
        AddEmployeeDialog(
            onDismiss = { showAddEmployeeDialog = false },
            onSave = { name, user, pin, role ->
                viewModel.saveEmployee(
                    Employee(
                        name = name,
                        username = user,
                        pin = pin,
                        role = role,
                        canAccessCashier = true,
                        canVoid = (role != "KASIR"),
                        canCancelCart = (role != "KASIR"),
                        canOpenShift = true,
                        canViewReports = (role == "OWNER" || role == "SUPERVISOR")
                    )
                )
                showAddEmployeeDialog = false
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            SettingsCardHeader(
                title = "Manajemen Karyawan & Hak Akses",
                description = "Kelola pengguna kasir, supervisor, dan pemilik beserta PIN akses otorisasi.",
                icon = Icons.Default.People
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            Button(
                onClick = { showAddEmployeeDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(imageVector = Icons.Default.People, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Tambah Karyawan")
            }
        }

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                employees.forEach { emp ->
                    Surface(
                        color = Color(0xFFF8FAFC),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(emp.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                Text("Peran: ${emp.role} | PIN: ${emp.pin}", fontSize = 11.sp, color = Color.Gray)
                            }

                            if (emp.role != "OWNER") {
                                IconButton(onClick = { viewModel.deleteEmployee(emp) }) {
                                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Hapus", tint = Color.Red)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------------------------
// SECTION 7: LISENSI APLIKASI POS
// -------------------------------------------------------------------------------------
@Composable
private fun LicenseSection(viewModel: PosViewModel) {
    val licenseInfo by viewModel.licenseInfo.collectAsState()
    var licenseKeyInput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SettingsCardHeader(
            title = "Aktivasi & Status Lisensi POS",
            description = "Lihat status lisensi perangkat ini dan masukkan kunci aktivasi Pro / Unlimited.",
            icon = Icons.Default.Key
        )

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Device ID Perangkat Ini:", fontWeight = FontWeight.Bold)
                Surface(
                    color = Color(0xFFF1F5F9),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = licenseInfo.deviceId,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF0F172A),
                        modifier = Modifier.padding(12.dp)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Tingkat Lisensi:")
                    Text(licenseInfo.licenseTier, fontWeight = FontWeight.Bold, color = Color(0xFF059669))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Total Transaksi Tercatat:")
                    Text("${licenseInfo.transactionCount} Transaksi", fontWeight = FontWeight.Bold)
                }

                Divider(modifier = Modifier.padding(vertical = 6.dp))

                Text("Masukkan Kunci Lisensi Aktivasi:", fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = licenseKeyInput,
                    onValueChange = { licenseKeyInput = it.uppercase() },
                    placeholder = { Text("Contoh: PRO-XXXX-XXXX") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Button(
                    onClick = {
                        viewModel.activateLicenseKey(licenseKeyInput.trim())
                        licenseKeyInput = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Text("Aktivasi Lisensi Sekarang", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun SettingsCardHeader(
    title: String,
    description: String,
    icon: ImageVector
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(Color(0xFF059669).copy(alpha = 0.12f), RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = Color(0xFF059669), modifier = Modifier.size(22.dp))
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A)
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )
        }
    }
}

@Composable
private fun AddEmployeeDialog(
    onDismiss: () -> Unit,
    onSave: (name: String, username: String, pin: String, role: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var role by remember { mutableStateOf("KASIR") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah Karyawan Baru", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nama Lengkap") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("Username") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = pin,
                    onValueChange = { if (it.length <= 6) pin = it.filter { c -> c.isDigit() } },
                    label = { Text("PIN Otorisasi (4-6 Digit Angka)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Peran Jabatan:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("KASIR", "SUPERVISOR", "OWNER").forEach { r ->
                        val isSel = role == r
                        Surface(
                            color = if (isSel) Color(0xFF059669) else Color(0xFFF1F5F9),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.clickable { role = r }
                        ) {
                            Text(
                                text = r,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSel) Color.White else Color.DarkGray,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(name, username, pin, role) },
                enabled = name.isNotBlank() && pin.length >= 4,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669))
            ) {
                Text("Simpan")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}
