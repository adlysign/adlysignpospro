package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.Employee

@Composable
fun EmployeeManagementDialog(
    employees: List<Employee>,
    onDismiss: () -> Unit,
    onSaveEmployee: (Employee) -> Unit,
    onDeleteEmployee: (Employee) -> Unit
) {
    var editingEmployee by remember { mutableStateOf<Employee?>(null) }
    var isAddingNew by remember { mutableStateOf(false) }

    var formName by remember { mutableStateOf("") }
    var formUsername by remember { mutableStateOf("") }
    var formPin by remember { mutableStateOf("") }
    var formRole by remember { mutableStateOf("KASIR") }
    var formIsActive by remember { mutableStateOf(true) }

    // Granular permissions
    var formCanAccessCashier by remember { mutableStateOf(true) }
    var formCanOpenShift by remember { mutableStateOf(true) }
    var formCanVoid by remember { mutableStateOf(false) }
    var formCanCancelCart by remember { mutableStateOf(false) }
    var formCanDeletePendingCart by remember { mutableStateOf(false) }

    var formCanStockOpname by remember { mutableStateOf(false) }
    var formCanSupplierPurchase by remember { mutableStateOf(false) }
    var formCanManageReceivables by remember { mutableStateOf(false) }
    var formCanManagePrinter by remember { mutableStateOf(false) }

    var formCanAddMember by remember { mutableStateOf(false) }
    var formCanViewReports by remember { mutableStateOf(false) }
    var formCanAccessSettings by remember { mutableStateOf(false) }

    fun applyRoleDefaults(role: String) {
        formRole = role
        when (role) {
            "OWNER" -> {
                formCanAccessCashier = true
                formCanOpenShift = true
                formCanVoid = true
                formCanCancelCart = true
                formCanDeletePendingCart = true
                formCanStockOpname = true
                formCanSupplierPurchase = true
                formCanManageReceivables = true
                formCanManagePrinter = true
                formCanAddMember = true
                formCanViewReports = true
                formCanAccessSettings = true
            }
            "SUPERVISOR" -> {
                formCanAccessCashier = true
                formCanOpenShift = true
                formCanVoid = true
                formCanCancelCart = true
                formCanDeletePendingCart = true
                formCanStockOpname = true
                formCanSupplierPurchase = true
                formCanManageReceivables = true
                formCanManagePrinter = true
                formCanAddMember = true
                formCanViewReports = true
                formCanAccessSettings = false
            }
            "KASIR" -> {
                formCanAccessCashier = true
                formCanOpenShift = true
                formCanVoid = false
                formCanCancelCart = false
                formCanDeletePendingCart = false
                formCanStockOpname = false
                formCanSupplierPurchase = false
                formCanManageReceivables = false
                formCanManagePrinter = false
                formCanAddMember = false
                formCanViewReports = false
                formCanAccessSettings = false
            }
        }
    }

    fun openForm(emp: Employee?) {
        editingEmployee = emp
        if (emp != null) {
            formName = emp.name
            formUsername = emp.username
            formPin = emp.pin
            formRole = emp.role
            formIsActive = emp.isActive
            formCanAccessCashier = emp.canAccessCashier
            formCanOpenShift = emp.canOpenShift
            formCanVoid = emp.canVoid
            formCanCancelCart = emp.canCancelCart
            formCanDeletePendingCart = emp.canDeletePendingCart
            formCanStockOpname = emp.canStockOpname
            formCanSupplierPurchase = emp.canSupplierPurchase
            formCanManageReceivables = emp.canManageReceivables
            formCanManagePrinter = emp.canManagePrinter
            formCanAddMember = emp.canAddMember
            formCanViewReports = emp.canViewReports
            formCanAccessSettings = emp.canAccessSettings
        } else {
            formName = ""
            formUsername = ""
            formPin = "1111"
            formIsActive = true
            applyRoleDefaults("KASIR")
        }
        isAddingNew = true
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("employee_management_dialog")
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Header
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(Color(0xFFE0F2FE), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Badge,
                                contentDescription = null,
                                tint = Color(0xFF0284C7),
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Kelola Karyawan & Hak Akses",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color(0xFF0F172A)
                            )
                            Text(
                                text = "Atur wewenang void, pembatalan, dan menu per user",
                                fontSize = 11.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup", tint = Color(0xFF64748B))
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                if (!isAddingNew) {
                    // TABEL / LIST KARYAWAN
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Daftar Pengguna (${employees.size})",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF334155)
                        )
                        Button(
                            onClick = { openForm(null) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(34.dp).testTag("add_employee_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Tambah User", fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(340.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(employees, key = { it.id }) { emp ->
                            val roleColor = when (emp.role) {
                                "OWNER" -> Color(0xFFDC2626)
                                "SUPERVISOR" -> Color(0xFFD97706)
                                else -> Color(0xFF0284C7)
                            }

                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                                border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = emp.name,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp,
                                                color = Color(0xFF0F172A)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = roleColor.copy(alpha = 0.15f)
                                            ) {
                                                Text(
                                                    text = emp.role,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = roleColor,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "Username: ${emp.username} • PIN: ${emp.pin}",
                                            fontSize = 11.sp,
                                            color = Color(0xFF64748B)
                                        )

                                        // Permission summary badges
                                        Spacer(modifier = Modifier.height(4.dp))
                                        val perms = mutableListOf<String>()
                                        if (emp.canVoid) perms.add("Void Struk")
                                        if (emp.canCancelCart) perms.add("Batal")
                                        if (emp.canDeletePendingCart) perms.add("Hapus Pending")
                                        if (emp.canStockOpname) perms.add("Stok Opname")
                                        if (emp.canSupplierPurchase) perms.add("Pembelian")
                                        if (emp.canManageReceivables) perms.add("Piutang")
                                        if (emp.canManagePrinter) perms.add("Printer")
                                        if (emp.canAddMember) perms.add("Tambah Member")
                                        if (emp.canAccessSettings) perms.add("Pengaturan")

                                        Text(
                                            text = if (perms.isEmpty()) "Hak Akses: Kasir Standar (Terbatas)" else "Hak Akses: ${perms.joinToString(", ")}",
                                            fontSize = 10.sp,
                                            color = if (perms.isEmpty()) Color(0xFF94A3B8) else Color(0xFF0369A1),
                                            maxLines = 2
                                        )
                                    }

                                    Row {
                                        IconButton(onClick = { openForm(emp) }) {
                                            Icon(Icons.Default.Edit, contentDescription = "Edit", tint = Color(0xFF0284C7))
                                        }
                                        if (employees.size > 1 && emp.role != "OWNER") {
                                            IconButton(onClick = { onDeleteEmployee(emp) }) {
                                                Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = Color(0xFFDC2626))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // FORM TAMBAH / EDIT KARYAWAN DENGAN TOGGLE HAK AKSES LENGKAP
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f, fill = false),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            Text(
                                text = if (editingEmployee == null) "Tambah Pengguna Baru" else "Edit Hak Akses: ${editingEmployee?.name}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color(0xFF0F172A)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                        }

                        // Data Pengguna
                        item {
                            OutlinedTextField(
                                value = formName,
                                onValueChange = { formName = it },
                                label = { Text("Nama Lengkap") },
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth().testTag("employee_name_input")
                            )
                        }

                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = formUsername,
                                    onValueChange = { formUsername = it.lowercase().trim() },
                                    label = { Text("Username") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = formPin,
                                    onValueChange = { if (it.length <= 4) formPin = it.filter { c -> c.isDigit() } },
                                    label = { Text("PIN (4 Digit)") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f).testTag("employee_pin_input")
                                )
                            }
                        }

                        // Preset Role
                        item {
                            Text(
                                text = "Preset Peran (Klik untuk wewenang otomatis):",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF334155)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("KASIR", "SUPERVISOR", "OWNER").forEach { r ->
                                    val isSelected = formRole == r
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .background(
                                                if (isSelected) Color(0xFF0284C7) else Color(0xFFF1F5F9),
                                                RoundedCornerShape(8.dp)
                                            )
                                            .clickable { applyRoleDefaults(r) }
                                            .padding(vertical = 8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = r,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) Color.White else Color(0xFF334155)
                                        )
                                    }
                                }
                            }
                        }

                        // Status Akun Aktif
                        item {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Color(0xFFF8FAFC),
                                border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text("Status Akun Aktif", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    Switch(
                                        checked = formIsActive,
                                        onCheckedChange = { formIsActive = it },
                                        colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF0284C7))
                                    )
                                }
                            }
                        }

                        // SECTION 1: KASIR & OTORISASI KRITIS
                        item {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Hak Akses Kasir & Otorisasi Kritis:",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFDC2626)
                            )
                        }

                        item {
                            PermissionToggleCard(
                                icon = Icons.Default.ShoppingCart,
                                title = "Akses Layar Kasir",
                                subtitle = "Dapat menggunakan mode kasir & transaksi",
                                isChecked = formCanAccessCashier,
                                onCheckedChange = { formCanAccessCashier = it }
                            )
                        }

                        item {
                            PermissionToggleCard(
                                icon = Icons.Default.DeleteForever,
                                title = "Void Struk Terbayar [F5]",
                                subtitle = "Dapat membatalkan struk belanja yang sudah dibayar",
                                isChecked = formCanVoid,
                                onCheckedChange = { formCanVoid = it },
                                highlightWarning = true
                            )
                        }

                        item {
                            PermissionToggleCard(
                                icon = Icons.Default.Cancel,
                                title = "Batal Transaksi (Kosongkan Keranjang)",
                                subtitle = "Dapat membatalkan belanja yang sedang berlangsung",
                                isChecked = formCanCancelCart,
                                onCheckedChange = { formCanCancelCart = it },
                                highlightWarning = true
                            )
                        }

                        item {
                            PermissionToggleCard(
                                icon = Icons.Default.Delete,
                                title = "Hapus Antrean Pending",
                                subtitle = "Dapat menghapus nota belanja yang ditahan/pending",
                                isChecked = formCanDeletePendingCart,
                                onCheckedChange = { formCanDeletePendingCart = it },
                                highlightWarning = true
                            )
                        }

                        // SECTION 2: MENU OPERASIONAL TOKO
                        item {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Hak Akses Menu Operasional:",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFD97706)
                            )
                            Text(
                                text = "*Jika dinonaktifkan, menu tidak akan ditampilkan sama sekali di kasir",
                                fontSize = 10.sp,
                                color = Color(0xFF64748B)
                            )
                        }

                        item {
                            PermissionToggleCard(
                                icon = Icons.Default.Inventory,
                                title = "Menu Stok Opname [F6]",
                                subtitle = "Dapat mengakses dan melakukan penyesuaian stok opname",
                                isChecked = formCanStockOpname,
                                onCheckedChange = { formCanStockOpname = it }
                            )
                        }

                        item {
                            PermissionToggleCard(
                                icon = Icons.Default.LocalShipping,
                                title = "Menu Pembelian Barang (Supplier)",
                                subtitle = "Dapat mencatat pengadaan dan faktur beli masuk",
                                isChecked = formCanSupplierPurchase,
                                onCheckedChange = { formCanSupplierPurchase = it }
                            )
                        }

                        item {
                            PermissionToggleCard(
                                icon = Icons.Default.Receipt,
                                title = "Menu Buku Piutang Pelanggan",
                                subtitle = "Dapat membuka buku piutang dan menerima cicilan",
                                isChecked = formCanManageReceivables,
                                onCheckedChange = { formCanManageReceivables = it }
                            )
                        }

                        item {
                            PermissionToggleCard(
                                icon = Icons.Default.Print,
                                title = "Menu & Pengaturan Printer Struk",
                                subtitle = "Dapat mengganti printer Bluetooth dan format struk",
                                isChecked = formCanManagePrinter,
                                onCheckedChange = { formCanManagePrinter = it }
                            )
                        }

                        // SECTION 3: MASTER DATA & PENGATURAN
                        item {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Hak Akses Master Data & Sistem:",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0284C7)
                            )
                        }

                        item {
                            PermissionToggleCard(
                                icon = Icons.Default.PersonAdd,
                                title = "Tambah / Daftarkan Member Baru",
                                subtitle = "Dapat mendaftarkan member baru di menu member",
                                isChecked = formCanAddMember,
                                onCheckedChange = { formCanAddMember = it }
                            )
                        }

                        item {
                            PermissionToggleCard(
                                icon = Icons.Default.Security,
                                title = "Akses Menu Laporan & Rekap Omzet",
                                subtitle = "Dapat melihat laporan penjualan dan laba rugi",
                                isChecked = formCanViewReports,
                                onCheckedChange = { formCanViewReports = it }
                            )
                        }

                        item {
                            PermissionToggleCard(
                                icon = Icons.Default.Settings,
                                title = "Akses Menu Pengaturan Toko & Lisensi",
                                subtitle = "Dapat membuka tab Pengaturan (dikunci jika dimatikan)",
                                isChecked = formCanAccessSettings,
                                onCheckedChange = { formCanAccessSettings = it },
                                highlightWarning = true
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { isAddingNew = false },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f).height(44.dp)
                        ) {
                            Text("Batal")
                        }
                        Button(
                            onClick = {
                                if (formName.isNotBlank() && formPin.length == 4) {
                                    val emp = Employee(
                                        id = editingEmployee?.id ?: 0L,
                                        name = formName.trim(),
                                        username = formUsername.ifBlank { formName.lowercase().replace(" ", "") },
                                        pin = formPin,
                                        role = formRole,
                                        isActive = formIsActive,
                                        canAccessCashier = formCanAccessCashier,
                                        canOpenShift = formCanOpenShift,
                                        canVoidAndCancel = formCanVoid && formCanCancelCart,
                                        canVoid = formCanVoid,
                                        canCancelCart = formCanCancelCart,
                                        canDeletePendingCart = formCanDeletePendingCart,
                                        canStockOpname = formCanStockOpname,
                                        canSupplierPurchase = formCanSupplierPurchase,
                                        canManageReceivables = formCanManageReceivables,
                                        canManagePrinter = formCanManagePrinter,
                                        canAddMember = formCanAddMember,
                                        canViewReports = formCanViewReports,
                                        canAccessSettings = formCanAccessSettings
                                    )
                                    onSaveEmployee(emp)
                                    isAddingNew = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1.2f).height(44.dp).testTag("save_employee_button")
                        ) {
                            Text("Simpan Perubahan", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionToggleCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    highlightWarning: Boolean = false
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (isChecked && highlightWarning) Color(0xFFFEF2F2) else Color(0xFFF8FAFC),
        border = BorderStroke(
            1.dp,
            if (isChecked && highlightWarning) Color(0xFFFCA5A5) else Color(0xFFE2E8F0)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    icon,
                    contentDescription = null,
                    tint = if (isChecked) {
                        if (highlightWarning) Color(0xFFDC2626) else Color(0xFF0284C7)
                    } else Color(0xFF94A3B8),
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = title,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF0F172A)
                    )
                    Text(
                        text = subtitle,
                        fontSize = 10.sp,
                        color = Color(0xFF64748B)
                    )
                }
            }
            Switch(
                checked = isChecked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = if (highlightWarning) Color(0xFFDC2626) else Color(0xFF0284C7)
                )
            )
        }
    }
}
