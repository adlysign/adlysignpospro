package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.TransactionRecord
import com.example.data.repository.PosRepository
import org.json.JSONArray

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VoidTransactionDialog(
    transactions: List<TransactionRecord>,
    onVoidTransaction: (TransactionRecord, String) -> Unit,
    onPrintReceipt: (TransactionRecord) -> Unit,
    onDismiss: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedTx by remember { mutableStateOf<TransactionRecord?>(null) }
    var voidReason by remember { mutableStateOf("") }
    var isConfirmingVoid by remember { mutableStateOf(false) }

    val presetReasons = listOf(
        "Salah input kasir",
        "Pelanggan batal beli",
        "Retur barang",
        "Salah metode bayar",
        "Barang rusak / cacat"
    )

    val filteredTransactions = transactions.filter {
        searchQuery.isBlank() ||
                it.receiptNumber.contains(searchQuery, ignoreCase = true) ||
                it.customerName.contains(searchQuery, ignoreCase = true) ||
                it.cashierName.contains(searchQuery, ignoreCase = true)
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("void_transaction_dialog")
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Header
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (selectedTx != null) {
                            IconButton(
                                onClick = {
                                    selectedTx = null
                                    isConfirmingVoid = false
                                }
                            ) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Kembali")
                            }
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(Color(0xFFFEE2E2), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.DeleteForever,
                                    contentDescription = null,
                                    tint = Color(0xFFDC2626),
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                        }
                        Column {
                            Text(
                                text = if (selectedTx != null) "Detail Void Nota" else "Void Struk Terbayar [F5]",
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp,
                                color = Color(0xFF0F172A)
                            )
                            Text(
                                text = if (selectedTx != null)
                                    selectedTx!!.receiptNumber
                                else
                                    "Pilih struk transaksi yang telah dibayar untuk dibatalkan",
                                fontSize = 12.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup", tint = Color(0xFF64748B))
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                if (selectedTx == null) {
                    // Search Bar
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Cari no. struk, kasir, atau pelanggan...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF94A3B8)) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("void_search_input")
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Transactions List
                    if (filteredTransactions.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    Icons.Default.ReceiptLong,
                                    contentDescription = null,
                                    tint = Color(0xFFCBD5E1),
                                    modifier = Modifier.size(44.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    "Tidak ada transaksi yang cocok",
                                    color = Color(0xFF94A3B8),
                                    fontSize = 13.sp
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(320.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(filteredTransactions, key = { it.id }) { tx ->
                                val isVoided = tx.isVoid
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (isVoided) Color(0xFFF1F5F9) else Color(0xFFF8FAFC),
                                    border = BorderStroke(
                                        1.dp,
                                        if (isVoided) Color(0xFFCBD5E1) else Color(0xFFE2E8F0)
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            selectedTx = tx
                                            voidReason = ""
                                            isConfirmingVoid = false
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = tx.receiptNumber,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 13.sp,
                                                    color = if (isVoided) Color(0xFF64748B) else Color(0xFF0F172A)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                if (isVoided) {
                                                    Surface(
                                                        shape = RoundedCornerShape(4.dp),
                                                        color = Color(0xFFFEE2E2)
                                                    ) {
                                                        Text(
                                                            "VOID",
                                                            fontSize = 10.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color(0xFFDC2626),
                                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                } else {
                                                    Surface(
                                                        shape = RoundedCornerShape(4.dp),
                                                        color = Color(0xFFDCFCE7)
                                                    ) {
                                                        Text(
                                                            tx.paymentMethod,
                                                            fontSize = 10.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color(0xFF16A34A),
                                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = "${PosRepository.formatDate(tx.timestamp)} • Kasir: ${tx.cashierName}",
                                                fontSize = 11.sp,
                                                color = Color(0xFF64748B)
                                            )
                                            if (tx.customerName.isNotBlank() && tx.customerName != "Pelanggan Umum") {
                                                Text(
                                                    text = "Pelanggan: ${tx.customerName}",
                                                    fontSize = 11.sp,
                                                    color = Color(0xFF0284C7)
                                                )
                                            }
                                        }

                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(
                                                text = PosRepository.formatRupiah(tx.totalAmount),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp,
                                                color = if (isVoided) Color(0xFF94A3B8) else Color(0xFF0F172A)
                                            )
                                            Text(
                                                text = if (isVoided) "Dibatalkan" else "Klik untuk Void",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Medium,
                                                color = if (isVoided) Color(0xFFDC2626) else Color(0xFF0284C7)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // DETAIL TRANSAKSI TERPILIH
                    val tx = selectedTx!!
                    val isVoided = tx.isVoid

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f, fill = false),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            // Ringkasan Transaksi
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isVoided) Color(0xFFFEF2F2) else Color(0xFFF8FAFC)
                                ),
                                border = BorderStroke(1.dp, if (isVoided) Color(0xFFFCA5A5) else Color(0xFFE2E8F0)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = tx.receiptNumber,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = Color(0xFF0F172A)
                                        )
                                        Text(
                                            text = if (isVoided) "STATUS: SUDAH DIBATALKAN" else "STATUS: LUNAS",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = if (isVoided) Color(0xFFDC2626) else Color(0xFF16A34A)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Waktu: ${PosRepository.formatDate(tx.timestamp)} | Kasir: ${tx.cashierName} (Shift #${tx.shiftNumber})",
                                        fontSize = 11.sp,
                                        color = Color(0xFF64748B)
                                    )
                                    Text(
                                        text = "Metode Pembayaran: ${tx.paymentMethod} | Total: ${PosRepository.formatRupiah(tx.totalAmount)}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF0F172A)
                                    )

                                    if (isVoided) {
                                        Spacer(modifier = Modifier.height(6.dp))
                                        HorizontalDivider(color = Color(0xFFFCA5A5))
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = "Alasan Void: ${tx.voidReason}",
                                            fontSize = 12.sp,
                                            color = Color(0xFFB91C1C),
                                            fontWeight = FontWeight.Medium
                                        )
                                        Text(
                                            text = "Dibatalkan oleh: ${tx.voidBy} pada ${PosRepository.formatDate(tx.voidTimestamp)}",
                                            fontSize = 11.sp,
                                            color = Color(0xFF991B1B)
                                        )
                                    }
                                }
                            }
                        }

                        // Daftar Barang
                        item {
                            Text(
                                "Daftar Item / Produk Transaksi:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = Color(0xFF475569)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            val items = remember(tx.itemsJson) { parseItemsJson(tx.itemsJson) }
                            if (items.isNotEmpty()) {
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    for (item in items) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(Color(0xFFF1F5F9), RoundedCornerShape(6.dp))
                                                .padding(horizontal = 8.dp, vertical = 6.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(item.name, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                                Text(
                                                    "${item.qty} x ${PosRepository.formatRupiah(item.price)}",
                                                    fontSize = 11.sp,
                                                    color = Color(0xFF64748B)
                                                )
                                            }
                                            Text(
                                                PosRepository.formatRupiah(if (item.subtotal > 0) item.subtotal else item.price * item.qty),
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF0F172A)
                                            )
                                        }
                                    }
                                }
                            } else {
                                Text("Detail barang tidak dapat ditampilkan", fontSize = 11.sp, color = Color.Gray)
                            }
                        }

                        if (!isVoided) {
                            item {
                                Spacer(modifier = Modifier.height(4.dp))
                                Card(
                                    shape = RoundedCornerShape(10.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB)),
                                    border = BorderStroke(1.dp, Color(0xFFFDE68A))
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            Icons.Default.Warning,
                                            contentDescription = null,
                                            tint = Color(0xFFD97706),
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "Void akan mengembalikan seluruh stok barang di nota ini ke inventaris dan menyesuaikan omzet kasir.",
                                            fontSize = 11.sp,
                                            color = Color(0xFF92400E),
                                            lineHeight = 15.sp
                                        )
                                    }
                                }
                            }

                            item {
                                Text(
                                    "Pilih / Masukkan Alasan Void:",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = Color(0xFF334155)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    presetReasons.forEach { reason ->
                                        val isSelected = voidReason == reason
                                        FilterChip(
                                            selected = isSelected,
                                            onClick = { voidReason = reason },
                                            label = { Text(reason, fontSize = 11.sp) },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = Color(0xFFDC2626),
                                                selectedLabelColor = Color.White
                                            )
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                OutlinedTextField(
                                    value = voidReason,
                                    onValueChange = { voidReason = it },
                                    label = { Text("Alasan Pembatalan (Wajib Diisi)") },
                                    placeholder = { Text("Ketik alasan pembatalan struk...") },
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("void_reason_input")
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Action buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                selectedTx = null
                                isConfirmingVoid = false
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f).height(46.dp)
                        ) {
                            Text("Tutup", color = Color(0xFF64748B))
                        }

                        if (isVoided) {
                            // Can reprint void receipt
                            Button(
                                onClick = { onPrintReceipt(tx) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1.3f).height(46.dp)
                            ) {
                                Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Cetak Struk Void")
                            }
                        } else {
                            Button(
                                onClick = {
                                    onVoidTransaction(tx, voidReason.ifBlank { "Dibatalkan oleh kasir" })
                                    selectedTx = null
                                },
                                enabled = voidReason.isNotBlank(),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1.3f)
                                    .height(46.dp)
                                    .testTag("confirm_void_transaction_button")
                            ) {
                                Icon(Icons.Default.DeleteForever, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Konfirmasi Void", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
