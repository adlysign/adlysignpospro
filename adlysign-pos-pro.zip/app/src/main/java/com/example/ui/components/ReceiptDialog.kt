package com.example.ui.components

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.LicenseInfo
import com.example.data.model.TransactionRecord
import com.example.data.repository.PosRepository
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.SlateDark
import com.example.ui.theme.SlateMedium
import org.json.JSONArray

@Composable
fun ReceiptDialog(
    transaction: TransactionRecord,
    licenseInfo: LicenseInfo,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val items = parseItemsJson(transaction.itemsJson)

    // Build plain text receipt for sharing
    val shareableText = buildReceiptText(transaction, licenseInfo, items)

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header action
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Struk Pembayaran",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_receipt_button")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Simulated Thermal Receipt Paper
                Card(
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFBFBFA)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(8.dp))
                        .padding(2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Store Logo (if available)
                        if (licenseInfo.storeLogoUri.isNotBlank()) {
                            AsyncImage(
                                model = licenseInfo.storeLogoUri,
                                contentDescription = "Logo Toko",
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                        }

                        // Store Name & Info
                        Text(
                            text = licenseInfo.storeName.uppercase(),
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            fontFamily = FontFamily.Monospace,
                            textAlign = TextAlign.Center,
                            color = SlateDark
                        )
                        Text(
                            text = licenseInfo.storeAddress,
                            fontSize = 11.sp,
                            color = SlateMedium,
                            fontFamily = FontFamily.Monospace,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "Telp: ${licenseInfo.storePhone}",
                            fontSize = 11.sp,
                            color = SlateMedium,
                            fontFamily = FontFamily.Monospace
                        )

                        Text(
                            text = "================================",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = Color.Gray,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        // Meta details
                        ReceiptRow("No. Struk", transaction.receiptNumber)
                        ReceiptRow("Waktu", PosRepository.formatDate(transaction.timestamp))
                        ReceiptRow("Shift", "Shift ${transaction.shiftNumber}")
                        ReceiptRow("Kasir", transaction.cashierName)
                        ReceiptRow("Pelanggan", transaction.customerName)

                        Text(
                            text = "--------------------------------",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = Color.Gray,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        // Items list
                        for (item in items) {
                            Column(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                                Text(
                                    text = item.name,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    fontFamily = FontFamily.Monospace,
                                    color = SlateDark
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${item.qty} x ${PosRepository.formatRupiah(item.price)}",
                                        fontSize = 11.sp,
                                        color = SlateMedium,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = PosRepository.formatRupiah(item.subtotal),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        fontFamily = FontFamily.Monospace,
                                        color = SlateDark
                                    )
                                }
                            }
                        }

                        Text(
                            text = "--------------------------------",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = Color.Gray,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        // Calculations
                        ReceiptRow("Subtotal", PosRepository.formatRupiah(transaction.subtotal))
                        if (transaction.discount > 0) {
                            ReceiptRow("Diskon", "-${PosRepository.formatRupiah(transaction.discount)}")
                        }
                        if (transaction.tax > 0) {
                            ReceiptRow("Pajak (PPN)", PosRepository.formatRupiah(transaction.tax))
                        }

                        Text(
                            text = "================================",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = Color.Gray,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        // Total
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "TOTAL",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = SlateDark
                            )
                            Text(
                                text = PosRepository.formatRupiah(transaction.totalAmount),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = SlateDark
                            )
                        }

                        ReceiptRow("Metode Bayar", transaction.paymentMethod)
                        ReceiptRow("Bayar", PosRepository.formatRupiah(transaction.paidAmount))
                        ReceiptRow("Kembali", PosRepository.formatRupiah(transaction.changeAmount))

                        Text(
                            text = "================================",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = Color.Gray,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        // Footer Note
                        Text(
                            text = licenseInfo.receiptFooter,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center,
                            fontFamily = FontFamily.Monospace,
                            color = SlateMedium,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                        Text(
                            text = "Layanan Konsumen: ${licenseInfo.storePhone}",
                            fontSize = 10.sp,
                            textAlign = TextAlign.Center,
                            fontFamily = FontFamily.Monospace,
                            color = Color.Gray
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Actions: Share & Done
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val sendIntent = Intent().apply {
                                action = Intent.ACTION_SEND
                                putExtra(Intent.EXTRA_TEXT, shareableText)
                                type = "text/plain"
                            }
                            context.startActivity(Intent.createChooser(sendIntent, "Bagikan Struk"))
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("share_receipt_button")
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Bagikan")
                    }

                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("done_receipt_button")
                    ) {
                        Text("Selesai")
                    }
                }
            }
        }
    }
}

@Composable
private fun ReceiptRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 1.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = SlateMedium,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = value,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            fontFamily = FontFamily.Monospace,
            color = SlateDark
        )
    }
}

data class ParsedReceiptItem(
    val name: String,
    val qty: Int,
    val price: Long,
    val subtotal: Long
)

fun parseItemsJson(jsonStr: String): List<ParsedReceiptItem> {
    val list = mutableListOf<ParsedReceiptItem>()
    try {
        val array = JSONArray(jsonStr)
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            list.add(
                ParsedReceiptItem(
                    name = obj.optString("name", "Produk"),
                    qty = obj.optInt("quantity", obj.optInt("qty", 1)),
                    price = obj.optLong("price", 0L),
                    subtotal = obj.optLong("subtotal", 0L)
                )
            )
        }
    } catch (e: Exception) {
        // Fallback
    }
    return list
}

fun buildReceiptText(tx: TransactionRecord, license: LicenseInfo, items: List<ParsedReceiptItem>): String {
    val sb = StringBuilder()
    sb.appendLine("================================")
    sb.appendLine(license.storeName.uppercase())
    sb.appendLine(license.storeAddress)
    sb.appendLine("Telp: ${license.storePhone}")
    sb.appendLine("================================")
    sb.appendLine("No. Struk : ${tx.receiptNumber}")
    sb.appendLine("Waktu     : ${PosRepository.formatDate(tx.timestamp)}")
    sb.appendLine("Shift     : Shift ${tx.shiftNumber}")
    sb.appendLine("Kasir     : ${tx.cashierName}")
    sb.appendLine("Pelanggan : ${tx.customerName}")
    sb.appendLine("--------------------------------")
    for (it in items) {
        sb.appendLine(it.name)
        sb.appendLine("  ${it.qty} x ${PosRepository.formatRupiah(it.price)} = ${PosRepository.formatRupiah(it.subtotal)}")
    }
    sb.appendLine("--------------------------------")
    sb.appendLine("Subtotal  : ${PosRepository.formatRupiah(tx.subtotal)}")
    if (tx.discount > 0) sb.appendLine("Diskon    : -${PosRepository.formatRupiah(tx.discount)}")
    if (tx.tax > 0) sb.appendLine("PPN       : ${PosRepository.formatRupiah(tx.tax)}")
    sb.appendLine("================================")
    sb.appendLine("TOTAL     : ${PosRepository.formatRupiah(tx.totalAmount)}")
    sb.appendLine("Metode    : ${tx.paymentMethod}")
    sb.appendLine("Bayar     : ${PosRepository.formatRupiah(tx.paidAmount)}")
    sb.appendLine("Kembali   : ${PosRepository.formatRupiah(tx.changeAmount)}")
    sb.appendLine("================================")
    sb.appendLine(license.receiptFooter)
    return sb.toString()
}
