package com.example.ui.components

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.model.LicenseInfo
import com.example.data.model.PrinterSettings
import com.example.data.model.TransactionRecord
import com.example.data.repository.PosRepository
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.SlateDark
import com.example.ui.theme.SlateLight
import com.example.ui.theme.SlateMedium
import org.json.JSONArray

@Composable
fun ReceiptDialog(
    transaction: TransactionRecord,
    licenseInfo: LicenseInfo,
    printerSettings: PrinterSettings = PrinterSettings(),
    onDismiss: () -> Unit,
    onPrintBluetooth: (() -> Unit)? = null,
    onOpenPrinterSettings: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val items = parseItemsJson(transaction.itemsJson)

    // Build plain text receipt for sharing (respects settings)
    val shareableText = buildReceiptText(transaction, licenseInfo, items, printerSettings)

    // Typography customization based on printer settings
    val receiptFontFamily = when (printerSettings.fontFamilyType) {
        "SANS_SERIF" -> FontFamily.SansSerif
        "SERIF" -> FontFamily.Serif
        "DEFAULT" -> FontFamily.Default
        else -> FontFamily.Monospace
    }

    val fontScale = when (printerSettings.fontSizePreset) {
        "KECIL" -> 0.85f
        "BESAR" -> 1.18f
        else -> 1.0f
    }

    val baseFontSize = (12f * fontScale).sp
    val smallFontSize = (10.5f * fontScale).sp
    val titleFontSize = (16f * fontScale).sp
    val totalFontSize = (14.5f * fontScale).sp

    val bodyFontWeight = when (printerSettings.fontWeightPreset) {
        "MEDIUM" -> FontWeight.Medium
        "BOLD" -> FontWeight.Bold
        else -> FontWeight.Normal
    }

    val headerFontWeight = when (printerSettings.fontWeightPreset) {
        "BOLD" -> FontWeight.ExtraBold
        else -> FontWeight.Bold
    }

    val rowPadding = when (printerSettings.lineSpacingPreset) {
        "RAPAT" -> 1.dp
        "RENGGANG" -> 5.dp
        else -> 2.5.dp
    }

    val paperMaxWidth = if (printerSettings.paperSize == "80mm") 420.dp else 340.dp

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color.White,
            tonalElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 500.dp)
                .padding(vertical = 12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header action bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Struk Pembayaran",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = SlateDark
                            )
                            Text(
                                text = "Template: ${printerSettings.receiptTemplate} • ${printerSettings.paperSize}",
                                fontSize = 11.sp,
                                color = SlateMedium
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (onOpenPrinterSettings != null) {
                            IconButton(
                                onClick = onOpenPrinterSettings,
                                modifier = Modifier.testTag("open_printer_settings_from_receipt")
                            ) {
                                Icon(
                                    Icons.Default.Edit,
                                    contentDescription = "Ubah Format Struk",
                                    tint = SlateMedium,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.testTag("close_receipt_button")
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Tutup", tint = SlateDark)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Simulated Thermal Receipt Paper with selected template & font customizations
                Card(
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFBFBFA)),
                    modifier = Modifier
                        .widthIn(max = paperMaxWidth)
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(8.dp))
                        .padding(2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // 1. Logo Toko
                        if (printerSettings.printLogo && licenseInfo.storeLogoUri.isNotBlank()) {
                            AsyncImage(
                                model = licenseInfo.storeLogoUri,
                                contentDescription = "Logo Toko",
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                        }

                        // 2. Header Toko
                        if (printerSettings.printHeader) {
                            Text(
                                text = licenseInfo.storeName.uppercase(),
                                fontWeight = headerFontWeight,
                                fontSize = titleFontSize,
                                fontFamily = receiptFontFamily,
                                textAlign = TextAlign.Center,
                                color = SlateDark
                            )
                            if (licenseInfo.storeAddress.isNotBlank()) {
                                Text(
                                    text = licenseInfo.storeAddress,
                                    fontSize = smallFontSize,
                                    color = SlateMedium,
                                    fontFamily = receiptFontFamily,
                                    textAlign = TextAlign.Center
                                )
                            }
                            if (licenseInfo.storePhone.isNotBlank()) {
                                Text(
                                    text = "Telp: ${licenseInfo.storePhone}",
                                    fontSize = smallFontSize,
                                    color = SlateMedium,
                                    fontFamily = receiptFontFamily,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }

                        if (printerSettings.customHeader.isNotBlank()) {
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = printerSettings.customHeader,
                                fontSize = smallFontSize,
                                color = SlateDark,
                                fontFamily = receiptFontFamily,
                                textAlign = TextAlign.Center,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        // Divider based on template
                        ReceiptDivider(template = printerSettings.receiptTemplate, fontFamily = receiptFontFamily)

                        // 3. Metadata Transaksi: No. Struk, Waktu, Shift, Kasir, Pelanggan
                        ReceiptStyledRow(
                            label = "No. Struk",
                            value = transaction.receiptNumber,
                            fontFamily = receiptFontFamily,
                            fontSize = smallFontSize,
                            fontWeight = bodyFontWeight,
                            rowPadding = rowPadding
                        )
                        ReceiptStyledRow(
                            label = "Waktu",
                            value = PosRepository.formatDate(transaction.timestamp),
                            fontFamily = receiptFontFamily,
                            fontSize = smallFontSize,
                            fontWeight = bodyFontWeight,
                            rowPadding = rowPadding
                        )

                        // NAMA KASIR: Hanya tampil jika diaktifkan di PrinterSettings!
                        val resolvedCashier = transaction.cashierName.ifBlank { "Kasir" }
                        if (printerSettings.printCashier) {
                            ReceiptStyledRow(
                                label = "Kasir",
                                value = resolvedCashier,
                                fontFamily = receiptFontFamily,
                                fontSize = smallFontSize,
                                fontWeight = FontWeight.SemiBold,
                                rowPadding = rowPadding
                            )
                        }

                        // SHIFT: Hanya tampil jika diaktifkan
                        if (printerSettings.printShift) {
                            ReceiptStyledRow(
                                label = "Shift",
                                value = "Shift ${transaction.shiftNumber}",
                                fontFamily = receiptFontFamily,
                                fontSize = smallFontSize,
                                fontWeight = bodyFontWeight,
                                rowPadding = rowPadding
                            )
                        }

                        // PELANGGAN: Tampil jika diaktifkan dan bukan pelanggan umum kosong
                        if (printerSettings.printCustomer && transaction.customerName.isNotBlank() && transaction.customerName != "Pelanggan Umum") {
                            ReceiptStyledRow(
                                label = "Pelanggan",
                                value = transaction.customerName,
                                fontFamily = receiptFontFamily,
                                fontSize = smallFontSize,
                                fontWeight = bodyFontWeight,
                                rowPadding = rowPadding
                            )
                        }

                        ReceiptDivider(template = printerSettings.receiptTemplate, fontFamily = receiptFontFamily)

                        // 4. Daftar Item Transaksi
                        for (item in items) {
                            if (printerSettings.receiptTemplate == "KOMPAK") {
                                // Tampilan Kompak 1 Baris
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = rowPadding),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${item.qty}x ${item.name}",
                                        fontSize = baseFontSize,
                                        fontFamily = receiptFontFamily,
                                        fontWeight = bodyFontWeight,
                                        color = SlateDark,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        text = PosRepository.formatRupiah(item.subtotal),
                                        fontSize = baseFontSize,
                                        fontFamily = receiptFontFamily,
                                        fontWeight = FontWeight.SemiBold,
                                        color = SlateDark
                                    )
                                }
                            } else {
                                // Tampilan Standar / Modern / Rinci / Elegan (2 Baris)
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = rowPadding)
                                ) {
                                    Text(
                                        text = item.name,
                                        fontSize = baseFontSize,
                                        fontWeight = FontWeight.SemiBold,
                                        fontFamily = receiptFontFamily,
                                        color = SlateDark
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "  ${item.qty} x ${PosRepository.formatRupiah(item.price)}",
                                            fontSize = smallFontSize,
                                            color = SlateMedium,
                                            fontFamily = receiptFontFamily
                                        )
                                        Text(
                                            text = PosRepository.formatRupiah(item.subtotal),
                                            fontSize = baseFontSize,
                                            fontWeight = bodyFontWeight,
                                            fontFamily = receiptFontFamily,
                                            color = SlateDark
                                        )
                                    }
                                }
                            }
                        }

                        ReceiptDivider(template = printerSettings.receiptTemplate, fontFamily = receiptFontFamily)

                        // 5. Perhitungan: Subtotal, Diskon, Pajak
                        ReceiptStyledRow(
                            label = "Subtotal",
                            value = PosRepository.formatRupiah(transaction.subtotal),
                            fontFamily = receiptFontFamily,
                            fontSize = smallFontSize,
                            fontWeight = bodyFontWeight,
                            rowPadding = rowPadding
                        )
                        if (transaction.discount > 0) {
                            ReceiptStyledRow(
                                label = "Diskon",
                                value = "-${PosRepository.formatRupiah(transaction.discount)}",
                                fontFamily = receiptFontFamily,
                                fontSize = smallFontSize,
                                fontWeight = bodyFontWeight,
                                rowPadding = rowPadding
                            )
                        }
                        if (transaction.tax > 0) {
                            ReceiptStyledRow(
                                label = "Pajak (PPN)",
                                value = PosRepository.formatRupiah(transaction.tax),
                                fontFamily = receiptFontFamily,
                                fontSize = smallFontSize,
                                fontWeight = bodyFontWeight,
                                rowPadding = rowPadding
                            )
                        }

                        ReceiptDivider(template = printerSettings.receiptTemplate, isDouble = true, fontFamily = receiptFontFamily)

                        // 6. Total Akhir
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = rowPadding + 2.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "TOTAL",
                                fontSize = totalFontSize,
                                fontWeight = FontWeight.Bold,
                                fontFamily = receiptFontFamily,
                                color = SlateDark
                            )
                            Text(
                                text = PosRepository.formatRupiah(transaction.totalAmount),
                                fontSize = totalFontSize,
                                fontWeight = FontWeight.Bold,
                                fontFamily = receiptFontFamily,
                                color = SlateDark
                            )
                        }

                        ReceiptStyledRow(
                            label = "Metode Bayar",
                            value = transaction.paymentMethod,
                            fontFamily = receiptFontFamily,
                            fontSize = smallFontSize,
                            fontWeight = bodyFontWeight,
                            rowPadding = rowPadding
                        )
                        ReceiptStyledRow(
                            label = "Bayar",
                            value = PosRepository.formatRupiah(transaction.paidAmount),
                            fontFamily = receiptFontFamily,
                            fontSize = smallFontSize,
                            fontWeight = bodyFontWeight,
                            rowPadding = rowPadding
                        )
                        ReceiptStyledRow(
                            label = "Kembali",
                            value = PosRepository.formatRupiah(transaction.changeAmount),
                            fontFamily = receiptFontFamily,
                            fontSize = smallFontSize,
                            fontWeight = bodyFontWeight,
                            rowPadding = rowPadding
                        )

                        if (printerSettings.printNotes && transaction.notes.isNotBlank()) {
                            ReceiptDivider(template = printerSettings.receiptTemplate, fontFamily = receiptFontFamily)
                            Text(
                                text = "Catatan: ${transaction.notes}",
                                fontSize = smallFontSize,
                                color = SlateMedium,
                                fontFamily = receiptFontFamily,
                                textAlign = TextAlign.Start,
                                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                            )
                        }

                        ReceiptDivider(template = printerSettings.receiptTemplate, isDouble = true, fontFamily = receiptFontFamily)

                        // 7. Footer & Pesan Terima Kasih
                        if (printerSettings.printFooter) {
                            val footerText = printerSettings.customFooter.ifBlank { licenseInfo.receiptFooter }
                            if (footerText.isNotBlank()) {
                                Text(
                                    text = footerText,
                                    fontSize = smallFontSize,
                                    textAlign = TextAlign.Center,
                                    fontFamily = receiptFontFamily,
                                    color = SlateMedium,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                            if (licenseInfo.storePhone.isNotBlank()) {
                                Text(
                                    text = "Layanan Pelanggan: ${licenseInfo.storePhone}",
                                    fontSize = (9.5f * fontScale).sp,
                                    textAlign = TextAlign.Center,
                                    fontFamily = receiptFontFamily,
                                    color = Color.Gray
                                )
                            }
                        }

                        // 8. Visual Auto-Cut Indicator jika Auto-Cut Kertas aktif
                        if (printerSettings.cutPaper) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFFF1F5F9), RoundedCornerShape(4.dp))
                                    .padding(vertical = 4.dp, horizontal = 8.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentCut,
                                    contentDescription = "Auto Cut",
                                    tint = EmeraldPrimary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "- - - - - AUTO-CUT STRUK AKTIF - - - - -",
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0F766E)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Bottom Action Buttons: Cetak Bluetooth, Bagikan, Selesai
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (onPrintBluetooth != null) {
                        Button(
                            onClick = onPrintBluetooth,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("print_bluetooth_receipt_button")
                        ) {
                            Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Cetak ke Printer Bluetooth", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                val sendIntent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, shareableText)
                                    type = "text/plain"
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "Bagikan Struk"))
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("share_receipt_button")
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Bagikan")
                        }

                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("done_receipt_button")
                        ) {
                            Text("Selesai")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ReceiptStyledRow(
    label: String,
    value: String,
    fontFamily: FontFamily,
    fontSize: TextUnit,
    fontWeight: FontWeight,
    rowPadding: Dp
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = rowPadding),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = fontSize,
            color = SlateMedium,
            fontFamily = fontFamily
        )
        Text(
            text = value,
            fontSize = fontSize,
            fontWeight = fontWeight,
            fontFamily = fontFamily,
            color = SlateDark
        )
    }
}

@Composable
private fun ReceiptDivider(template: String, isDouble: Boolean = false, fontFamily: FontFamily) {
    when (template) {
        "MODERN" -> {
            HorizontalDivider(
                modifier = Modifier.padding(vertical = 5.dp),
                thickness = if (isDouble) 1.5.dp else 0.8.dp,
                color = Color(0xFFCBD5E1)
            )
        }
        "ELEGAN" -> {
            val symbol = if (isDouble) "✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦" else "― ― ― ― ― ― ― ― ― ― ― ― ― ― ― ―"
            Text(
                text = symbol,
                fontFamily = fontFamily,
                fontSize = 10.sp,
                color = Color(0xFF94A3B8),
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
            )
        }
        "KOMPAK" -> {
            Text(
                text = "--------------------------------",
                fontFamily = fontFamily,
                fontSize = 9.sp,
                color = Color(0xFFCBD5E1),
                modifier = Modifier.padding(vertical = 1.dp)
            )
        }
        else -> {
            // KLASIK / RINCI
            val pattern = if (isDouble) "================================" else "--------------------------------"
            Text(
                text = pattern,
                fontFamily = fontFamily,
                fontSize = 10.sp,
                color = Color(0xFF94A3B8),
                modifier = Modifier.padding(vertical = 3.dp)
            )
        }
    }
}

data class ParsedReceiptItem(
    val name: String,
    val qty: Int,
    val price: Long,
    val subtotal: Long
)

fun parseItemsJson(jsonStr: String): List<ParsedReceiptItem> {
    val list = mutableListOf<ParsedReceiptItem>()
    try {
        val array = JSONArray(jsonStr)
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            list.add(
                ParsedReceiptItem(
                    name = obj.optString("name", "Produk"),
                    qty = obj.optInt("quantity", obj.optInt("qty", 1)),
                    price = obj.optLong("price", 0L),
                    subtotal = obj.optLong("subtotal", 0L)
                )
            )
        }
    } catch (e: Exception) {
        // Fallback
    }
    return list
}

fun buildReceiptText(
    tx: TransactionRecord,
    license: LicenseInfo,
    items: List<ParsedReceiptItem>,
    settings: PrinterSettings = PrinterSettings()
): String {
    val sb = StringBuilder()
    val divider = "--------------------------------"
    val doubleDivider = "================================"

    sb.appendLine(doubleDivider)
    if (settings.printHeader) {
        sb.appendLine(license.storeName.uppercase())
        if (license.storeAddress.isNotBlank()) sb.appendLine(license.storeAddress)
        if (license.storePhone.isNotBlank()) sb.appendLine("Telp: ${license.storePhone}")
    }
    if (settings.customHeader.isNotBlank()) {
        sb.appendLine(settings.customHeader)
    }
    sb.appendLine(doubleDivider)

    sb.appendLine("No. Struk : ${tx.receiptNumber}")
    sb.appendLine("Waktu     : ${PosRepository.formatDate(tx.timestamp)}")

    val resolvedCashier = tx.cashierName.ifBlank { "Kasir" }
    if (settings.printCashier) {
        sb.appendLine("Kasir     : $resolvedCashier")
    }
    if (settings.printShift) {
        sb.appendLine("Shift     : Shift ${tx.shiftNumber}")
    }
    if (settings.printCustomer && tx.customerName.isNotBlank() && tx.customerName != "Pelanggan Umum") {
        sb.appendLine("Pelanggan : ${tx.customerName}")
    }

    sb.appendLine(divider)
    for (it in items) {
        sb.appendLine(it.name)
        sb.appendLine("  ${it.qty} x ${PosRepository.formatRupiah(it.price)} = ${PosRepository.formatRupiah(it.subtotal)}")
    }
    sb.appendLine(divider)

    sb.appendLine("Subtotal  : ${PosRepository.formatRupiah(tx.subtotal)}")
    if (tx.discount > 0) sb.appendLine("Diskon    : -${PosRepository.formatRupiah(tx.discount)}")
    if (tx.tax > 0) sb.appendLine("PPN       : ${PosRepository.formatRupiah(tx.tax)}")
    sb.appendLine(doubleDivider)

    sb.appendLine("TOTAL     : ${PosRepository.formatRupiah(tx.totalAmount)}")
    sb.appendLine("Metode    : ${tx.paymentMethod}")
    sb.appendLine("Bayar     : ${PosRepository.formatRupiah(tx.paidAmount)}")
    sb.appendLine("Kembali   : ${PosRepository.formatRupiah(tx.changeAmount)}")

    if (settings.printNotes && tx.notes.isNotBlank()) {
        sb.appendLine(divider)
        sb.appendLine("Catatan   : ${tx.notes}")
    }

    sb.appendLine(doubleDivider)
    if (settings.printFooter) {
        val footer = settings.customFooter.ifBlank { license.receiptFooter }
        if (footer.isNotBlank()) sb.appendLine(footer)
    }
    return sb.toString()
}
