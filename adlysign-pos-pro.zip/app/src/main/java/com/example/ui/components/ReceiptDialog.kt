package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.LicenseInfo
import com.example.data.model.TransactionRecord
import com.example.data.repository.PosRepository
import org.json.JSONArray

data class ReceiptItemDisplay(
    val name: String,
    val qty: Int,
    val price: Long,
    val unit: String,
    val subtotal: Long
)

@Composable
fun ReceiptDialog(
    transaction: TransactionRecord,
    licenseInfo: LicenseInfo = LicenseInfo(""),
    storeInfo: LicenseInfo = licenseInfo,
    isPrinting: Boolean = false,
    onPrint: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()
    val activeStore = if (licenseInfo.storeName.isNotBlank()) licenseInfo else storeInfo

    val parsedItems = remember(transaction.itemsJson) {
        val list = mutableListOf<ReceiptItemDisplay>()
        try {
            val jsonArray = JSONArray(transaction.itemsJson)
            for (i in 0 until jsonArray.length()) {
                val item = jsonArray.getJSONObject(i)
                val qty = item.optInt("quantity", item.optInt("qty", 1))
                val price = item.optLong("price", 0L)
                val subtotal = item.optLong("subtotal", qty * price)
                list.add(
                    ReceiptItemDisplay(
                        name = item.optString("name", "Item"),
                        qty = qty,
                        price = price,
                        unit = item.optString("unit", ""),
                        subtotal = subtotal
                    )
                )
            }
        } catch (_: Exception) {}
        list
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .padding(vertical = 24.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header success
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Color(0xFF059669),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (transaction.isVoid) "STRUK VOID" else "Transaksi Berhasil",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (transaction.isVoid) Color.Red else Color(0xFF059669)
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Tutup")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Thermal Paper Mockup
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false)
                        .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp)),
                    color = Color(0xFFFCFDFD),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(scrollState)
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Store Info
                        Text(
                            text = activeStore.storeName.uppercase(),
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            textAlign = TextAlign.Center,
                            fontFamily = FontFamily.Monospace
                        )
                        if (activeStore.storeAddress.isNotBlank()) {
                            Text(
                                text = activeStore.storeAddress,
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center,
                                color = Color.Gray,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        if (activeStore.storePhone.isNotBlank()) {
                            Text(
                                text = "Telp: ${activeStore.storePhone}",
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center,
                                color = Color.Gray,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Divider(modifier = Modifier.padding(vertical = 8.dp), thickness = 1.dp, color = Color.LightGray)

                        // Meta details
                        ReceiptLine("No. Struk", transaction.receiptNumber)
                        ReceiptLine("Tanggal", PosRepository.formatDate(transaction.timestamp))
                        ReceiptLine("Kasir", "${transaction.cashierName} (Shift ${transaction.shiftNumber})")
                        if (transaction.customerName.isNotBlank() && transaction.customerName != "Pelanggan Umum") {
                            ReceiptLine("Pelanggan", transaction.customerName)
                        }

                        Divider(modifier = Modifier.padding(vertical = 8.dp), thickness = 1.dp, color = Color.LightGray)

                        // Items
                        if (parsedItems.isEmpty()) {
                            Text(transaction.itemsJson, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        } else {
                            parsedItems.forEach { item ->
                                Column(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                                    Text(
                                        text = item.name,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        val unitStr = if (item.unit.isNotBlank() && item.unit != "Pcs") " ${item.unit}" else ""
                                        Text(
                                            text = "  ${item.qty}$unitStr x ${PosRepository.formatRupiah(item.price)}",
                                            fontSize = 11.sp,
                                            color = Color.DarkGray,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        Text(
                                            text = PosRepository.formatRupiah(item.subtotal),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }

                        Divider(modifier = Modifier.padding(vertical = 8.dp), thickness = 1.dp, color = Color.LightGray)

                        // Totals
                        ReceiptLine("Subtotal", PosRepository.formatRupiah(transaction.subtotal))
                        if (transaction.discount > 0) {
                            ReceiptLine("Diskon / Poin", "-${PosRepository.formatRupiah(transaction.discount)}")
                        }
                        if (transaction.tax > 0) {
                            ReceiptLine("PPN (Tax)", PosRepository.formatRupiah(transaction.tax))
                        }

                        Divider(modifier = Modifier.padding(vertical = 4.dp), thickness = 1.dp, color = Color.Black)
                        ReceiptLine(
                            label = "TOTAL",
                            value = PosRepository.formatRupiah(transaction.totalAmount),
                            isBold = true,
                            fontSize = 15.sp
                        )
                        Divider(modifier = Modifier.padding(vertical = 4.dp), thickness = 1.dp, color = Color.Black)

                        ReceiptLine("Metode Bayar", transaction.paymentMethod)
                        ReceiptLine("Bayar", PosRepository.formatRupiah(transaction.paidAmount))
                        if (transaction.changeAmount > 0) {
                            ReceiptLine("Kembalian", PosRepository.formatRupiah(transaction.changeAmount), isBold = true)
                        }

                        if (transaction.notes.isNotBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Catatan: ${transaction.notes}", fontSize = 10.sp, color = Color.Gray, fontFamily = FontFamily.Monospace)
                        }

                        if (transaction.isVoid) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "*** DIBATALKAN (VOID) ***",
                                color = Color.Red,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Alasan: ${transaction.voidReason}",
                                color = Color.Red,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = activeStore.receiptFooter.ifBlank { "Terima kasih atas kunjungan Anda!" },
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center,
                            fontFamily = FontFamily.Monospace,
                            color = Color.DarkGray
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Actions: Cetak Bluetooth, Bagikan Teks Struk, Selesai
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val shareText = buildReceiptShareText(transaction, activeStore)
                            val sendIntent = Intent().apply {
                                action = Intent.ACTION_SEND
                                putExtra(Intent.EXTRA_TEXT, shareText)
                                type = "text/plain"
                            }
                            context.startActivity(Intent.createChooser(sendIntent, "Bagikan Struk Belanja"))
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Bagikan", fontSize = 12.sp)
                    }

                    Button(
                        onClick = onPrint,
                        enabled = !isPrinting,
                        modifier = Modifier.weight(1.3f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F172A)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (isPrinting) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Mencetak...", fontSize = 12.sp)
                        } else {
                            Icon(imageVector = Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Cetak Struk", fontSize = 12.sp)
                        }
                    }

                    Button(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1.2f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Selesai", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun ReceiptLine(
    label: String,
    value: String,
    isBold: Boolean = false,
    fontSize: androidx.compose.ui.unit.TextUnit = 12.sp
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 1.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            fontSize = fontSize,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
            fontFamily = FontFamily.Monospace,
            color = Color.Black
        )
        Text(
            text = value,
            fontSize = fontSize,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
            fontFamily = FontFamily.Monospace,
            color = Color.Black
        )
    }
}

private fun buildReceiptShareText(transaction: TransactionRecord, storeInfo: LicenseInfo): String {
    return buildString {
        appendLine("================================")
        appendLine(storeInfo.storeName.uppercase())
        if (storeInfo.storeAddress.isNotBlank()) appendLine(storeInfo.storeAddress)
        if (storeInfo.storePhone.isNotBlank()) appendLine("Telp: ${storeInfo.storePhone}")
        appendLine("================================")
        appendLine("No. Struk : ${transaction.receiptNumber}")
        appendLine("Tanggal   : ${PosRepository.formatDate(transaction.timestamp)}")
        appendLine("Kasir     : ${transaction.cashierName}")
        if (transaction.customerName.isNotBlank() && transaction.customerName != "Pelanggan Umum") {
            appendLine("Pelanggan : ${transaction.customerName}")
        }
        appendLine("--------------------------------")
        try {
            val jsonArray = JSONArray(transaction.itemsJson)
            for (i in 0 until jsonArray.length()) {
                val item = jsonArray.getJSONObject(i)
                val name = item.optString("name", "Item")
                val qty = item.optInt("quantity", item.optInt("qty", 1))
                val price = item.optLong("price", 0L)
                val subtotal = item.optLong("subtotal", qty * price)
                appendLine(name)
                appendLine("  $qty x ${PosRepository.formatRupiah(price)} = ${PosRepository.formatRupiah(subtotal)}")
            }
        } catch (_: Exception) {}
        appendLine("--------------------------------")
        appendLine("SUBTOTAL  : ${PosRepository.formatRupiah(transaction.subtotal)}")
        if (transaction.discount > 0) appendLine("DISKON    : -${PosRepository.formatRupiah(transaction.discount)}")
        if (transaction.tax > 0) appendLine("PPN (TAX) : ${PosRepository.formatRupiah(transaction.tax)}")
        appendLine("TOTAL     : ${PosRepository.formatRupiah(transaction.totalAmount)}")
        appendLine("BAYAR (${transaction.paymentMethod}): ${PosRepository.formatRupiah(transaction.paidAmount)}")
        if (transaction.changeAmount > 0) appendLine("KEMBALIAN : ${PosRepository.formatRupiah(transaction.changeAmount)}")
        appendLine("================================")
        appendLine(storeInfo.receiptFooter.ifBlank { "Terima kasih atas kunjungan Anda!" })
    }
}
