package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.repository.PosRepository
import com.example.ui.theme.BlueShift2
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.SlateDark
import com.example.ui.theme.SlateLight
import com.example.ui.theme.SlateMedium
import com.example.ui.theme.SuccessGreen
import com.example.util.ComprehensiveReportData
import com.example.util.ReportExportHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class ExportDocFormat {
    PDF, WORD
}

@Composable
fun ExportReportDialog(
    format: ExportDocFormat,
    reportData: ComprehensiveReportData,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var isGenerating by remember { mutableStateOf(true) }
    var generatedFile by remember { mutableStateOf<File?>(null) }
    var savedToDownloadPath by remember { mutableStateOf<String?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val docTypeLabel = if (format == ExportDocFormat.PDF) "Dokumen PDF" else "Dokumen Microsoft Word (.doc)"
    val mimeType = if (format == ExportDocFormat.PDF) "application/pdf" else "application/msword"

    // Generate in background
    LaunchedEffect(format, reportData) {
        withContext(Dispatchers.IO) {
            try {
                val file = if (format == ExportDocFormat.PDF) {
                    ReportExportHelper.generatePdfDocument(context, reportData)
                } else {
                    ReportExportHelper.generateWordDocument(context, reportData)
                }
                generatedFile = file
                isGenerating = false
            } catch (e: Exception) {
                errorMessage = e.message ?: "Gagal membuat dokumen"
                isGenerating = false
            }
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = Color.White,
            tonalElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("export_report_dialog")
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(
                                    if (format == ExportDocFormat.PDF) Color(0xFFFEF2F2) else Color(0xFFEFF6FF),
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (format == ExportDocFormat.PDF) Icons.Default.PictureAsPdf else Icons.Default.Description,
                                contentDescription = null,
                                tint = if (format == ExportDocFormat.PDF) Color(0xFFDC2626) else Color(0xFF2563EB),
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Simpan $docTypeLabel",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = SlateDark
                            )
                            Text(
                                text = "Laporan Lengkap & Rekap Toko",
                                fontSize = 11.sp,
                                color = SlateLight
                            )
                        }
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup", tint = SlateMedium)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Metadata Card
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Periode Laporan:", fontSize = 11.sp, color = SlateLight)
                            Text(reportData.periodLabel, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SlateDark)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Total Omset:", fontSize = 11.sp, color = SlateLight)
                            Text(PosRepository.formatRupiah(reportData.totalOmset), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Estimasi Laba:", fontSize = 11.sp, color = SlateLight)
                            Text(PosRepository.formatRupiah(reportData.totalProfit), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SuccessGreen)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Checklist included
                Text(
                    text = "Isi Laporan yang Disertakan:",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = SlateDark
                )
                Spacer(modifier = Modifier.height(6.dp))

                val items = listOf(
                    "Ringkasan Finansial, HPP & Margin Laba",
                    "Barang Cepat Laku (Fast Moving) & Lambat Laku",
                    "Pencatatan Pembelian Supplier (Kulakan)",
                    "Pencatatan Retur Barang (Konsumen/Supplier)",
                    "Audit Stok Opname & Selisih Fisik",
                    "Transaksi Dibatalkan (VOID) & Otorisasi",
                    "Buku Piutang & Kasbon Pelanggan"
                )

                items.forEach { item ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(vertical = 2.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = item, fontSize = 10.5.sp, color = SlateMedium)
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))
                HorizontalDivider(color = Color(0xFFE2E8F0))
                Spacer(modifier = Modifier.height(16.dp))

                // Status & Actions
                if (isGenerating) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            color = EmeraldPrimary,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Menyusun dokumen $docTypeLabel...",
                            fontSize = 12.sp,
                            color = SlateMedium
                        )
                    }
                } else if (errorMessage != null) {
                    Text(
                        text = "Terjadi kesalahan: $errorMessage",
                        color = Color(0xFFDC2626),
                        fontSize = 12.sp
                    )
                } else {
                    val file = generatedFile
                    if (file != null) {
                        // 3 Action buttons
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            // Button 1: Open Document Directly
                            Button(
                                onClick = {
                                    ReportExportHelper.openDocument(context, file, mimeType)
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (format == ExportDocFormat.PDF) Color(0xFFDC2626) else Color(0xFF2563EB)
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(44.dp)
                                    .testTag("btn_open_exported_doc")
                            ) {
                                Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Buka Dokumen Sekarang",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }

                            // Button 2: Save to Downloads
                            OutlinedButton(
                                onClick = {
                                    val saved = ReportExportHelper.saveToDownloads(context, file, file.name)
                                    if (saved != null) {
                                        savedToDownloadPath = saved.absolutePath
                                    }
                                },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(44.dp)
                                    .testTag("btn_save_to_downloads")
                            ) {
                                Icon(Icons.Default.Download, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (savedToDownloadPath != null) "Tersimpan di Download ✓" else "Simpan ke Folder Download",
                                    fontWeight = FontWeight.SemiBold,
                                    color = EmeraldPrimary,
                                    fontSize = 13.sp
                                )
                            }

                            // Button 3: Share Document
                            OutlinedButton(
                                onClick = {
                                    ReportExportHelper.shareDocument(
                                        context,
                                        file,
                                        mimeType,
                                        "Laporan Lengkap ${reportData.storeInfo.storeName} (${reportData.periodLabel})"
                                    )
                                },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(44.dp)
                                    .testTag("btn_share_exported_doc")
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, tint = SlateDark, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Bagikan (WhatsApp / Email / Drive)",
                                    fontWeight = FontWeight.Normal,
                                    color = SlateDark,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
