package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.PosRepository
import com.example.ui.theme.BlueShift2
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.SlateDark
import com.example.ui.theme.SlateLight
import com.example.ui.theme.SlateMedium
import kotlin.math.max

data class ChartBarData(
    val label: String,       // e.g. "Sen", "14/09", "10:00"
    val fullDate: String,    // e.g. "Senin, 14 September 2026"
    val amount: Long,        // e.g. 1500000L
    val txCount: Int = 0     // e.g. 12
)

@Composable
fun SalesBarChart(
    title: String = "Grafik Tren Penjualan",
    subtitle: String = "Pergerakan omset dan volume transaksi",
    dataPoints: List<ChartBarData>,
    modifier: Modifier = Modifier
) {
    if (dataPoints.isEmpty()) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(16.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.ShowChart,
                    contentDescription = null,
                    tint = SlateLight,
                    modifier = Modifier.size(36.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Belum Ada Data Grafik",
                    fontWeight = FontWeight.Bold,
                    color = SlateDark,
                    fontSize = 14.sp
                )
                Text(
                    text = "Data grafik penjualan akan muncul setelah ada transaksi tercatat pada periode ini.",
                    color = SlateLight,
                    fontSize = 11.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        }
        return
    }

    var selectedIndex by remember(dataPoints) {
        mutableIntStateOf(if (dataPoints.isNotEmpty()) dataPoints.size - 1 else -1)
    }

    val maxAmount = remember(dataPoints) {
        val maxVal = dataPoints.maxOfOrNull { it.amount } ?: 0L
        if (maxVal <= 0L) 100000L else maxVal
    }

    val totalAmount = remember(dataPoints) { dataPoints.sumOf { it.amount } }
    val averageAmount = remember(dataPoints) {
        if (dataPoints.isNotEmpty()) totalAmount / dataPoints.size else 0L
    }

    val selectedPoint = dataPoints.getOrNull(selectedIndex) ?: dataPoints.lastOrNull()

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(16.dp))
            .testTag("sales_bar_chart_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .background(Color(0xFFECFDF5), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.TrendingUp,
                                contentDescription = null,
                                tint = EmeraldPrimary,
                                modifier = Modifier.size(15.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = SlateDark
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 11.sp,
                        color = SlateLight
                    )
                }

                // Average badge
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFFF1F5F9),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
                ) {
                    Text(
                        text = "Rata2: ${formatChartCurrency(averageAmount)}",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = SlateMedium,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Tooltip / Active Highlight Banner
            selectedPoint?.let { sp ->
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFF8FAFC),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = sp.fullDate,
                                fontSize = 11.sp,
                                color = SlateLight
                            )
                            Text(
                                text = PosRepository.formatRupiah(sp.amount),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = EmeraldPrimary
                            )
                        }

                        if (sp.txCount > 0) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = Color(0xFFE0F2FE)
                            ) {
                                Text(
                                    text = "${sp.txCount} Transaksi",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = BlueShift2,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Chart Canvas
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .pointerInput(dataPoints) {
                            detectTapGestures { offset ->
                                val count = dataPoints.size
                                if (count > 0) {
                                    val leftMargin = 40f
                                    val rightMargin = 12f
                                    val availableWidth = size.width - leftMargin - rightMargin
                                    val slotWidth = availableWidth / count
                                    val relativeX = offset.x - leftMargin
                                    if (relativeX in 0f..availableWidth) {
                                        val idx = (relativeX / slotWidth).toInt().coerceIn(0, count - 1)
                                        selectedIndex = idx
                                    }
                                }
                            }
                        }
                ) {
                    val canvasWidth = size.width
                    val canvasHeight = size.height

                    val leftPadding = 50f
                    val rightPadding = 12f
                    val topPadding = 16f
                    val bottomPadding = 32f

                    val chartWidth = canvasWidth - leftPadding - rightPadding
                    val chartHeight = canvasHeight - topPadding - bottomPadding

                    // 1. Draw Horizontal Grid Lines & Labels
                    val gridLines = 3
                    val stepValue = maxAmount / gridLines
                    val textPaint = android.graphics.Paint().apply {
                        textSize = 9.sp.toPx()
                        color = android.graphics.Color.parseColor("#94A3B8")
                        textAlign = android.graphics.Paint.Align.RIGHT
                    }

                    for (i in 0..gridLines) {
                        val y = topPadding + (chartHeight / gridLines) * (gridLines - i)
                        val value = stepValue * i

                        // Grid line
                        drawLine(
                            color = Color(0xFFF1F5F9),
                            start = Offset(leftPadding, y),
                            end = Offset(canvasWidth - rightPadding, y),
                            strokeWidth = 1f
                        )

                        // Y-axis label
                        drawContext.canvas.nativeCanvas.drawText(
                            formatChartCurrency(value),
                            leftPadding - 8f,
                            y + 4.sp.toPx(),
                            textPaint
                        )
                    }

                    // 2. Draw Average Dotted Line
                    if (averageAmount > 0 && maxAmount > 0) {
                        val avgRatio = (averageAmount.toFloat() / maxAmount.toFloat()).coerceIn(0f, 1f)
                        val avgY = topPadding + chartHeight * (1f - avgRatio)
                        drawLine(
                            color = Color(0xFF94A3B8),
                            start = Offset(leftPadding, avgY),
                            end = Offset(canvasWidth - rightPadding, avgY),
                            strokeWidth = 1.5f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 6f), 0f)
                        )
                    }

                    // 3. Draw Bars
                    val count = dataPoints.size
                    val slotWidth = chartWidth / count
                    val maxBarWidth = 28.dp.toPx()
                    val barWidth = (slotWidth * 0.65f).coerceAtMost(maxBarWidth)

                    val labelPaint = android.graphics.Paint().apply {
                        textSize = 9.sp.toPx()
                        color = android.graphics.Color.parseColor("#64748B")
                        textAlign = android.graphics.Paint.Align.CENTER
                    }

                    val activeLabelPaint = android.graphics.Paint().apply {
                        textSize = 9.5.sp.toPx()
                        color = android.graphics.Color.parseColor("#065F46")
                        textAlign = android.graphics.Paint.Align.CENTER
                        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
                    }

                    dataPoints.forEachIndexed { index, point ->
                        val centerX = leftPadding + (index * slotWidth) + (slotWidth / 2f)
                        val barLeft = centerX - (barWidth / 2f)

                        val ratio = if (maxAmount > 0) (point.amount.toFloat() / maxAmount.toFloat()).coerceIn(0.03f, 1f) else 0.03f
                        val barHeight = chartHeight * ratio
                        val barTop = topPadding + (chartHeight - barHeight)

                        val isSelected = index == selectedIndex

                        // Bar Gradient
                        val gradientBrush = if (isSelected) {
                            Brush.verticalGradient(
                                colors = listOf(Color(0xFF059669), Color(0xFF10B981))
                            )
                        } else {
                            Brush.verticalGradient(
                                colors = listOf(Color(0xFF34D399), Color(0xFFA7F3D0))
                            )
                        }

                        // Draw Bar
                        drawRoundRect(
                            brush = gradientBrush,
                            topLeft = Offset(barLeft, barTop),
                            size = Size(barWidth, barHeight),
                            cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                        )

                        // Outline if selected
                        if (isSelected) {
                            drawRoundRect(
                                color = Color(0xFF065F46),
                                topLeft = Offset(barLeft - 1.5f, barTop - 1.5f),
                                size = Size(barWidth + 3f, barHeight + 3f),
                                cornerRadius = CornerRadius(5.dp.toPx(), 5.dp.toPx()),
                                style = Stroke(width = 1.5.dp.toPx())
                            )
                        }

                        // X-axis label
                        val currentPaint = if (isSelected) activeLabelPaint else labelPaint
                        drawContext.canvas.nativeCanvas.drawText(
                            point.label,
                            centerX,
                            canvasHeight - 6f,
                            currentPaint
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Ketuk batang grafik untuk melihat rincian tanggal & omset",
                    fontSize = 10.sp,
                    color = SlateLight
                )
            }
        }
    }
}

private fun formatChartCurrency(amount: Long): String {
    return when {
        amount >= 1_000_000_000L -> "${amount / 1_000_000_000}M"
        amount >= 1_000_000L -> {
            val millions = amount / 1_000_000.0
            if (millions % 1.0 == 0.0) "${millions.toLong()}jt" else String.format(java.util.Locale.US, "%.1fjt", millions)
        }
        amount >= 1_000L -> "${amount / 1_000}rb"
        else -> "$amount"
    }
}
