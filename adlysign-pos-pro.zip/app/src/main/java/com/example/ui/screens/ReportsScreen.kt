package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TransactionRecord
import com.example.data.repository.PosRepository
import com.example.ui.components.ReceiptDialog
import com.example.ui.viewmodel.PosViewModel
import com.example.util.ReportExportHelper
import org.json.JSONArray

@Composable
fun ReportsScreen(viewModel: PosViewModel) {
    val context = LocalContext.current
    val allTransactions by viewModel.recentTransactions.collectAsState()
    val licenseInfo by viewModel.licenseInfo.collectAsState()
    val allProducts by viewModel.allProducts.collectAsState()

    var selectedTab by remember { mutableStateOf(0) } // 0: Ringkasan Penjualan, 1: Riwayat Transaksi, 2: Piutang Pelanggan
    var selectedTransactionForReceipt by remember { mutableStateOf<TransactionRecord?>(null) }

    // Summary calculations
    val totalRevenue = remember(allTransactions) {
        allTransactions.filter { it.status != "VOID" }.sumOf { it.totalAmount }
    }
    val totalProfit = remember(allTransactions) {
        allTransactions.filter { it.status != "VOID" }.sumOf { it.profit }
    }
    val totalTransactionsCount = remember(allTransactions) {
        allTransactions.count { it.status != "VOID" }
    }
    val totalReceivable = remember(allTransactions) {
        allTransactions.filter { it.paymentMethod == "PIUTANG" && it.status != "VOID" }.sumOf { it.totalAmount - it.paidAmount }
    }

    if (selectedTransactionForReceipt != null) {
        ReceiptDialog(
            transaction = selectedTransactionForReceipt!!,
            storeInfo = licenseInfo,
            onDismiss = { selectedTransactionForReceipt = null },
            onPrint = {
                viewModel.printReceipt(selectedTransactionForReceipt!!)
                selectedTransactionForReceipt = null
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        // Header
        Surface(
            color = Color.White,
            modifier = Modifier.fillMaxWidth(),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Laporan & Riwayat Penjualan",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A)
                        )
                        Text(
                            text = "Pantau omzet, laba kotor, dan riwayat transaksi kasir",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                    }

                    // Export Document Button
                    Button(
                        onClick = {
                            val file = ReportExportHelper.generateSalesReportDoc(
                                context = context,
                                storeInfo = licenseInfo,
                                transactions = allTransactions,
                                periodName = "Laporan Lengkap Keseluruhan"
                            )
                            ReportExportHelper.saveToDownloads(context, file, "Laporan_Penjualan_${System.currentTimeMillis()}.doc")
                            ReportExportHelper.openDocument(context, file, "application/msword")
                            Toast.makeText(context, "Dokumen laporan berhasil disimpan ke Unduhan!", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F172A)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Description, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Simpan Dokumen")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                ScrollableTabRow(
                    selectedTabIndex = selectedTab,
                    edgePadding = 0.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("Ringkasan & Metrik", fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Riwayat Transaksi (${allTransactions.size})", fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = { Text("Buku Piutang / Bon", fontWeight = FontWeight.Bold) }
                    )
                }
            }
        }

        Box(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            when (selectedTab) {
                0 -> {
                    // Ringkasan
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            SummaryCard(
                                title = "Total Omset Penjualan",
                                value = PosRepository.formatRupiah(totalRevenue),
                                icon = Icons.Default.MonetizationOn,
                                color = Color(0xFF059669),
                                modifier = Modifier.weight(1f)
                            )
                            SummaryCard(
                                title = "Total Laba Kotor (Profit)",
                                value = PosRepository.formatRupiah(totalProfit),
                                icon = Icons.Default.TrendingUp,
                                color = Color(0xFF0284C7),
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            SummaryCard(
                                title = "Jumlah Nota Transaksi",
                                value = "$totalTransactionsCount Transaksi",
                                icon = Icons.Default.Receipt,
                                color = Color(0xFF7C3AED),
                                modifier = Modifier.weight(1f)
                            )
                            SummaryCard(
                                title = "Sisa Piutang (Bon)",
                                value = PosRepository.formatRupiah(totalReceivable),
                                icon = Icons.Default.History,
                                color = Color(0xFFDC2626),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                1 -> {
                    // Riwayat Transaksi List
                    if (allTransactions.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("Belum ada transaksi tersimpan.", color = Color.Gray)
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(allTransactions) { trx ->
                                TransactionListItem(
                                    transaction = trx,
                                    onClick = { selectedTransactionForReceipt = trx }
                                )
                            }
                        }
                    }
                }

                2 -> {
                    // Piutang Tab
                    val creditTrx = allTransactions.filter { it.paymentMethod == "PIUTANG" }
                    if (creditTrx.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("Tidak ada piutang pelanggan tercatat.", color = Color.Gray)
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(creditTrx) { trx ->
                                val remaining = trx.totalAmount - trx.paidAmount
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedTransactionForReceipt = trx },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color.White),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(14.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(trx.customerName.ifBlank { "Pelanggan Tanpa Nama" }, fontWeight = FontWeight.Bold)
                                            Text("Faktur: ${trx.invoiceNumber} | ${PosRepository.formatDate(trx.date)}", fontSize = 11.sp, color = Color.Gray)
                                            if (trx.customerPhone.isNotBlank()) Text("HP: ${trx.customerPhone}", fontSize = 11.sp, color = Color.DarkGray)
                                        }

                                        Column(horizontalAlignment = Alignment.End) {
                                            Text("Sisa Hutang:", fontSize = 10.sp, color = Color.Red)
                                            Text(PosRepository.formatRupiah(remaining), fontWeight = FontWeight.ExtraBold, color = Color(0xFFDC2626))
                                            Text("Total: ${PosRepository.formatRupiah(trx.totalAmount)}", fontSize = 10.sp, color = Color.Gray)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SummaryCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(color.copy(alpha = 0.12f), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(title, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge, color = color)
        }
    }
}

@Composable
private fun TransactionListItem(
    transaction: TransactionRecord,
    onClick: () -> Unit
) {
    Surface(
        color = Color.White,
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(transaction.invoiceNumber, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        color = when (transaction.paymentMethod) {
                            "TUNAI" -> Color(0xFF059669).copy(alpha = 0.12f)
                            "CAMPURAN" -> Color(0xFF7C3AED).copy(alpha = 0.12f)
                            "QRIS" -> Color(0xFF0284C7).copy(alpha = 0.12f)
                            else -> Color(0xFFF1F5F9)
                        },
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = transaction.paymentMethod,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = when (transaction.paymentMethod) {
                                "TUNAI" -> Color(0xFF065F46)
                                "CAMPURAN" -> Color(0xFF5B21B6)
                                "QRIS" -> Color(0xFF0369A1)
                                else -> Color.DarkGray
                            },
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = "${PosRepository.formatDate(transaction.date)} | Kasir: ${transaction.cashierName} | Pelanggan: ${transaction.customerName}",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = PosRepository.formatRupiah(transaction.totalAmount),
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF059669),
                    style = MaterialTheme.typography.titleSmall
                )
                Text(
                    text = "Laba: +${PosRepository.formatRupiah(transaction.profit)}",
                    fontSize = 10.sp,
                    color = Color.DarkGray
                )
            }
        }
    }
}
