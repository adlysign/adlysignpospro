package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.TransactionRecord
import com.example.data.repository.PosRepository
import com.example.ui.components.ReceiptDialog
import com.example.ui.theme.AmberShift1
import com.example.ui.theme.BlueShift2
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.PurpleShift3
import com.example.ui.theme.SlateDark
import com.example.ui.theme.SlateLight
import com.example.ui.theme.SlateMedium
import com.example.ui.theme.SuccessGreen
import com.example.ui.viewmodel.PosViewModel

@Composable
fun ReportsScreen(viewModel: PosViewModel) {
    val transactions by viewModel.allTransactions.collectAsStateWithLifecycle()
    val licenseInfo by viewModel.licenseInfo.collectAsStateWithLifecycle()

    var selectedTransactionForReceipt by remember { mutableStateOf<TransactionRecord?>(null) }

    val totalRevenue = transactions.sumOf { it.totalAmount }
    val totalCost = transactions.sumOf { it.totalCost }
    val totalProfit = (totalRevenue - totalCost).coerceAtLeast(0L)
    val totalTxCount = transactions.size
    val averageBasket = if (totalTxCount > 0) totalRevenue / totalTxCount else 0L

    // Breakdown per shift
    val shift1Revenue = transactions.filter { it.shiftNumber == 1 }.sumOf { it.totalAmount }
    val shift2Revenue = transactions.filter { it.shiftNumber == 2 }.sumOf { it.totalAmount }
    val shift3Revenue = transactions.filter { it.shiftNumber == 3 }.sumOf { it.totalAmount }

    // Breakdown per payment
    val cashTotal = transactions.filter { it.paymentMethod == "TUNAI" }.sumOf { it.totalAmount }
    val qrisTotal = transactions.filter { it.paymentMethod == "QRIS" }.sumOf { it.totalAmount }
    val transferTotal = transactions.filter { it.paymentMethod == "TRANSFER" || it.paymentMethod == "DEBIT" }.sumOf { it.totalAmount }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Laporan Penjualan & Keuangan",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = SlateDark
            )
            Text(
                text = "Ringkasan omset, estimasi laba kotor/bersih, dan performa per shift.",
                style = MaterialTheme.typography.bodySmall,
                color = SlateLight
            )
        }

        // --- 4 Financial Metrics ---
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    KpiCard(
                        title = "Total Omset (Penjualan)",
                        value = PosRepository.formatRupiah(totalRevenue),
                        subtext = "Semua transaksi",
                        accentColor = EmeraldPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    KpiCard(
                        title = "Estimasi Laba Bersih",
                        value = PosRepository.formatRupiah(totalProfit),
                        subtext = "Omset - HPP",
                        accentColor = SuccessGreen,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    KpiCard(
                        title = "Total Transaksi",
                        value = "$totalTxCount",
                        subtext = "Struk tercetak",
                        accentColor = BlueShift2,
                        modifier = Modifier.weight(1f)
                    )
                    KpiCard(
                        title = "Rata-rata Transaksi",
                        value = PosRepository.formatRupiah(averageBasket),
                        subtext = "Nilai keranjang belanja",
                        accentColor = AmberShift1,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // --- Breakdown Penjualan Berdasarkan 3 Shift ---
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Kontribusi Omset per Shift",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = SlateDark
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    ShiftBreakdownBar("Shift 1 (Pagi)", shift1Revenue, totalRevenue, AmberShift1)
                    Spacer(modifier = Modifier.height(8.dp))
                    ShiftBreakdownBar("Shift 2 (Siang/Sore)", shift2Revenue, totalRevenue, BlueShift2)
                    Spacer(modifier = Modifier.height(8.dp))
                    ShiftBreakdownBar("Shift 3 (Malam)", shift3Revenue, totalRevenue, PurpleShift3)
                }
            }
        }

        // --- Breakdown Metode Pembayaran ---
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Metode Pembayaran",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = SlateDark
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        PaymentStatItem("Tunai", PosRepository.formatRupiah(cashTotal), Modifier.weight(1f))
                        PaymentStatItem("QRIS", PosRepository.formatRupiah(qrisTotal), Modifier.weight(1f))
                        PaymentStatItem("Transfer/Debit", PosRepository.formatRupiah(transferTotal), Modifier.weight(1f))
                    }
                }
            }
        }

        // --- Riwayat Transaksi ---
        item {
            Text(
                text = "Daftar Transaksi Terbaru",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = SlateDark
            )
            Text(
                text = "Klik transaksi untuk melihat atau mencetak ulang struk pembayaran.",
                fontSize = 11.sp,
                color = SlateLight
            )
        }

        if (transactions.isEmpty()) {
            item {
                Text(
                    text = "Belum ada transaksi tercatat.",
                    color = SlateLight,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            }
        } else {
            items(transactions, key = { it.id }) { tx ->
                TransactionRow(
                    tx = tx,
                    onClick = { selectedTransactionForReceipt = tx }
                )
            }
        }
    }

    selectedTransactionForReceipt?.let { tx ->
        ReceiptDialog(
            transaction = tx,
            licenseInfo = licenseInfo,
            onDismiss = { selectedTransactionForReceipt = null }
        )
    }
}

@Composable
private fun KpiCard(
    title: String,
    value: String,
    subtext: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier.border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(text = title, fontSize = 11.sp, color = SlateLight)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = accentColor
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = subtext, fontSize = 10.sp, color = SlateLight)
        }
    }
}

@Composable
private fun ShiftBreakdownBar(
    shiftName: String,
    amount: Long,
    total: Long,
    color: Color
) {
    val percentage = if (total > 0) (amount.toFloat() / total.toFloat()) else 0f
    val percentInt = (percentage * 100).toInt()

    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = shiftName, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Text(
                text = "${PosRepository.formatRupiah(amount)} ($percentInt%)",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .background(Color(0xFFF1F5F9), RoundedCornerShape(3.dp))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(fraction = percentage.coerceIn(0f, 1f))
                    .height(6.dp)
                    .background(color, RoundedCornerShape(3.dp))
            )
        }
    }
}

@Composable
private fun PaymentStatItem(name: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = name, fontSize = 11.sp, color = SlateLight)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SlateDark)
    }
}

@Composable
private fun TransactionRow(
    tx: TransactionRecord,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(10.dp))
            .testTag("tx_row_${tx.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = tx.receiptNumber,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = SlateDark
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "• Shift ${tx.shiftNumber}",
                        fontSize = 11.sp,
                        color = SlateLight
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${PosRepository.formatDate(tx.timestamp)} • ${tx.paymentMethod}",
                    fontSize = 11.sp,
                    color = SlateLight
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = PosRepository.formatRupiah(tx.totalAmount),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 14.sp,
                    color = EmeraldPrimary
                )
                Text(
                    text = "Lihat Struk >",
                    fontSize = 10.sp,
                    color = BlueShift2,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
