package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Product
import com.example.data.model.ProductReturnRecord
import com.example.data.model.PurchaseRecord
import com.example.data.model.ReceivableRecord
import com.example.data.model.StockOpnameRecord
import com.example.data.model.TransactionRecord
import com.example.data.repository.PosRepository
import com.example.ui.components.ChartBarData
import com.example.ui.components.ExportDocFormat
import com.example.ui.components.ExportReportDialog
import com.example.ui.components.ReceiptDialog
import com.example.ui.components.SalesBarChart
import com.example.ui.theme.AmberShift1
import com.example.ui.theme.BlueShift2
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.PurpleShift3
import com.example.ui.theme.SlateDark
import com.example.ui.theme.SlateLight
import com.example.ui.theme.SlateMedium
import com.example.ui.theme.SuccessGreen
import com.example.ui.viewmodel.PosViewModel
import com.example.util.ComprehensiveReportData
import com.example.util.ProductSalesMetric
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class ReportPeriod(val label: String) {
    TODAY("Hari Ini"),
    LAST_7_DAYS("7 Hari"),
    LAST_30_DAYS("30 Hari"),
    THIS_MONTH("Bulan Ini"),
    ALL_TIME("Semua Waktu")
}

@Composable
fun ReportsScreen(viewModel: PosViewModel) {
    val allTransactions by viewModel.allTransactions.collectAsStateWithLifecycle()
    val allProducts by viewModel.rawProducts.collectAsStateWithLifecycle()
    val allPurchases by viewModel.allPurchases.collectAsStateWithLifecycle()
    val allReturns by viewModel.allProductReturns.collectAsStateWithLifecycle()
    val allStockOpnames by viewModel.allStockOpname.collectAsStateWithLifecycle()
    val allReceivables by viewModel.allReceivables.collectAsStateWithLifecycle()
    val licenseInfo by viewModel.licenseInfo.collectAsStateWithLifecycle()
    val printerSettings by viewModel.printerSettings.collectAsStateWithLifecycle()

    var selectedPeriod by remember { mutableStateOf(ReportPeriod.LAST_7_DAYS) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedTxForReceipt by remember { mutableStateOf<TransactionRecord?>(null) }
    var exportDialogFormat by remember { mutableStateOf<ExportDocFormat?>(null) }

    // Calculate Start Timestamp for filter
    val periodStartTimestamp = remember(selectedPeriod) {
        val cal = Calendar.getInstance()
        when (selectedPeriod) {
            ReportPeriod.TODAY -> {
                cal.set(Calendar.HOUR_OF_DAY, 0)
                cal.set(Calendar.MINUTE, 0)
                cal.set(Calendar.SECOND, 0)
                cal.set(Calendar.MILLISECOND, 0)
                cal.timeInMillis
            }
            ReportPeriod.LAST_7_DAYS -> System.currentTimeMillis() - (7L * 24 * 60 * 60 * 1000)
            ReportPeriod.LAST_30_DAYS -> System.currentTimeMillis() - (30L * 24 * 60 * 60 * 1000)
            ReportPeriod.THIS_MONTH -> {
                cal.set(Calendar.DAY_OF_MONTH, 1)
                cal.set(Calendar.HOUR_OF_DAY, 0)
                cal.set(Calendar.MINUTE, 0)
                cal.set(Calendar.SECOND, 0)
                cal.set(Calendar.MILLISECOND, 0)
                cal.timeInMillis
            }
            ReportPeriod.ALL_TIME -> 0L
        }
    }

    // Filter datasets based on period
    val filteredTransactions = remember(allTransactions, periodStartTimestamp) {
        if (periodStartTimestamp == 0L) allTransactions
        else allTransactions.filter { it.timestamp >= periodStartTimestamp }
    }

    val successTransactions = remember(filteredTransactions) {
        filteredTransactions.filter { !it.isVoid }
    }

    val voidTransactions = remember(filteredTransactions) {
        filteredTransactions.filter { it.isVoid }
    }

    val filteredPurchases = remember(allPurchases, periodStartTimestamp) {
        if (periodStartTimestamp == 0L) allPurchases
        else allPurchases.filter { it.date >= periodStartTimestamp }
    }

    val filteredReturns = remember(allReturns, periodStartTimestamp) {
        if (periodStartTimestamp == 0L) allReturns
        else allReturns.filter { it.timestamp >= periodStartTimestamp }
    }

    val filteredStockOpnames = remember(allStockOpnames, periodStartTimestamp) {
        if (periodStartTimestamp == 0L) allStockOpnames
        else allStockOpnames.filter { it.date >= periodStartTimestamp }
    }

    val filteredReceivables = remember(allReceivables, periodStartTimestamp) {
        if (periodStartTimestamp == 0L) allReceivables
        else allReceivables.filter { it.createdAt >= periodStartTimestamp }
    }

    // --- Financial Summary Metrics ---
    val totalRevenue = remember(successTransactions) { successTransactions.sumOf { it.totalAmount } }
    val totalCost = remember(successTransactions) { successTransactions.sumOf { it.totalCost } }
    val totalProfit = remember(totalRevenue, totalCost) { (totalRevenue - totalCost).coerceAtLeast(0L) }
    val totalTxCount = successTransactions.size
    val averageBasket = remember(totalRevenue, totalTxCount) {
        if (totalTxCount > 0) totalRevenue / totalTxCount else 0L
    }

    // --- Product Sales Metrics (Fast Moving & Slow Moving) ---
    val productSalesMetrics = remember(successTransactions, allProducts) {
        val qtyMap = mutableMapOf<Long, Int>()
        val revMap = mutableMapOf<Long, Long>()
        val costMap = mutableMapOf<Long, Long>()

        for (tx in successTransactions) {
            try {
                val array = JSONArray(tx.itemsJson)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val prodId = obj.optLong("id", obj.optLong("productId", 0L))
                    val name = obj.optString("name", "")
                    val qty = obj.optInt("quantity", obj.optInt("qty", 1))
                    val subtotal = obj.optLong("subtotal", 0L)
                    val cost = obj.optLong("costPrice", 0L)

                    // Match product by id or name
                    val matched = allProducts.find { it.id == prodId } ?: allProducts.find { it.name.equals(name, ignoreCase = true) }
                    val key = matched?.id ?: prodId
                    if (key != 0L) {
                        qtyMap[key] = (qtyMap[key] ?: 0) + qty
                        revMap[key] = (revMap[key] ?: 0L) + subtotal
                        costMap[key] = (costMap[key] ?: 0L) + (cost * qty)
                    }
                }
            } catch (e: Exception) {
                // Ignore parse errors
            }
        }

        allProducts.map { prod ->
            val sold = qtyMap[prod.id] ?: 0
            val rev = revMap[prod.id] ?: 0L
            val cst = costMap[prod.id] ?: 0L
            val prof = (rev - cst).coerceAtLeast(0L)
            ProductSalesMetric(
                product = prod,
                totalSoldQty = sold,
                totalRevenue = rev,
                totalCost = cst,
                totalProfit = prof
            )
        }
    }

    val fastMovingProducts = remember(productSalesMetrics) {
        productSalesMetrics.filter { it.totalSoldQty > 0 }
            .sortedByDescending { it.totalSoldQty }
    }

    val slowMovingProducts = remember(productSalesMetrics) {
        // Sold <= 1 or 0 during period, but has inventory in stock
        productSalesMetrics.filter { it.product.stock > 0 }
            .sortedWith(compareBy<ProductSalesMetric> { it.totalSoldQty }.thenByDescending { it.product.stock * it.product.costPrice })
    }

    // --- Chart Data Calculation ---
    val chartDataPoints = remember(successTransactions, selectedPeriod) {
        buildChartDataPoints(successTransactions, selectedPeriod)
    }

    // Assembled Report Data for Export
    val comprehensiveData = remember(
        selectedPeriod,
        licenseInfo,
        filteredTransactions,
        fastMovingProducts,
        slowMovingProducts,
        filteredPurchases,
        filteredReturns,
        filteredStockOpnames,
        voidTransactions,
        filteredReceivables
    ) {
        ComprehensiveReportData(
            periodLabel = "${selectedPeriod.label} (${formatPeriodLabel(selectedPeriod)})",
            startDate = periodStartTimestamp,
            endDate = System.currentTimeMillis(),
            storeInfo = licenseInfo,
            transactions = filteredTransactions,
            fastMoving = fastMovingProducts,
            slowMoving = slowMovingProducts,
            purchases = filteredPurchases,
            returns = filteredReturns,
            stockOpnames = filteredStockOpnames,
            voidTransactions = voidTransactions,
            receivables = filteredReceivables
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        // --- Top Bar: Title & Document Export Buttons ---
        Surface(
            color = Color.White,
            tonalElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Laporan & Analisis Toko",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = SlateDark
                        )
                        Text(
                            text = "Grafik penjualan, perputaran produk, dan rekap dokumen.",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            color = SlateLight
                        )
                    }

                    // Export Buttons
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        // Word Export Button
                        OutlinedButton(
                            onClick = { exportDialogFormat = ExportDocFormat.WORD },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF2563EB)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .height(36.dp)
                                .testTag("btn_export_word")
                        ) {
                            Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Word (.doc)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        // PDF Export Button
                        Button(
                            onClick = { exportDialogFormat = ExportDocFormat.PDF },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .height(36.dp)
                                .testTag("btn_export_pdf")
                        ) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("PDF", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Period Filter Chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    ReportPeriod.values().forEach { period ->
                        val isSelected = selectedPeriod == period
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedPeriod = period },
                            label = {
                                Text(
                                    text = period.label,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EmeraldPrimary,
                                selectedLabelColor = Color.White,
                                containerColor = Color(0xFFF1F5F9),
                                labelColor = SlateDark
                            ),
                            shape = RoundedCornerShape(16.dp)
                        )
                    }
                }
            }
        }

        // --- Navigation Tabs ---
        val tabTitles = listOf(
            "Ringkasan & Grafik",
            "Cepat & Lambat Laku",
            "Pembelian Supplier",
            "Retur Barang",
            "Stok Opname",
            "Void / Batal",
            "Piutang Pelanggan",
            "Riwayat Struk"
        )

        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.White,
            contentColor = EmeraldPrimary,
            edgePadding = 16.dp,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = EmeraldPrimary,
                    height = 3.dp
                )
            }
        ) {
            tabTitles.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 12.sp,
                            color = if (selectedTab == index) EmeraldPrimary else SlateLight
                        )
                    }
                )
            }
        }

        // --- Main Tab Content ---
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            when (selectedTab) {
                0 -> SummaryAndChartsTab(
                    totalRevenue = totalRevenue,
                    totalProfit = totalProfit,
                    totalTxCount = totalTxCount,
                    averageBasket = averageBasket,
                    totalPurchases = filteredPurchases.sumOf { it.totalAmount },
                    totalReceivables = filteredReceivables.sumOf { it.remainingAmount },
                    totalVoidCount = voidTransactions.size,
                    totalReturnsCount = filteredReturns.size,
                    chartDataPoints = chartDataPoints,
                    transactions = successTransactions,
                    periodLabel = selectedPeriod.label
                )
                1 -> FastAndSlowMovingTab(
                    fastMoving = fastMovingProducts,
                    slowMoving = slowMovingProducts
                )
                2 -> PurchasesReportTab(
                    purchases = filteredPurchases
                )
                3 -> ReturnsReportTab(
                    returns = filteredReturns
                )
                4 -> StockOpnameReportTab(
                    opnames = filteredStockOpnames
                )
                5 -> VoidTransactionsReportTab(
                    voidTransactions = voidTransactions,
                    onViewReceipt = { selectedTxForReceipt = it }
                )
                6 -> ReceivablesReportTab(
                    receivables = filteredReceivables
                )
                7 -> TransactionHistoryTab(
                    transactions = filteredTransactions,
                    onViewReceipt = { selectedTxForReceipt = it }
                )
            }
        }
    }

    // Receipt Dialog Popup
    selectedTxForReceipt?.let { tx ->
        ReceiptDialog(
            transaction = tx,
            licenseInfo = licenseInfo,
            printerSettings = printerSettings,
            onDismiss = { selectedTxForReceipt = null },
            onPrintBluetooth = { viewModel.printTransactionReceipt(tx) }
        )
    }

    // Export Word / PDF Dialog
    exportDialogFormat?.let { fmt ->
        ExportReportDialog(
            format = fmt,
            reportData = comprehensiveData,
            onDismiss = { exportDialogFormat = null }
        )
    }
}

// =========================================================================
// TAB 0: RINGKASAN FINANSIAL & GRAFIK PENJUALAN PROFESIONAL
// =========================================================================
@Composable
private fun SummaryAndChartsTab(
    totalRevenue: Long,
    totalProfit: Long,
    totalTxCount: Int,
    averageBasket: Long,
    totalPurchases: Long,
    totalReceivables: Long,
    totalVoidCount: Int,
    totalReturnsCount: Int,
    chartDataPoints: List<ChartBarData>,
    transactions: List<TransactionRecord>,
    periodLabel: String
) {
    // Breakdown per shift
    val shift1Revenue = transactions.filter { it.shiftNumber == 1 }.sumOf { it.totalAmount }
    val shift2Revenue = transactions.filter { it.shiftNumber == 2 }.sumOf { it.totalAmount }
    val shift3Revenue = transactions.filter { it.shiftNumber == 3 }.sumOf { it.totalAmount }

    // Breakdown per payment
    val cashTotal = transactions.filter { it.paymentMethod == "TUNAI" }.sumOf { it.totalAmount }
    val qrisTotal = transactions.filter { it.paymentMethod == "QRIS" }.sumOf { it.totalAmount }
    val transferTotal = transactions.filter { it.paymentMethod == "TRANSFER" || it.paymentMethod == "DEBIT" }.sumOf { it.totalAmount }
    val piutangTotal = transactions.filter { it.paymentMethod == "PIUTANG" }.sumOf { it.totalAmount }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // --- 4 Primary Financial KPI Cards ---
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    KpiCard(
                        title = "Total Omset Penjualan",
                        value = PosRepository.formatRupiah(totalRevenue),
                        subtext = "Periode: $periodLabel",
                        accentColor = EmeraldPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    KpiCard(
                        title = "Estimasi Laba Bersih",
                        value = PosRepository.formatRupiah(totalProfit),
                        subtext = if (totalRevenue > 0) "Margin: ${(totalProfit * 100 / totalRevenue)}%" else "Margin: 0%",
                        accentColor = SuccessGreen,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    KpiCard(
                        title = "Total Transaksi",
                        value = "$totalTxCount Struk",
                        subtext = "Rata2: ${PosRepository.formatRupiah(averageBasket)}",
                        accentColor = BlueShift2,
                        modifier = Modifier.weight(1f)
                    )
                    KpiCard(
                        title = "Kulakan Supplier",
                        value = PosRepository.formatRupiah(totalPurchases),
                        subtext = "Belanja pasokan",
                        accentColor = AmberShift1,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    KpiCard(
                        title = "Piutang Pelanggan",
                        value = PosRepository.formatRupiah(totalReceivables),
                        subtext = "Kasbon berjalan",
                        accentColor = Color(0xFFD97706),
                        modifier = Modifier.weight(1f)
                    )
                    KpiCard(
                        title = "Void & Retur",
                        value = "$totalVoidCount Void / $totalReturnsCount Retur",
                        subtext = "Pembatalan & retur",
                        accentColor = Color(0xFFDC2626),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // --- Professional Sales Bar Chart ---
        item {
            SalesBarChart(
                title = "Grafik Tren Penjualan ($periodLabel)",
                subtitle = "Pergerakan omset dan intensitas transaksi",
                dataPoints = chartDataPoints
            )
        }

        // --- Breakdown Penjualan per Shift ---
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Kontribusi Omset per Shift Kerja",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = SlateDark
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    ShiftBreakdownBar("Shift 1 - Pagi (07:00 - 15:00)", shift1Revenue, totalRevenue, AmberShift1)
                    Spacer(modifier = Modifier.height(8.dp))
                    ShiftBreakdownBar("Shift 2 - Siang/Sore (15:00 - 23:00)", shift2Revenue, totalRevenue, BlueShift2)
                    Spacer(modifier = Modifier.height(8.dp))
                    ShiftBreakdownBar("Shift 3 - Malam (23:00 - 07:00)", shift3Revenue, totalRevenue, PurpleShift3)
                }
            }
        }

        // --- Breakdown Metode Pembayaran ---
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Arus Kas Berdasarkan Metode Pembayaran",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = SlateDark
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        PaymentStatItem("Tunai", PosRepository.formatRupiah(cashTotal), Modifier.weight(1f))
                        PaymentStatItem("QRIS", PosRepository.formatRupiah(qrisTotal), Modifier.weight(1f))
                        PaymentStatItem("Transfer/Debit", PosRepository.formatRupiah(transferTotal), Modifier.weight(1f))
                        PaymentStatItem("Piutang", PosRepository.formatRupiah(piutangTotal), Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

// =========================================================================
// TAB 1: BARANG CEPAT LAKU (FAST MOVING) & KURANG LAKU (SLOW MOVING)
// =========================================================================
@Composable
private fun FastAndSlowMovingTab(
    fastMoving: List<ProductSalesMetric>,
    slowMoving: List<ProductSalesMetric>
) {
    var analysisSubTab by remember { mutableIntStateOf(0) } // 0: Cepat Laku, 1: Kurang Laku

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { analysisSubTab = 0 },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (analysisSubTab == 0) EmeraldPrimary else Color(0xFFF1F5F9),
                    contentColor = if (analysisSubTab == 0) Color.White else SlateDark
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("⚡ Cepat Laku (${fastMoving.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = { analysisSubTab = 1 },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (analysisSubTab == 1) Color(0xFFD97706) else Color(0xFFF1F5F9),
                    contentColor = if (analysisSubTab == 1) Color.White else SlateDark
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.TrendingDown, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("❄ Kurang Laku (${slowMoving.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        if (analysisSubTab == 0) {
            // FAST MOVING LIST
            if (fastMoving.isEmpty()) {
                EmptyStateCard(
                    icon = Icons.Default.Speed,
                    title = "Belum Ada Data Penjualan",
                    message = "Produk cepat laku akan diranking berdasarkan volume penjualan terbanyak pada periode yang dipilih."
                )
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        Text(
                            text = "Daftar Barang Terlaris (Top Fast Moving)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = SlateDark
                        )
                        Text(
                            text = "Diurutkan dari jumlah produk paling sering dibeli konsumen.",
                            fontSize = 11.sp,
                            color = SlateLight
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                    }

                    items(fastMoving.take(20)) { metric ->
                        val index = fastMoving.indexOf(metric) + 1
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = if (index <= 3) Color(0xFFECFDF5) else Color(0xFFF1F5F9),
                                        modifier = Modifier.size(34.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = "#$index",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = if (index <= 3) EmeraldPrimary else SlateMedium
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = metric.product.name,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = SlateDark,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${metric.product.category} • SKU: ${metric.product.sku} • Sisa Stok: ${metric.product.stock}",
                                            fontSize = 10.5.sp,
                                            color = SlateLight
                                        )
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "${metric.totalSoldQty} ${metric.product.unit} Terjual",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 13.sp,
                                        color = EmeraldPrimary
                                    )
                                    Text(
                                        text = PosRepository.formatRupiah(metric.totalRevenue),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SlateDark
                                    )
                                    Text(
                                        text = "Laba: +${PosRepository.formatRupiah(metric.totalProfit)}",
                                        fontSize = 10.sp,
                                        color = SuccessGreen
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // SLOW MOVING LIST
            if (slowMoving.isEmpty()) {
                EmptyStateCard(
                    icon = Icons.Default.TrendingDown,
                    title = "Tidak Ada Barang Mengendap",
                    message = "Semua produk terjual dengan baik dan perputaran stok berjalan optimal."
                )
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        Text(
                            text = "Barang Kurang Laku (Slow Moving / Dead Stock)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = SlateDark
                        )
                        Text(
                            text = "Produk dengan penjualan minim/nihil namun memiliki stok fisik menumpuk di toko.",
                            fontSize = 11.sp,
                            color = SlateLight
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                    }

                    items(slowMoving.take(20)) { metric ->
                        val parkedAsset = metric.product.stock * metric.product.costPrice
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = metric.product.name,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = SlateDark
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = Color(0xFFFFFBEB)
                                        ) {
                                            Text(
                                                text = "SLOW MOVING",
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFFD97706),
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "${metric.product.category} • Terjual: ${metric.totalSoldQty} • Stok Fisik: ${metric.product.stock} ${metric.product.unit}",
                                        fontSize = 11.sp,
                                        color = SlateLight
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "💡 Rekomendasi: Diskon cuci gudang / bundling promosi",
                                        fontSize = 10.sp,
                                        color = Color(0xFF2563EB)
                                    )
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "Aset Terparkir:",
                                        fontSize = 9.5.sp,
                                        color = SlateLight
                                    )
                                    Text(
                                        text = PosRepository.formatRupiah(parkedAsset),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = Color(0xFFD97706)
                                    )
                                    Text(
                                        text = "@ ${PosRepository.formatRupiah(metric.product.costPrice)}/HPP",
                                        fontSize = 10.sp,
                                        color = SlateLight
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// =========================================================================
// TAB 2: LAPORAN PEMBELIAN SUPPLIER (KULAKAN)
// =========================================================================
@Composable
private fun PurchasesReportTab(purchases: List<PurchaseRecord>) {
    val totalPurchases = purchases.sumOf { it.totalAmount }

    if (purchases.isEmpty()) {
        EmptyStateCard(
            icon = Icons.Default.LocalShipping,
            title = "Belum Ada Catatan Pembelian Supplier",
            message = "Catatan kulakan barang dari supplier yang dimasukkan di menu Produk akan tampil di sini secara otomatis."
        )
    } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Total Pengadaan / Kulakan", fontSize = 11.sp, color = SlateMedium)
                            Text(
                                text = PosRepository.formatRupiah(totalPurchases),
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp,
                                color = Color(0xFF2563EB)
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = Color.White
                        ) {
                            Text(
                                text = "${purchases.size} Faktur",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = Color(0xFF2563EB),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            items(purchases) { p ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = p.invoiceNumber,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = SlateDark
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = if (p.paymentType == "TUNAI") Color(0xFFECFDF5) else Color(0xFFFFFBEB)
                                ) {
                                    Text(
                                        text = p.paymentType,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (p.paymentType == "TUNAI") EmeraldPrimary else Color(0xFFD97706),
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = PosRepository.formatRupiah(p.totalAmount),
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 14.sp,
                                color = Color(0xFF2563EB)
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Supplier: ${p.supplierName} ${if (p.supplierPhone.isNotBlank()) "(${p.supplierPhone})" else ""}",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Medium,
                            color = SlateDark
                        )
                        Text(
                            text = "Tanggal: ${PosRepository.formatDate(p.date)} • Penerima: ${p.receivedBy}",
                            fontSize = 10.5.sp,
                            color = SlateLight
                        )
                        if (p.notes.isNotBlank()) {
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Catatan: ${p.notes}",
                                fontSize = 10.5.sp,
                                color = SlateMedium
                            )
                        }
                    }
                }
            }
        }
    }
}

// =========================================================================
// TAB 3: LAPORAN RETUR BARANG
// =========================================================================
@Composable
private fun ReturnsReportTab(returns: List<ProductReturnRecord>) {
    if (returns.isEmpty()) {
        EmptyStateCard(
            icon = Icons.Default.Restore,
            title = "Tidak Ada Catatan Retur Barang",
            message = "Pengembalian barang dari konsumen atau retur barang rusak ke supplier yang diproses akan tersimpan di sini."
        )
    } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Riwayat Retur Barang (${returns.size} Kasus)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = SlateDark
                    )
                }
            }

            items(returns) { r ->
                val isCustomerReturn = r.returnType == "MASUK_STOK"
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = r.productName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = SlateDark
                            )
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (isCustomerReturn) Color(0xFFECFDF5) else Color(0xFFFEF2F2)
                            ) {
                                Text(
                                    text = if (isCustomerReturn) "+ Retur Pelanggan" else "- Retur Rusak/Supplier",
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isCustomerReturn) EmeraldPrimary else Color(0xFFDC2626),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Kuantitas: ${r.qty} item • Alasan: ${r.reason}",
                                fontSize = 11.sp,
                                color = SlateDark
                            )
                        }

                        Text(
                            text = "Pihak: ${r.customerOrSupplier.ifBlank { "Pelanggan Umum" }} • ${PosRepository.formatDate(r.timestamp)}",
                            fontSize = 10.5.sp,
                            color = SlateLight
                        )

                        if (r.notes.isNotBlank()) {
                            Text(
                                text = "Keterangan: ${r.notes}",
                                fontSize = 10.sp,
                                color = SlateMedium
                            )
                        }
                    }
                }
            }
        }
    }
}

// =========================================================================
// TAB 4: LAPORAN STOK OPNAME (AUDIT FISIK)
// =========================================================================
@Composable
private fun StockOpnameReportTab(opnames: List<StockOpnameRecord>) {
    if (opnames.isEmpty()) {
        EmptyStateCard(
            icon = Icons.Default.Inventory,
            title = "Belum Ada Riwayat Stok Opname",
            message = "Audit stok fisik dan penyesuaian selisih barang yang dilakukan di menu Produk akan terekam di sini."
        )
    } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Text(
                    text = "Riwayat Audit Stok Opname (${opnames.size} Kali)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = SlateDark
                )
            }

            items(opnames) { so ->
                val isMatch = so.difference == 0
                val isMinus = so.difference < 0
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = so.productName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = SlateDark
                            )
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = when {
                                    isMatch -> Color(0xFFECFDF5)
                                    isMinus -> Color(0xFFFEF2F2)
                                    else -> Color(0xFFFFFBEB)
                                }
                            ) {
                                Text(
                                    text = when {
                                        isMatch -> "Sesuai (0)"
                                        isMinus -> "${so.difference} Kurang"
                                        else -> "+${so.difference} Lebih"
                                    },
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when {
                                        isMatch -> EmeraldPrimary
                                        isMinus -> Color(0xFFDC2626)
                                        else -> Color(0xFFD97706)
                                    },
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Sistem: ${so.systemStock} → Fisik: ${so.physicalStock}",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Medium,
                                color = SlateDark
                            )
                            Text(
                                text = PosRepository.formatDate(so.date),
                                fontSize = 10.5.sp,
                                color = SlateLight
                            )
                        }

                        Text(
                            text = "Alasan: ${so.reason} • Petugas: ${so.conductedBy}",
                            fontSize = 10.5.sp,
                            color = SlateMedium
                        )
                        if (so.notes.isNotBlank()) {
                            Text(
                                text = "Catatan: ${so.notes}",
                                fontSize = 10.sp,
                                color = SlateLight
                            )
                        }
                    }
                }
            }
        }
    }
}

// =========================================================================
// TAB 5: LAPORAN TRANSAKSI DIBATALKAN (VOID)
// =========================================================================
@Composable
private fun VoidTransactionsReportTab(
    voidTransactions: List<TransactionRecord>,
    onViewReceipt: (TransactionRecord) -> Unit
) {
    if (voidTransactions.isEmpty()) {
        EmptyStateCard(
            icon = Icons.Default.Block,
            title = "Tidak Ada Transaksi Dibatalkan (VOID)",
            message = "Semua transaksi kasir berstatus normal dan belum ada pembatalan struk oleh supervisor."
        )
    } else {
        val totalVoidAmount = voidTransactions.sumOf { it.totalAmount }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Total Nilai Void Dibatalkan", fontSize = 11.sp, color = Color(0xFF991B1B))
                            Text(
                                text = PosRepository.formatRupiah(totalVoidAmount),
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp,
                                color = Color(0xFFDC2626)
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = Color.White
                        ) {
                            Text(
                                text = "${voidTransactions.size} Transaksi Void",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = Color(0xFFDC2626),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            items(voidTransactions) { tx ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFFFCA5A5), RoundedCornerShape(12.dp))
                        .clickable { onViewReceipt(tx) }
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = tx.receiptNumber,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = SlateDark
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = Color(0xFFFEF2F2)
                                ) {
                                    Text(
                                        text = "VOID / BATAL",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFDC2626),
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = PosRepository.formatRupiah(tx.totalAmount),
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 14.sp,
                                color = Color(0xFFDC2626)
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Alasan: ${tx.voidReason.ifBlank { "Kesalahan Input" }}",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF991B1B)
                        )
                        Text(
                            text = "Kasir: ${tx.cashierName} • Otorisasi: ${tx.voidBy.ifBlank { "Supervisor" }}",
                            fontSize = 10.5.sp,
                            color = SlateMedium
                        )
                        Text(
                            text = "Waktu Void: ${PosRepository.formatDate(if (tx.voidTimestamp > 0) tx.voidTimestamp else tx.timestamp)}",
                            fontSize = 10.sp,
                            color = SlateLight
                        )
                    }
                }
            }
        }
    }
}

// =========================================================================
// TAB 6: LAPORAN PIUTANG PELANGGAN (KASBON)
// =========================================================================
@Composable
private fun ReceivablesReportTab(receivables: List<ReceivableRecord>) {
    val totalRemaining = receivables.sumOf { it.remainingAmount }
    val totalPiutang = receivables.sumOf { it.totalAmount }

    if (receivables.isEmpty()) {
        EmptyStateCard(
            icon = Icons.Default.MonetizationOn,
            title = "Tidak Ada Piutang Pelanggan",
            message = "Catatan bon/kasbon pelanggan yang belum lunas atau riwayat pembayaran akan muncul di sini."
        )
    } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Sisa Piutang Berjalan", fontSize = 11.sp, color = Color(0xFF92400E))
                            Text(
                                text = PosRepository.formatRupiah(totalRemaining),
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp,
                                color = Color(0xFFD97706)
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Total Bon: ${PosRepository.formatRupiah(totalPiutang)}", fontSize = 11.sp, color = SlateMedium)
                            Text("${receivables.size} Catatan Bon", fontSize = 10.sp, color = SlateLight)
                        }
                    }
                }
            }

            items(receivables) { r ->
                val isLunas = r.status == "LUNAS"
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = r.customerName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = SlateDark
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = if (isLunas) Color(0xFFECFDF5) else Color(0xFFFFFBEB)
                                ) {
                                    Text(
                                        text = if (isLunas) "LUNAS" else "BELUM LUNAS",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isLunas) EmeraldPrimary else Color(0xFFD97706),
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = PosRepository.formatRupiah(r.remainingAmount),
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 14.sp,
                                color = if (isLunas) EmeraldPrimary else Color(0xFFDC2626)
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "No. Bon: ${r.receiptNumber} • Telp: ${r.customerPhone.ifBlank { "-" }}",
                            fontSize = 11.sp,
                            color = SlateMedium
                        )
                        Text(
                            text = "Total: ${PosRepository.formatRupiah(r.totalAmount)} | Terbayar: ${PosRepository.formatRupiah(r.paidAmount)}",
                            fontSize = 10.5.sp,
                            color = SlateLight
                        )
                        Text(
                            text = "Dibuat: ${PosRepository.formatDate(r.createdAt)} • Jatuh Tempo: ${PosRepository.formatDate(r.dueDate)}",
                            fontSize = 10.sp,
                            color = SlateLight
                        )
                    }
                }
            }
        }
    }
}

// =========================================================================
// TAB 7: RIWAYAT STRUK TRANSAKSI LENGKAP
// =========================================================================
@Composable
private fun TransactionHistoryTab(
    transactions: List<TransactionRecord>,
    onViewReceipt: (TransactionRecord) -> Unit
) {
    if (transactions.isEmpty()) {
        EmptyStateCard(
            icon = Icons.Default.ReceiptLong,
            title = "Belum Ada Transaksi",
            message = "Transaksi yang dilakukan kasir akan muncul di sini dan dapat diklik untuk mencetak struk."
        )
    } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(transactions, key = { it.id }) { tx ->
                TransactionRowCard(tx = tx, onClick = { onViewReceipt(tx) })
            }
        }
    }
}

// =========================================================================
// HELPER COMPOSABLES
// =========================================================================
@Composable
private fun KpiCard(
    title: String,
    value: String,
    subtext: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier.border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = title, fontSize = 10.5.sp, color = SlateLight)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 14.sp,
                color = accentColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = subtext, fontSize = 9.5.sp, color = SlateLight)
        }
    }
}

@Composable
private fun ShiftBreakdownBar(
    shiftName: String,
    amount: Long,
    total: Long,
    color: Color
) {
    val percentage = if (total > 0) (amount.toFloat() / total.toFloat()) else 0f
    val percentInt = (percentage * 100).toInt()

    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = shiftName, fontSize = 11.5.sp, fontWeight = FontWeight.Medium)
            Text(
                text = "${PosRepository.formatRupiah(amount)} ($percentInt%)",
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .background(Color(0xFFF1F5F9), RoundedCornerShape(3.dp))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(fraction = percentage.coerceIn(0f, 1f))
                    .height(6.dp)
                    .background(color, RoundedCornerShape(3.dp))
            )
        }
    }
}

@Composable
private fun PaymentStatItem(name: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = name, fontSize = 10.5.sp, color = SlateLight)
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = SlateDark,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun TransactionRowCard(tx: TransactionRecord, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(10.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = tx.receiptNumber,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = if (tx.isVoid) Color(0xFFDC2626) else SlateDark
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    if (tx.isVoid) {
                        Surface(shape = RoundedCornerShape(4.dp), color = Color(0xFFFEF2F2)) {
                            Text("VOID", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFFDC2626), modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                        }
                    } else {
                        Text(
                            text = "• Shift ${tx.shiftNumber}",
                            fontSize = 11.sp,
                            color = SlateLight
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${PosRepository.formatDate(tx.timestamp)} • ${tx.paymentMethod}",
                    fontSize = 11.sp,
                    color = SlateLight
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = PosRepository.formatRupiah(tx.totalAmount),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.5.sp,
                    color = if (tx.isVoid) Color(0xFFDC2626) else EmeraldPrimary
                )
                Text(
                    text = "Lihat Struk >",
                    fontSize = 10.sp,
                    color = BlueShift2,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
private fun EmptyStateCard(icon: ImageVector, title: String, message: String) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(14.dp))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = SlateLight,
                modifier = Modifier.size(40.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = SlateDark
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = message,
                fontSize = 11.5.sp,
                color = SlateLight,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}

private fun formatPeriodLabel(period: ReportPeriod): String {
    val sdf = SimpleDateFormat("dd MMM yyyy", Locale("id", "ID"))
    val now = System.currentTimeMillis()
    return when (period) {
        ReportPeriod.TODAY -> sdf.format(Date(now))
        ReportPeriod.LAST_7_DAYS -> "${sdf.format(Date(now - 7 * 86400000L))} - ${sdf.format(Date(now))}"
        ReportPeriod.LAST_30_DAYS -> "${sdf.format(Date(now - 30 * 86400000L))} - ${sdf.format(Date(now))}"
        ReportPeriod.THIS_MONTH -> SimpleDateFormat("MMMM yyyy", Locale("id", "ID")).format(Date(now))
        ReportPeriod.ALL_TIME -> "Semua Transaksi"
    }
}

private fun buildChartDataPoints(transactions: List<TransactionRecord>, period: ReportPeriod): List<ChartBarData> {
    if (period == ReportPeriod.TODAY) {
        // Hourly buckets: 08:00, 10:00, 12:00, 14:00, 16:00, 18:00, 20:00, 22:00
        val cal = Calendar.getInstance()
        val buckets = listOf(8, 10, 12, 14, 16, 18, 20, 22)
        return buckets.map { hour ->
            val count = transactions.count { tx ->
                cal.timeInMillis = tx.timestamp
                val h = cal.get(Calendar.HOUR_OF_DAY)
                h in hour..(hour + 1)
            }
            val amount = transactions.filter { tx ->
                cal.timeInMillis = tx.timestamp
                val h = cal.get(Calendar.HOUR_OF_DAY)
                h in hour..(hour + 1)
            }.sumOf { it.totalAmount }

            ChartBarData(
                label = String.format(Locale.US, "%02d:00", hour),
                fullDate = "Hari Ini, Jam %02d:00 - %02d:00".format(hour, hour + 2),
                amount = amount,
                txCount = count
            )
        }
    } else {
        // Last 7 days or days of month
        val countDays = if (period == ReportPeriod.LAST_7_DAYS) 7 else if (period == ReportPeriod.LAST_30_DAYS) 10 else 7
        val dayFormat = SimpleDateFormat("EEE", Locale("id", "ID"))
        val fullFormat = SimpleDateFormat("EEEE, dd MMM yyyy", Locale("id", "ID"))
        val cal = Calendar.getInstance()

        val list = mutableListOf<ChartBarData>()
        for (i in (countDays - 1) downTo 0) {
            val targetCal = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, -i)
            }
            val targetYear = targetCal.get(Calendar.YEAR)
            val targetDay = targetCal.get(Calendar.DAY_OF_YEAR)

            val dayTxs = transactions.filter { tx ->
                cal.timeInMillis = tx.timestamp
                cal.get(Calendar.YEAR) == targetYear && cal.get(Calendar.DAY_OF_YEAR) == targetDay
            }

            val amount = dayTxs.sumOf { it.totalAmount }
            list.add(
                ChartBarData(
                    label = if (countDays <= 7) dayFormat.format(targetCal.time) else "${targetCal.get(Calendar.DAY_OF_MONTH)}",
                    fullDate = fullFormat.format(targetCal.time),
                    amount = amount,
                    txCount = dayTxs.size
                )
            )
        }
        return list
    }
}
