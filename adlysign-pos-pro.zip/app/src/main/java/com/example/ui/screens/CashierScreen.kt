package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.delay
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.CartItem
import com.example.data.model.MemberRecord
import com.example.data.model.Product
import com.example.data.repository.PosRepository
import com.example.ui.components.CheckoutDialog
import com.example.ui.components.CameraBarcodeScannerDialog
import com.example.ui.components.CloseShiftDialog
import com.example.data.model.Employee
import com.example.ui.components.ItemQuantityDialog
import com.example.ui.components.LockCashierDialog
import com.example.ui.components.LoginEmployeeDialog
import com.example.ui.components.MemberSelectionDialog
import com.example.ui.components.PendingCartDialog
import com.example.ui.components.PointSettingsDialog
import com.example.ui.components.PrinterSettingsDialog
import com.example.ui.components.ReceiptDialog
import com.example.ui.components.ReceivableDialog
import com.example.ui.components.ShortcutCheatsheetDialog
import com.example.ui.components.StartShiftDialog
import com.example.ui.components.StockOpnameDialog
import com.example.ui.components.SupervisorAuthDialog
import com.example.ui.components.SupplierPurchaseDialog
import com.example.ui.components.VoidTransactionDialog
import com.example.ui.theme.AmberShift1
import com.example.ui.theme.BlueShift2
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.PurpleShift3
import com.example.ui.theme.SlateDark
import com.example.ui.theme.SlateLight
import com.example.ui.theme.SlateMedium
import com.example.ui.theme.SuccessGreen
import com.example.ui.viewmodel.PosViewModel
import kotlinx.coroutines.launch

enum class CashierMode {
    FAST_CASHIER,
    GALLERY
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CashierScreen(
    viewModel: PosViewModel,
    onNavigateToShift: () -> Unit,
    onNavigateToLicense: () -> Unit
) {
    val products by viewModel.filteredProducts.collectAsStateWithLifecycle()
    val allProducts by viewModel.allProducts.collectAsStateWithLifecycle()
    val categories by viewModel.categories.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val cartTotal by viewModel.cartTotal.collectAsStateWithLifecycle()
    val cartItemCount by viewModel.cartItemCount.collectAsStateWithLifecycle()
    val activeShift by viewModel.activeShift.collectAsStateWithLifecycle()
    val licenseInfo by viewModel.licenseInfo.collectAsStateWithLifecycle()

    // New State Flows
    val currentEmployee by viewModel.currentEmployee.collectAsStateWithLifecycle()
    val isLocked by viewModel.isLocked.collectAsStateWithLifecycle()
    val selectedMember by viewModel.selectedMember.collectAsStateWithLifecycle()
    val members by viewModel.members.collectAsStateWithLifecycle()
    val pendingCarts by viewModel.pendingCarts.collectAsStateWithLifecycle()
    val pointSettings by viewModel.pointSettings.collectAsStateWithLifecycle()
    val pointsToRedeem by viewModel.pointsToRedeem.collectAsStateWithLifecycle()
    val pointDiscountAmount by viewModel.pointDiscountAmount.collectAsStateWithLifecycle()
    val stockOpnames by viewModel.stockOpnames.collectAsStateWithLifecycle()
    val soTasks by viewModel.stockOpnameTasks.collectAsStateWithLifecycle()
    val purchaseRecords by viewModel.purchaseRecords.collectAsStateWithLifecycle()
    val receivables by viewModel.receivables.collectAsStateWithLifecycle()
    val employees by viewModel.employees.collectAsStateWithLifecycle()
    val lastCompletedTransaction by viewModel.lastCompletedTransaction.collectAsStateWithLifecycle()
    val printerSettings by viewModel.printerSettings.collectAsStateWithLifecycle()
    val isPrinting by viewModel.isPrinting.collectAsStateWithLifecycle()

    // Dialog Visibilities
    var showCartSheet by remember { mutableStateOf(false) }
    var showCheckoutDialog by remember { mutableStateOf(false) }
    var showStartShiftDialog by remember { mutableStateOf(false) }
    var showCloseShiftDialog by remember { mutableStateOf(false) }
    var showSavePendingDialog by remember { mutableStateOf(false) }
    var showPendingListDialog by remember { mutableStateOf(false) }
    var showMemberDialog by remember { mutableStateOf(false) }
    var showShortcutDialog by remember { mutableStateOf(false) }
    var showCameraScanner by remember { mutableStateOf(false) }
    var showQuantityDialog by remember { mutableStateOf<CartItem?>(null) }
    var showStockOpnameDialog by remember { mutableStateOf(false) }
    var showSupplierPurchaseDialog by remember { mutableStateOf(false) }
    var showReceivableDialog by remember { mutableStateOf(false) }
    var showPointSettingsDialog by remember { mutableStateOf(false) }
    var showLoginDialog by remember { mutableStateOf(false) }
    var showReceiptDialog by remember { mutableStateOf(false) }
    var showPrinterSettingsDialog by remember { mutableStateOf(false) }
    var showVoidDialog by remember { mutableStateOf(false) }
    var showSupervisorAuthForVoid by remember { mutableStateOf(false) }
    var showSupervisorAuthForCancelCart by remember { mutableStateOf(false) }
    var showSupervisorAuthForDeletePending by remember { mutableStateOf(false) }
    var showSupervisorAuthForDeleteItem by remember { mutableStateOf(false) }
    var itemToDeleteWithAuth by remember { mutableStateOf<Product?>(null) }
    var pendingCartIdToDelete by remember { mutableStateOf<Long?>(null) }
    var lastVoidAuthorizedEmployee by remember { mutableStateOf<Employee?>(null) }

    var currentCashierMode by remember { mutableStateOf(CashierMode.FAST_CASHIER) }
    var currentTimeString by remember { mutableStateOf("") }
    var currentDateString by remember { mutableStateOf("") }
    var hasPromptedShiftOnEnter by remember { mutableStateOf(false) }

    val searchFocusRequester = remember { FocusRequester() }
    val mainContainerFocusRequester = remember { FocusRequester() }
    val scope = rememberCoroutineScope()
    val sheetState = rememberModalBottomSheetState()

    LaunchedEffect(Unit) {
        runCatching {
            mainContainerFocusRequester.requestFocus()
        }
        while (true) {
            val now = Date()
            currentTimeString = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(now)
            currentDateString = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("id", "ID")).format(now)
            delay(1000L)
        }
    }

    LaunchedEffect(activeShift, currentEmployee) {
        if (currentEmployee != null && activeShift == null && !hasPromptedShiftOnEnter) {
            hasPromptedShiftOnEnter = true
            showStartShiftDialog = true
        }
    }

    fun onBarcodeOrSearchSubmit() {
        val query = searchQuery.trim()
        if (query.isNotEmpty()) {
            val match = allProducts.find {
                it.sku.equals(query, ignoreCase = true) || it.name.equals(query, ignoreCase = true)
            } ?: products.firstOrNull()

            if (match != null) {
                if (activeShift == null) {
                    showStartShiftDialog = true
                } else {
                    viewModel.addToCart(match)
                    viewModel.searchQuery.value = ""
                }
            }
        }
    }

    LaunchedEffect(lastCompletedTransaction) {
        if (lastCompletedTransaction != null) {
            showReceiptDialog = true
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .focusRequester(mainContainerFocusRequester)
            .focusable()
            .onKeyEvent { keyEvent ->
                if (keyEvent.type == KeyEventType.KeyDown) {
                    when (keyEvent.key) {
                        Key.F1 -> {
                            runCatching { searchFocusRequester.requestFocus() }
                            true
                        }
                        Key.F2 -> {
                            if (cartItems.isNotEmpty()) {
                                showQuantityDialog = cartItems.last()
                            }
                            true
                        }
                        Key.F3 -> {
                            if (cartItems.isNotEmpty()) {
                                showSavePendingDialog = true
                            }
                            true
                        }
                        Key.F4 -> {
                            showPendingListDialog = true
                            true
                        }
                        Key.F5 -> {
                            if (currentEmployee?.canVoid == true) {
                                showVoidDialog = true
                            } else {
                                showSupervisorAuthForVoid = true
                            }
                            true
                        }
                        Key.F6 -> {
                            showStockOpnameDialog = true
                            true
                        }
                        Key.F7 -> {
                            showStartShiftDialog = true
                            true
                        }
                        Key.F8 -> {
                            if (activeShift != null) {
                                showCloseShiftDialog = true
                            } else {
                                showStartShiftDialog = true
                            }
                            true
                        }
                        Key.F9 -> {
                            showSupplierPurchaseDialog = true
                            true
                        }
                        Key.F10 -> {
                            showReceivableDialog = true
                            true
                        }
                        Key.F11 -> {
                            viewModel.lockCashier()
                            true
                        }
                        Key.F12 -> {
                            if (cartItems.isNotEmpty()) {
                                if (activeShift == null) {
                                    showStartShiftDialog = true
                                } else {
                                    showCheckoutDialog = true
                                }
                            }
                            true
                        }
                        Key.Escape -> {
                            if (cartItems.isNotEmpty()) {
                                if (currentEmployee?.canCancelCart == true) {
                                    viewModel.clearCart()
                                } else {
                                    showSupervisorAuthForCancelCart = true
                                }
                            }
                            true
                        }
                        else -> false
                    }
                } else false
            }
            .background(Color(0xFFF8FAFC))
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // --- 1. HEADER KASIR RESMI (Nama Toko Terang & Jelas, Status Kasir & Shift Aktif) ---
            Surface(
                color = EmeraldPrimary,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    // BARIS 1: Logo Toko + Nama Toko (Besar & Jelas) + Badge Lisensi (Kiri), Jam Digital & Tanggal + Bantuan [F1] (Kanan)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Sisi Kiri: Identitas Toko (Diberi prioritas ruang lebar agar Nama Toko tidak terpotong)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color.White,
                                shadowElevation = 2.dp,
                                modifier = Modifier.size(38.dp)
                            ) {
                                Box(
                                    modifier = Modifier.fillMaxSize(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (licenseInfo.storeLogoUri.isNotBlank()) {
                                        AsyncImage(
                                            model = licenseInfo.storeLogoUri,
                                            contentDescription = "Logo Toko",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    } else {
                                        Icon(
                                            Icons.Default.Storefront,
                                            contentDescription = "Toko",
                                            tint = EmeraldPrimary,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = licenseInfo.storeName.ifBlank { "Toko Modern Kasir" },
                                        color = Color.White,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 17.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f, fill = false)
                                    )

                                    Spacer(modifier = Modifier.width(6.dp))

                                    val isEnterprise = licenseInfo.isActivated && licenseInfo.licenseTier.equals("ENTERPRISE", ignoreCase = true)
                                    val isPro = licenseInfo.isActivated && !isEnterprise
                                    val tierBadgeText = when {
                                        isEnterprise -> "ENTERPRISE"
                                        isPro -> "PRO"
                                        else -> "TRIAL"
                                    }
                                    val tierBadgeBg = when {
                                        isEnterprise -> PurpleShift3 // Ungu Royal Enterprise
                                        isPro -> AmberShift1         // Amber / Emas PRO
                                        else -> SlateLight          // Slate Trial
                                    }

                                    Box(
                                        modifier = Modifier
                                            .background(tierBadgeBg, RoundedCornerShape(4.dp))
                                            .padding(horizontal = 5.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = tierBadgeText,
                                            color = Color.White,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            letterSpacing = 0.5.sp
                                        )
                                    }
                                }

                                Text(
                                    text = licenseInfo.storeAddress.ifBlank { "Sistem Kasir Modern & Multi-Shift" },
                                    color = Color(0xFFD1FAE5),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        // Sisi Kanan: Jam Digital & Tanggal + Bantuan [F1]
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0x33000000),
                            border = BorderStroke(0.8.dp, Color.White.copy(alpha = 0.2f))
                        ) {
                            Row(
                                modifier = Modifier.padding(start = 8.dp, end = 2.dp, top = 2.dp, bottom = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = currentTimeString.ifBlank { "11:48:38" },
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        letterSpacing = 0.5.sp
                                    )
                                    Text(
                                        text = currentDateString.ifBlank { "Hari ini" },
                                        color = Color(0xFFD1FAE5),
                                        fontSize = 9.sp
                                    )
                                }
                                IconButton(
                                    onClick = { showShortcutDialog = true },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        Icons.Default.HelpOutline,
                                        contentDescription = "Panduan Pintasan [F1]",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    HorizontalDivider(color = Color.White.copy(alpha = 0.25f), thickness = 0.8.dp)
                    Spacer(modifier = Modifier.height(6.dp))

                    // BARIS 2: Status Kasir Aktif & Status Shift (Kiri), Tombol Kunci Kasir [F11] & Keluar (Kanan)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Sisi Kiri: Chip Kasir & Chip Shift (bisa digeser jika di layar sempit)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier
                                .weight(1f, fill = false)
                                .horizontalScroll(rememberScrollState())
                        ) {
                            // Chip Kasir Aktif
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = Color.White.copy(alpha = 0.18f),
                                border = BorderStroke(0.8.dp, Color.White.copy(alpha = 0.3f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Default.Person,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    val role = currentEmployee?.role ?: "KASIR"
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                if (role == "OWNER") AmberShift1 else Color(0xFF10B981),
                                                RoundedCornerShape(3.dp)
                                            )
                                            .padding(horizontal = 4.dp, vertical = 1.dp)
                                    ) {
                                        Text(
                                            text = role,
                                            color = Color.White,
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Text(
                                        text = currentEmployee?.name ?: "Kasir Aktif",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1
                                    )
                                }
                            }

                            // Chip Status Shift (Bisa diklik untuk Buka/Tutup Shift)
                            val shiftColor = if (activeShift != null) {
                                when (activeShift!!.shiftNumber) {
                                    1 -> AmberShift1
                                    2 -> BlueShift2
                                    else -> PurpleShift3
                                }
                            } else {
                                ErrorRed
                            }

                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = shiftColor.copy(alpha = 0.35f),
                                border = BorderStroke(1.dp, shiftColor.copy(alpha = 0.8f)),
                                modifier = Modifier.clickable {
                                    if (activeShift != null) {
                                        showCloseShiftDialog = true
                                    } else {
                                        showStartShiftDialog = true
                                    }
                                }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        if (activeShift != null) Icons.Default.Schedule else Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = if (activeShift != null) Color.White else Color(0xFFFDE68A),
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (activeShift != null) {
                                            "Shift ${activeShift!!.shiftNumber}: ${activeShift!!.shiftName}"
                                        } else {
                                            "Belum Buka Shift [F7]"
                                        },
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1
                                    )
                                    if (activeShift != null) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .background(Color(0xFF4ADE80), CircleShape)
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        // Sisi Kanan: Tombol Kunci Kasir [F11] & Keluar
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            // Tombol Kunci Kasir [F11]
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = Color(0x33000000),
                                border = BorderStroke(0.8.dp, Color.White.copy(alpha = 0.25f)),
                                modifier = Modifier.clickable { viewModel.lockCashier() }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Lock,
                                        contentDescription = "Kunci Kasir",
                                        tint = Color(0xFFFDE68A),
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = "Kunci [F11]",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            // Tombol Keluar / Ganti Kasir
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = Color(0x44EF4444),
                                border = BorderStroke(0.8.dp, Color(0xFFFCA5A5).copy(alpha = 0.5f)),
                                modifier = Modifier.clickable {
                                    viewModel.logoutEmployee()
                                    showLoginDialog = true
                                }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Logout,
                                        contentDescription = "Keluar Kasir",
                                        tint = Color(0xFFFECACA),
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = "Keluar",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // --- 2. MAIN CASHIER INTERFACE (No Red-Circled Sub-menu Tabs!) ---
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                // CARD 1: TOTAL TAGIHAN
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "TOTAL TAGIHAN",
                                    color = Color(0xFF34D399),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    letterSpacing = 0.5.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .background(Color(0xFF334155), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = if (cartItems.isEmpty()) "STANDBY" else "TRANSAKSI",
                                        color = Color(0xFFCBD5E1),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Text(
                                text = "${cartItems.size} Item (${cartItems.sumOf { it.quantity }} pcs)",
                                color = Color(0xFF94A3B8),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        val displayTotal = (cartTotal - pointDiscountAmount).coerceAtLeast(0L)
                        Text(
                            text = PosRepository.formatRupiah(displayTotal),
                            color = Color(0xFF34D399),
                            fontSize = 28.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // CARD 2: QUICK SEARCH & MODE BAR
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Segmented Toggle: Kasir Cepat vs Galeri Produk
                            Row(
                                modifier = Modifier
                                    .background(Color(0xFFF1F5F9), RoundedCornerShape(8.dp))
                                    .padding(3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .background(
                                            if (currentCashierMode == CashierMode.FAST_CASHIER) EmeraldPrimary else Color.Transparent,
                                            RoundedCornerShape(6.dp)
                                        )
                                        .clickable { currentCashierMode = CashierMode.FAST_CASHIER }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = "Kasir Cepat",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (currentCashierMode == CashierMode.FAST_CASHIER) Color.White else Color(0xFF64748B)
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .background(
                                            if (currentCashierMode == CashierMode.GALLERY) EmeraldPrimary else Color.Transparent,
                                            RoundedCornerShape(6.dp)
                                        )
                                        .clickable { currentCashierMode = CashierMode.GALLERY }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = "Galeri Produk",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (currentCashierMode == CashierMode.GALLERY) Color.White else Color(0xFF64748B)
                                    )
                                }
                            }

                            // Member Button [F8]
                            OutlinedButton(
                                onClick = { showMemberDialog = true },
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.5f)),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = EmeraldPrimary),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = selectedMember?.let { "${it.name} (${it.points}P)" } ?: "Member [F8]",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Quick Operational Menus Bar (Stok Opname, Pembelian, Piutang, Printer)
                        val canStockOpname = currentEmployee?.canStockOpname == true
                        val canPurchase = currentEmployee?.canSupplierPurchase == true
                        val canReceivables = currentEmployee?.canManageReceivables == true
                        val canPrinter = currentEmployee?.canManagePrinter == true
                        val hasAnyOperationalMenu = canStockOpname || canPurchase || canReceivables || canPrinter

                        if (hasAnyOperationalMenu) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 8.dp)
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Menu 1: Stok Opname
                                if (canStockOpname) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color(0xFFFEF3C7),
                                        border = BorderStroke(1.dp, Color(0xFFF59E0B)),
                                        modifier = Modifier
                                            .clickable { showStockOpnameDialog = true }
                                            .testTag("menu_stok_opname_button")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(Icons.Default.Inventory, contentDescription = null, tint = Color(0xFFB45309), modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Stok Opname [F6]", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF78350F))
                                        }
                                    }
                                }

                                // Menu 2: Pembelian Barang
                                if (canPurchase) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color(0xFFDBEAFE),
                                        border = BorderStroke(1.dp, Color(0xFF3B82F6)),
                                        modifier = Modifier
                                            .clickable { showSupplierPurchaseDialog = true }
                                            .testTag("menu_pembelian_barang_button")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(Icons.Default.LocalShipping, contentDescription = null, tint = Color(0xFF1D4ED8), modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Pembelian [F9]", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E40AF))
                                        }
                                    }
                                }

                                // Menu 3: Piutang Pelanggan
                                if (canReceivables) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color(0xFFFCE7F3),
                                        border = BorderStroke(1.dp, Color(0xFFEC4899)),
                                        modifier = Modifier
                                            .clickable { showReceivableDialog = true }
                                            .testTag("menu_piutang_button")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = Color(0xFFBE185D), modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Piutang [F10]", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF9D174D))
                                        }
                                    }
                                }

                                // Menu 4: Printer Struk
                                if (canPrinter) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color(0xFFF1F5F9),
                                        border = BorderStroke(1.dp, Color(0xFFCBD5E1)),
                                        modifier = Modifier
                                            .clickable { showPrinterSettingsDialog = true }
                                            .testTag("menu_printer_settings_button")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(Icons.Default.Print, contentDescription = null, tint = Color(0xFF475569), modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Printer Struk", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF334155))
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Barcode Scanner / SKU Search Input
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFFF8FAFC), RoundedCornerShape(8.dp))
                                .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.QrCodeScanner,
                                contentDescription = null,
                                tint = EmeraldPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            TextField(
                                value = searchQuery,
                                onValueChange = { viewModel.searchQuery.value = it },
                                placeholder = {
                                    Text("Scan Barcode / Cari Produk... [F2]", fontSize = 12.sp, color = Color(0xFF64748B))
                                },
                                colors = TextFieldDefaults.colors(
                                    focusedTextColor = Color(0xFF0F172A),
                                    unfocusedTextColor = Color(0xFF0F172A),
                                    cursorColor = EmeraldPrimary,
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent,
                                    focusedIndicatorColor = Color.Transparent,
                                    unfocusedIndicatorColor = Color.Transparent
                                ),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(
                                    imeAction = ImeAction.Done,
                                    keyboardType = KeyboardType.Text
                                ),
                                keyboardActions = KeyboardActions(
                                    onDone = { onBarcodeOrSearchSubmit() }
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .focusRequester(searchFocusRequester)
                                    .testTag("search_product_input")
                            )
                            if (searchQuery.isNotBlank()) {
                                IconButton(
                                    onClick = { viewModel.searchQuery.value = "" },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.Clear, contentDescription = "Hapus", modifier = Modifier.size(16.dp))
                                }
                            }
                            // Tombol Kamera Barcode Scanner (Tepat sebelum tombol Enter)
                            Button(
                                onClick = { showCameraScanner = true },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = EmeraldPrimary.copy(alpha = 0.15f),
                                    contentColor = EmeraldPrimary
                                ),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier
                                    .height(34.dp)
                                    .testTag("btn_camera_barcode_scanner")
                            ) {
                                Icon(
                                    Icons.Default.PhotoCamera,
                                    contentDescription = "Scan Barcode Kamera",
                                    tint = EmeraldPrimary,
                                    modifier = Modifier.size(17.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    "Kamera",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldPrimary
                                )
                            }
                            Spacer(modifier = Modifier.width(4.dp))
                            Button(
                                onClick = { onBarcodeOrSearchSubmit() },
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier
                                    .height(34.dp)
                                    .testTag("btn_barcode_enter")
                            ) {
                                Text("Enter", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // CARD 3: MAIN BODY AREA (Fills available space)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    if (currentCashierMode == CashierMode.FAST_CASHIER) {
                        if (cartItems.isEmpty()) {
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                modifier = Modifier
                                    .fillMaxSize()
                                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(14.dp))
                            ) {
                                Box(
                                    modifier = Modifier.fillMaxSize(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier.padding(20.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.ShoppingCart,
                                            contentDescription = null,
                                            tint = Color(0xFFCBD5E1),
                                            modifier = Modifier.size(64.dp)
                                        )
                                        Spacer(modifier = Modifier.height(10.dp))
                                        Text(
                                            text = "Keranjang Transaksi Kosong",
                                            color = Color(0xFF475569),
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "Scan barcode atau cari produk untuk memasukkan barang",
                                            color = Color(0xFF94A3B8),
                                            fontSize = 12.sp,
                                            textAlign = TextAlign.Center
                                        )
                                        if (activeShift == null) {
                                            Spacer(modifier = Modifier.height(14.dp))
                                            Button(
                                                onClick = { showStartShiftDialog = true },
                                                colors = ButtonDefaults.buttonColors(containerColor = AmberShift1),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Icon(Icons.Default.Warning, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Buka Shift Kasir Sekarang [F7]", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            // Table of Cart Items
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                modifier = Modifier
                                    .fillMaxSize()
                                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(14.dp))
                            ) {
                                Column(modifier = Modifier.fillMaxSize().padding(10.dp)) {
                                    // Table Header
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color(0xFFF1F5F9), RoundedCornerShape(6.dp))
                                            .padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("ITEM", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF475569), modifier = Modifier.weight(2f))
                                        Text("HARGA", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF475569), modifier = Modifier.weight(1.2f))
                                        Text("QTY", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF475569), textAlign = TextAlign.Center, modifier = Modifier.weight(1.2f))
                                        Text("SUBTOTAL", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF475569), textAlign = TextAlign.End, modifier = Modifier.weight(1.3f))
                                        Spacer(modifier = Modifier.width(36.dp))
                                    }

                                    HorizontalDivider(color = Color(0xFFE2E8F0), modifier = Modifier.padding(vertical = 4.dp))

                                    LazyColumn(
                                        modifier = Modifier.fillMaxSize(),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        items(cartItems, key = { it.product.id }) { item ->
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .border(1.dp, Color(0xFFF1F5F9), RoundedCornerShape(8.dp))
                                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                             ) {
                                                Column(
                                                    modifier = Modifier
                                                        .weight(2f)
                                                        .clickable { showQuantityDialog = item }
                                                ) {
                                                    Text(
                                                        text = item.product.name,
                                                        fontWeight = FontWeight.SemiBold,
                                                        fontSize = 12.sp,
                                                        color = SlateDark,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        Text(
                                                            text = item.product.sku.ifBlank { "SKU: -" },
                                                            fontSize = 10.sp,
                                                            color = SlateLight
                                                        )
                                                        if (item.unitMultiplier > 1) {
                                                            Spacer(modifier = Modifier.width(4.dp))
                                                            Text(
                                                                text = "(1 ${item.selectedUnit}=${item.unitMultiplier}${item.product.unit})",
                                                                fontSize = 9.sp,
                                                                color = EmeraldPrimary,
                                                                fontWeight = FontWeight.Bold
                                                            )
                                                        }
                                                    }
                                                }
                                                Column(modifier = Modifier.weight(1.2f)) {
                                                    Text(
                                                        text = PosRepository.formatRupiah(item.effectiveUnitPrice),
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.SemiBold,
                                                        color = SlateDark
                                                    )
                                                    Text(
                                                        text = "/${item.selectedUnit}",
                                                        fontSize = 9.sp,
                                                        color = SlateLight
                                                    )
                                                }
                                                // Stepper
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.Center,
                                                    modifier = Modifier.weight(1.2f)
                                                ) {
                                                    Box(
                                                        modifier = Modifier
                                                            .size(28.dp)
                                                            .background(Color(0xFFF1F5F9), RoundedCornerShape(6.dp))
                                                            .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(6.dp))
                                                            .clickable {
                                                                if (item.quantity > 1) {
                                                                    viewModel.updateCartItemQuantityAndUnit(item.product, item.quantity - 1, item.selectedUnit)
                                                                } else {
                                                                    if (currentEmployee?.role == "KASIR") {
                                                                        itemToDeleteWithAuth = item.product
                                                                        showSupervisorAuthForDeleteItem = true
                                                                    } else {
                                                                        viewModel.updateCartItemQuantityAndUnit(item.product, 0, item.selectedUnit)
                                                                    }
                                                                }
                                                            },
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Icon(
                                                            Icons.Default.Remove,
                                                            contentDescription = "Kurang",
                                                            tint = Color(0xFF0F172A),
                                                            modifier = Modifier.size(16.dp)
                                                        )
                                                    }
                                                    Box(
                                                        modifier = Modifier
                                                            .padding(horizontal = 4.dp)
                                                            .background(Color(0xFFE2E8F0), RoundedCornerShape(4.dp))
                                                            .clickable { showQuantityDialog = item }
                                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                                    ) {
                                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                            Text(
                                                                text = "${item.quantity}",
                                                                fontWeight = FontWeight.ExtraBold,
                                                                fontSize = 13.sp,
                                                                color = Color(0xFF0F172A)
                                                            )
                                                            Text(
                                                                text = item.selectedUnit,
                                                                fontSize = 8.sp,
                                                                color = Color(0xFF475569)
                                                            )
                                                        }
                                                    }
                                                    Box(
                                                        modifier = Modifier
                                                            .size(28.dp)
                                                            .background(EmeraldLight, RoundedCornerShape(6.dp))
                                                            .border(1.dp, EmeraldPrimary, RoundedCornerShape(6.dp))
                                                            .clickable {
                                                                viewModel.updateCartItemQuantityAndUnit(item.product, item.quantity + 1, item.selectedUnit)
                                                            },
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Icon(
                                                            Icons.Default.Add,
                                                             contentDescription = "Tambah",
                                                             tint = EmeraldPrimary,
                                                             modifier = Modifier.size(16.dp)
                                                        )
                                                    }
                                                }
                                                Text(
                                                    text = PosRepository.formatRupiah(item.subtotal),
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 11.sp,
                                                    color = EmeraldPrimary,
                                                    textAlign = TextAlign.End,
                                                    modifier = Modifier.weight(1.3f)
                                                )
                                                IconButton(
                                                    onClick = {
                                                        if (currentEmployee?.role == "KASIR") {
                                                            itemToDeleteWithAuth = item.product
                                                            showSupervisorAuthForDeleteItem = true
                                                        } else {
                                                            viewModel.removeFromCart(item.product)
                                                        }
                                                    },
                                                    modifier = Modifier.size(36.dp)
                                                ) {
                                                    Icon(
                                                        Icons.Default.Delete,
                                                        contentDescription = "Hapus",
                                                        tint = if (currentEmployee?.role == "KASIR") SlateLight else ErrorRed,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        // Mode Gallery
                        Column(modifier = Modifier.fillMaxSize()) {
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.padding(bottom = 6.dp)
                            ) {
                                categories.forEach { cat ->
                                    val isSelected = selectedCategory == cat
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = { viewModel.selectedCategory.value = cat },
                                        label = { Text(cat, fontSize = 11.sp) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = EmeraldPrimary,
                                            selectedLabelColor = Color.White
                                        )
                                    )
                                }
                            }
                            LazyVerticalGrid(
                                columns = GridCells.Adaptive(minSize = 140.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                items(products, key = { it.id }) { product ->
                                    val inCartCount = cartItems.find { it.product.id == product.id }?.quantity ?: 0
                                    ProductCard(
                                        product = product,
                                        inCartCount = inCartCount,
                                        onAdd = {
                                            if (activeShift == null) {
                                                showStartShiftDialog = true
                                            } else {
                                                viewModel.addToCart(product)
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // CARD 4: BOTTOM ACTION BAR (Clean bar above bottom navigation menu)
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Batal button
                        OutlinedButton(
                            onClick = {
                                if (currentEmployee?.canCancelCart == true) {
                                    viewModel.clearCart()
                                } else {
                                    showSupervisorAuthForCancelCart = true
                                }
                            },
                            enabled = cartItems.isNotEmpty(),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = ErrorRed),
                            border = BorderStroke(1.dp, if (cartItems.isNotEmpty()) ErrorRed else Color(0xFFCBD5E1)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier
                                .height(44.dp)
                                .testTag("cancel_cart_button")
                        ) {
                            Text("Batal", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        // Void button [F5] - tetap aktif meski belum ada item di keranjang
                        Button(
                            onClick = {
                                if (currentEmployee?.canVoid == true) {
                                    showVoidDialog = true
                                } else {
                                    showSupervisorAuthForVoid = true
                                }
                            },
                            enabled = true,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFFEE2E2),
                                contentColor = Color(0xFFDC2626)
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier
                                .height(44.dp)
                                .testTag("void_receipt_button")
                        ) {
                            Text("Void [F5]", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        // Pending button
                        Button(
                            onClick = {
                                if (cartItems.isNotEmpty()) {
                                    showSavePendingDialog = true
                                } else {
                                    showPendingListDialog = true
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFFEF3C7),
                                contentColor = Color(0xFFD97706)
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.height(44.dp)
                        ) {
                            Text("Pending (${pendingCarts.size})", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        Spacer(modifier = Modifier.weight(1f))

                        // Pay button [F12]
                        Button(
                            onClick = {
                                if (activeShift == null) {
                                    showStartShiftDialog = true
                                } else {
                                    showCheckoutDialog = true
                                }
                            },
                            enabled = cartItems.isNotEmpty(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = EmeraldPrimary,
                                disabledContainerColor = Color(0xFFCBD5E1)
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                            modifier = Modifier
                                .height(44.dp)
                                .testTag("checkout_button")
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("BAYAR [F12]", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }

    // Modal Bottom Sheet: Cart Details
    if (showCartSheet) {
        ModalBottomSheet(
            onDismissRequest = { showCartSheet = false },
            sheetState = sheetState
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 24.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Keranjang Transaksi",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Row {
                        IconButton(onClick = { showSavePendingDialog = true }) {
                            Icon(Icons.Default.Bookmark, contentDescription = "Hold", tint = Color(0xFFEA580C))
                        }
                        IconButton(onClick = { viewModel.clearCart() }) {
                            Icon(Icons.Default.Delete, contentDescription = "Kosongkan Keranjang", tint = ErrorRed)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                cartItems.forEach { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { showQuantityDialog = item }
                        ) {
                            Text(
                                text = item.product.name,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp
                            )
                            val unitDetail = if (item.unitMultiplier > 1) " (1 ${item.selectedUnit}=${item.unitMultiplier}${item.product.unit})" else ""
                            Text(
                                text = "${PosRepository.formatRupiah(item.effectiveUnitPrice)}/${item.selectedUnit} x ${item.quantity} $unitDetail [Ubah: F2]",
                                fontSize = 11.sp,
                                color = SlateMedium
                            )
                            Text(
                                text = PosRepository.formatRupiah(item.subtotal),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = EmeraldPrimary
                            )
                        }

                        // Qty counter
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(20.dp))
                                .padding(2.dp)
                        ) {
                            IconButton(
                                onClick = {
                                    if (item.quantity > 1) {
                                        viewModel.updateCartItemQuantityAndUnit(item.product, item.quantity - 1, item.selectedUnit)
                                    } else {
                                        if (currentEmployee?.role == "KASIR") {
                                            itemToDeleteWithAuth = item.product
                                            showSupervisorAuthForDeleteItem = true
                                        } else {
                                            viewModel.updateCartItemQuantityAndUnit(item.product, 0, item.selectedUnit)
                                        }
                                    }
                                },
                                modifier = Modifier.size(26.dp)
                            ) {
                                Icon(Icons.Default.Remove, contentDescription = "Kurang", modifier = Modifier.size(14.dp))
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "${item.quantity}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    modifier = Modifier.padding(horizontal = 4.dp)
                                )
                                Text(
                                    text = item.selectedUnit,
                                    fontSize = 8.sp,
                                    color = Color(0xFF475569)
                                )
                            }
                            IconButton(
                                onClick = { viewModel.updateCartItemQuantityAndUnit(item.product, item.quantity + 1, item.selectedUnit) },
                                modifier = Modifier.size(26.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "Tambah", modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                    HorizontalDivider(color = Color(0xFFF1F5F9))
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Member Points Summary in Sheet
                if (selectedMember != null) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    "Member: ${selectedMember!!.name}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = Color(0xFF92400E)
                                )
                                Text(
                                    "Poin tersedia: ${selectedMember!!.points} Poin",
                                    fontSize = 11.sp,
                                    color = Color(0xFFB45309)
                                )
                            }
                            Text(
                                if (pointDiscountAmount > 0) "-${PosRepository.formatRupiah(pointDiscountAmount)}" else "Belum dipakai",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = Color(0xFF15803D)
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Total Tagihan", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(
                        PosRepository.formatRupiah((cartTotal - pointDiscountAmount).coerceAtLeast(0L)),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 18.sp,
                        color = EmeraldPrimary
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        showCartSheet = false
                        showCheckoutDialog = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("cart_proceed_checkout_button")
                ) {
                    Text("Lanjut ke Pembayaran [F12]", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }
    }

    // --- DIALOGS INTEGRATION ---

    // 1. Lock Screen Dialog (F11 or Background)
    if (isLocked) {
        LockCashierDialog(
            currentEmployee = currentEmployee,
            onUnlock = { pin -> viewModel.unlockCashier(pin) },
            onLogout = {
                viewModel.logoutEmployee()
                showLoginDialog = true
            }
        )
    }

    // 2. Login Employee Dialog
    if (showLoginDialog) {
        LoginEmployeeDialog(
            employees = employees,
            onDismiss = { showLoginDialog = false },
            onLoginSuccess = { emp ->
                viewModel.loginEmployee(emp)
                showLoginDialog = false
            }
        )
    }

    // 3 & 4. Pending / Hold Transaction Dialog (F3 / F4)
    if (showSavePendingDialog || showPendingListDialog) {
        PendingCartDialog(
            currentCartItems = cartItems,
            pendingCarts = pendingCarts,
            onDismiss = {
                showSavePendingDialog = false
                showPendingListDialog = false
            },
            onSaveCurrentToPending = { label ->
                viewModel.saveCartToPending(label)
                showSavePendingDialog = false
                showPendingListDialog = false
                showCartSheet = false
            },
            onRecallPendingCart = { pending ->
                viewModel.recallPendingCart(pending)
                showPendingListDialog = false
                showSavePendingDialog = false
            },
            onDeletePendingCart = { id ->
                if (currentEmployee?.canDeletePendingCart == true) {
                    viewModel.deletePendingCart(id)
                } else {
                    pendingCartIdToDelete = id
                    showSupervisorAuthForDeletePending = true
                }
            }
        )
    }

    // 5. Member Selection & Point Redemption Dialog
    if (showMemberDialog) {
        MemberSelectionDialog(
            members = members,
            selectedMember = selectedMember,
            canAddMember = currentEmployee?.canAddMember == true,
            onDismiss = { showMemberDialog = false },
            onSelectMember = { member ->
                viewModel.selectMember(member)
                showMemberDialog = false
            },
            onClearMember = {
                viewModel.clearSelectedMember()
                showMemberDialog = false
            },
            onAddNewMember = { name, phone, memberNum ->
                viewModel.saveMember(MemberRecord(name = name, phone = phone, memberNumber = memberNum))
            }
        )
    }

    // 6. Shortcut Cheatsheet Dialog
    if (showShortcutDialog) {
        ShortcutCheatsheetDialog(onDismiss = { showShortcutDialog = false })
    }

    // 7. Quantity Input Dialog (F2)
    if (showQuantityDialog != null) {
        ItemQuantityDialog(
            item = showQuantityDialog!!,
            onDismiss = { showQuantityDialog = null },
            onConfirmQuantityAndUnit = { qty, unit ->
                val targetProduct = showQuantityDialog!!.product
                if (qty <= 0) {
                    if (currentEmployee?.role == "KASIR") {
                        itemToDeleteWithAuth = targetProduct
                        showSupervisorAuthForDeleteItem = true
                    } else {
                        viewModel.updateCartItemQuantityAndUnit(targetProduct, 0, unit)
                    }
                } else {
                    viewModel.updateCartItemQuantityAndUnit(targetProduct, qty, unit)
                }
                showQuantityDialog = null
            }
        )
    }

    // 8. Stock Opname Dialog (F6)
    if (showStockOpnameDialog) {
        StockOpnameDialog(
            products = allProducts,
            history = stockOpnames,
            tasks = soTasks,
            storeInfo = licenseInfo,
            onDismiss = { showStockOpnameDialog = false },
            onFinalizeTask = { taskCode, title, notes, items, onSuccess ->
                viewModel.finalizeStockOpnameBatch(taskCode, title, notes, items, onSuccess)
            }
        )
    }

    // 9. Supplier Purchase Dialog (F9)
    if (showSupplierPurchaseDialog) {
        SupplierPurchaseDialog(
            products = allProducts,
            purchaseHistory = purchaseRecords,
            onDismiss = { showSupplierPurchaseDialog = false },
            onSubmitPurchase = { inv, sup, phone, payType, items, notes ->
                viewModel.submitSupplierPurchase(inv, sup, phone, payType, items, notes)
            }
        )
    }

    // 10. Receivable / Piutang Dialog (F10)
    if (showReceivableDialog) {
        ReceivableDialog(
            receivables = receivables,
            onDismiss = { showReceivableDialog = false },
            onPayReceivable = { id, amount ->
                viewModel.payReceivable(id, amount)
            }
        )
    }

    // 11. Point Settings Dialog
    if (showPointSettingsDialog) {
        PointSettingsDialog(
            initialSettings = pointSettings,
            onDismiss = { showPointSettingsDialog = false },
            onSaveSettings = { newSettings ->
                viewModel.savePointSettings(newSettings)
            }
        )
    }

    // 12. Checkout Dialog (F12)
    if (showCheckoutDialog) {
        CheckoutDialog(
            cartItems = cartItems,
            totalAmount = cartTotal,
            member = selectedMember,
            pointSettings = pointSettings,
            pointsToRedeem = pointsToRedeem,
            licenseInfo = licenseInfo,
            onPointsToRedeemChange = { pts -> viewModel.setPointsToRedeem(pts) },
            onDismiss = { showCheckoutDialog = false },
            onConfirmCheckout = { method, paid, customer, phone, discount, notes, dueDays, shouldPrint ->
                viewModel.checkout(
                    paymentMethod = method,
                    paidAmount = paid,
                    customerName = customer,
                    customerPhone = phone,
                    discount = discount,
                    notes = notes,
                    dueDateDays = dueDays,
                    shouldPrint = shouldPrint
                )
                showCheckoutDialog = false
            }
        )
    }

    // 13. Start Shift Dialog (F7)
    if (showStartShiftDialog) {
        StartShiftDialog(
            onDismiss = { showStartShiftDialog = false },
            onConfirm = { shiftNum, name, cashier, cash, notes ->
                viewModel.startShift(shiftNum, name, cashier, cash, notes)
                showStartShiftDialog = false
            }
        )
    }

    // 14. Close Shift Dialog (F8)
    if (showCloseShiftDialog && activeShift != null) {
        CloseShiftDialog(
            activeShift = activeShift!!,
            pendingCount = pendingCarts.size,
            onDismiss = { showCloseShiftDialog = false },
            onConfirm = { closingCash, notes ->
                viewModel.closeShift(closingCash, notes)
                showCloseShiftDialog = false
            }
        )
    }

    // 15. Receipt Dialog
    if (showReceiptDialog && lastCompletedTransaction != null) {
        ReceiptDialog(
            transaction = lastCompletedTransaction!!,
            licenseInfo = licenseInfo,
            printerSettings = printerSettings,
            onDismiss = { showReceiptDialog = false },
            onPrintBluetooth = { viewModel.printTransactionReceipt(lastCompletedTransaction!!) },
            onOpenPrinterSettings = { showPrinterSettingsDialog = true }
        )
    }

    // 16. Printer & Receipt Settings Dialog
    if (showPrinterSettingsDialog) {
        PrinterSettingsDialog(
            initialSettings = printerSettings,
            pairedDevices = viewModel.getPairedPrinters(),
            isPrinting = isPrinting,
            onDismiss = { showPrinterSettingsDialog = false },
            onTestPrint = { customSettings ->
                viewModel.testPrint(customSettings)
            },
            onSaveSettings = { updated ->
                viewModel.updatePrinterSettings(updated)
            }
        )
    }

    // 17. Void Transaction Dialog (Struk Terbayar)
    if (showVoidDialog) {
        val allTx by viewModel.allTransactions.collectAsStateWithLifecycle()
        VoidTransactionDialog(
            transactions = allTx,
            onVoidTransaction = { tx, reason ->
                val voidByName = lastVoidAuthorizedEmployee?.name ?: currentEmployee?.name ?: "Kasir"
                viewModel.voidTransaction(tx, reason, voidByName)
                showVoidDialog = false
                lastVoidAuthorizedEmployee = null
            },
            onPrintReceipt = { tx ->
                viewModel.printTransactionReceipt(tx)
            },
            onDismiss = {
                showVoidDialog = false
                lastVoidAuthorizedEmployee = null
            }
        )
    }

    // 18. Supervisor Auth Dialog for Void Struk
    if (showSupervisorAuthForVoid) {
        SupervisorAuthDialog(
            title = "Otorisasi Void Struk",
            description = "Kasir (${currentEmployee?.name ?: "Kasir"}) tidak memiliki hak akses untuk membatalkan struk belanja. Masukkan PIN Supervisor / Pemilik Toko.",
            employees = employees,
            requiredRoleOrPermission = { it.canVoid },
            onAuthorized = { supervisor ->
                lastVoidAuthorizedEmployee = supervisor
                showSupervisorAuthForVoid = false
                showVoidDialog = true
            },
            onDismiss = { showSupervisorAuthForVoid = false }
        )
    }

    // 19. Supervisor Auth Dialog for Batal Keranjang
    if (showSupervisorAuthForCancelCart) {
        SupervisorAuthDialog(
            title = "Otorisasi Batal Keranjang",
            description = "Kasir (${currentEmployee?.name ?: "Kasir"}) tidak memiliki hak akses untuk membatalkan keranjang belanja. Masukkan PIN Supervisor / Pemilik Toko.",
            employees = employees,
            requiredRoleOrPermission = { it.canCancelCart },
            onAuthorized = {
                showSupervisorAuthForCancelCart = false
                viewModel.clearCart()
            },
            onDismiss = { showSupervisorAuthForCancelCart = false }
        )
    }

    // 20. Supervisor Auth Dialog for Hapus Pending Cart
    if (showSupervisorAuthForDeletePending && pendingCartIdToDelete != null) {
        SupervisorAuthDialog(
            title = "Otorisasi Hapus Pending",
            description = "Kasir (${currentEmployee?.name ?: "Kasir"}) tidak memiliki hak akses untuk menghapus nota pending. Masukkan PIN Supervisor / Pemilik Toko.",
            employees = employees,
            requiredRoleOrPermission = { it.canDeletePendingCart },
            onAuthorized = {
                showSupervisorAuthForDeletePending = false
                pendingCartIdToDelete?.let { viewModel.deletePendingCart(it) }
                pendingCartIdToDelete = null
            },
            onDismiss = {
                showSupervisorAuthForDeletePending = false
                pendingCartIdToDelete = null
            }
        )
    }

    // 21. Supervisor Auth Dialog for Hapus Item di Keranjang
    if (showSupervisorAuthForDeleteItem && itemToDeleteWithAuth != null) {
        SupervisorAuthDialog(
            title = "Otorisasi Hapus Item Keranjang",
            description = "Kasir (${currentEmployee?.name ?: "Kasir"}) tidak memiliki hak akses untuk menghapus item dari keranjang belanja. Masukkan PIN Supervisor / Pemilik Toko.",
            employees = employees,
            requiredRoleOrPermission = { it.canCancelCart || it.role == "OWNER" || it.role == "SUPERVISOR" },
            onAuthorized = {
                showSupervisorAuthForDeleteItem = false
                itemToDeleteWithAuth?.let { viewModel.removeFromCart(it) }
                itemToDeleteWithAuth = null
            },
            onDismiss = {
                showSupervisorAuthForDeleteItem = false
                itemToDeleteWithAuth = null
            }
        )
    }

    // 22. Camera Barcode Scanner Dialog
    if (showCameraScanner) {
        CameraBarcodeScannerDialog(
            sampleProducts = allProducts,
            onDismiss = { showCameraScanner = false },
            onBarcodeScanned = { barcode ->
                showCameraScanner = false
                viewModel.searchQuery.value = barcode
                onBarcodeOrSearchSubmit()
            }
        )
    }
}

@Composable
private fun QuickKeyChip(
    text: String,
    accentColor: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .background(accentColor.copy(alpha = 0.12f), RoundedCornerShape(6.dp))
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = accentColor
        )
    }
}

@Composable
fun ProductCard(
    product: Product,
    inCartCount: Int,
    onAdd: () -> Unit
) {
    Card(
        onClick = onAdd,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (inCartCount > 0) 1.5.dp else 1.dp,
                color = if (inCartCount > 0) EmeraldPrimary else Color(0xFFE2E8F0),
                shape = RoundedCornerShape(12.dp)
            )
            .testTag("product_card_${product.id}")
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = product.category,
                    fontSize = 10.sp,
                    color = SlateLight,
                    fontWeight = FontWeight.Medium
                )
                if (inCartCount > 0) {
                    Box(
                        modifier = Modifier
                            .background(EmeraldPrimary, CircleShape)
                            .size(20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "$inCartCount",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = product.name,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                color = SlateDark
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = PosRepository.formatRupiah(product.sellPrice),
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = EmeraldPrimary
            )

            Spacer(modifier = Modifier.height(4.dp))

            val isLowStock = product.stock <= 10
            val isOutOfStock = product.stock <= 0
            val stockColor = when {
                isOutOfStock -> ErrorRed
                isLowStock -> AmberShift1
                else -> SlateLight
            }

            Text(
                text = when {
                    isOutOfStock -> "Stok Habis"
                    else -> "Stok: ${product.stock} ${product.unit}"
                },
                fontSize = 11.sp,
                color = stockColor,
                fontWeight = if (isLowStock) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}
