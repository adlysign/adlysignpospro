package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.Product
import com.example.data.model.PurchaseRecord
import com.example.data.repository.PosRepository
import com.example.ui.theme.posOutlinedTextFieldColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SupplierPurchaseDialog(
    products: List<Product>,
    purchaseHistory: List<PurchaseRecord>,
    onDismiss: () -> Unit,
    onSubmitPurchase: (
        invoice: String,
        supplier: String,
        phone: String,
        paymentType: String,
        items: List<Triple<Product, Int, Long>>,
        notes: String
    ) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }

    var invoiceNumber by remember { mutableStateOf("INV-SUP-${System.currentTimeMillis() % 100000}") }
    var supplierName by remember { mutableStateOf("PT Sumber Distribusi") }
    var supplierPhone by remember { mutableStateOf("08123456789") }
    var paymentType by remember { mutableStateOf("TUNAI") }
    var notes by remember { mutableStateOf("") }

    val purchaseItems = remember { mutableStateListOf<Triple<Product, Int, Long>>() }

    // State for adding item
    var itemProduct by remember { mutableStateOf<Product?>(products.firstOrNull()) }
    var itemQtyText by remember { mutableStateOf("10") }
    var itemBuyPriceText by remember { mutableStateOf(products.firstOrNull()?.costPrice?.toString() ?: "5000") }
    var expandedDropdown by remember { mutableStateOf(false) }

    val totalPurchaseAmount = purchaseItems.sumOf { it.second * it.third }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("supplier_purchase_dialog")
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Header
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(Color(0xFFEDE9FE), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.LocalShipping, contentDescription = null, tint = Color(0xFF7C3AED))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Pembelian Supplier [F9]",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color(0xFF0F172A)
                            )
                            Text(
                                text = "Barang Masuk & Tambah Stok Otomatis",
                                fontSize = 12.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color(0xFFF1F5F9),
                    modifier = Modifier.background(Color(0xFFF1F5F9), RoundedCornerShape(10.dp))
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("Faktur Baru", fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Riwayat Faktur (${purchaseHistory.size})", fontSize = 13.sp) }
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                if (selectedTab == 0) {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(340.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = invoiceNumber,
                                    onValueChange = { invoiceNumber = it },
                                    label = { Text("No. Faktur") },
                                    colors = posOutlinedTextFieldColors(),
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = supplierName,
                                    onValueChange = { supplierName = it },
                                    label = { Text("Nama Supplier") },
                                    colors = posOutlinedTextFieldColors(),
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1.2f)
                                )
                            }
                        }

                        item {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                                border = CardDefaults.outlinedCardBorder(),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text("Tambah Barang Masuk:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Spacer(modifier = Modifier.height(6.dp))

                                    ExposedDropdownMenuBox(
                                        expanded = expandedDropdown,
                                        onExpandedChange = { expandedDropdown = it },
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        OutlinedTextField(
                                            value = itemProduct?.name ?: "Pilih Barang",
                                            onValueChange = {},
                                            readOnly = true,
                                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedDropdown) },
                                            modifier = Modifier
                                                .menuAnchor()
                                                .fillMaxWidth(),
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        ExposedDropdownMenu(
                                            expanded = expandedDropdown,
                                            onDismissRequest = { expandedDropdown = false }
                                        ) {
                                            products.forEach { p ->
                                                DropdownMenuItem(
                                                    text = { Text("${p.name} (Stok: ${p.stock})") },
                                                    onClick = {
                                                        itemProduct = p
                                                        itemBuyPriceText = p.costPrice.toString()
                                                        expandedDropdown = false
                                                    }
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        OutlinedTextField(
                                            value = itemQtyText,
                                            onValueChange = { itemQtyText = it.filter { c -> c.isDigit() } },
                                            label = { Text("Qty Masuk") },
                                            colors = posOutlinedTextFieldColors(),
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.weight(1f)
                                        )
                                        OutlinedTextField(
                                            value = itemBuyPriceText,
                                            onValueChange = { itemBuyPriceText = it.filter { c -> c.isDigit() } },
                                            label = { Text("Harga Beli (Satuan)") },
                                            colors = posOutlinedTextFieldColors(),
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.weight(1.4f)
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))
                                    Button(
                                        onClick = {
                                            val p = itemProduct
                                            val q = itemQtyText.toIntOrNull() ?: 1
                                            val bp = itemBuyPriceText.toLongOrNull() ?: 0L
                                            if (p != null && q > 0) {
                                                purchaseItems.add(Triple(p, q, bp))
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Tambahkan ke Faktur", fontSize = 12.sp)
                                    }
                                }
                            }
                        }

                        item {
                            Text("Daftar Barang (${purchaseItems.size}):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        items(purchaseItems) { item ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFFF1F5F9), RoundedCornerShape(8.dp))
                                    .padding(8.dp)
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.first.name, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                    Text(
                                        "${item.second} ${item.first.unit} x ${PosRepository.formatRupiah(item.third)} = ${PosRepository.formatRupiah(item.second * item.third)}",
                                        fontSize = 11.sp,
                                        color = Color(0xFF64748B)
                                    )
                                }
                                IconButton(
                                    onClick = { purchaseItems.remove(item) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(16.dp))
                                }
                            }
                        }

                        item {
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Total Tagihan Faktur:", fontWeight = FontWeight.Bold)
                                Text(
                                    PosRepository.formatRupiah(totalPurchaseAmount),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 16.sp,
                                    color = Color(0xFF7C3AED)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            if (invoiceNumber.isNotBlank() && supplierName.isNotBlank() && purchaseItems.isNotEmpty()) {
                                onSubmitPurchase(
                                    invoiceNumber,
                                    supplierName,
                                    supplierPhone,
                                    paymentType,
                                    purchaseItems.toList(),
                                    notes
                                )
                                onDismiss()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("submit_purchase_button")
                    ) {
                        Text("Simpan & Tambah Stok Masuk", fontWeight = FontWeight.Bold)
                    }
                } else {
                    // TAB 1: History
                    if (purchaseHistory.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Belum ada riwayat pembelian supplier", color = Color(0xFF94A3B8), fontSize = 13.sp)
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(320.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(purchaseHistory) { ph ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                                    border = CardDefaults.outlinedCardBorder(),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(ph.invoiceNumber, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            Text(
                                                PosRepository.formatRupiah(ph.totalAmount),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = Color(0xFF7C3AED)
                                            )
                                        }
                                        Text(
                                            "Supplier: ${ph.supplierName} • Metode: ${ph.paymentType}",
                                            fontSize = 12.sp,
                                            color = Color(0xFF475569)
                                        )
                                        Text(
                                            "${PosRepository.formatTime(ph.timestamp)} • Diterima: ${ph.receivedBy}",
                                            fontSize = 10.sp,
                                            color = Color(0xFF94A3B8)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
