package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.LicenseInfo
import com.example.data.model.Product
import com.example.data.model.PurchaseRecord
import com.example.data.model.StorePartnerRecord
import com.example.data.model.SupplierRecord
import com.example.data.repository.PosRepository
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SlateDark
import com.example.ui.theme.SlateLight
import com.example.ui.theme.SlateMedium
import com.example.ui.theme.posOutlinedTextFieldColors
import org.json.JSONArray

data class PurchaseItemEditState(
    val product: Product,
    val initialQty: Int,
    val initialPrice: Long,
    val isSupplierTab: Boolean
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SupplierPurchaseDialog(
    products: List<Product>,
    purchaseHistory: List<PurchaseRecord>,
    suppliers: List<SupplierRecord> = emptyList(),
    storePartners: List<StorePartnerRecord> = emptyList(),
    initialTab: Int = 0,
    activeUserName: String = "Admin/Owner",
    storeInfo: LicenseInfo? = null,
    onDismiss: () -> Unit,
    onSubmitPurchase: (
        invoice: String,
        supplier: String,
        phone: String,
        paymentType: String,
        items: List<Triple<Product, Int, Long>>,
        notes: String,
        purchaseType: String
    ) -> Unit,
    onSaveSupplier: (name: String, phone: String, address: String, contactPerson: String, notes: String) -> Unit = { _, _, _, _, _ -> },
    onSaveStorePartner: (name: String, phone: String, address: String, notes: String) -> Unit = { _, _, _, _ -> },
    onSaveProduct: (
        id: Long,
        name: String,
        sku: String,
        category: String,
        sellPrice: Long,
        costPrice: Long,
        stock: Int,
        unit: String,
        repackUnitsJson: String,
        tieredPricesJson: String
    ) -> Unit = { _, _, _, _, _, _, _, _, _, _ -> }
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(initialTab) }

    // Dialog states
    var showAddSupplierDialog by remember { mutableStateOf(false) }
    var showAddStorePartnerDialog by remember { mutableStateOf(false) }
    var showProductPickerForPurchase by remember { mutableStateOf(false) }
    var showCameraScannerForPurchase by remember { mutableStateOf(false) }
    var selectedDetailPurchase by remember { mutableStateOf<PurchaseRecord?>(null) }
    var productToEditFromPurchase by remember { mutableStateOf<Product?>(null) }
    // State untuk edit Qty & Satuan dari keranjang belanja/pembelian
    var purchaseEditQtyItem by remember { mutableStateOf<PurchaseItemEditState?>(null) }

    // ==========================================
    // 1. STATE: PEMBELIAN SUPPLIER
    // ==========================================
    var supInvoiceNumber by remember { mutableStateOf("FAK-SUP-${System.currentTimeMillis() % 100000}") }
    var selectedSupplier by remember { mutableStateOf<SupplierRecord?>(suppliers.firstOrNull()) }
    var supNameText by remember { mutableStateOf(suppliers.firstOrNull()?.name ?: "PT Sumber Makmur") }
    var supPhoneText by remember { mutableStateOf(suppliers.firstOrNull()?.phone ?: "08123456789") }
    var supPaymentType by remember { mutableStateOf("TUNAI") }
    var supNotes by remember { mutableStateOf("") }
    var supBarcodeInput by remember { mutableStateOf("") }
    val supPurchaseItems = remember { mutableStateListOf<Triple<Product, Int, Long>>() }
    var expandedSupDropdown by remember { mutableStateOf(false) }

    // ==========================================
    // 2. STATE: BELANJA TOKO
    // ==========================================
    var storeReceiptNumber by remember { mutableStateOf("STRUK-TOKO-${System.currentTimeMillis() % 100000}") }
    var selectedStorePartner by remember { mutableStateOf<StorePartnerRecord?>(storePartners.firstOrNull()) }
    var storeNameText by remember { mutableStateOf(storePartners.firstOrNull()?.name ?: "Pasar Induk Grosir") }
    var storePhoneText by remember { mutableStateOf(storePartners.firstOrNull()?.phone ?: "") }
    var storePaymentType by remember { mutableStateOf("TUNAI") }
    var storeNotes by remember { mutableStateOf("") }
    var storeBarcodeInput by remember { mutableStateOf("") }
    val storePurchaseItems = remember { mutableStateListOf<Triple<Product, Int, Long>>() }
    var expandedStoreDropdown by remember { mutableStateOf(false) }

    // ==========================================
    // 3. STATE: RIWAYAT BELANJA
    // ==========================================
    var historyFilterType by remember { mutableStateOf("SEMUA") }
    var historySearchQuery by remember { mutableStateOf("") }

    // Helper function to add product to current tab cart
    fun addProductToActiveTabCart(product: Product, defaultQty: Int = 1) {
        val targetList = if (selectedTab == 0) supPurchaseItems else storePurchaseItems
        val existingIndex = targetList.indexOfFirst { it.first.id == product.id }
        if (existingIndex >= 0) {
            val existing = targetList[existingIndex]
            targetList[existingIndex] = existing.copy(second = existing.second + defaultQty)
        } else {
            targetList.add(Triple(product, defaultQty, product.costPrice))
        }
        Toast.makeText(context, "${product.name} dimasukkan ke keranjang", Toast.LENGTH_SHORT).show()
    }

    // Helper function to handle barcode submission (dengan tombol enter atau keyboard)
    fun handleBarcodeSubmit(query: String) {
        val trimmed = query.trim()
        if (trimmed.isBlank()) return
        val matched = products.find {
            it.sku.equals(trimmed, ignoreCase = true) ||
            it.name.contains(trimmed, ignoreCase = true)
        }
        if (matched != null) {
            addProductToActiveTabCart(matched)
            if (selectedTab == 0) supBarcodeInput = "" else storeBarcodeInput = ""
        } else {
            Toast.makeText(context, "Produk dengan kode/nama \"$trimmed\" tidak ditemukan di katalog", Toast.LENGTH_LONG).show()
        }
    }

    // Helper function untuk input scan barcode otomatis (langsung tambah tanpa tekan enter)
    fun handleBarcodeInputChange(input: String, isSupplierTab: Boolean) {
        val cleanInput = input.replace("\r", "").replace("\n", "")
        val hasTrailingEnter = input.contains("\n") || input.contains("\r")
        val trimmed = cleanInput.trim()

        if (hasTrailingEnter && trimmed.isNotEmpty()) {
            val match = products.find {
                it.sku.equals(trimmed, ignoreCase = true) || it.name.equals(trimmed, ignoreCase = true)
            } ?: products.find { it.sku.contains(trimmed, ignoreCase = true) }
            if (match != null) {
                addProductToActiveTabCart(match)
                if (isSupplierTab) supBarcodeInput = "" else storeBarcodeInput = ""
                return
            }
        }

        // Cek kecocokan persis barcode / SKU secara otomatis tanpa harus tekan enter
        if (trimmed.isNotEmpty()) {
            val exactSkuMatch = products.find { it.sku.isNotBlank() && it.sku.equals(trimmed, ignoreCase = true) }
            if (exactSkuMatch != null) {
                addProductToActiveTabCart(exactSkuMatch)
                if (isSupplierTab) supBarcodeInput = "" else storeBarcodeInput = ""
                return
            }
        }

        if (isSupplierTab) {
            supBarcodeInput = cleanInput
        } else {
            storeBarcodeInput = cleanInput
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.94f)
                .padding(vertical = 6.dp)
                .testTag("purchase_management_dialog")
        ) {
            Column(modifier = Modifier.fillMaxSize().padding(14.dp)) {
                // Header Dialog
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(Color(0xFFEDE9FE), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.LocalShipping, contentDescription = null, tint = Color(0xFF7C3AED), modifier = Modifier.size(22.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Pengadaan & Pembelian Stok",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color(0xFF0F172A)
                            )
                            Text(
                                text = "Input produk mirip kasir, terhubung otomatis ke stok barang",
                                fontSize = 11.sp,
                                color = SlateMedium
                            )
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Navigation Tabs: 1. Pembelian Supplier | 2. Belanja Toko | 3. Riwayat Belanja
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color(0xFFF8FAFC),
                    contentColor = Color(0xFF7C3AED),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.LocalShipping, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Pembelian Supplier", fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal, fontSize = 12.sp)
                            }
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Store, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Belanja Toko", fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal, fontSize = 12.sp)
                            }
                        }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Riwayat Belanja", fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal, fontSize = 12.sp)
                            }
                        }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // =========================================================================
                // TAB 0: PEMBELIAN SUPPLIER
                // =========================================================================
                if (selectedTab == 0) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        // BARIS 1: Kolom Pengisian Nomor Faktur dan Nama Supplier (bisa tambah data supplier)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Kolom Nomor Faktur
                            OutlinedTextField(
                                value = supInvoiceNumber,
                                onValueChange = { supInvoiceNumber = it },
                                label = { Text("Nomor Faktur") },
                                colors = posOutlinedTextFieldColors(),
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f).testTag("purchase_invoice_input")
                            )

                            // Kolom Nama Supplier (Dropdown / Select + Tombol Tambah Supplier)
                            Box(modifier = Modifier.weight(1.5f)) {
                                ExposedDropdownMenuBox(
                                    expanded = expandedSupDropdown,
                                    onExpandedChange = { expandedSupDropdown = it }
                                ) {
                                    OutlinedTextField(
                                        value = supNameText,
                                        onValueChange = { supNameText = it },
                                        label = { Text("Nama Supplier") },
                                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedSupDropdown) },
                                        modifier = Modifier.menuAnchor().fillMaxWidth().testTag("supplier_name_input"),
                                        shape = RoundedCornerShape(8.dp),
                                        colors = posOutlinedTextFieldColors()
                                    )
                                    ExposedDropdownMenu(
                                        expanded = expandedSupDropdown,
                                        onDismissRequest = { expandedSupDropdown = false }
                                    ) {
                                        suppliers.forEach { sup ->
                                            DropdownMenuItem(
                                                text = {
                                                    Column {
                                                        Text(sup.name, fontWeight = FontWeight.Bold)
                                                        if (sup.phone.isNotBlank()) Text("Telp: ${sup.phone}", fontSize = 11.sp, color = SlateMedium)
                                                    }
                                                },
                                                onClick = {
                                                    selectedSupplier = sup
                                                    supNameText = sup.name
                                                    supPhoneText = sup.phone
                                                    expandedSupDropdown = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }

                            // Tombol Tambah Data Supplier Baru
                            Button(
                                onClick = { showAddSupplierDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                                modifier = Modifier.height(52.dp).testTag("add_supplier_button")
                            ) {
                                Icon(Icons.Default.PersonAdd, contentDescription = "Tambah Supplier", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Supplier", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // TEPAT DI BAWAHNYA: Kolom scan barcode, tombol kamera (icon saja), tombol produk, tombol enter
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Kolom Scan Barcode
                            OutlinedTextField(
                                value = supBarcodeInput,
                                onValueChange = { handleBarcodeInputChange(it, isSupplierTab = true) },
                                placeholder = { Text("Scan barcode / ketik SKU...", fontSize = 12.sp) },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = SlateMedium, modifier = Modifier.size(18.dp)) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                keyboardActions = KeyboardActions(onDone = { handleBarcodeSubmit(supBarcodeInput) }),
                                shape = RoundedCornerShape(8.dp),
                                colors = posOutlinedTextFieldColors(),
                                modifier = Modifier.weight(1f).testTag("purchase_barcode_input")
                            )

                            // Tombol Kamera (HANYA ICON KAMERA SAJA)
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFFEDE9FE),
                                border = BorderStroke(1.dp, Color(0xFFC4B5FD)),
                                modifier = Modifier
                                    .size(50.dp)
                                    .clickable { showCameraScannerForPurchase = true }
                                    .testTag("purchase_camera_button")
                            ) {
                                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                                    Icon(
                                        Icons.Default.PhotoCamera,
                                        contentDescription = "Scan Kamera",
                                        tint = Color(0xFF7C3AED),
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }

                            // Tombol Produk
                            Button(
                                onClick = { showProductPickerForPurchase = true },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6D28D9)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(50.dp).testTag("purchase_product_picker_button")
                            ) {
                                Icon(Icons.Default.ShoppingCart, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Produk", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            // Tombol Enter
                            Button(
                                onClick = { handleBarcodeSubmit(supBarcodeInput) },
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(50.dp).testTag("purchase_enter_button")
                            ) {
                                Text("Enter", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // DI BAWAHNYA KERANJANG BELANJA (MIRIP LAYAR KASIR)
                        // Klik nama produk -> membuka menu edit produk sesuai nama produk tersebut
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f).fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
                                // Table Header
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFFEDE9FE), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("No", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(24.dp), color = Color(0xFF5B21B6))
                                    Text("Nama Produk (Klik untuk Edit)", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.8f), color = Color(0xFF5B21B6))
                                    Text("Qty Masuk", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.1f), textAlign = TextAlign.Center, color = Color(0xFF5B21B6))
                                    Text("Harga Beli (Rp)", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.2f), textAlign = TextAlign.End, color = Color(0xFF5B21B6))
                                    Text("Subtotal", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.3f), textAlign = TextAlign.End, color = Color(0xFF5B21B6))
                                    Spacer(modifier = Modifier.width(36.dp))
                                }

                                if (supPurchaseItems.isEmpty()) {
                                    Box(
                                        modifier = Modifier.fillMaxSize(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = SlateLight, modifier = Modifier.size(36.dp))
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text("Keranjang belanja supplier masih kosong", fontSize = 12.sp, color = SlateMedium)
                                            Text("Scan barcode, klik tombol kamera, atau klik 'Produk' di atas", fontSize = 11.sp, color = SlateLight)
                                        }
                                    }
                                } else {
                                    LazyColumn(
                                        modifier = Modifier.fillMaxSize().padding(top = 4.dp),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        items(supPurchaseItems.indices.toList()) { idx ->
                                            val item = supPurchaseItems[idx]
                                            val p = item.first
                                            val qty = item.second
                                            val price = item.third
                                            val subtotal = qty * price

                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .background(Color.White, RoundedCornerShape(6.dp))
                                                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(6.dp))
                                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                                            ) {
                                                // No
                                                Text("${idx + 1}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(24.dp), color = SlateMedium)

                                                // Nama Produk -> KLIK UNTUK MENU EDIT PRODUK
                                                Row(
                                                    modifier = Modifier
                                                        .weight(1.8f)
                                                        .clickable { productToEditFromPurchase = p },
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Column {
                                                        Text(
                                                            text = p.name,
                                                            fontSize = 12.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color(0xFF1D4ED8),
                                                            maxLines = 1,
                                                            overflow = TextOverflow.Ellipsis
                                                        )
                                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                                            Icon(Icons.Default.Edit, contentDescription = null, tint = Color(0xFF2563EB), modifier = Modifier.size(10.dp))
                                                            Spacer(modifier = Modifier.width(2.dp))
                                                            Text("Klik untuk update harga/data", fontSize = 9.sp, color = Color(0xFF2563EB))
                                                        }
                                                    }
                                                }

                                                // Qty Masuk (- / +) & Satuan (Klik untuk ubah Qty & Satuan)
                                                Row(
                                                    modifier = Modifier.weight(1.1f),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.Center
                                                ) {
                                                    IconButton(
                                                        onClick = {
                                                             if (qty > 1) {
                                                                 supPurchaseItems[idx] = item.copy(second = qty - 1)
                                                             } else {
                                                                 supPurchaseItems.removeAt(idx)
                                                             }
                                                        },
                                                        modifier = Modifier.size(22.dp)
                                                    ) {
                                                        Text("-", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                                    }
                                                    Surface(
                                                        shape = RoundedCornerShape(4.dp),
                                                        color = Color(0xFFEFF6FF),
                                                        border = BorderStroke(0.5.dp, Color(0xFFBFDBFE)),
                                                        modifier = Modifier
                                                            .clickable {
                                                                purchaseEditQtyItem = PurchaseItemEditState(
                                                                    product = p,
                                                                    initialQty = qty,
                                                                    initialPrice = price,
                                                                    isSupplierTab = true
                                                                )
                                                            }
                                                            .padding(horizontal = 2.dp, vertical = 1.dp)
                                                    ) {
                                                        Text(
                                                            text = "$qty ${p.unit}",
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color(0xFF1D4ED8),
                                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                    IconButton(
                                                        onClick = {
                                                            supPurchaseItems[idx] = item.copy(second = qty + 1)
                                                        },
                                                        modifier = Modifier.size(22.dp)
                                                    ) {
                                                        Text("+", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                                    }
                                                }

                                                // Harga Beli Satuan (bisa diedit)
                                                Text(
                                                    text = PosRepository.formatRupiah(price),
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.SemiBold,
                                                    modifier = Modifier.weight(1.2f),
                                                    textAlign = TextAlign.End
                                                )

                                                // Subtotal
                                                Text(
                                                    text = PosRepository.formatRupiah(subtotal),
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = EmeraldPrimary,
                                                    modifier = Modifier.weight(1.3f),
                                                    textAlign = TextAlign.End
                                                )

                                                // Tombol Hapus
                                                IconButton(
                                                    onClick = { supPurchaseItems.removeAt(idx) },
                                                    modifier = Modifier.size(28.dp)
                                                ) {
                                                    Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = ErrorRed, modifier = Modifier.size(16.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // DI BAWAH KERANJANG BELANJA: Ringkasan Total & Tombol "Tambahkan Produk Pembelian & Simpan"
                        val totalSupQty = supPurchaseItems.sumOf { it.second }
                        val totalSupAmount = supPurchaseItems.sumOf { it.second * it.third }

                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFEDE9FE)),
                            border = BorderStroke(1.5.dp, Color(0xFFC4B5FD)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("Total Pembelian ($totalSupQty unit • ${supPurchaseItems.size} jenis):", fontSize = 12.sp, color = SlateMedium)
                                        Text(PosRepository.formatRupiah(totalSupAmount), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF5B21B6))
                                    }

                                    // Pilihan Metode Pembayaran
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                                        listOf("TUNAI", "TRANSFER", "TEMPO").forEach { pay ->
                                            FilterChip(
                                                selected = supPaymentType == pay,
                                                onClick = { supPaymentType = pay },
                                                label = { Text(pay, fontSize = 10.sp, fontWeight = if (supPaymentType == pay) FontWeight.Bold else FontWeight.Normal) }
                                            )
                                        }
                                    }
                                }

                                // Tombol Utama Simpan & Masukkan ke Stok
                                Button(
                                    onClick = {
                                        if (supPurchaseItems.isEmpty()) {
                                            Toast.makeText(context, "Keranjang belanja masih kosong! Silakan pilih atau scan produk terlebih dahulu.", Toast.LENGTH_SHORT).show()
                                            return@Button
                                        }
                                        if (supNameText.isBlank()) {
                                            Toast.makeText(context, "Nama supplier tidak boleh kosong!", Toast.LENGTH_SHORT).show()
                                            return@Button
                                        }
                                        onSubmitPurchase(
                                            supInvoiceNumber,
                                            supNameText,
                                            supPhoneText,
                                            supPaymentType,
                                            supPurchaseItems.toList(),
                                            supNotes,
                                            "SUPPLIER"
                                        )
                                        supPurchaseItems.clear()
                                        supInvoiceNumber = "FAK-SUP-${System.currentTimeMillis() % 100000}"
                                        supNotes = ""
                                        Toast.makeText(context, "Berhasil! Produk pembelian telah disimpan dan langsung ditambahkan ke stok barang.", Toast.LENGTH_LONG).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = EmeraldPrimary,
                                        disabledContainerColor = Color(0xFFA7F3D0)
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("save_purchase_supplier_button")
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(20.dp), tint = Color.White)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (supPurchaseItems.isEmpty()) "Tambahkan Produk Pembelian & Simpan (Pilih Barang Dulu)" else "Simpan & Tambahkan ${supPurchaseItems.size} Produk ke Stok",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }

                // =========================================================================
                // TAB 1: BELANJA TOKO (Sama persis dengan Pembelian Supplier, beda nama faktur/struk & toko)
                // =========================================================================
                else if (selectedTab == 1) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        // BARIS 1: Kolom Pengisian Nomor Struk dan Nama Toko (bisa tambah data toko)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Kolom Nomor Struk (menggantikan nomor faktur)
                            OutlinedTextField(
                                value = storeReceiptNumber,
                                onValueChange = { storeReceiptNumber = it },
                                label = { Text("Nomor Struk") },
                                colors = posOutlinedTextFieldColors(),
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f).testTag("store_receipt_input")
                            )

                            // Kolom Nama Toko (menggantikan nama supplier, dengan dropdown / select)
                            Box(modifier = Modifier.weight(1.5f)) {
                                ExposedDropdownMenuBox(
                                    expanded = expandedStoreDropdown,
                                    onExpandedChange = { expandedStoreDropdown = it }
                                ) {
                                    OutlinedTextField(
                                        value = storeNameText,
                                        onValueChange = { storeNameText = it },
                                        label = { Text("Nama Toko") },
                                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedStoreDropdown) },
                                        modifier = Modifier.menuAnchor().fillMaxWidth().testTag("store_name_input"),
                                        shape = RoundedCornerShape(8.dp),
                                        colors = posOutlinedTextFieldColors()
                                    )
                                    ExposedDropdownMenu(
                                        expanded = expandedStoreDropdown,
                                        onDismissRequest = { expandedStoreDropdown = false }
                                    ) {
                                        storePartners.forEach { sp ->
                                            DropdownMenuItem(
                                                text = {
                                                    Column {
                                                        Text(sp.name, fontWeight = FontWeight.Bold)
                                                        if (sp.address.isNotBlank()) Text(sp.address, fontSize = 11.sp, color = SlateMedium)
                                                    }
                                                },
                                                onClick = {
                                                    selectedStorePartner = sp
                                                    storeNameText = sp.name
                                                    storePhoneText = sp.phone
                                                    expandedStoreDropdown = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }

                            // Tombol Tambah Data Toko Baru
                            Button(
                                onClick = { showAddStorePartnerDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D)),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                                modifier = Modifier.height(52.dp).testTag("add_store_button")
                            ) {
                                Icon(Icons.Default.Store, contentDescription = "Tambah Toko", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Toko", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // TEPAT DI BAWAHNYA: Kolom scan barcode, tombol kamera (icon kamera saja), tombol produk, tombol enter
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Kolom Scan Barcode
                            OutlinedTextField(
                                value = storeBarcodeInput,
                                onValueChange = { handleBarcodeInputChange(it, isSupplierTab = false) },
                                placeholder = { Text("Scan barcode / ketik SKU...", fontSize = 12.sp) },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = SlateMedium, modifier = Modifier.size(18.dp)) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                keyboardActions = KeyboardActions(onDone = { handleBarcodeSubmit(storeBarcodeInput) }),
                                shape = RoundedCornerShape(8.dp),
                                colors = posOutlinedTextFieldColors(),
                                modifier = Modifier.weight(1f).testTag("store_barcode_input")
                            )

                            // Tombol Kamera (HANYA ICON KAMERA SAJA)
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFFDCFCE7),
                                border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                                modifier = Modifier
                                    .size(50.dp)
                                    .clickable { showCameraScannerForPurchase = true }
                                    .testTag("store_camera_button")
                            ) {
                                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                                    Icon(
                                        Icons.Default.PhotoCamera,
                                        contentDescription = "Scan Kamera",
                                        tint = Color(0xFF16A34A),
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }

                            // Tombol Produk
                            Button(
                                onClick = { showProductPickerForPurchase = true },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(50.dp).testTag("store_product_picker_button")
                            ) {
                                Icon(Icons.Default.ShoppingCart, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Produk", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            // Tombol Enter
                            Button(
                                onClick = { handleBarcodeSubmit(storeBarcodeInput) },
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(50.dp).testTag("store_enter_button")
                            ) {
                                Text("Enter", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // DI BAWAHNYA KERANJANG BELANJA (MIRIP LAYAR KASIR)
                        // Klik nama produk -> membuka menu edit produk sesuai nama produk tersebut
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f).fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
                                // Table Header
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFFDCFCE7), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("No", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(24.dp), color = Color(0xFF15803D))
                                    Text("Nama Produk (Klik untuk Edit)", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.8f), color = Color(0xFF15803D))
                                    Text("Qty Belanja", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.1f), textAlign = TextAlign.Center, color = Color(0xFF15803D))
                                    Text("Harga Beli (Rp)", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.2f), textAlign = TextAlign.End, color = Color(0xFF15803D))
                                    Text("Subtotal", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.3f), textAlign = TextAlign.End, color = Color(0xFF15803D))
                                    Spacer(modifier = Modifier.width(36.dp))
                                }

                                if (storePurchaseItems.isEmpty()) {
                                    Box(
                                        modifier = Modifier.fillMaxSize(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Icon(Icons.Default.Store, contentDescription = null, tint = SlateLight, modifier = Modifier.size(36.dp))
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text("Keranjang belanja toko masih kosong", fontSize = 12.sp, color = SlateMedium)
                                            Text("Scan barcode, klik kamera, atau klik 'Produk' di atas", fontSize = 11.sp, color = SlateLight)
                                        }
                                    }
                                } else {
                                    LazyColumn(
                                        modifier = Modifier.fillMaxSize().padding(top = 4.dp),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        items(storePurchaseItems.indices.toList()) { idx ->
                                            val item = storePurchaseItems[idx]
                                            val p = item.first
                                            val qty = item.second
                                            val price = item.third
                                            val subtotal = qty * price

                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .background(Color.White, RoundedCornerShape(6.dp))
                                                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(6.dp))
                                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                                            ) {
                                                // No
                                                Text("${idx + 1}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(24.dp), color = SlateMedium)

                                                // Nama Produk -> KLIK UNTUK MENU EDIT PRODUK
                                                Row(
                                                    modifier = Modifier
                                                        .weight(1.8f)
                                                        .clickable { productToEditFromPurchase = p },
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Column {
                                                        Text(
                                                            text = p.name,
                                                            fontSize = 12.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color(0xFF1D4ED8),
                                                            maxLines = 1,
                                                            overflow = TextOverflow.Ellipsis
                                                        )
                                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                                            Icon(Icons.Default.Edit, contentDescription = null, tint = Color(0xFF2563EB), modifier = Modifier.size(10.dp))
                                                            Spacer(modifier = Modifier.width(2.dp))
                                                            Text("Klik untuk update harga/data", fontSize = 9.sp, color = Color(0xFF2563EB))
                                                        }
                                                    }
                                                }

                                                // Qty Masuk (- / +) & Satuan (Klik untuk ubah Qty & Satuan)
                                                Row(
                                                    modifier = Modifier.weight(1.1f),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.Center
                                                ) {
                                                    IconButton(
                                                        onClick = {
                                                             if (qty > 1) {
                                                                 storePurchaseItems[idx] = item.copy(second = qty - 1)
                                                             } else {
                                                                 storePurchaseItems.removeAt(idx)
                                                             }
                                                        },
                                                        modifier = Modifier.size(22.dp)
                                                    ) {
                                                        Text("-", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                                    }
                                                    Surface(
                                                        shape = RoundedCornerShape(4.dp),
                                                        color = Color(0xFFEFF6FF),
                                                        border = BorderStroke(0.5.dp, Color(0xFFBFDBFE)),
                                                        modifier = Modifier
                                                            .clickable {
                                                                purchaseEditQtyItem = PurchaseItemEditState(
                                                                    product = p,
                                                                    initialQty = qty,
                                                                    initialPrice = price,
                                                                    isSupplierTab = false
                                                                )
                                                            }
                                                            .padding(horizontal = 2.dp, vertical = 1.dp)
                                                    ) {
                                                        Text(
                                                            text = "$qty ${p.unit}",
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color(0xFF1D4ED8),
                                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                    IconButton(
                                                        onClick = {
                                                            storePurchaseItems[idx] = item.copy(second = qty + 1)
                                                        },
                                                        modifier = Modifier.size(22.dp)
                                                    ) {
                                                        Text("+", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                                    }
                                                }

                                                // Harga Beli Satuan
                                                Text(
                                                    text = PosRepository.formatRupiah(price),
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.SemiBold,
                                                    modifier = Modifier.weight(1.2f),
                                                    textAlign = TextAlign.End
                                                )

                                                // Subtotal
                                                Text(
                                                    text = PosRepository.formatRupiah(subtotal),
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = EmeraldPrimary,
                                                    modifier = Modifier.weight(1.3f),
                                                    textAlign = TextAlign.End
                                                )

                                                // Tombol Hapus
                                                IconButton(
                                                    onClick = { storePurchaseItems.removeAt(idx) },
                                                    modifier = Modifier.size(28.dp)
                                                ) {
                                                    Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = ErrorRed, modifier = Modifier.size(16.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // DI BAWAH KERANJANG BELANJA: Ringkasan Total & Tombol "Tambahkan Belanja & Simpan"
                        val totalStoreQty = storePurchaseItems.sumOf { it.second }
                        val totalStoreAmount = storePurchaseItems.sumOf { it.second * it.third }

                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFDCFCE7)),
                            border = BorderStroke(1.5.dp, Color(0xFF86EFAC)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("Total Belanja Toko ($totalStoreQty unit • ${storePurchaseItems.size} jenis):", fontSize = 12.sp, color = SlateMedium)
                                        Text(PosRepository.formatRupiah(totalStoreAmount), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF15803D))
                                    }

                                    // Pilihan Metode Pembayaran
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                                        listOf("TUNAI", "TRANSFER", "TEMPO").forEach { pay ->
                                            FilterChip(
                                                selected = storePaymentType == pay,
                                                onClick = { storePaymentType = pay },
                                                label = { Text(pay, fontSize = 10.sp, fontWeight = if (storePaymentType == pay) FontWeight.Bold else FontWeight.Normal) }
                                            )
                                        }
                                    }
                                }

                                // Tombol Tambahkan Belanja & Simpan -> Otomatis Masuk ke Stok Barang
                                Button(
                                    onClick = {
                                        if (storePurchaseItems.isEmpty()) {
                                            Toast.makeText(context, "Keranjang belanja masih kosong! Silakan pilih atau scan produk terlebih dahulu.", Toast.LENGTH_SHORT).show()
                                            return@Button
                                        }
                                        if (storeNameText.isBlank()) {
                                            Toast.makeText(context, "Nama toko tidak boleh kosong!", Toast.LENGTH_SHORT).show()
                                            return@Button
                                        }
                                        onSubmitPurchase(
                                            storeReceiptNumber,
                                            storeNameText,
                                            storePhoneText,
                                            storePaymentType,
                                            storePurchaseItems.toList(),
                                            storeNotes,
                                            "STORE_PURCHASE"
                                        )
                                        storePurchaseItems.clear()
                                        storeReceiptNumber = "STRUK-TOKO-${System.currentTimeMillis() % 100000}"
                                        storeNotes = ""
                                        Toast.makeText(context, "Berhasil! Belanja toko telah disimpan dan langsung ditambahkan ke stok barang.", Toast.LENGTH_LONG).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = EmeraldPrimary,
                                        disabledContainerColor = Color(0xFFA7F3D0)
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("save_store_purchase_button")
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(20.dp), tint = Color.White)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (storePurchaseItems.isEmpty()) "Tambahkan Belanja & Simpan (Pilih Barang Dulu)" else "Simpan & Tambahkan ${storePurchaseItems.size} Produk ke Stok",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }

                // =========================================================================
                // TAB 2: RIWAYAT BELANJA (Melihat Riwayat & Menyimpan sebagai Dokumen)
                // =========================================================================
                else if (selectedTab == 2) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        // Filter & Pencarian
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = historySearchQuery,
                                onValueChange = { historySearchQuery = it },
                                placeholder = { Text("Cari no faktur/struk, supplier, toko...", fontSize = 11.sp) },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = SlateMedium, modifier = Modifier.size(16.dp)) },
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp),
                                colors = posOutlinedTextFieldColors(),
                                modifier = Modifier.weight(1f)
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                listOf("SEMUA", "SUPPLIER", "STORE_PURCHASE").forEach { type ->
                                    val label = when(type) {
                                        "SUPPLIER" -> "Supplier"
                                        "STORE_PURCHASE" -> "Belanja Toko"
                                        else -> "Semua"
                                    }
                                    FilterChip(
                                        selected = historyFilterType == type,
                                        onClick = { historyFilterType = type },
                                        label = { Text(label, fontSize = 10.sp) }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Filtered Records
                        val filteredHistory = remember(purchaseHistory, historyFilterType, historySearchQuery) {
                            purchaseHistory.filter { rec ->
                                val matchesType = when (historyFilterType) {
                                    "SUPPLIER" -> rec.purchaseType == "SUPPLIER"
                                    "STORE_PURCHASE" -> rec.purchaseType == "STORE_PURCHASE"
                                    else -> true
                                }
                                val matchesSearch = historySearchQuery.isBlank() ||
                                        rec.invoiceNumber.contains(historySearchQuery, ignoreCase = true) ||
                                        rec.supplierName.contains(historySearchQuery, ignoreCase = true) ||
                                        rec.receivedBy.contains(historySearchQuery, ignoreCase = true)

                                matchesType && matchesSearch
                            }
                        }

                        if (filteredHistory.isEmpty()) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.Description, contentDescription = null, tint = SlateLight, modifier = Modifier.size(40.dp))
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("Belum ada riwayat transaksi pengadaan", fontSize = 13.sp, color = SlateMedium)
                                }
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(filteredHistory) { rec ->
                                    val isStore = rec.purchaseType == "STORE_PURCHASE"
                                    Card(
                                        shape = RoundedCornerShape(10.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color.White),
                                        border = BorderStroke(1.dp, if (isStore) Color(0xFFBBF7D0) else Color(0xFFDDD6FE)),
                                        modifier = Modifier.fillMaxWidth().clickable { selectedDetailPurchase = rec }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Surface(
                                                        shape = RoundedCornerShape(4.dp),
                                                        color = if (isStore) Color(0xFFDCFCE7) else Color(0xFFEDE9FE)
                                                    ) {
                                                        Text(
                                                            text = if (isStore) "BELANJA TOKO" else "FAKTUR SUPPLIER",
                                                            fontSize = 9.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = if (isStore) Color(0xFF15803D) else Color(0xFF6D28D9),
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text(rec.invoiceNumber, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text("• " + PosRepository.formatTime(rec.timestamp), fontSize = 10.sp, color = SlateLight)
                                                }

                                                Spacer(modifier = Modifier.height(4.dp))

                                                Text(
                                                    text = "${if (isStore) "Toko/Pasar" else "Supplier"}: ${rec.supplierName}",
                                                    fontWeight = FontWeight.SemiBold,
                                                    fontSize = 12.sp,
                                                    color = SlateDark
                                                )

                                                // DICATAT PENGGUNA YANG MEMASUKKAN DATA SESUAI LOGIN AKTIF
                                                Text(
                                                    text = "Dicatat oleh (Login Aktif): ${rec.receivedBy.ifBlank { activeUserName }}",
                                                    fontSize = 10.sp,
                                                    color = Color(0xFF2563EB),
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                            }

                                            Column(horizontalAlignment = Alignment.End) {
                                                Text(
                                                    text = PosRepository.formatRupiah(rec.totalAmount),
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 14.sp,
                                                    color = if (isStore) EmeraldPrimary else Color(0xFF7C3AED)
                                                )
                                                Text(
                                                    text = "Metode: ${rec.paymentType}",
                                                    fontSize = 10.sp,
                                                    color = SlateMedium
                                                )
                                                Spacer(modifier = Modifier.height(4.dp))
                                                OutlinedButton(
                                                    onClick = { selectedDetailPurchase = rec },
                                                    shape = RoundedCornerShape(6.dp),
                                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                    modifier = Modifier.height(28.dp)
                                                ) {
                                                    Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(12.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("Dokumen", fontSize = 10.sp)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // =========================================================================
    // SUB-DIALOG 1: TAMBAH DATA SUPPLIER BARU
    // =========================================================================
    if (showAddSupplierDialog) {
        var newSupName by remember { mutableStateOf("") }
        var newSupPhone by remember { mutableStateOf("") }
        var newSupContact by remember { mutableStateOf("") }
        var newSupAddress by remember { mutableStateOf("") }
        var newSupNotes by remember { mutableStateOf("") }

        Dialog(onDismissRequest = { showAddSupplierDialog = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth().padding(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Tambah Data Supplier Baru", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color(0xFF5B21B6))
                        IconButton(onClick = { showAddSupplierDialog = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Tutup")
                        }
                    }
                    Text("Data tersimpan otomatis agar nanti mudah dipilih tanpa mengetik manual", fontSize = 11.sp, color = SlateMedium)

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = newSupName,
                        onValueChange = { newSupName = it },
                        label = { Text("Nama Supplier / PT / Distributor *") },
                        singleLine = true,
                        colors = posOutlinedTextFieldColors(),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().testTag("new_supplier_name_input")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = newSupPhone,
                        onValueChange = { newSupPhone = it },
                        label = { Text("No. Telepon / WhatsApp") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        colors = posOutlinedTextFieldColors(),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = newSupContact,
                        onValueChange = { newSupContact = it },
                        label = { Text("Nama PIC / Kontak Person") },
                        singleLine = true,
                        colors = posOutlinedTextFieldColors(),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = newSupAddress,
                        onValueChange = { newSupAddress = it },
                        label = { Text("Alamat Gudang / Kantor Supplier") },
                        singleLine = true,
                        colors = posOutlinedTextFieldColors(),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            if (newSupName.isNotBlank()) {
                                onSaveSupplier(newSupName.trim(), newSupPhone.trim(), newSupAddress.trim(), newSupContact.trim(), newSupNotes.trim())
                                supNameText = newSupName.trim()
                                supPhoneText = newSupPhone.trim()
                                showAddSupplierDialog = false
                                Toast.makeText(context, "Supplier \"$newSupName\" berhasil disimpan dan dipilih", Toast.LENGTH_SHORT).show()
                            }
                        },
                        enabled = newSupName.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().height(46.dp).testTag("save_new_supplier_button")
                    ) {
                        Text("Simpan Supplier", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // =========================================================================
    // SUB-DIALOG 2: TAMBAH DATA TOKO BARU (BELANJA TOKO)
    // =========================================================================
    if (showAddStorePartnerDialog) {
        var newStoreName by remember { mutableStateOf("") }
        var newStorePhone by remember { mutableStateOf("") }
        var newStoreAddress by remember { mutableStateOf("") }
        var newStoreNotes by remember { mutableStateOf("") }

        Dialog(onDismissRequest = { showAddStorePartnerDialog = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth().padding(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Tambah Data Mitra Toko / Grosir", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color(0xFF15803D))
                        IconButton(onClick = { showAddStorePartnerDialog = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Tutup")
                        }
                    }
                    Text("Data tersimpan otomatis agar nanti mudah dipilih tanpa mengetik manual", fontSize = 11.sp, color = SlateMedium)

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = newStoreName,
                        onValueChange = { newStoreName = it },
                        label = { Text("Nama Toko / Swalayan / Pasar *") },
                        singleLine = true,
                        colors = posOutlinedTextFieldColors(),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().testTag("new_store_name_input")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = newStorePhone,
                        onValueChange = { newStorePhone = it },
                        label = { Text("No. Telepon Toko (Opsional)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        colors = posOutlinedTextFieldColors(),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = newStoreAddress,
                        onValueChange = { newStoreAddress = it },
                        label = { Text("Alamat / Lokasi Toko") },
                        singleLine = true,
                        colors = posOutlinedTextFieldColors(),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            if (newStoreName.isNotBlank()) {
                                onSaveStorePartner(newStoreName.trim(), newStorePhone.trim(), newStoreAddress.trim(), newStoreNotes.trim())
                                storeNameText = newStoreName.trim()
                                storePhoneText = newStorePhone.trim()
                                showAddStorePartnerDialog = false
                                Toast.makeText(context, "Data toko \"$newStoreName\" berhasil disimpan dan dipilih", Toast.LENGTH_SHORT).show()
                            }
                        },
                        enabled = newStoreName.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().height(46.dp).testTag("save_new_store_button")
                    ) {
                        Text("Simpan Data Toko", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // =========================================================================
    // SUB-DIALOG 3: PILIH PRODUK DARI KATALOG UNTUK PEMBELIAN
    // =========================================================================
    if (showProductPickerForPurchase) {
        var pickerSearch by remember { mutableStateOf("") }
        val filteredPickerProducts = remember(products, pickerSearch) {
            if (pickerSearch.isBlank()) products else products.filter {
                it.name.contains(pickerSearch, ignoreCase = true) ||
                it.sku.contains(pickerSearch, ignoreCase = true) ||
                it.category.contains(pickerSearch, ignoreCase = true)
            }
        }

        Dialog(onDismissRequest = { showProductPickerForPurchase = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth(0.95f).fillMaxHeight(0.85f).padding(8.dp)
            ) {
                Column(modifier = Modifier.fillMaxSize().padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Pilih Produk untuk Pengadaan", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        IconButton(onClick = { showProductPickerForPurchase = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Tutup")
                        }
                    }

                    OutlinedTextField(
                        value = pickerSearch,
                        onValueChange = { pickerSearch = it },
                        placeholder = { Text("Cari nama produk, SKU, kategori...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        singleLine = true,
                        colors = posOutlinedTextFieldColors(),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val activeCart = if (selectedTab == 0) supPurchaseItems else storePurchaseItems
                        items(filteredPickerProducts) { p ->
                            val inCartItem = activeCart.find { it.first.id == p.id }
                            val inCartQty = inCartItem?.second ?: 0
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(if (inCartQty > 0) Color(0xFFF0FDF4) else Color(0xFFF8FAFC), RoundedCornerShape(8.dp))
                                    .border(
                                        width = if (inCartQty > 0) 1.5.dp else 1.dp,
                                        color = if (inCartQty > 0) EmeraldPrimary else Color(0xFFE2E8F0),
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .clickable {
                                        addProductToActiveTabCart(p)
                                    }
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(p.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("SKU: ${p.sku} • Stok saat ini: ${p.stock} ${p.unit}", fontSize = 11.sp, color = SlateMedium)
                                }
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = "Modal: ${PosRepository.formatRupiah(p.costPrice)}",
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 12.sp,
                                            color = EmeraldPrimary
                                        )
                                        if (inCartQty > 0) {
                                            Text(
                                                text = "Di Keranjang: $inCartQty ${p.unit}",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF15803D)
                                            )
                                        }
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (inCartQty > 0) EmeraldPrimary else Color(0xFFEDE9FE),
                                        modifier = Modifier.clickable { addProductToActiveTabCart(p) }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                Icons.Default.Add,
                                                contentDescription = null,
                                                tint = if (inCartQty > 0) Color.White else Color(0xFF6D28D9),
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(modifier = Modifier.width(2.dp))
                                            Text(
                                                text = if (inCartQty > 0) "Tambah" else "+ Masukkan",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (inCartQty > 0) Color.White else Color(0xFF6D28D9)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val totalActiveItems = (if (selectedTab == 0) supPurchaseItems else storePurchaseItems).sumOf { it.second }
                    Button(
                        onClick = { showProductPickerForPurchase = false },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().height(44.dp)
                    ) {
                        Text(
                            text = if (totalActiveItems > 0) "Selesai Memilih ($totalActiveItems Barang Dipilih)" else "Selesai Memilih",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }

    // =========================================================================
    // SUB-DIALOG 4: SCAN BARCODE MENGGUNAKAN KAMERA
    // =========================================================================
    if (showCameraScannerForPurchase) {
        CameraBarcodeScannerDialog(
            sampleProducts = products,
            onDismiss = { showCameraScannerForPurchase = false },
            onBarcodeScanned = { barcode ->
                showCameraScannerForPurchase = false
                handleBarcodeSubmit(barcode)
            }
        )
    }

    // =========================================================================
    // SUB-DIALOG 5: EDIT PRODUK LANGSUNG KETIKA NAMA PRODUK DI KERANJANG DIKLIK
    // =========================================================================
    productToEditFromPurchase?.let { prod ->
        ProductEditDialog(
            product = prod,
            onDismiss = { productToEditFromPurchase = null },
            onSave = { id, name, sku, category, sellPrice, costPrice, stock, unit, repackUnitsJson, tieredPricesJson ->
                onSaveProduct(id, name, sku, category, sellPrice, costPrice, stock, unit, repackUnitsJson, tieredPricesJson)

                // Update juga produk di keranjang pembelian aktif
                val updatedProduct = prod.copy(
                    name = name,
                    sku = sku,
                    category = category,
                    sellPrice = sellPrice,
                    costPrice = costPrice,
                    unit = unit,
                    repackUnitsJson = repackUnitsJson,
                    tieredPricesJson = tieredPricesJson
                )

                // Update cart items
                val supIdx = supPurchaseItems.indexOfFirst { it.first.id == id }
                if (supIdx >= 0) {
                    supPurchaseItems[supIdx] = supPurchaseItems[supIdx].copy(first = updatedProduct, third = costPrice)
                }
                val storeIdx = storePurchaseItems.indexOfFirst { it.first.id == id }
                if (storeIdx >= 0) {
                    storePurchaseItems[storeIdx] = storePurchaseItems[storeIdx].copy(first = updatedProduct, third = costPrice)
                }

                productToEditFromPurchase = null
                Toast.makeText(context, "Produk \"$name\" berhasil diperbarui", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // =========================================================================
    // SUB-DIALOG 6: DOKUMEN RIWAYAT LENGKAP & SIMPAN/BAGIKAN SEBAGAI DOKUMEN
    // =========================================================================
    selectedDetailPurchase?.let { rec ->
        PurchaseDocumentDetailDialog(
            purchase = rec,
            storeInfo = storeInfo,
            onDismiss = { selectedDetailPurchase = null }
        )
    }

    // =========================================================================
    // SUB-DIALOG 7: EDIT QTY DAN SATUAN ITEM PEMBELIAN / BELANJA
    // =========================================================================
    purchaseEditQtyItem?.let { editState ->
        PurchaseItemQtyDialog(
            editState = editState,
            onDismiss = { purchaseEditQtyItem = null },
            onConfirm = { newQty, newUnit, newPrice ->
                val targetList = if (editState.isSupplierTab) supPurchaseItems else storePurchaseItems
                val idx = targetList.indexOfFirst { it.first.id == editState.product.id }
                if (idx >= 0) {
                    val current = targetList[idx]
                    val updatedProduct = current.first.copy(unit = newUnit)
                    targetList[idx] = Triple(updatedProduct, newQty, newPrice)
                }
                purchaseEditQtyItem = null
                Toast.makeText(context, "${editState.product.name}: $newQty $newUnit", Toast.LENGTH_SHORT).show()
            }
        )
    }
}

/**
 * Dialog untuk mengisi/mengubah Qty dan Satuan serta Harga Beli pada saat Pembelian Supplier & Belanja Toko
 */
@Composable
fun PurchaseItemQtyDialog(
    editState: PurchaseItemEditState,
    onDismiss: () -> Unit,
    onConfirm: (newQty: Int, newUnit: String, newPrice: Long) -> Unit
) {
    val p = editState.product
    val repacks = remember(p.repackUnitsJson) { p.getRepackUnits() }

    var qtyText by remember { mutableStateOf(editState.initialQty.toString()) }
    val currentQty = (qtyText.toIntOrNull() ?: 1).coerceAtLeast(1)

    var selectedUnit by remember { mutableStateOf(p.unit) }
    var priceText by remember { mutableStateOf(editState.initialPrice.toString()) }
    val currentPrice = priceText.toLongOrNull() ?: editState.initialPrice
    val subtotal = currentQty * currentPrice

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("purchase_item_qty_dialog")
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (editState.isSupplierTab) "Isi Qty & Satuan Pembelian" else "Isi Qty & Satuan Belanja",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 16.sp,
                        color = Color(0xFF0F172A)
                    )
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup", tint = SlateMedium)
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = p.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Color(0xFF1D4ED8)
                )
                Text(
                    text = "SKU: ${p.sku.ifBlank { "-" }} | Satuan dasar: ${p.unit} | Stok saat ini: ${p.stock}",
                    fontSize = 11.sp,
                    color = Color(0xFF64748B)
                )

                Spacer(modifier = Modifier.height(14.dp))

                // 1. Pilihan Satuan (Satuan Dasar & Satuan Repack / Grosir)
                Text(
                    text = "Pilih Satuan Pengadaan:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF334155)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = selectedUnit.equals(p.unit, ignoreCase = true),
                        onClick = { selectedUnit = p.unit },
                        label = { Text(p.unit, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EmeraldPrimary.copy(alpha = 0.15f),
                            selectedLabelColor = EmeraldPrimary
                        )
                    )
                    repacks.forEach { rep ->
                        FilterChip(
                            selected = selectedUnit.equals(rep.unitName, ignoreCase = true),
                            onClick = { selectedUnit = rep.unitName },
                            label = { Text("${rep.unitName.uppercase()} (${rep.multiplier} ${p.unit})", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFFDBEAFE),
                                selectedLabelColor = Color(0xFF1D4ED8)
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 2. Input Kuantitas (Stepper & Text Input)
                Text(
                    text = "Jumlah (Qty):",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF334155)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Button(
                        onClick = {
                            val newQ = (currentQty - 1).coerceAtLeast(1)
                            qtyText = newQ.toString()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF1F5F9)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.size(44.dp)
                    ) {
                        Text("-", color = SlateDark, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    OutlinedTextField(
                        value = qtyText,
                        onValueChange = { input ->
                            val clean = input.filter { it.isDigit() }
                            qtyText = clean
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.width(90.dp),
                        textStyle = LocalTextStyle.current.copy(
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp,
                            color = Color(0xFF0F172A)
                        ),
                        colors = posOutlinedTextFieldColors()
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = {
                            val newQ = currentQty + 1
                            qtyText = newQ.toString()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF1F5F9)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.size(44.dp)
                    ) {
                        Text("+", color = SlateDark, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    }

                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = selectedUnit,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF334155)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 3. Input Harga Beli Satuan
                Text(
                    text = "Harga Beli per $selectedUnit:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF334155)
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = priceText,
                    onValueChange = { input ->
                        priceText = input.filter { it.isDigit() }
                    },
                    prefix = { Text("Rp ", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = SlateDark) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    colors = posOutlinedTextFieldColors()
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Ringkasan Subtotal
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFF8FAFC), RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Total Biaya Item:", fontSize = 12.sp, color = SlateDark)
                        Text(
                            text = PosRepository.formatRupiah(subtotal),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = EmeraldPrimary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Tombol Aksi Bawah
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Batal", color = SlateDark)
                    }
                    Button(
                        onClick = {
                            val finalQty = (qtyText.toIntOrNull() ?: 1).coerceAtLeast(1)
                            val finalPrice = priceText.toLongOrNull() ?: editState.initialPrice
                            onConfirm(finalQty, selectedUnit, finalPrice)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        modifier = Modifier.weight(1.3f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Simpan", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

/**
 * Dialog Dokumen Faktur Riwayat Pengadaan Lengkap (Dicatat oleh pengguna aktif, simpan sebagai dokumen / bagikan)
 */
@Composable
fun PurchaseDocumentDetailDialog(
    purchase: PurchaseRecord,
    storeInfo: LicenseInfo? = null,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val isStore = purchase.purchaseType == "STORE_PURCHASE"
    val docTitle = if (isStore) "DOKUMEN NOTA BELANJA TOKO" else "DOKUMEN FAKTUR PEMBELIAN SUPPLIER"

    // Parse items JSON
    val parsedItems = remember(purchase.itemsJson) {
        val list = mutableListOf<Triple<String, Int, Long>>()
        try {
            val arr = JSONArray(purchase.itemsJson)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val name = obj.optString("name", "Produk")
                val qty = obj.optInt("qty", 1)
                val buyPrice = obj.optLong("buyPrice", 0L)
                list.add(Triple(name, qty, buyPrice))
            }
        } catch (_: Exception) {}
        list
    }

    // Build document text
    val documentText = buildString {
        appendLine("==================================================")
        appendLine("       ${storeInfo?.storeName ?: "TOKO MODERN KASIR"}")
        if (!storeInfo?.storeAddress.isNullOrBlank()) {
            appendLine("       ${storeInfo?.storeAddress}")
        }
        appendLine("==================================================")
        appendLine("           $docTitle")
        appendLine("==================================================")
        appendLine("No. Dokumen    : ${purchase.invoiceNumber}")
        appendLine("Jenis          : ${if (isStore) "Belanja Toko (Operasional)" else "Pembelian Supplier"}")
        appendLine("Tanggal & Waktu: ${PosRepository.formatTime(purchase.timestamp)}")
        appendLine("${if (isStore) "Tempat Belanja" else "Supplier"}       : ${purchase.supplierName}")
        if (purchase.supplierPhone.isNotBlank()) {
            appendLine("No. Telepon    : ${purchase.supplierPhone}")
        }
        appendLine("Metode Bayar   : ${purchase.paymentType}")
        appendLine("Petugas Input  : ${purchase.receivedBy}")
        appendLine("--------------------------------------------------")
        appendLine("RINCIAN BARANG PENGADAAN:")
        parsedItems.forEachIndexed { idx, item ->
            val sub = item.second * item.third
            appendLine("${idx + 1}. ${item.first}")
            appendLine("   ${item.second} unit x ${PosRepository.formatRupiah(item.third)} = ${PosRepository.formatRupiah(sub)}")
        }
        appendLine("--------------------------------------------------")
        appendLine("TOTAL TAGIHAN  : ${PosRepository.formatRupiah(purchase.totalAmount)}")
        if (purchase.notes.isNotBlank()) {
            appendLine("Catatan        : ${purchase.notes}")
        }
        appendLine("==================================================")
        appendLine("Status: Stok barang telah otomatis masuk ke sistem.")
        appendLine("Dicatat oleh pengguna aktif: ${purchase.receivedBy}")
        appendLine("==================================================")
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.88f)
                .padding(vertical = 12.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                // Header Dokumen
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(docTitle, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = if (isStore) Color(0xFF15803D) else Color(0xFF7C3AED))
                        Text("No: ${purchase.invoiceNumber} • Dicatat: ${purchase.receivedBy}", fontSize = 11.sp, color = SlateMedium)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Tampilan Pratinjau Dokumen Lengkap
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(Color(0xFFF8FAFC), RoundedCornerShape(8.dp))
                        .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        item {
                            Text(
                                text = documentText,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = SlateDark,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Tombol Aksi Dokumen: Salin Teks & Simpan/Bagikan Dokumen
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("Dokumen Faktur", documentText)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "Teks dokumen faktur berhasil disalin!", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Salin Teks", fontSize = 11.sp)
                    }

                    Button(
                        onClick = {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "$docTitle - ${purchase.invoiceNumber}")
                                putExtra(Intent.EXTRA_TEXT, documentText)
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Simpan / Bagikan Dokumen Faktur"))
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = if (isStore) EmeraldPrimary else Color(0xFF7C3AED)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1.4f)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Simpan Dokumen", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
