package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.CartItem
import com.example.data.model.LicenseInfo
import com.example.data.model.MemberRecord
import com.example.data.model.PointSettings
import com.example.data.model.Product
import com.example.data.model.RepackUnit
import com.example.data.model.TieredPrice
import com.example.data.model.ShiftRecord
import com.example.data.repository.PosRepository
import com.example.ui.theme.AmberShift1
import com.example.ui.theme.BlueShift2
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.PurpleShift3
import com.example.ui.theme.SlateDark
import com.example.ui.theme.SlateLight
import com.example.ui.theme.SlateMedium
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.posOutlinedTextFieldColors

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StartShiftDialog(
    onDismiss: () -> Unit,
    onConfirm: (shiftNumber: Int, shiftName: String, cashierName: String, openingCash: Long, notes: String) -> Unit
) {
    val currentCalendar = remember { java.util.Calendar.getInstance() }
    val currentHour = currentCalendar.get(java.util.Calendar.HOUR_OF_DAY)
    val currentMinute = currentCalendar.get(java.util.Calendar.MINUTE)

    val currentValidShift = when (currentHour) {
        in 7..14 -> 1
        in 15..22 -> 2
        else -> 3
    }

    var selectedShift by remember { mutableIntStateOf(currentValidShift) }
    var cashierName by remember { mutableStateOf("Kasir 1") }
    var openingCashText by remember { mutableStateOf("200000") }
    var notes by remember { mutableStateOf("") }
    var validationError by remember { mutableStateOf<String?>(null) }

    val shiftOptions = listOf(
        Triple(1, "Shift 1 - Pagi", "07:00 - 15:00"),
        Triple(2, "Shift 2 - Siang/Sore", "15:00 - 23:00"),
        Triple(3, "Shift 3 - Malam", "23:00 - 07:00")
    )

    fun isShiftAllowed(shiftNum: Int): Boolean {
        return when (shiftNum) {
            1 -> currentHour in 7..14
            2 -> currentHour in 15..22
            3 -> currentHour in 23..23 || currentHour in 0..6
            else -> false
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth().padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Buka Shift Kasir",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Batal")
                    }
                }

                Text(
                    text = "Jam saat ini: ${String.format("%02d:%02d", currentHour, currentMinute)} WIB",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldPrimary
                )

                if (validationError != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = validationError!!,
                            color = Color(0xFFDC2626),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 3-Shift Radio Cards
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    shiftOptions.forEach { (num, name, time) ->
                        val isSelected = selectedShift == num
                        val isAllowed = isShiftAllowed(num)
                        val color = when (num) {
                            1 -> AmberShift1
                            2 -> BlueShift2
                            else -> PurpleShift3
                        }
                        Card(
                            onClick = {
                                selectedShift = num
                                if (!isAllowed) {
                                    validationError = "Shift $num ($time) ditolak! Waktu sekarang (${String.format("%02d:%02d", currentHour, currentMinute)}) di luar jadwal shift."
                                } else {
                                    validationError = null
                                }
                            },
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) color.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) color else Color(0xFFE2E8F0),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .testTag("select_shift_$num")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(color.copy(alpha = 0.2f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "$num",
                                        fontWeight = FontWeight.Bold,
                                        color = color,
                                        fontSize = 16.sp
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    Text(text = "Jam: $time • " + (if (isAllowed) "Jadwal Aktif Sekarang" else "Di Luar Jam Operasional"),
                                        fontSize = 12.sp,
                                        color = if (isAllowed) Color(0xFF16A34A) else Color(0xFFDC2626)
                                    )
                                }
                                if (isSelected) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = color)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = cashierName,
                    onValueChange = { cashierName = it },
                    label = { Text("Nama Kasir Bertugas") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("cashier_name_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = openingCashText,
                    onValueChange = { openingCashText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Modal Awal Kas (Laci)") },
                    leadingIcon = { Icon(Icons.Default.AccountBalanceWallet, contentDescription = null) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    supportingText = {
                        val amount = openingCashText.toLongOrNull() ?: 0L
                        Text("Terbaca: ${PosRepository.formatRupiah(amount)}")
                    },
                    modifier = Modifier.fillMaxWidth().testTag("opening_cash_input")
                )

                // Quick preset chips for modal awal
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    listOf(100000L, 200000L, 300000L, 500000L).forEach { preset ->
                        FilterChip(
                            selected = (openingCashText.toLongOrNull() == preset),
                            onClick = { openingCashText = preset.toString() },
                            label = { Text(PosRepository.formatRupiah(preset), fontSize = 11.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Catatan Buka Shift (Opsional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        if (!isShiftAllowed(selectedShift)) {
                            validationError = "Gagal membuka shift! Jam saat ini (${String.format("%02d:%02d", currentHour, currentMinute)} WIB) tidak sesuai dengan jadwal Shift $selectedShift. Anda hanya diperbolehkan membuka shift yang sesuai waktu operasional."
                            return@Button
                        }
                        val cash = openingCashText.toLongOrNull() ?: 0L
                        val shiftName = shiftOptions.first { it.first == selectedShift }.second
                        onConfirm(selectedShift, shiftName, cashierName, cash, notes)
                    },
                    enabled = isShiftAllowed(selectedShift),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldPrimary,
                        disabledContainerColor = Color(0xFFCBD5E1)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("confirm_start_shift_button")
                ) {
                    Text(
                        text = if (isShiftAllowed(selectedShift)) "Buka Shift Sekarang" else "Shift Tidak Diizinkan (Di Luar Jadwal)",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun CloseShiftDialog(
    activeShift: ShiftRecord,
    pendingCount: Int = 0,
    onDismiss: () -> Unit,
    onConfirm: (closingCash: Long, notes: String) -> Unit
) {
    var closingCashText by remember { mutableStateOf("${activeShift.expectedCash}") }
    var notes by remember { mutableStateOf("") }

    val actualCash = closingCashText.toLongOrNull() ?: 0L
    val difference = actualCash - activeShift.expectedCash

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth().padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Tutup Shift & Serah Terima",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Batal")
                    }
                }

                Text(
                    text = "Shift #${activeShift.shiftNumber} (${activeShift.cashierName})",
                    fontSize = 13.sp,
                    color = Color(0xFF475569)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Warning if there are pending carts
                if (pendingCount > 0) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "⛔ TIDAK BISA TUTUP SHIFT",
                                color = Color(0xFFDC2626),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Masih ada $pendingCount transaksi yang berstatus Pending (tertahan). Sesuai SOP kasir, semua transaksi pending harus diselesaikan (Recall & Bayar) atau dihapus sebelum tutup shift.",
                                color = Color(0xFF991B1B),
                                fontSize = 12.sp,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }

                // Summary stats of current shift
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F5F9)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        ShiftSummaryLine("Jam Mulai", PosRepository.formatTime(activeShift.startTime))
                        ShiftSummaryLine("Modal Awal Kas", PosRepository.formatRupiah(activeShift.openingCash))
                        ShiftSummaryLine("Total Transaksi", "${activeShift.totalTransactions} transaksi")
                        ShiftSummaryLine("Penjualan Tunai", PosRepository.formatRupiah(activeShift.totalCash))
                        ShiftSummaryLine("Penjualan Non-Tunai", PosRepository.formatRupiah(activeShift.totalNonCash))
                        ShiftSummaryLine("Total Omset Shift", PosRepository.formatRupiah(activeShift.totalSales), isBold = true)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(1.dp)
                                .background(Color(0xFFCBD5E1))
                        )
                        ShiftSummaryLine("Kas Seharusnya di Laci", PosRepository.formatRupiah(activeShift.expectedCash), isBold = true)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = closingCashText,
                    onValueChange = { closingCashText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Uang Fisik Kasir di Laci (Dihitung)") },
                    leadingIcon = { Icon(Icons.Default.AccountBalanceWallet, contentDescription = null) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("closing_cash_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Difference indicator
                val diffColor = when {
                    difference > 0 -> SuccessGreen
                    difference < 0 -> ErrorRed
                    else -> EmeraldPrimary
                }
                val diffText = when {
                    difference > 0 -> "Selisih LEBIH: +${PosRepository.formatRupiah(difference)}"
                    difference < 0 -> "Selisih KURANG: ${PosRepository.formatRupiah(difference)}"
                    else -> "Selisih PAS (Uang fisik sesuai target)"
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = diffColor.copy(alpha = 0.1f)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = diffText,
                        color = diffColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(10.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Catatan Serah Terima (Opsional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { onConfirm(actualCash, notes) },
                    enabled = pendingCount == 0,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldPrimary,
                        disabledContainerColor = Color(0xFFCBD5E1)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("confirm_close_shift_button")
                ) {
                    Text(
                        text = if (pendingCount > 0) "Selesaikan Pending Dulu ($pendingCount)" else "Tutup Shift Sekarang",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun ShiftSummaryLine(label: String, value: String, isBold: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 12.sp, color = Color(0xFF334155), fontWeight = if (isBold) FontWeight.SemiBold else FontWeight.Normal)
        Text(
            text = value,
            fontSize = 12.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Medium,
            color = if (isBold) Color(0xFF0F172A) else Color(0xFF1E293B)
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CheckoutDialog(
    cartItems: List<CartItem>,
    totalAmount: Long,
    member: MemberRecord? = null,
    pointSettings: PointSettings = PointSettings(),
    pointsToRedeem: Int = 0,
    licenseInfo: LicenseInfo = LicenseInfo(""),
    onPointsToRedeemChange: (Int) -> Unit = {},
    onDismiss: () -> Unit,
    onConfirmCheckout: (
        paymentMethod: String,
        paidAmount: Long,
        customerName: String,
        customerPhone: String,
        discount: Long,
        notes: String,
        dueDateDays: Int,
        shouldPrint: Boolean
    ) -> Unit
) {
    var paymentMethod by remember { mutableStateOf("TUNAI") }
    var customerName by remember { mutableStateOf(member?.name ?: "Pelanggan Umum") }
    var customerPhone by remember { mutableStateOf(member?.phone ?: "") }
    var discountText by remember { mutableStateOf("") }
    var paidAmountText by remember { mutableStateOf("$totalAmount") }
    var notes by remember { mutableStateOf("") }
    var dueDateDays by remember { mutableIntStateOf(14) }
    var shouldPrintReceipt by remember { mutableStateOf(true) }

    val rawDiscount = discountText.toLongOrNull() ?: 0L

    // Calculate Member Point Discount
    val pointDiscountValue = (pointsToRedeem * pointSettings.pointValueInRupiah)
    val maxAllowedBySetting = (totalAmount * pointSettings.maxRedeemPercentage) / 100
    val actualPointDiscount = pointDiscountValue.coerceAtMost(maxAllowedBySetting)

    val finalTotal = (totalAmount - rawDiscount - actualPointDiscount).coerceAtLeast(0L)
    val paidAmount = paidAmountText.toLongOrNull() ?: finalTotal
    val changeAmount = (paidAmount - finalTotal).coerceAtLeast(0L)

    val methods = listOf("TUNAI", "QRIS", "TRANSFER", "DEBIT", "PIUTANG")

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth().padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Pembayaran Kasir [F12]",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Batal")
                    }
                }

                // Total Tagihan Box
                Card(
                    colors = CardDefaults.cardColors(containerColor = EmeraldPrimary.copy(alpha = 0.1f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "TOTAL HARUS DIBAYAR", fontSize = 12.sp, color = SlateMedium, fontWeight = FontWeight.Bold)
                        Text(
                            text = PosRepository.formatRupiah(finalTotal),
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = EmeraldPrimary
                        )
                        if (actualPointDiscount > 0 || rawDiscount > 0) {
                            Text(
                                text = "Subtotal: ${PosRepository.formatRupiah(totalAmount)}" +
                                        (if (actualPointDiscount > 0) " | Potongan Poin: -${PosRepository.formatRupiah(actualPointDiscount)}" else "") +
                                        (if (rawDiscount > 0) " | Diskon: -${PosRepository.formatRupiah(rawDiscount)}" else ""),
                                fontSize = 11.sp,
                                color = Color(0xFF15803D),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                // Member Points Redemption Section
                if (member != null && member.points > 0) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Member: ${member.name} (${member.points} Poin)",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF92400E)
                                )
                                Text(
                                    text = "Tukar: ${PosRepository.formatRupiah(actualPointDiscount)}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFB45309)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Button(
                                    onClick = { onPointsToRedeemChange(0) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (pointsToRedeem == 0) Color(0xFFD97706) else Color(0xFFFDE68A)
                                    ),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.weight(1f).height(32.dp)
                                ) {
                                    Text("0 Poin", fontSize = 11.sp, color = if (pointsToRedeem == 0) Color.White else Color(0xFF78350F))
                                }
                                val halfPts = member.points / 2
                                if (halfPts > 0) {
                                    Button(
                                        onClick = { onPointsToRedeemChange(halfPts) },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (pointsToRedeem == halfPts) Color(0xFFD97706) else Color(0xFFFDE68A)
                                        ),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.weight(1f).height(32.dp)
                                    ) {
                                        Text("$halfPts Poin", fontSize = 11.sp, color = if (pointsToRedeem == halfPts) Color.White else Color(0xFF78350F))
                                    }
                                }
                                Button(
                                    onClick = { onPointsToRedeemChange(member.points) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (pointsToRedeem == member.points) Color(0xFFD97706) else Color(0xFFFDE68A)
                                    ),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.weight(1f).height(32.dp)
                                ) {
                                    Text("Semua (${member.points})", fontSize = 11.sp, color = if (pointsToRedeem == member.points) Color.White else Color(0xFF78350F))
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Payment Method Selector
                Text(text = "Metode Pembayaran", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    methods.forEach { method ->
                        val isSelected = paymentMethod == method
                        val chipColor = if (method == "PIUTANG") Color(0xFFDB2777) else EmeraldPrimary
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                paymentMethod = method
                                if (method != "TUNAI" && method != "PIUTANG") {
                                    paidAmountText = "$finalTotal"
                                } else if (method == "PIUTANG") {
                                    paidAmountText = "0"
                                }
                            },
                            label = {
                                Text(
                                    method,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = chipColor,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier.testTag("payment_method_$method")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Detail input per method
                if (paymentMethod == "TUNAI") {
                    OutlinedTextField(
                        value = paidAmountText,
                        onValueChange = { paidAmountText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Uang Diterima (Tunai)") },
                        colors = posOutlinedTextFieldColors(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("cash_paid_input")
                    )

                    // Quick cash chips
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(top = 6.dp)
                    ) {
                        FilterChip(
                            selected = (paidAmountText == "$finalTotal"),
                            onClick = { paidAmountText = "$finalTotal" },
                            label = { Text("Uang Pas", fontSize = 11.sp) }
                        )
                        listOf(20000L, 50000L, 100000L, 200000L, 500000L).forEach { amount ->
                            if (amount >= finalTotal) {
                                FilterChip(
                                    selected = (paidAmountText == "$amount"),
                                    onClick = { paidAmountText = "$amount" },
                                    label = { Text(PosRepository.formatRupiah(amount), fontSize = 11.sp) }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Change display
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFF1F5F9), RoundedCornerShape(8.dp))
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Kembalian:", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        Text(
                            text = PosRepository.formatRupiah(changeAmount),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (paidAmount < finalTotal) ErrorRed else SuccessGreen
                        )
                    }
                } else if (paymentMethod == "PIUTANG") {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF1F2)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "Pencatatan Piutang / Kasbon Pelanggan",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = Color(0xFF9F1239)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = paidAmountText,
                                onValueChange = { paidAmountText = it.filter { ch -> ch.isDigit() } },
                                label = { Text("Uang Muka / DP (Rp, 0 jika belum bayar)") },
                                colors = posOutlinedTextFieldColors(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            val remaining = (finalTotal - (paidAmountText.toLongOrNull() ?: 0L)).coerceAtLeast(0L)
                            Text(
                                text = "Sisa Hutang Pelanggan: ${PosRepository.formatRupiah(remaining)}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFE11D48)
                            )

                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Jatuh Tempo Pembayaran:", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(7 to "7 Hari", 14 to "14 Hari", 30 to "30 Hari").forEach { (days, label) ->
                                    FilterChip(
                                        selected = dueDateDays == days,
                                        onClick = { dueDateDays = days },
                                        label = { Text(label, fontSize = 11.sp) }
                                    )
                                }
                            }
                        }
                    }
                } else if (paymentMethod == "QRIS") {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                            .padding(4.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "QRIS STANDAR PEMBAYARAN NASIONAL",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = SlateDark
                            )
                            val merchant = licenseInfo.qrisMerchantName.ifBlank {
                                licenseInfo.storeName.ifBlank { "KASIR POS" }
                            }
                            Text(
                                text = merchant.uppercase(),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF0284C7)
                            )
                            if (licenseInfo.qrisNmid.isNotBlank()) {
                                Text(
                                    text = "NMID: ${licenseInfo.qrisNmid}",
                                    fontSize = 11.sp,
                                    color = SlateMedium,
                                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))

                            if (licenseInfo.qrisImageUri.isNotBlank()) {
                                Box(
                                    modifier = Modifier
                                        .size(190.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(8.dp))
                                        .background(Color.White),
                                    contentAlignment = Alignment.Center
                                ) {
                                    AsyncImage(
                                        model = licenseInfo.qrisImageUri,
                                        contentDescription = "Gambar Barcode QRIS",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Fit
                                    )
                                }
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(140.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFFF8FAFC)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.QrCode,
                                        contentDescription = "QRIS Code",
                                        tint = SlateDark,
                                        modifier = Modifier.size(100.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Belum ada gambar QRIS. Upload di Menu Pengaturan > Pengaturan Pembayaran",
                                    fontSize = 11.sp,
                                    color = Color(0xFFDC2626),
                                    textAlign = TextAlign.Center
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Bisa dipindai menggunakan GoPay, OVO, Dana, ShopeePay, BCA, Mandiri, BRI & semua m-Banking",
                                fontSize = 10.sp,
                                color = SlateMedium,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = customerName,
                        onValueChange = { customerName = it },
                        label = { Text("Nama Pelanggan") },
                        colors = posOutlinedTextFieldColors(),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = customerPhone,
                        onValueChange = { customerPhone = it },
                        label = { Text("No. HP / WA") },
                        colors = posOutlinedTextFieldColors(),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = discountText,
                        onValueChange = { discountText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Diskon Manual (Rp)") },
                        colors = posOutlinedTextFieldColors(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Catatan") },
                        colors = posOutlinedTextFieldColors(),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Pilihan Cetak Struk
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFF1F5F9), RoundedCornerShape(10.dp))
                        .clickable { shouldPrintReceipt = !shouldPrintReceipt }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Print,
                            contentDescription = null,
                            tint = if (shouldPrintReceipt) EmeraldPrimary else Color(0xFF64748B),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Cetak Struk Transaksi",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = SlateDark
                            )
                            Text(
                                text = if (shouldPrintReceipt) "Struk akan dicetak ke printer Bluetooth" else "Struk tidak akan dicetak (hemat kertas)",
                                fontSize = 11.sp,
                                color = SlateMedium
                            )
                        }
                    }
                    Switch(
                        checked = shouldPrintReceipt,
                        onCheckedChange = { shouldPrintReceipt = it }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                val canSubmit = when (paymentMethod) {
                    "TUNAI" -> paidAmount >= finalTotal
                    "PIUTANG" -> customerName.isNotBlank() && customerName != "Pelanggan Umum"
                    else -> true
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Tombol Lewati Cetak (Bayar Saja)
                    OutlinedButton(
                        onClick = {
                            val finalPaid = when (paymentMethod) {
                                "TUNAI" -> paidAmount
                                "PIUTANG" -> paidAmountText.toLongOrNull() ?: 0L
                                else -> finalTotal
                            }
                            onConfirmCheckout(
                                paymentMethod,
                                finalPaid,
                                customerName,
                                customerPhone,
                                rawDiscount,
                                notes,
                                dueDateDays,
                                false // Lewati Cetak
                            )
                        },
                        enabled = canSubmit,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("skip_print_checkout_button")
                    ) {
                        Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Lewati Cetak",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }

                    // Tombol Bayar & Cetak
                    Button(
                        onClick = {
                            val finalPaid = when (paymentMethod) {
                                "TUNAI" -> paidAmount
                                "PIUTANG" -> paidAmountText.toLongOrNull() ?: 0L
                                else -> finalTotal
                            }
                            onConfirmCheckout(
                                paymentMethod,
                                finalPaid,
                                customerName,
                                customerPhone,
                                rawDiscount,
                                notes,
                                dueDateDays,
                                shouldPrintReceipt // Mengikuti opsi struk
                            )
                        },
                        enabled = canSubmit,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (paymentMethod == "PIUTANG") Color(0xFFDB2777) else EmeraldPrimary
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1.3f)
                            .height(50.dp)
                            .testTag("confirm_checkout_button")
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (paymentMethod == "PIUTANG") "Simpan Piutang" else "Bayar & Cetak",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProductEditDialog(
    product: Product? = null,
    onDismiss: () -> Unit,
    onSave: (
        id: Long,
        name: String,
        sku: String,
        category: String,
        sellPrice: Long,
        costPrice: Long,
        stock: Int,
        unit: String,
        repackUnitsJson: String,
        tieredPricesJson: String
    ) -> Unit
) {
    var name by remember { mutableStateOf(product?.name ?: "") }
    var sku by remember { mutableStateOf(product?.sku ?: "") }
    var category by remember { mutableStateOf(product?.category ?: "Makanan") }
    var sellPriceText by remember { mutableStateOf(product?.sellPrice?.toString() ?: "") }
    var costPriceText by remember { mutableStateOf(product?.costPrice?.toString() ?: "") }
    var stockText by remember { mutableStateOf(product?.stock?.toString() ?: "50") }
    var unit by remember { mutableStateOf(product?.unit ?: "pcs") }

    // Repack and Tiered Price lists
    var repackList by remember { mutableStateOf(product?.getRepackUnits() ?: emptyList()) }
    var tieredList by remember { mutableStateOf(product?.getTieredPrices() ?: emptyList()) }

    // Repack form inputs
    var repackUnitName by remember { mutableStateOf("pack") }
    var repackMultiplierText by remember { mutableStateOf("10") }
    var repackPriceText by remember { mutableStateOf("") }

    // Tiered price form inputs
    var tieredMinQtyText by remember { mutableStateOf("3") }
    var tieredPriceText by remember { mutableStateOf("") }

    val categories = listOf("Makanan", "Minuman", "Snack", "Sembako", "Lainnya")
    val units = listOf("pcs", "cup", "porsi", "bungkus", "botol", "kg", "butir")
    val repackPresets = listOf("pack", "box", "dus", "bungkus", "slop", "bal", "renceng", "karton", "lusin")

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth().padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (product == null) "Tambah Produk Baru" else "Edit Produk",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Batal")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nama Produk *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("product_name_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = sku,
                    onValueChange = { sku = it },
                    label = { Text("SKU / Barcode (Opsional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text("Kategori", fontSize = 12.sp, color = SlateLight)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    categories.forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat, fontSize = 11.sp) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = sellPriceText,
                        onValueChange = { sellPriceText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Harga Jual Dasar (Rp) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("product_sell_price_input")
                    )
                    OutlinedTextField(
                        value = costPriceText,
                        onValueChange = { costPriceText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Harga Modal (HPP)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = stockText,
                        onValueChange = { stockText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Stok Awal ($unit)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = unit,
                        onValueChange = { unit = it },
                        label = { Text("Satuan Dasar") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // ==========================================
                // FITUR REPACK / SATUAN MULTI (Pack, Box, Dus, dll)
                // ==========================================
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                    border = CardDefaults.outlinedCardBorder(),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "📦 Fitur Repack / Satuan Kemasan",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color(0xFF0F172A)
                            )
                        }
                        Text(
                            text = "Jual produk dalam kemasan pack, box, dus, slop, dll. Penjualan otomatis memotong stok satuan dasar ($unit).",
                            fontSize = 11.sp,
                            color = Color(0xFF64748B),
                            lineHeight = 15.sp,
                            modifier = Modifier.padding(top = 2.dp, bottom = 8.dp)
                        )

                        // Quick presets
                        Text("Pilihan Cepat:", fontSize = 10.sp, color = Color(0xFF64748B), fontWeight = FontWeight.SemiBold)
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.padding(bottom = 6.dp)
                        ) {
                            repackPresets.forEach { preset ->
                                FilterChip(
                                    selected = repackUnitName.equals(preset, ignoreCase = true),
                                    onClick = { repackUnitName = preset },
                                    label = { Text(preset, fontSize = 10.sp) },
                                    shape = RoundedCornerShape(6.dp)
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            OutlinedTextField(
                                value = repackUnitName,
                                onValueChange = { repackUnitName = it },
                                label = { Text("Satuan Repack", fontSize = 10.sp) },
                                singleLine = true,
                                modifier = Modifier.weight(1.1f)
                            )
                            OutlinedTextField(
                                value = repackMultiplierText,
                                onValueChange = { repackMultiplierText = it.filter { ch -> ch.isDigit() } },
                                label = { Text("Isi ($unit)", fontSize = 10.sp) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(0.9f)
                            )
                            OutlinedTextField(
                                value = repackPriceText,
                                onValueChange = { repackPriceText = it.filter { ch -> ch.isDigit() } },
                                label = { Text("Harga (Rp)", fontSize = 10.sp) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(1.2f)
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Button(
                            onClick = {
                                val mult = repackMultiplierText.toIntOrNull() ?: 1
                                val price = repackPriceText.toLongOrNull() ?: 0L
                                if (repackUnitName.isNotBlank() && mult > 0 && price > 0L) {
                                    val filtered = repackList.filterNot { it.unitName.equals(repackUnitName, ignoreCase = true) }
                                    repackList = filtered + RepackUnit(
                                        unitName = repackUnitName.trim().lowercase(),
                                        multiplier = mult,
                                        sellPrice = price
                                    )
                                    repackPriceText = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth().height(36.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Tambah Satuan Repack", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        if (repackList.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Daftar Satuan Repack Aktif:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF334155))
                            Spacer(modifier = Modifier.height(4.dp))
                            repackList.forEach { rep ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color.White),
                                    border = CardDefaults.outlinedCardBorder(),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(
                                                text = "1 ${rep.unitName.uppercase()} = ${rep.multiplier} $unit",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = Color(0xFF0F172A)
                                            )
                                            Text(
                                                text = "Harga: ${PosRepository.formatRupiah(rep.sellPrice)}",
                                                fontSize = 11.sp,
                                                color = Color(0xFF0284C7),
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                        IconButton(
                                            onClick = {
                                                repackList = repackList.filterNot { it.unitName == rep.unitName }
                                            },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = ErrorRed, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // ==========================================
                // HARGA GROSIR BERTINGKAT (Tiered Pricing)
                // ==========================================
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB)),
                    border = CardDefaults.outlinedCardBorder(),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "🏷️ Pengaturan Otomatis Harga Grosir Bertingkat",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFF92400E)
                        )
                        Text(
                            text = "Pengaturan otomatis jika pembeli membeli sejumlah kuantitas, harga per unit dasar ($unit) otomatis berubah lebih murah.",
                            fontSize = 11.sp,
                            color = Color(0xFFB45309),
                            lineHeight = 15.sp,
                            modifier = Modifier.padding(top = 2.dp, bottom = 8.dp)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            OutlinedTextField(
                                value = tieredMinQtyText,
                                onValueChange = { tieredMinQtyText = it.filter { ch -> ch.isDigit() } },
                                label = { Text("Minimal Beli (Qty)", fontSize = 10.sp) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = tieredPriceText,
                                onValueChange = { tieredPriceText = it.filter { ch -> ch.isDigit() } },
                                label = { Text("Harga Satuan (Rp)", fontSize = 10.sp) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(1.3f)
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Button(
                            onClick = {
                                val minQ = tieredMinQtyText.toIntOrNull() ?: 1
                                val p = tieredPriceText.toLongOrNull() ?: 0L
                                if (minQ > 1 && p > 0L) {
                                    val filtered = tieredList.filterNot { it.minQty == minQ }
                                    tieredList = (filtered + TieredPrice(minQty = minQ, unitPrice = p)).sortedBy { it.minQty }
                                    tieredPriceText = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth().height(36.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Tambah Aturan Grosir", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        if (tieredList.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Aturan Grosir Aktif:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF78350F))
                            Spacer(modifier = Modifier.height(4.dp))
                            tieredList.forEach { tp ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color.White),
                                    border = CardDefaults.outlinedCardBorder(),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(
                                                text = "Beli minimal ≥ ${tp.minQty} $unit",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = Color(0xFF0F172A)
                                            )
                                            Text(
                                                text = "Harga: ${PosRepository.formatRupiah(tp.unitPrice)} / $unit",
                                                fontSize = 11.sp,
                                                color = Color(0xFFD97706),
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                        IconButton(
                                            onClick = {
                                                tieredList = tieredList.filterNot { it.minQty == tp.minQty }
                                            },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = ErrorRed, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        val sell = sellPriceText.toLongOrNull() ?: 0L
                        val cost = costPriceText.toLongOrNull() ?: 0L
                        val stk = stockText.toIntOrNull() ?: 0
                        val repackJson = Product.encodeRepackUnits(repackList)
                        val tieredJson = Product.encodeTieredPrices(tieredList)
                        onSave(product?.id ?: 0L, name, sku, category, sell, cost, stk, unit, repackJson, tieredJson)
                    },
                    enabled = name.isNotBlank() && (sellPriceText.toLongOrNull() ?: 0L) > 0L,
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("save_product_button")
                ) {
                    Text("Simpan Produk", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
