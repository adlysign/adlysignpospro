package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.AssignmentReturn
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sell
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Product
import com.example.data.repository.PosRepository
import com.example.ui.components.ProductEditDialog
import com.example.ui.components.PriceTagLabelDialog
import com.example.ui.components.ProductReturnDialog
import com.example.ui.components.ReceivableDialog
import com.example.ui.components.StockOpnameDialog
import com.example.ui.components.SupplierPurchaseDialog
import com.example.ui.theme.AmberShift1
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SlateDark
import com.example.ui.theme.SlateLight
import com.example.ui.theme.posOutlinedTextFieldColors
import com.example.ui.theme.SlateMedium
import com.example.ui.theme.SuccessGreen
import com.example.ui.viewmodel.PosViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProductsScreen(viewModel: PosViewModel) {
    val products by viewModel.filteredProducts.collectAsStateWithLifecycle()
    val allRawProducts by viewModel.rawProducts.collectAsStateWithLifecycle()
    val categories by viewModel.categories.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()

    var productToEdit by remember { mutableStateOf<Product?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }
    var productToDelete by remember { mutableStateOf<Product?>(null) }

    val stockOpnames by viewModel.stockOpnames.collectAsStateWithLifecycle()
    val soTasks by viewModel.stockOpnameTasks.collectAsStateWithLifecycle()
    val licenseInfo by viewModel.licenseInfo.collectAsStateWithLifecycle()
    val purchaseRecords by viewModel.purchaseRecords.collectAsStateWithLifecycle()
    val receivables by viewModel.receivables.collectAsStateWithLifecycle()
    val allSuppliers by viewModel.allSuppliers.collectAsStateWithLifecycle()
    val allStorePartners by viewModel.allStorePartners.collectAsStateWithLifecycle()
    val allTransactions by viewModel.allTransactions.collectAsStateWithLifecycle()
    val currentEmployee by viewModel.currentEmployee.collectAsStateWithLifecycle()
    val isCashier = currentEmployee?.role == "KASIR"

    var showStockOpnameDialog by remember { mutableStateOf(false) }
    var showPurchaseDialog by remember { mutableStateOf(false) }
    var purchaseDialogInitialTab by remember { mutableIntStateOf(0) }
    var showReceivableDialog by remember { mutableStateOf(false) }
    var showReturnDialog by remember { mutableStateOf(false) }
    var showPriceLabelDialog by remember { mutableStateOf(false) }
    var productForLabel by remember { mutableStateOf<Product?>(null) }

    val totalSku = allRawProducts.size
    val totalAssetValue = allRawProducts.sumOf { it.costPrice * it.stock }
    val lowStockCount = allRawProducts.count { it.stock <= 10 }

    Scaffold(
        floatingActionButton = {
            if (!isCashier) {
                FloatingActionButton(
                    onClick = { showAddDialog = true },
                    containerColor = EmeraldPrimary,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("add_product_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Tambah Produk")
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFFF8FAFC))
        ) {
            // Header & Inventory Summary
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Katalog & Manajemen Stok",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Kelola produk, varian harga, & pergerakan stok",
                                fontSize = 11.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    // 3 KPI Cards
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        InventoryKpiCard(
                            label = "Total SKU",
                            value = "$totalSku produk",
                            modifier = Modifier.weight(1f)
                        )
                        InventoryKpiCard(
                            label = "Nilai Stok",
                            value = PosRepository.formatRupiah(totalAssetValue),
                            modifier = Modifier.weight(1.3f)
                        )
                        InventoryKpiCard(
                            label = "Stok Menipis",
                            value = "$lowStockCount produk",
                            isWarning = lowStockCount > 0,
                            modifier = Modifier.weight(1.1f)
                        )
                    }

                    // Operational Menus: Stok Opname, Pembelian Barang, Piutang, and Retur
                    // Hidden if current user is Cashier
                    if (!isCashier) {
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Menu 1: Stok Opname
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Color(0xFFFEF3C7),
                                border = BorderStroke(1.dp, Color(0xFFF59E0B)),
                                modifier = Modifier
                                    .clickable { showStockOpnameDialog = true }
                                    .testTag("products_menu_stok_opname")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Inventory, contentDescription = null, tint = Color(0xFFB45309), modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Stok Opname", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF78350F))
                                }
                            }

                            // Menu 2: Pembelian Supplier
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Color(0xFFEDE9FE),
                                border = BorderStroke(1.dp, Color(0xFF8B5CF6)),
                                modifier = Modifier
                                    .clickable {
                                        purchaseDialogInitialTab = 0
                                        showPurchaseDialog = true
                                    }
                                    .testTag("products_menu_pembelian_supplier")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.LocalShipping, contentDescription = null, tint = Color(0xFF6D28D9), modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Pembelian Supplier", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF5B21B6))
                                }
                            }

                            // Menu 3: Belanja Toko
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Color(0xFFDCFCE7),
                                border = BorderStroke(1.dp, Color(0xFF22C55E)),
                                modifier = Modifier
                                    .clickable {
                                        purchaseDialogInitialTab = 1
                                        showPurchaseDialog = true
                                    }
                                    .testTag("products_menu_belanja_toko")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Store, contentDescription = null, tint = Color(0xFF15803D), modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Belanja Toko", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF14532D))
                                }
                            }

                            // Menu 4: Riwayat Belanja & Dokumen
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Color(0xFFDBEAFE),
                                border = BorderStroke(1.dp, Color(0xFF3B82F6)),
                                modifier = Modifier
                                    .clickable {
                                        purchaseDialogInitialTab = 2
                                        showPurchaseDialog = true
                                    }
                                    .testTag("products_menu_riwayat_belanja")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Description, contentDescription = null, tint = Color(0xFF1D4ED8), modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Riwayat Belanja", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E40AF))
                                }
                            }

                            // Menu 3: Piutang Pelanggan
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Color(0xFFFCE7F3),
                                border = BorderStroke(1.dp, Color(0xFFEC4899)),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { showReceivableDialog = true }
                                    .testTag("products_menu_piutang")
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = Color(0xFFBE185D), modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("Buku Piutang", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF9D174D), maxLines = 1)
                                }
                            }

                            // Menu 4: Retur Barang
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Color(0xFFEDE9FE),
                                border = BorderStroke(1.dp, Color(0xFF8B5CF6)),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { showReturnDialog = true }
                                    .testTag("products_menu_retur")
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.AssignmentReturn, contentDescription = null, tint = Color(0xFF6D28D9), modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("Retur", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF5B21B6), maxLines = 1)
                                }
                            }

                            // Menu 5: Cetak Label Harga Rak
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Color(0xFFD1FAE5),
                                border = BorderStroke(1.dp, Color(0xFF10B981)),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        productForLabel = null
                                        showPriceLabelDialog = true
                                    }
                                    .testTag("products_menu_cetak_label")
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(Icons.Default.Sell, contentDescription = null, tint = Color(0xFF047857), modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("Cetak Label", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF065F46), maxLines = 1)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Search Field
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { viewModel.searchQuery.value = it },
                        placeholder = { Text("Cari produk berdasarkan nama atau SKU...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = SlateLight) },
                        colors = posOutlinedTextFieldColors(),
                        trailingIcon = {
                            if (searchQuery.isNotBlank()) {
                                IconButton(onClick = { viewModel.searchQuery.value = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                    )

                    // Categories Filter
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(top = 8.dp)
                    ) {
                        categories.forEach { cat ->
                            val isSelected = selectedCategory == cat
                            FilterChip(
                                selected = isSelected,
                                onClick = { viewModel.selectedCategory.value = cat },
                                label = { Text(cat, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = EmeraldPrimary,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }
            }

            // Products List
            if (products.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.Inventory2,
                            contentDescription = null,
                            modifier = Modifier.size(64.dp),
                            tint = Color(0xFFCBD5E1)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Tidak ada produk dalam kategori ini", color = SlateMedium)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(products, key = { it.id }) { product ->
                        ProductListItem(
                            product = product,
                            canManage = !isCashier,
                            onPrintLabel = {
                                productForLabel = product
                                showPriceLabelDialog = true
                            },
                            onEdit = { productToEdit = product },
                            onDelete = { productToDelete = product }
                        )
                    }
                }
            }
        }
    }

    // Add Product Dialog
    if (showAddDialog && !isCashier) {
        ProductEditDialog(
            product = null,
            onDismiss = { showAddDialog = false },
            onSave = { _, name, sku, category, sellPrice, costPrice, stock, unit, repackUnitsJson, tieredPricesJson ->
                viewModel.saveProduct(
                    name = name,
                    sku = sku,
                    category = category,
                    sellPrice = sellPrice,
                    costPrice = costPrice,
                    stock = stock,
                    unit = unit,
                    repackUnitsJson = repackUnitsJson,
                    tieredPricesJson = tieredPricesJson
                )
                showAddDialog = false
            }
        )
    }

    // Edit Product Dialog
    if (!isCashier) {
        productToEdit?.let { product ->
            ProductEditDialog(
                product = product,
                onDismiss = { productToEdit = null },
                onSave = { id, name, sku, category, sellPrice, costPrice, stock, unit, repackUnitsJson, tieredPricesJson ->
                    viewModel.saveProduct(
                        id = id,
                        name = name,
                        sku = sku,
                        category = category,
                        sellPrice = sellPrice,
                        costPrice = costPrice,
                        stock = stock,
                        unit = unit,
                        repackUnitsJson = repackUnitsJson,
                        tieredPricesJson = tieredPricesJson
                    )
                    productToEdit = null
                }
            )
        }
    }

    // Delete Confirmation
    if (!isCashier) {
        productToDelete?.let { prod ->
            AlertDialog(
                onDismissRequest = { productToDelete = null },
                title = { Text("Hapus Produk") },
                text = { Text("Yakin ingin menghapus produk \"${prod.name}\"?") },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.deleteProduct(prod)
                            productToDelete = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                    ) {
                        Text("Hapus")
                    }
                },
                dismissButton = {
                    OutlinedButton(onClick = { productToDelete = null }) {
                        Text("Batal")
                    }
                }
            )
        }
    }

    // Stock Opname Dialog
    if (showStockOpnameDialog && !isCashier) {
        StockOpnameDialog(
            products = allRawProducts,
            history = stockOpnames,
            tasks = soTasks,
            storeInfo = licenseInfo,
            onDismiss = { showStockOpnameDialog = false },
            onFinalizeTask = { taskCode, title, notes, items, onSuccess ->
                viewModel.finalizeStockOpnameBatch(taskCode, title, notes, items, onSuccess)
            }
        )
    }

    // Supplier Purchase & Store Shopping Dialog
    if (showPurchaseDialog && !isCashier) {
        SupplierPurchaseDialog(
            products = allRawProducts,
            purchaseHistory = purchaseRecords,
            suppliers = allSuppliers,
            storePartners = allStorePartners,
            initialTab = purchaseDialogInitialTab,
            activeUserName = currentEmployee?.name ?: "Admin/Owner",
            storeInfo = licenseInfo,
            onDismiss = { showPurchaseDialog = false },
            onSubmitPurchase = { invoice, supplier, phone, payType, items, notes, purchaseType ->
                viewModel.submitSupplierPurchase(invoice, supplier, phone, payType, items, notes, purchaseType)
            },
            onSaveSupplier = { name, phone, address, contact, notes ->
                viewModel.saveSupplier(name, phone, address, contact, notes)
            },
            onSaveStorePartner = { name, phone, address, notes ->
                viewModel.saveStorePartner(name, phone, address, notes)
            },
            onSaveProduct = { id, name, sku, category, sellPrice, costPrice, stock, unit, repackUnitsJson, tieredPricesJson ->
                viewModel.saveProduct(
                    id = id,
                    name = name,
                    sku = sku,
                    category = category,
                    sellPrice = sellPrice,
                    costPrice = costPrice,
                    stock = stock,
                    unit = unit,
                    repackUnitsJson = repackUnitsJson,
                    tieredPricesJson = tieredPricesJson
                )
            }
        )
    }

    // Receivable Dialog
    if (showReceivableDialog && !isCashier) {
        ReceivableDialog(
            receivables = receivables,
            onDismiss = { showReceivableDialog = false },
            onPayReceivable = { id, amount ->
                viewModel.payReceivable(id, amount)
            }
        )
    }

    // Return (Retur) Dialog
    if (showReturnDialog && !isCashier) {
        ProductReturnDialog(
            products = allRawProducts,
            transactions = allTransactions,
            onDismiss = { showReturnDialog = false },
            onSubmitReturn = { productId, productName, qty, returnType, reason, customerOrSupplier, notes ->
                viewModel.submitProductReturn(
                    productId = productId,
                    productName = productName,
                    qty = qty,
                    returnType = returnType,
                    reason = reason,
                    customerOrSupplier = customerOrSupplier,
                    notes = notes
                )
            },
            onVoidTransactionForReturn = { tx, reasonStr ->
                viewModel.voidTransaction(
                    transaction = tx,
                    reason = reasonStr,
                    authorizedByName = currentEmployee?.name ?: "Supervisor"
                )
            }
        )
    }

    // Price Tag Label Dialog
    if (showPriceLabelDialog) {
        PriceTagLabelDialog(
            products = allRawProducts,
            storeInfo = licenseInfo,
            initialSelectedProduct = productForLabel,
            onDismiss = {
                showPriceLabelDialog = false
                productForLabel = null
            },
            onPrintBluetooth = { items, model ->
                viewModel.printPriceLabels(items, model)
            }
        )
    }
}

@Composable
private fun InventoryKpiCard(
    label: String,
    value: String,
    isWarning: Boolean = false,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isWarning) Color(0xFFFEF2F2) else Color(0xFFF1F5F9)
        ),
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(text = label, fontSize = 11.sp, color = if (isWarning) ErrorRed else SlateLight)
            Text(
                text = value,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = if (isWarning) ErrorRed else SlateDark
            )
        }
    }
}

@Composable
private fun ProductListItem(
    product: Product,
    canManage: Boolean,
    onPrintLabel: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val margin = product.sellPrice - product.costPrice

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
            .clickable { onEdit() }
            .testTag("product_list_item_${product.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = product.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = SlateDark,
                        modifier = Modifier.clickable { onEdit() }
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "• ${product.category}",
                        fontSize = 12.sp,
                        color = SlateLight
                    )
                }

                if (product.sku.isNotBlank()) {
                    Text(
                        text = "SKU: ${product.sku}",
                        fontSize = 11.sp,
                        color = SlateLight
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Jual: ${PosRepository.formatRupiah(product.sellPrice)}",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        color = EmeraldPrimary
                    )
                    if (product.costPrice > 0) {
                        Text(
                            text = "Modal: ${PosRepository.formatRupiah(product.costPrice)}",
                            fontSize = 12.sp,
                            color = SlateLight
                        )
                        Text(
                            text = "Margin: +${PosRepository.formatRupiah(margin)}",
                            fontSize = 12.sp,
                            color = SuccessGreen
                        )
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                val isLow = product.stock <= 10
                Text(
                    text = "Stok: ${product.stock} ${product.unit}",
                    fontWeight = if (isLow) FontWeight.Bold else FontWeight.Medium,
                    fontSize = 12.sp,
                    color = if (isLow) ErrorRed else SlateMedium
                )

                val repacks = remember(product.repackUnitsJson) { product.getRepackUnits() }
                if (repacks.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Satuan Repack: " + repacks.joinToString(", ") { "${it.unitName.uppercase()} (${it.multiplier} ${product.unit})" },
                        fontSize = 10.sp,
                        color = Color(0xFF0284C7),
                        fontWeight = FontWeight.SemiBold
                    )
                }

                val tiers = remember(product.tieredPricesJson) { product.getTieredPrices() }
                if (tiers.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Grosir Otomatis: " + tiers.joinToString(", ") { "≥${it.minQty} ${product.unit} (${PosRepository.formatRupiah(it.unitPrice)})" },
                        fontSize = 10.sp,
                        color = Color(0xFFD97706),
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Row {
                IconButton(onClick = onPrintLabel) {
                    Icon(Icons.Default.Sell, contentDescription = "Cetak Label Harga", tint = Color(0xFF0284C7), modifier = Modifier.size(20.dp))
                }
                if (canManage) {
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit", tint = SlateMedium, modifier = Modifier.size(20.dp))
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = ErrorRed, modifier = Modifier.size(20.dp))
                    }
                }
            }
        }
    }
}
