package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ShiftRecord
import com.example.data.repository.PosRepository
import com.example.ui.components.CloseShiftDialog
import com.example.ui.components.StartShiftDialog
import com.example.ui.theme.AmberShift1
import com.example.ui.theme.BlueShift2
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.PurpleShift3
import com.example.ui.theme.SlateDark
import com.example.ui.theme.SlateLight
import com.example.ui.theme.SlateMedium
import com.example.ui.theme.SuccessGreen
import com.example.ui.viewmodel.PosViewModel

@Composable
fun ShiftScreen(viewModel: PosViewModel) {
    val activeShift by viewModel.activeShift.collectAsStateWithLifecycle()
    val todayShifts by viewModel.todayShifts.collectAsStateWithLifecycle()
    val allShifts by viewModel.allShifts.collectAsStateWithLifecycle()
    val pendingCarts by viewModel.pendingCarts.collectAsStateWithLifecycle()

    var showStartShiftDialog by remember { mutableStateOf(false) }
    var showCloseShiftDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- Header ---
        item {
            Text(
                text = "Manajemen Shift Kerja (3 Shift)",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = SlateDark
            )
            Text(
                text = "Dukungan penuh rotasi 3 shift kerja dengan rekonsiliasi kas dan serah terima.",
                style = MaterialTheme.typography.bodySmall,
                color = SlateLight
            )
        }

        // --- Active Shift Hero Card ---
        item {
            if (activeShift != null) {
                val shift = activeShift!!
                val shiftColor = when (shift.shiftNumber) {
                    1 -> AmberShift1
                    2 -> BlueShift2
                    else -> PurpleShift3
                }

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.5.dp, shiftColor.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                        .testTag("active_shift_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(shiftColor.copy(alpha = 0.15f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "${shift.shiftNumber}",
                                        fontWeight = FontWeight.Bold,
                                        color = shiftColor,
                                        fontSize = 18.sp
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = shift.shiftName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp
                                    )
                                    Text(
                                        text = "Kasir: ${shift.cashierName} • Sejak ${PosRepository.formatTime(shift.startTime)}",
                                        fontSize = 12.sp,
                                        color = SlateLight
                                    )
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .background(SuccessGreen.copy(alpha = 0.15f), RoundedCornerShape(20.dp))
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "SEDANG AKTIF",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SuccessGreen
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Financial Breakdown of active shift
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ShiftMetricBox(
                                title = "Modal Awal Kas",
                                value = PosRepository.formatRupiah(shift.openingCash),
                                modifier = Modifier.weight(1f)
                            )
                            ShiftMetricBox(
                                title = "Penjualan Tunai",
                                value = PosRepository.formatRupiah(shift.totalCash),
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ShiftMetricBox(
                                title = "Non-Tunai (QRIS/Trf)",
                                value = PosRepository.formatRupiah(shift.totalNonCash),
                                modifier = Modifier.weight(1f)
                            )
                            ShiftMetricBox(
                                title = "Total Omset Shift",
                                value = PosRepository.formatRupiah(shift.totalSales),
                                highlightColor = EmeraldPrimary,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Expected Cash in Drawer
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFFF1F5F9),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "Kas Seharusnya di Laci (Uang Fisik):",
                                        fontSize = 12.sp,
                                        color = SlateLight
                                    )
                                    Text(
                                        text = "Modal Awal + Penjualan Tunai",
                                        fontSize = 10.sp,
                                        color = SlateLight
                                    )
                                }
                                Text(
                                    text = PosRepository.formatRupiah(shift.expectedCash),
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SlateDark
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = { showCloseShiftDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = SlateDark),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("close_shift_button")
                        ) {
                            Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Tutup Shift & Serah Terima", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                // No Active Shift Banner
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, ErrorRed.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.Schedule,
                            contentDescription = null,
                            tint = ErrorRed,
                            modifier = Modifier.size(44.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Belum Ada Shift Kasir yang Aktif",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = SlateDark
                        )
                        Text(
                            text = "Buka shift baru untuk mencatat kasir yang bertugas dan modal awal kas.",
                            fontSize = 12.sp,
                            color = SlateMedium,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { showStartShiftDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            modifier = Modifier.testTag("open_new_shift_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Buka Shift Baru Sekarang", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // --- 3-Shift Comparison Rekap Hari Ini ---
        item {
            Text(
                text = "Rekap 3 Shift Hari Ini",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = SlateDark
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Performa masing-masing shift kerja sepanjang hari ini:",
                fontSize = 12.sp,
                color = SlateLight
            )
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    Triple(1, "Shift 1 - Pagi (07:00 - 15:00)", AmberShift1),
                    Triple(2, "Shift 2 - Siang/Sore (15:00 - 23:00)", BlueShift2),
                    Triple(3, "Shift 3 - Malam (23:00 - 07:00)", PurpleShift3)
                ).forEach { (shiftNum, defaultLabel, color) ->
                    val shiftForSlot = todayShifts.find { it.shiftNumber == shiftNum }
                    ShiftSlotCard(
                        shiftNumber = shiftNum,
                        label = defaultLabel,
                        color = color,
                        shift = shiftForSlot,
                        onOpenShift = {
                            if (activeShift == null) {
                                showStartShiftDialog = true
                            }
                        }
                    )
                }
            }
        }

        // --- Riwayat Shift Sebelumnya ---
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Riwayat Shift Terdahulu",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = SlateDark
            )
        }

        val closedShifts = allShifts.filter { it.status == "CLOSED" }
        if (closedShifts.isEmpty()) {
            item {
                Text(
                    text = "Belum ada riwayat shift yang ditutup.",
                    fontSize = 12.sp,
                    color = SlateLight,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }
        } else {
            items(closedShifts, key = { it.id }) { shift ->
                ClosedShiftItem(shift)
            }
        }
    }

    if (showStartShiftDialog) {
        StartShiftDialog(
            onDismiss = { showStartShiftDialog = false },
            onConfirm = { shiftNum, name, cashier, cash, notes ->
                viewModel.startShift(shiftNum, name, cashier, cash, notes)
                showStartShiftDialog = false
            }
        )
    }

    if (showCloseShiftDialog && activeShift != null) {
        CloseShiftDialog(
            activeShift = activeShift!!,
            pendingCount = pendingCarts.size,
            onDismiss = { showCloseShiftDialog = false },
            onConfirm = { closingCash, notes ->
                viewModel.closeShift(closingCash, notes)
                showCloseShiftDialog = false
            }
        )
    }
}

@Composable
private fun ShiftSlotCard(
    shiftNumber: Int,
    label: String,
    color: Color,
    shift: ShiftRecord?,
    onOpenShift: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .background(color.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "$shiftNumber",
                        fontWeight = FontWeight.Bold,
                        color = color,
                        fontSize = 14.sp
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = label,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        color = SlateDark
                    )
                    if (shift != null) {
                        Text(
                            text = "Kasir: ${shift.cashierName} • ${shift.totalTransactions} transaksi",
                            fontSize = 11.sp,
                            color = SlateLight
                        )
                    } else {
                        Text(
                            text = "Belum berjalan hari ini",
                            fontSize = 11.sp,
                            color = SlateLight
                        )
                    }
                }
            }

            if (shift != null) {
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = PosRepository.formatRupiah(shift.totalSales),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = EmeraldPrimary
                    )
                    Text(
                        text = if (shift.status == "ACTIVE") "SEDANG AKTIF" else "SELESAI",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (shift.status == "ACTIVE") SuccessGreen else SlateLight
                    )
                }
            } else {
                OutlinedButton(
                    onClick = onOpenShift,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(32.dp)
                ) {
                    Text("Buka", fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun ClosedShiftItem(shift: ShiftRecord) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${shift.shiftName} (Kasir: ${shift.cashierName})",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = PosRepository.formatDate(shift.startTime),
                    fontSize = 11.sp,
                    color = SlateLight
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Total Omset:", fontSize = 11.sp, color = SlateLight)
                    Text(
                        text = PosRepository.formatRupiah(shift.totalSales),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = EmeraldPrimary
                    )
                }
                Column {
                    Text("Uang Fisik Dihitung:", fontSize = 11.sp, color = SlateLight)
                    Text(
                        text = PosRepository.formatRupiah(shift.closingCash ?: 0L),
                        fontWeight = FontWeight.Medium,
                        fontSize = 13.sp
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Selisih Kas:", fontSize = 11.sp, color = SlateLight)
                    val diff = shift.difference
                    val diffColor = when {
                        diff > 0 -> SuccessGreen
                        diff < 0 -> ErrorRed
                        else -> SlateMedium
                    }
                    val diffText = when {
                        diff > 0 -> "+${PosRepository.formatRupiah(diff)}"
                        diff < 0 -> PosRepository.formatRupiah(diff)
                        else -> "Pas"
                    }
                    Text(
                        text = diffText,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = diffColor
                    )
                }
            }
        }
    }
}

@Composable
private fun ShiftMetricBox(
    title: String,
    value: String,
    highlightColor: Color = SlateDark,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color(0xFFF8FAFC),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(text = title, fontSize = 11.sp, color = SlateLight)
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = highlightColor
            )
        }
    }
}
