package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.PosRepository
import com.example.ui.viewmodel.PosViewModel
import com.example.util.ReportExportHelper

@Composable
fun ShiftScreen(viewModel: PosViewModel) {
    val context = LocalContext.current
    val activeShift by viewModel.activeShift.collectAsState()
    val currentEmployee by viewModel.currentEmployee.collectAsState()
    val licenseInfo by viewModel.licenseInfo.collectAsState()

    var showCloseShiftDialog by remember { mutableStateOf(false) }
    var initialCashText by remember { mutableStateOf("") }
    var notesText by remember { mutableStateOf("") }

    var actualCashText by remember { mutableStateOf("") }
    var closeNotesText by remember { mutableStateOf("") }

    if (showCloseShiftDialog && activeShift != null) {
        val shift = activeShift!!
        val actualCash = actualCashText.toLongOrNull() ?: 0L
        val expectedCash = shift.expectedCash
        val difference = actualCash - expectedCash

        AlertDialog(
            onDismissRequest = { showCloseShiftDialog = false },
            title = { Text("Tutup Shift #${shift.shiftNumber}", fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Kasir: ${shift.cashierName}")
                    Text("Modal Awal: ${PosRepository.formatRupiah(shift.startingCash)}")
                    Text("Total Penjualan Tunai: ${PosRepository.formatRupiah(shift.totalCashSales)}")
                    Text(
                        text = "Total Kas Seharusnya di Laci: ${PosRepository.formatRupiah(expectedCash)}",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF059669)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = actualCashText,
                        onValueChange = { actualCashText = it.filter { c -> c.isDigit() } },
                        label = { Text("Hitungan Fisik Uang di Laci Kasir *") },
                        prefix = { Text("Rp ") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (actualCashText.isNotBlank()) {
                        Surface(
                            color = if (difference == 0L) Color(0xFFEFF6FF) else if (difference > 0) Color(0xFFECFDF5) else Color(0xFFFEF2F2),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = when {
                                    difference == 0L -> "Uang Pas (Tidak Ada Selisih)"
                                    difference > 0 -> "Kas Lebih: +${PosRepository.formatRupiah(difference)}"
                                    else -> "Kas Kurang: ${PosRepository.formatRupiah(difference)}"
                                },
                                fontWeight = FontWeight.Bold,
                                color = if (difference >= 0) Color(0xFF065F46) else Color(0xFF991B1B),
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }

                    OutlinedTextField(
                        value = closeNotesText,
                        onValueChange = { closeNotesText = it },
                        label = { Text("Catatan Serah Terima Shift") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.closeCurrentShift(
                            actualEndingCash = actualCash,
                            notes = closeNotesText,
                            printReport = true
                        )
                        showCloseShiftDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("Tutup Shift & Cetak Z-Report")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showCloseShiftDialog = false }) {
                    Text("Batal")
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Manajemen Shift Kasir & Laci Uang (Cash Drawer)",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF0F172A)
        )

        if (activeShift == null) {
            // OPEN SHIFT FORM
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(Color(0xFFDC2626).copy(alpha = 0.12f), RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = Color(0xFFDC2626))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Shift Kasir Belum Dibuka", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text("Buka shift kasir terlebih dahulu untuk mulai melayani transaksi pelanggan.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }
                    }

                    Divider(modifier = Modifier.padding(vertical = 4.dp))

                    Text("Kasir Bertugas: ${currentEmployee?.name ?: "Kasir Utama"}", fontWeight = FontWeight.SemiBold)

                    OutlinedTextField(
                        value = initialCashText,
                        onValueChange = { initialCashText = it.filter { c -> c.isDigit() } },
                        label = { Text("Modal Awal Kasir (Uang Kembalian di Laci) *") },
                        placeholder = { Text("Contoh: 100000") },
                        prefix = { Text("Rp ", fontWeight = FontWeight.Bold) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = notesText,
                        onValueChange = { notesText = it },
                        label = { Text("Catatan Shift Masuk (Opsional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            val cash = initialCashText.toLongOrNull() ?: 0L
                            viewModel.openNewShift(
                                shiftNumber = 1,
                                cashierName = currentEmployee?.name ?: "Kasir",
                                startingCash = cash,
                                notes = notesText
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().height(50.dp)
                    ) {
                        Icon(imageVector = Icons.Default.LockOpen, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Buka Shift Kasir Sekarang", fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            // ACTIVE SHIFT DASHBOARD
            val shift = activeShift!!
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(Color(0xFF059669).copy(alpha = 0.12f), RoundedCornerShape(10.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF059669))
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Shift #${shift.shiftNumber} Sedang Aktif", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                Text("Kasir: ${shift.cashierName} | Dibuka: ${PosRepository.formatTime(shift.startTime)}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            }
                        }

                        Button(
                            onClick = { showCloseShiftDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Tutup Shift")
                        }
                    }

                    Divider()

                    // Metrics Grid
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ShiftMetricBox(
                            title = "Modal Awal",
                            value = PosRepository.formatRupiah(shift.startingCash),
                            color = Color(0xFF0284C7),
                            modifier = Modifier.weight(1f)
                        )
                        ShiftMetricBox(
                            title = "Penjualan Tunai",
                            value = PosRepository.formatRupiah(shift.totalCashSales),
                            color = Color(0xFF059669),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ShiftMetricBox(
                            title = "Non-Tunai (QRIS/Bank)",
                            value = PosRepository.formatRupiah(shift.totalNonCashSales),
                            color = Color(0xFF7C3AED),
                            modifier = Modifier.weight(1f)
                        )
                        ShiftMetricBox(
                            title = "Total Transaksi",
                            value = "${shift.transactionCount} Nota",
                            color = Color(0xFFD97706),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Surface(
                        color = Color(0xFFEFF6FF),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBFDBFE)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Total Uang Kas Seharusnya di Laci:",
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1E3A8A)
                            )
                            Text(
                                text = PosRepository.formatRupiah(shift.expectedCash),
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp,
                                color = Color(0xFF1D4ED8)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ShiftMetricBox(
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = color.copy(alpha = 0.08f),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.25f)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = color)
        }
    }
}
