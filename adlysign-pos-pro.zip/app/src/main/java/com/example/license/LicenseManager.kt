package com.example.license

import android.content.Context
import android.content.SharedPreferences
import android.provider.Settings
import com.example.data.model.LicenseInfo
import java.security.MessageDigest
import java.util.Locale

class LicenseManager(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("kasir_pos_license_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val SECRET_SALT = "KASIR_POS_SECURE_SALT_2026"
        const val ADMIN_MASTER_PIN = "8888" // PIN untuk mode distributor/penjual lisensi
    }

    val deviceId: String by lazy {
        val existing = prefs.getString("device_id", null)
        if (!existing.isNullOrBlank()) {
            existing
        } else {
            val androidId = try {
                Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
            } catch (e: Exception) {
                null
            }
            val raw = if (!androidId.isNullOrBlank() && androidId != "9774d56d682e549c") {
                androidId.uppercase(Locale.ROOT)
            } else {
                java.util.UUID.randomUUID().toString().replace("-", "").substring(0, 12).uppercase(Locale.ROOT)
            }
            // Format into readable groups: ABCD-EFGH-IJKL
            val clean = raw.padEnd(12, 'X').substring(0, 12)
            val formatted = "${clean.substring(0, 4)}-${clean.substring(4, 8)}-${clean.substring(8, 12)}"
            prefs.edit().putString("device_id", formatted).apply()
            formatted
        }
    }

    fun getLicenseInfo(): LicenseInfo {
        val tier = prefs.getString("license_tier", "TRIAL") ?: "TRIAL"
        val isActivated = prefs.getBoolean("is_activated", false)
        val key = prefs.getString("license_key", "") ?: ""
        val storeName = prefs.getString("store_name", "Toko Modern Kasir") ?: "Toko Modern Kasir"
        val storeAddress = prefs.getString("store_address", "Jl. Nusantara No. 88") ?: "Jl. Nusantara No. 88"
        val storePhone = prefs.getString("store_phone", "0812-3456-7890") ?: "0812-3456-7890"
        val footer = prefs.getString("receipt_footer", "Terima kasih telah berbelanja!") ?: "Terima kasih telah berbelanja!"
        val storeLogoUri = prefs.getString("store_logo_uri", "") ?: ""
        val qrisImageUri = prefs.getString("qris_image_uri", "") ?: ""
        val qrisMerchantName = prefs.getString("qris_merchant_name", "Toko Modern Kasir") ?: "Toko Modern Kasir"
        val qrisNmid = prefs.getString("qris_nmid", "ID1020304050607") ?: "ID1020304050607"
        val activationDate = prefs.getLong("activation_date", 0L)
        val txCount = prefs.getInt("tx_count", 0)

        return LicenseInfo(
            deviceId = deviceId,
            storeName = storeName,
            storeAddress = storeAddress,
            storePhone = storePhone,
            receiptFooter = footer,
            storeLogoUri = storeLogoUri,
            qrisImageUri = qrisImageUri,
            qrisMerchantName = qrisMerchantName,
            qrisNmid = qrisNmid,
            licenseKey = key,
            licenseTier = tier,
            isActivated = isActivated,
            isLifetime = true,
            maxTrialTransactions = 50,
            currentTransactionsCount = txCount,
            activationDate = activationDate
        )
    }

    fun incrementTransactionCount() {
        val current = prefs.getInt("tx_count", 0)
        prefs.edit().putInt("tx_count", current + 1).apply()
    }

    fun updateStoreInfo(name: String, address: String, phone: String, footer: String, logoUri: String? = null) {
        val editor = prefs.edit()
            .putString("store_name", name.trim())
            .putString("store_address", address.trim())
            .putString("store_phone", phone.trim())
            .putString("receipt_footer", footer.trim())
        if (logoUri != null) {
            editor.putString("store_logo_uri", logoUri.trim())
        }
        editor.apply()
    }

    fun updateStoreLogo(logoUri: String) {
        prefs.edit().putString("store_logo_uri", logoUri.trim()).apply()
    }

    fun updateQrisSettings(imageUri: String, merchantName: String, nmid: String) {
        prefs.edit()
            .putString("qris_image_uri", imageUri.trim())
            .putString("qris_merchant_name", merchantName.trim())
            .putString("qris_nmid", nmid.trim())
            .apply()
    }

    /**
     * Algoritma pembuatan kunci lisensi resmi:
     * Format: KPOS-[TIER]-[HASH1]-[HASH2]
     * Contoh: KPOS-PRO-7A9F-2B4C
     */
    fun generateLicenseKey(targetDeviceId: String, tier: String): String {
        val normalizedId = targetDeviceId.replace("-", "").trim().uppercase(Locale.ROOT)
        val normalizedTier = tier.trim().uppercase(Locale.ROOT) // "PRO" or "ENT"

        val rawInput = "$normalizedId:$normalizedTier:$SECRET_SALT"
        val hash = sha256(rawInput)

        val part1 = hash.substring(0, 4).uppercase(Locale.ROOT)
        val part2 = hash.substring(4, 8).uppercase(Locale.ROOT)

        return "KPOS-$normalizedTier-$part1-$part2"
    }

    /**
     * Memverifikasi lisensi untuk perangkat ini
     */
    fun activateLicense(inputKey: String): Result<String> {
        val cleanKey = inputKey.trim().uppercase(Locale.ROOT)
        val parts = cleanKey.split("-")

        if (parts.size != 4 || parts[0] != "KPOS") {
            return Result.failure(Exception("Format kunci tidak valid. Format: KPOS-[PRO/ENT]-XXXX-XXXX"))
        }

        val tier = parts[1] // "PRO" or "ENT"
        if (tier != "PRO" && tier != "ENT") {
            return Result.failure(Exception("Tipe lisensi tidak dikenali ($tier). Gunakan PRO atau ENT."))
        }

        val expectedKey = generateLicenseKey(deviceId, tier)
        if (cleanKey != expectedKey) {
            return Result.failure(Exception("Kunci lisensi tidak cocok untuk Device ID perangkat ini ($deviceId)."))
        }

        // Simpan lisensi berhasil
        prefs.edit()
            .putBoolean("is_activated", true)
            .putString("license_tier", if (tier == "PRO") "PRO" else "ENTERPRISE")
            .putString("license_key", cleanKey)
            .putLong("activation_date", System.currentTimeMillis())
            .apply()

        return Result.success("Lisensi $tier Berhasil Diaktifkan Seumur Hidup!")
    }

    // --- Member Point Settings ---
    fun getPointSettings(): com.example.data.model.PointSettings {
        val spend = prefs.getLong("point_spend_per_pt", 10000L)
        val value = prefs.getLong("point_value_rupiah", 100L)
        val maxPct = prefs.getInt("point_max_percentage", 100)
        val minPts = prefs.getInt("point_min_redeem", 10)
        return com.example.data.model.PointSettings(
            spendPerPoint = spend,
            pointValueInRupiah = value,
            maxRedeemPercentage = maxPct,
            minPointsToRedeem = minPts
        )
    }

    fun updatePointSettings(settings: com.example.data.model.PointSettings) {
        prefs.edit()
            .putLong("point_spend_per_pt", settings.spendPerPoint)
            .putLong("point_value_rupiah", settings.pointValueInRupiah)
            .putInt("point_max_percentage", settings.maxRedeemPercentage)
            .putInt("point_min_redeem", settings.minPointsToRedeem)
            .apply()
    }

    fun resetToTrial() {
        prefs.edit()
            .putBoolean("is_activated", false)
            .putString("license_tier", "TRIAL")
            .putString("license_key", "")
            .putLong("activation_date", 0L)
            .apply()
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
