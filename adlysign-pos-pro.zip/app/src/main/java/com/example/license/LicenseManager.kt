package com.example.license

import android.content.Context
import android.content.SharedPreferences
import android.provider.Settings
import com.example.data.model.LicenseInfo
import com.example.data.model.ShortcutRegistry
import java.security.MessageDigest
import java.util.Locale

class LicenseManager(private val context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("kasir_pos_license_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val SECRET_SALT = "KASIR_POS_SECURE_SALT_2026"
        const val ADMIN_MASTER_PIN = "8888"
    }

    val deviceId: String by lazy {
        val existing = prefs.getString("device_id", null)
        if (!existing.isNullOrBlank()) {
            existing
        } else {
            val androidId = try {
                Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
            } catch (e: Exception) {
                null
            }
            val raw = if (!androidId.isNullOrBlank() && androidId != "9774d56d682e549c") {
                androidId.uppercase(Locale.ROOT)
            } else {
                java.util.UUID.randomUUID().toString().replace("-", "").substring(0, 12).uppercase(Locale.ROOT)
            }
            val clean = raw.padEnd(12, 'X').substring(0, 12)
            val formatted = "${clean.substring(0, 4)}-${clean.substring(4, 8)}-${clean.substring(8, 12)}"
            prefs.edit().putString("device_id", formatted).apply()
            formatted
        }
    }

    fun getLicenseInfo(): LicenseInfo {
        val tier = prefs.getString("license_tier", "TRIAL") ?: "TRIAL"
        val isActivated = prefs.getBoolean("is_activated", false)
        val key = prefs.getString("license_key", "") ?: ""
        val storeName = prefs.getString("store_name", "Toko Modern Kasir") ?: "Toko Modern Kasir"
        val storeAddress = prefs.getString("store_address", "Jl. Nusantara No. 88") ?: "Jl. Nusantara No. 88"
        val storePhone = prefs.getString("store_phone", "0812-3456-7890") ?: "0812-3456-7890"
        val footer = prefs.getString("receipt_footer", "Terima kasih telah berbelanja!") ?: "Terima kasih telah berbelanja!"
        val storeLogoUri = prefs.getString("store_logo_uri", "") ?: ""
        val qrisImageUri = prefs.getString("qris_image_uri", "") ?: ""
        val qrisMerchantName = prefs.getString("qris_merchant_name", "Toko Modern Kasir") ?: "Toko Modern Kasir"
        val qrisNmid = prefs.getString("qris_nmid", "ID1020304050607") ?: "ID1020304050607"
        val activationDate = prefs.getLong("activation_date", 0L)
        val txCount = prefs.getInt("tx_count", 0)

        return LicenseInfo(
            deviceId = deviceId,
            storeName = storeName,
            storeAddress = storeAddress,
            storePhone = storePhone,
            receiptFooter = footer,
            storeLogoUri = storeLogoUri,
            qrisImageUri = qrisImageUri,
            qrisMerchantName = qrisMerchantName,
            qrisNmid = qrisNmid,
            licenseKey = key,
            licenseTier = tier,
            isActivated = isActivated,
            isLifetime = true,
            maxTrialTransactions = 50,
            currentTransactionsCount = txCount,
            activationDate = activationDate
        )
    }

    fun incrementTransactionCount() {
        val current = prefs.getInt("tx_count", 0)
        prefs.edit().putInt("tx_count", current + 1).apply()
    }

    fun updateStoreInfo(name: String, address: String, phone: String, footer: String, logoUri: String? = null) {
        val editor = prefs.edit()
            .putString("store_name", name.trim())
            .putString("store_address", address.trim())
            .putString("store_phone", phone.trim())
            .putString("receipt_footer", footer.trim())
        if (logoUri != null) {
            editor.putString("store_logo_uri", logoUri.trim())
        }
        editor.apply()
    }

    fun updateStoreLogo(logoUri: String) {
        prefs.edit().putString("store_logo_uri", logoUri.trim()).apply()
    }

    fun updateQrisSettings(imageUri: String, merchantName: String, nmid: String) {
        prefs.edit()
            .putString("qris_image_uri", imageUri.trim())
            .putString("qris_merchant_name", merchantName.trim())
            .putString("qris_nmid", nmid.trim())
            .apply()
    }

    fun generateLicenseKey(targetDeviceId: String, tier: String): String {
        val normalizedId = targetDeviceId.replace("-", "").trim().uppercase(Locale.ROOT)
        val normalizedTier = tier.trim().uppercase(Locale.ROOT)
        val rawInput = "$normalizedId:$normalizedTier:$SECRET_SALT"
        val hash = sha256(rawInput)
        val part1 = hash.substring(0, 4).uppercase(Locale.ROOT)
        val part2 = hash.substring(4, 8).uppercase(Locale.ROOT)
        return "KPOS-$normalizedTier-$part1-$part2"
    }

    fun activateLicense(inputKey: String): Result<String> {
        val cleanKey = inputKey.trim().uppercase(Locale.ROOT)
        val parts = cleanKey.split("-")
        if (parts.size != 4 || parts[0] != "KPOS") {
            return Result.failure(Exception("Format kunci tidak valid. Format: KPOS-[PRO/ENT]-XXXX-XXXX"))
        }
        val tier = parts[1]
        if (tier != "PRO" && tier != "ENT") {
            return Result.failure(Exception("Tipe lisensi tidak dikenali ($tier). Gunakan PRO atau ENT."))
        }
        val expectedKey = generateLicenseKey(deviceId, tier)
        if (cleanKey != expectedKey) {
            return Result.failure(Exception("Kunci lisensi tidak cocok untuk Device ID perangkat ini ($deviceId)."))
        }
        prefs.edit()
            .putBoolean("is_activated", true)
            .putString("license_tier", if (tier == "PRO") "PRO" else "ENTERPRISE")
            .putString("license_key", cleanKey)
            .putLong("activation_date", System.currentTimeMillis())
            .apply()
        return Result.success("Lisensi $tier Berhasil Diaktifkan Seumur Hidup!")
    }

    // --- Member Point Settings ---
    fun getPointSettings(): com.example.data.model.PointSettings {
        val spend = prefs.getLong("point_spend_per_pt", 10000L)
        val value = prefs.getLong("point_value_rupiah", 100L)
        val maxPct = prefs.getInt("point_max_percentage", 100)
        val minPts = prefs.getInt("point_min_redeem", 10)
        return com.example.data.model.PointSettings(
            spendPerPoint = spend,
            pointValueInRupiah = value,
            maxRedeemPercentage = maxPct,
            minPointsToRedeem = minPts
        )
    }

    fun updatePointSettings(settings: com.example.data.model.PointSettings) {
        prefs.edit()
            .putLong("point_spend_per_pt", settings.spendPerPoint)
            .putLong("point_value_rupiah", settings.pointValueInRupiah)
            .putInt("point_max_percentage", settings.maxRedeemPercentage)
            .putInt("point_min_redeem", settings.minPointsToRedeem)
            .apply()
    }

    // --- Shortcut Mappings F1 - F12 ---
    fun getShortcutMappings(): Map<String, String> {
        val map = mutableMapOf<String, String>()
        for (i in 1..12) {
            val key = "F$i"
            val defaultAction = ShortcutRegistry.DEFAULT_MAPPINGS[key] ?: "CARI_BARANG"
            val savedAction = prefs.getString("shortcut_$key", defaultAction) ?: defaultAction
            map[key] = savedAction
        }
        return map
    }

    fun setShortcutMapping(key: String, actionId: String) {
        prefs.edit().putString("shortcut_$key", actionId).apply()
    }

    fun resetShortcutMappings() {
        val editor = prefs.edit()
        for (i in 1..12) {
            editor.remove("shortcut_F$i")
        }
        editor.apply()
    }

    // --- Bluetooth Printer Settings ---
    fun getPrinterSettings(): com.example.data.model.PrinterSettings {
        return com.example.data.model.PrinterSettings(
            selectedDeviceAddress = prefs.getString("printer_device_address", "") ?: "",
            selectedDeviceName = prefs.getString("printer_device_name", "") ?: "",
            paperSize = prefs.getString("printer_paper_size", "58mm") ?: "58mm",
            autoPrintOnCheckout = prefs.getBoolean("printer_auto_print", false),
            printLogo = prefs.getBoolean("printer_print_logo", true),
            printHeader = prefs.getBoolean("printer_print_header", true),
            printFooter = prefs.getBoolean("printer_print_footer", true),
            printCashier = prefs.getBoolean("printer_print_cashier", true),
            printShift = prefs.getBoolean("printer_print_shift", true),
            printCustomer = prefs.getBoolean("printer_print_customer", true),
            printNotes = prefs.getBoolean("printer_print_notes", true),
            cutPaper = prefs.getBoolean("printer_cut_paper", true),
            receiptTemplate = prefs.getString("printer_receipt_template", "KLASIK") ?: "KLASIK",
            fontFamilyType = prefs.getString("printer_font_family", "MONOSPACE") ?: "MONOSPACE",
            fontSizePreset = prefs.getString("printer_font_size", "SEDANG") ?: "SEDANG",
            fontWeightPreset = prefs.getString("printer_font_weight", "NORMAL") ?: "NORMAL",
            lineSpacingPreset = prefs.getString("printer_line_spacing", "STANDAR") ?: "STANDAR",
            feedLines = prefs.getInt("printer_feed_lines", 3),
            customHeader = prefs.getString("printer_custom_header", "Selamat Datang & Terima Kasih") ?: "Selamat Datang & Terima Kasih",
            customFooter = prefs.getString("printer_custom_footer", "Barang yang sudah dibeli tidak dapat ditukar/dikembalikan.\nTerima kasih atas kunjungan Anda!") ?: "Barang yang sudah dibeli tidak dapat ditukar/dikembalikan.\nTerima kasih atas kunjungan Anda!"
        )
    }

    fun updatePrinterSettings(settings: com.example.data.model.PrinterSettings) {
        prefs.edit()
            .putString("printer_device_address", settings.selectedDeviceAddress.trim())
            .putString("printer_device_name", settings.selectedDeviceName.trim())
            .putString("printer_paper_size", settings.paperSize)
            .putBoolean("printer_auto_print", settings.autoPrintOnCheckout)
            .putBoolean("printer_print_logo", settings.printLogo)
            .putBoolean("printer_print_header", settings.printHeader)
            .putBoolean("printer_print_footer", settings.printFooter)
            .putBoolean("printer_print_cashier", settings.printCashier)
            .putBoolean("printer_print_shift", settings.printShift)
            .putBoolean("printer_print_customer", settings.printCustomer)
            .putBoolean("printer_print_notes", settings.printNotes)
            .putBoolean("printer_cut_paper", settings.cutPaper)
            .putString("printer_receipt_template", settings.receiptTemplate)
            .putString("printer_font_family", settings.fontFamilyType)
            .putString("printer_font_size", settings.fontSizePreset)
            .putString("printer_font_weight", settings.fontWeightPreset)
            .putString("printer_line_spacing", settings.lineSpacingPreset)
            .putInt("printer_feed_lines", settings.feedLines)
            .putString("printer_custom_header", settings.customHeader.trim())
            .putString("printer_custom_footer", settings.customFooter.trim())
            .apply()
    }

    fun getLastBackupTimestamp(): Long {
        return prefs.getLong("last_backup_timestamp", 0L)
    }

    fun setLastBackupTimestamp(timestamp: Long) {
        prefs.edit().putLong("last_backup_timestamp", timestamp).apply()
    }

    fun exportSettingsToJson(): org.json.JSONObject {
        val root = org.json.JSONObject()
        val store = org.json.JSONObject().apply {
            put("storeName", prefs.getString("store_name", "Toko Modern Kasir") ?: "Toko Modern Kasir")
            put("storeAddress", prefs.getString("store_address", "Jl. Nusantara No. 88") ?: "Jl. Nusantara No. 88")
            put("storePhone", prefs.getString("store_phone", "0812-3456-7890") ?: "0812-3456-7890")
            put("receiptFooter", prefs.getString("receipt_footer", "Terima kasih telah berbelanja!") ?: "Terima kasih telah berbelanja!")
            put("storeLogoUri", prefs.getString("store_logo_uri", "") ?: "")
            put("qrisImageUri", prefs.getString("qris_image_uri", "") ?: "")
            put("qrisMerchantName", prefs.getString("qris_merchant_name", "Toko Modern Kasir") ?: "Toko Modern Kasir")
            put("qrisNmid", prefs.getString("qris_nmid", "ID1020304050607") ?: "ID1020304050607")
            put("licenseTier", prefs.getString("license_tier", "TRIAL") ?: "TRIAL")
            put("isActivated", prefs.getBoolean("is_activated", false))
            put("licenseKey", prefs.getString("license_key", "") ?: "")
        }
        root.put("storeSettings", store)
        return root
    }

    fun importSettingsFromJson(root: org.json.JSONObject) {
        val editor = prefs.edit()
        root.optJSONObject("storeSettings")?.let { store ->
            if (store.has("storeName")) editor.putString("store_name", store.optString("storeName"))
            if (store.has("storeAddress")) editor.putString("store_address", store.optString("storeAddress"))
            if (store.has("storePhone")) editor.putString("store_phone", store.optString("storePhone"))
            if (store.has("receiptFooter")) editor.putString("receipt_footer", store.optString("receiptFooter"))
            if (store.has("storeLogoUri")) editor.putString("store_logo_uri", store.optString("storeLogoUri"))
            if (store.has("qrisImageUri")) editor.putString("qris_image_uri", store.optString("qrisImageUri"))
            if (store.has("qrisMerchantName")) editor.putString("qris_merchant_name", store.optString("qrisMerchantName"))
            if (store.has("qrisNmid")) editor.putString("qris_nmid", store.optString("qrisNmid"))
            if (store.has("licenseTier")) editor.putString("license_tier", store.optString("licenseTier"))
            if (store.has("isActivated")) editor.putBoolean("is_activated", store.optBoolean("isActivated"))
            if (store.has("licenseKey")) editor.putString("license_key", store.optString("licenseKey"))
        }
        editor.apply()
    }

    // --- Master Supplier Persistence ---
    fun getSuppliers(): List<com.example.data.model.SupplierData> {
        val json = prefs.getString("master_suppliers_json", null)
        if (json.isNullOrBlank()) {
            val defaults = listOf(
                com.example.data.model.SupplierData(name = "PT Indomarco Distribusi", phone = "0812-3456-7890", address = "Kawasan Pergudangan Blok A", notes = "Distributor Sembako & Minuman"),
                com.example.data.model.SupplierData(name = "CV Sumber Makmur Perkasa", phone = "0856-1234-5678", address = "Jl. Pasar Lama No. 12", notes = "Grosir Snack & Roti"),
                com.example.data.model.SupplierData(name = "PT Wings Surya Perkasa", phone = "0878-9876-5432", address = "Komp. Niaga Barat No. 88", notes = "Sabun, Deterjen & Kebersihan"),
                com.example.data.model.SupplierData(name = "PT Mayora Indah Distribusi", phone = "0813-2233-4455", address = "Sentra Distribusi Cemerlang", notes = "Biskuit, Permen & Kopi"),
                com.example.data.model.SupplierData(name = "Unilever Distributor Utama", phone = "0811-5566-7788", address = "Jl. Industri Raya Km 5", notes = "Perawatan & Produk Rumah Tangga")
            )
            saveSuppliers(defaults)
            return defaults
        }
        return try {
            val arr = org.json.JSONArray(json)
            val list = mutableListOf<com.example.data.model.SupplierData>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    com.example.data.model.SupplierData(
                        id = obj.optString("id", java.util.UUID.randomUUID().toString()),
                        name = obj.optString("name", ""),
                        phone = obj.optString("phone", ""),
                        address = obj.optString("address", ""),
                        notes = obj.optString("notes", "")
                    )
                )
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveSuppliers(list: List<com.example.data.model.SupplierData>) {
        val arr = org.json.JSONArray()
        for (s in list) {
            arr.put(org.json.JSONObject().apply {
                put("id", s.id)
                put("name", s.name)
                put("phone", s.phone)
                put("address", s.address)
                put("notes", s.notes)
            })
        }
        prefs.edit().putString("master_suppliers_json", arr.toString()).apply()
    }

    fun addSupplier(supplier: com.example.data.model.SupplierData) {
        val current = getSuppliers().toMutableList()
        current.removeAll { it.name.trim().equals(supplier.name.trim(), ignoreCase = true) }
        current.add(0, supplier)
        saveSuppliers(current)
    }

    fun deleteSupplier(id: String) {
        val current = getSuppliers().toMutableList()
        current.removeAll { it.id == id }
        saveSuppliers(current)
    }

    // --- Master Toko (Belanja Toko) Persistence ---
    fun getStores(): List<com.example.data.model.StorePartnerData> {
        val json = prefs.getString("master_stores_json", null)
        if (json.isNullOrBlank()) {
            val defaults = listOf(
                com.example.data.model.StorePartnerData(name = "Toko Grosir Berkah Jaya", phone = "0812-9988-7766", address = "Pasar Besar Blok A-12", notes = "Kulakan sembako murah"),
                com.example.data.model.StorePartnerData(name = "Superindo Mart", phone = "0821-4455-6677", address = "Jl. Pahlawan No. 45", notes = "Belanja barang segar & promo"),
                com.example.data.model.StorePartnerData(name = "Pasar Induk Los B", phone = "0857-1122-3344", address = "Kawasan Pasar Induk", notes = "Bahan makanan pokok segar"),
                com.example.data.model.StorePartnerData(name = "Agen Sembako Makmur", phone = "0813-7788-9900", address = "Jl. Sudirman No. 101", notes = "Beras, minyak, gula grosir"),
                com.example.data.model.StorePartnerData(name = "Lotte Grosir Wholesale", phone = "0812-6655-4433", address = "Komp. Pergudangan Jaya", notes = "Belanja kartonan dus-dusan")
            )
            saveStores(defaults)
            return defaults
        }
        return try {
            val arr = org.json.JSONArray(json)
            val list = mutableListOf<com.example.data.model.StorePartnerData>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    com.example.data.model.StorePartnerData(
                        id = obj.optString("id", java.util.UUID.randomUUID().toString()),
                        name = obj.optString("name", ""),
                        phone = obj.optString("phone", ""),
                        address = obj.optString("address", ""),
                        notes = obj.optString("notes", "")
                    )
                )
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveStores(list: List<com.example.data.model.StorePartnerData>) {
        val arr = org.json.JSONArray()
        for (s in list) {
            arr.put(org.json.JSONObject().apply {
                put("id", s.id)
                put("name", s.name)
                put("phone", s.phone)
                put("address", s.address)
                put("notes", s.notes)
            })
        }
        prefs.edit().putString("master_stores_json", arr.toString()).apply()
    }

    fun addStore(store: com.example.data.model.StorePartnerData) {
        val current = getStores().toMutableList()
        current.removeAll { it.name.trim().equals(store.name.trim(), ignoreCase = true) }
        current.add(0, store)
        saveStores(current)
    }

    fun deleteStore(id: String) {
        val current = getStores().toMutableList()
        current.removeAll { it.id == id }
        saveStores(current)
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
