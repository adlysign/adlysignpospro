package com.example.license

import android.content.Context
import android.content.SharedPreferences
import android.provider.Settings
import com.example.data.model.LicenseInfo
import java.security.MessageDigest
import java.util.Locale

class LicenseManager(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("kasir_pos_license_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val SECRET_SALT = "KASIR_POS_SECURE_SALT_2026"
        const val ADMIN_MASTER_PIN = "8888" // PIN untuk mode distributor/penjual lisensi
    }

    val deviceId: String by lazy {
        val existing = prefs.getString("device_id", null)
        if (!existing.isNullOrBlank()) {
            existing
        } else {
            val androidId = try {
                Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
            } catch (e: Exception) {
                null
            }
            val raw = if (!androidId.isNullOrBlank() && androidId != "9774d56d682e549c") {
                androidId.uppercase(Locale.ROOT)
            } else {
                java.util.UUID.randomUUID().toString().replace("-", "").substring(0, 12).uppercase(Locale.ROOT)
            }
            // Format into readable groups: ABCD-EFGH-IJKL
            val clean = raw.padEnd(12, 'X').substring(0, 12)
            val formatted = "${clean.substring(0, 4)}-${clean.substring(4, 8)}-${clean.substring(8, 12)}"
            prefs.edit().putString("device_id", formatted).apply()
            formatted
        }
    }

    fun getLicenseInfo(): LicenseInfo {
        val tier = prefs.getString("license_tier", "TRIAL") ?: "TRIAL"
        val isActivated = prefs.getBoolean("is_activated", false)
        val key = prefs.getString("license_key", "") ?: ""
        val storeName = prefs.getString("store_name", "Toko Modern Kasir") ?: "Toko Modern Kasir"
        val storeAddress = prefs.getString("store_address", "Jl. Nusantara No. 88") ?: "Jl. Nusantara No. 88"
        val storePhone = prefs.getString("store_phone", "0812-3456-7890") ?: "0812-3456-7890"
        val footer = prefs.getString("receipt_footer", "Terima kasih telah berbelanja!") ?: "Terima kasih telah berbelanja!"
        val storeLogoUri = prefs.getString("store_logo_uri", "") ?: ""
        val qrisImageUri = prefs.getString("qris_image_uri", "") ?: ""
        val qrisMerchantName = prefs.getString("qris_merchant_name", "Toko Modern Kasir") ?: "Toko Modern Kasir"
        val qrisNmid = prefs.getString("qris_nmid", "ID1020304050607") ?: "ID1020304050607"
        val activationDate = prefs.getLong("activation_date", 0L)
        val txCount = prefs.getInt("tx_count", 0)

        return LicenseInfo(
            deviceId = deviceId,
            storeName = storeName,
            storeAddress = storeAddress,
            storePhone = storePhone,
            receiptFooter = footer,
            storeLogoUri = storeLogoUri,
            qrisImageUri = qrisImageUri,
            qrisMerchantName = qrisMerchantName,
            qrisNmid = qrisNmid,
            licenseKey = key,
            licenseTier = tier,
            isActivated = isActivated,
            isLifetime = true,
            maxTrialTransactions = 50,
            currentTransactionsCount = txCount,
            activationDate = activationDate
        )
    }

    fun incrementTransactionCount() {
        val current = prefs.getInt("tx_count", 0)
        prefs.edit().putInt("tx_count", current + 1).apply()
    }

    fun updateStoreInfo(name: String, address: String, phone: String, footer: String, logoUri: String? = null) {
        val editor = prefs.edit()
            .putString("store_name", name.trim())
            .putString("store_address", address.trim())
            .putString("store_phone", phone.trim())
            .putString("receipt_footer", footer.trim())
        if (logoUri != null) {
            editor.putString("store_logo_uri", logoUri.trim())
        }
        editor.apply()
    }

    fun updateStoreLogo(logoUri: String) {
        prefs.edit().putString("store_logo_uri", logoUri.trim()).apply()
    }

    fun updateQrisSettings(imageUri: String, merchantName: String, nmid: String) {
        prefs.edit()
            .putString("qris_image_uri", imageUri.trim())
            .putString("qris_merchant_name", merchantName.trim())
            .putString("qris_nmid", nmid.trim())
            .apply()
    }

    /**
     * Algoritma pembuatan kunci lisensi resmi:
     * Format: KPOS-[TIER]-[HASH1]-[HASH2]
     * Contoh: KPOS-PRO-7A9F-2B4C
     */
    fun generateLicenseKey(targetDeviceId: String, tier: String): String {
        val normalizedId = targetDeviceId.replace("-", "").trim().uppercase(Locale.ROOT)
        val normalizedTier = tier.trim().uppercase(Locale.ROOT) // "PRO" or "ENT"

        val rawInput = "$normalizedId:$normalizedTier:$SECRET_SALT"
        val hash = sha256(rawInput)

        val part1 = hash.substring(0, 4).uppercase(Locale.ROOT)
        val part2 = hash.substring(4, 8).uppercase(Locale.ROOT)

        return "KPOS-$normalizedTier-$part1-$part2"
    }

    /**
     * Memverifikasi lisensi untuk perangkat ini
     */
    fun activateLicense(inputKey: String): Result<String> {
        val cleanKey = inputKey.trim().uppercase(Locale.ROOT)
        val parts = cleanKey.split("-")

        if (parts.size != 4 || parts[0] != "KPOS") {
            return Result.failure(Exception("Format kunci tidak valid. Format: KPOS-[PRO/ENT]-XXXX-XXXX"))
        }

        val tier = parts[1] // "PRO" or "ENT"
        if (tier != "PRO" && tier != "ENT") {
            return Result.failure(Exception("Tipe lisensi tidak dikenali ($tier). Gunakan PRO atau ENT."))
        }

        val expectedKey = generateLicenseKey(deviceId, tier)
        if (cleanKey != expectedKey) {
            return Result.failure(Exception("Kunci lisensi tidak cocok untuk Device ID perangkat ini ($deviceId)."))
        }

        // Simpan lisensi berhasil
        prefs.edit()
            .putBoolean("is_activated", true)
            .putString("license_tier", if (tier == "PRO") "PRO" else "ENTERPRISE")
            .putString("license_key", cleanKey)
            .putLong("activation_date", System.currentTimeMillis())
            .apply()

        return Result.success("Lisensi $tier Berhasil Diaktifkan Seumur Hidup!")
    }

    // --- Member Point Settings ---
    fun getPointSettings(): com.example.data.model.PointSettings {
        val spend = prefs.getLong("point_spend_per_pt", 10000L)
        val value = prefs.getLong("point_value_rupiah", 100L)
        val maxPct = prefs.getInt("point_max_percentage", 100)
        val minPts = prefs.getInt("point_min_redeem", 10)
        return com.example.data.model.PointSettings(
            spendPerPoint = spend,
            pointValueInRupiah = value,
            maxRedeemPercentage = maxPct,
            minPointsToRedeem = minPts
        )
    }

    fun updatePointSettings(settings: com.example.data.model.PointSettings) {
        prefs.edit()
            .putLong("point_spend_per_pt", settings.spendPerPoint)
            .putLong("point_value_rupiah", settings.pointValueInRupiah)
            .putInt("point_max_percentage", settings.maxRedeemPercentage)
            .putInt("point_min_redeem", settings.minPointsToRedeem)
            .apply()
    }

    // --- Bluetooth Printer Settings ---
    fun getPrinterSettings(): com.example.data.model.PrinterSettings {
        return com.example.data.model.PrinterSettings(
            selectedDeviceAddress = prefs.getString("printer_device_address", "") ?: "",
            selectedDeviceName = prefs.getString("printer_device_name", "") ?: "",
            paperSize = prefs.getString("printer_paper_size", "58mm") ?: "58mm",
            autoPrintOnCheckout = prefs.getBoolean("printer_auto_print", false),
            printLogo = prefs.getBoolean("printer_print_logo", true),
            printHeader = prefs.getBoolean("printer_print_header", true),
            printFooter = prefs.getBoolean("printer_print_footer", true),
            printCashier = prefs.getBoolean("printer_print_cashier", true),
            cutPaper = prefs.getBoolean("printer_cut_paper", false),
            customHeader = prefs.getString("printer_custom_header", "Selamat Datang & Terima Kasih") ?: "Selamat Datang & Terima Kasih",
            customFooter = prefs.getString("printer_custom_footer", "Barang yang sudah dibeli tidak dapat ditukar.\nTerima kasih atas kunjungan Anda!") ?: "Barang yang sudah dibeli tidak dapat ditukar.\nTerima kasih atas kunjungan Anda!"
        )
    }

    fun updatePrinterSettings(settings: com.example.data.model.PrinterSettings) {
        prefs.edit()
            .putString("printer_device_address", settings.selectedDeviceAddress.trim())
            .putString("printer_device_name", settings.selectedDeviceName.trim())
            .putString("printer_paper_size", settings.paperSize)
            .putBoolean("printer_auto_print", settings.autoPrintOnCheckout)
            .putBoolean("printer_print_logo", settings.printLogo)
            .putBoolean("printer_print_header", settings.printHeader)
            .putBoolean("printer_print_footer", settings.printFooter)
            .putBoolean("printer_print_cashier", settings.printCashier)
            .putBoolean("printer_cut_paper", settings.cutPaper)
            .putString("printer_custom_header", settings.customHeader.trim())
            .putString("printer_custom_footer", settings.customFooter.trim())
            .apply()
    }

    fun resetToTrial() {
        prefs.edit()
            .putBoolean("is_activated", false)
            .putString("license_tier", "TRIAL")
            .putString("license_key", "")
            .putLong("activation_date", 0L)
            .apply()
    }

    // --- Backup & Restore Settings ---
    fun getLastBackupTimestamp(): Long {
        return prefs.getLong("last_backup_timestamp", 0L)
    }

    fun setLastBackupTimestamp(timestamp: Long) {
        prefs.edit().putLong("last_backup_timestamp", timestamp).apply()
    }

    fun exportSettingsToJson(): org.json.JSONObject {
        val root = org.json.JSONObject()

        val store = org.json.JSONObject().apply {
            put("storeName", prefs.getString("store_name", "Toko Modern Kasir") ?: "Toko Modern Kasir")
            put("storeAddress", prefs.getString("store_address", "Jl. Nusantara No. 88") ?: "Jl. Nusantara No. 88")
            put("storePhone", prefs.getString("store_phone", "0812-3456-7890") ?: "0812-3456-7890")
            put("receiptFooter", prefs.getString("receipt_footer", "Terima kasih telah berbelanja!") ?: "Terima kasih telah berbelanja!")
            put("storeLogoUri", prefs.getString("store_logo_uri", "") ?: "")
            put("qrisImageUri", prefs.getString("qris_image_uri", "") ?: "")
            put("qrisMerchantName", prefs.getString("qris_merchant_name", "Toko Modern Kasir") ?: "Toko Modern Kasir")
            put("qrisNmid", prefs.getString("qris_nmid", "ID1020304050607") ?: "ID1020304050607")
            put("licenseTier", prefs.getString("license_tier", "TRIAL") ?: "TRIAL")
            put("isActivated", prefs.getBoolean("is_activated", false))
            put("licenseKey", prefs.getString("license_key", "") ?: "")
        }
        root.put("storeSettings", store)

        val points = org.json.JSONObject().apply {
            put("spendPerPoint", prefs.getLong("point_spend_per_pt", 10000L))
            put("pointValueInRupiah", prefs.getLong("point_value_rupiah", 100L))
            put("maxRedeemPercentage", prefs.getInt("point_max_percentage", 100))
            put("minPointsToRedeem", prefs.getInt("point_min_redeem", 10))
        }
        root.put("pointSettings", points)

        val printer = org.json.JSONObject().apply {
            put("printerDeviceAddress", prefs.getString("printer_device_address", "") ?: "")
            put("printerDeviceName", prefs.getString("printer_device_name", "") ?: "")
            put("paperSize", prefs.getString("printer_paper_size", "58mm") ?: "58mm")
            put("autoPrint", prefs.getBoolean("printer_auto_print", false))
            put("printLogo", prefs.getBoolean("printer_print_logo", true))
            put("printHeader", prefs.getBoolean("printer_print_header", true))
            put("printFooter", prefs.getBoolean("printer_print_footer", true))
            put("printCashier", prefs.getBoolean("printer_print_cashier", true))
            put("cutPaper", prefs.getBoolean("printer_cut_paper", false))
            put("customHeader", prefs.getString("printer_custom_header", "Selamat Datang & Terima Kasih") ?: "Selamat Datang & Terima Kasih")
            put("customFooter", prefs.getString("printer_custom_footer", "Barang yang sudah dibeli tidak dapat ditukar.\nTerima kasih atas kunjungan Anda!") ?: "Barang yang sudah dibeli tidak dapat ditukar.\nTerima kasih atas kunjungan Anda!")
        }
        root.put("printerSettings", printer)

        return root
    }

    fun importSettingsFromJson(root: org.json.JSONObject) {
        val editor = prefs.edit()

        root.optJSONObject("storeSettings")?.let { store ->
            if (store.has("storeName")) editor.putString("store_name", store.optString("storeName"))
            if (store.has("storeAddress")) editor.putString("store_address", store.optString("storeAddress"))
            if (store.has("storePhone")) editor.putString("store_phone", store.optString("storePhone"))
            if (store.has("receiptFooter")) editor.putString("receipt_footer", store.optString("receiptFooter"))
            if (store.has("storeLogoUri")) editor.putString("store_logo_uri", store.optString("storeLogoUri"))
            if (store.has("qrisImageUri")) editor.putString("qris_image_uri", store.optString("qrisImageUri"))
            if (store.has("qrisMerchantName")) editor.putString("qris_merchant_name", store.optString("qrisMerchantName"))
            if (store.has("qrisNmid")) editor.putString("qris_nmid", store.optString("qrisNmid"))
            if (store.has("licenseTier")) editor.putString("license_tier", store.optString("licenseTier"))
            if (store.has("isActivated")) editor.putBoolean("is_activated", store.optBoolean("isActivated"))
            if (store.has("licenseKey")) editor.putString("license_key", store.optString("licenseKey"))
        }

        root.optJSONObject("pointSettings")?.let { pt ->
            if (pt.has("spendPerPoint")) editor.putLong("point_spend_per_pt", pt.optLong("spendPerPoint", 10000L))
            if (pt.has("pointValueInRupiah")) editor.putLong("point_value_rupiah", pt.optLong("pointValueInRupiah", 100L))
            if (pt.has("maxRedeemPercentage")) editor.putInt("point_max_percentage", pt.optInt("maxRedeemPercentage", 100))
            if (pt.has("minPointsToRedeem")) editor.putInt("point_min_redeem", pt.optInt("minPointsToRedeem", 10))
        }

        root.optJSONObject("printerSettings")?.let { pr ->
            if (pr.has("printerDeviceAddress")) editor.putString("printer_device_address", pr.optString("printerDeviceAddress"))
            if (pr.has("printerDeviceName")) editor.putString("printer_device_name", pr.optString("printerDeviceName"))
            if (pr.has("paperSize")) editor.putString("printer_paper_size", pr.optString("paperSize", "58mm"))
            if (pr.has("autoPrint")) editor.putBoolean("printer_auto_print", pr.optBoolean("autoPrint", false))
            if (pr.has("printLogo")) editor.putBoolean("printer_print_logo", pr.optBoolean("printLogo", true))
            if (pr.has("printHeader")) editor.putBoolean("printer_print_header", pr.optBoolean("printHeader", true))
            if (pr.has("printFooter")) editor.putBoolean("printer_print_footer", pr.optBoolean("printFooter", true))
            if (pr.has("printCashier")) editor.putBoolean("printer_print_cashier", pr.optBoolean("printCashier", true))
            if (pr.has("cutPaper")) editor.putBoolean("printer_cut_paper", pr.optBoolean("cutPaper", false))
            if (pr.has("customHeader")) editor.putString("printer_custom_header", pr.optString("customHeader"))
            if (pr.has("customFooter")) editor.putString("printer_custom_footer", pr.optString("customFooter"))
        }

        editor.apply()
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
