package com.example.ui.screens.sis

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.CashierUserEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.PosViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmployeeManagementScreen(
    viewModel: PosViewModel,
    onNavigateBack: () -> Unit
) {
    val cashiers by viewModel.allCashiers.collectAsState()

    var showEditorDialog by remember { mutableStateOf(false) }
    var selectedUserToEdit by remember { mutableStateOf<CashierUserEntity?>(null) }
    var feedbackMsg by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("DATA KARYAWAN & HAK AKSES", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Kembali")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = RetailNavy,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    selectedUserToEdit = null
                    showEditorDialog = true
                },
                containerColor = RetailRedPrimary,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.PersonAdd, contentDescription = "Tambah Karyawan")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(PosSurface)
                .padding(12.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = RetailBlueLight)
            ) {
                Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = RetailNavy)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "Kelola staf toko dan atur hak akses secara detail (otorisasi void, retur, pending, edit produk, laporan, dll).",
                        fontSize = 11.sp,
                        color = DarkText
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (feedbackMsg.isNotEmpty()) {
                Text(feedbackMsg, color = RetailGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp))
            }

            Text("DAFTAR KARYAWAN TOKO (${cashiers.size} Orang):", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = GrayText)

            Spacer(modifier = Modifier.height(6.dp))

            LazyColumn(modifier = Modifier.weight(1f)) {
                items(cashiers) { user ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable {
                                selectedUserToEdit = user
                                showEditorDialog = true
                            },
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = androidx.compose.foundation.BorderStroke(1.dp, PosCardBorder)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(user.nama, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.Black)
                                Surface(
                                    color = if (user.role.contains("COS") || user.role.contains("ADMIN")) RetailRedPrimary else RetailNavy,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        user.role,
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Text("NIK: ${user.nik} | Password: ${user.password} | PIN: ${user.pinEtrans}", fontSize = 11.sp, color = Color.DarkGray)

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                "Hak Akses: " + listOfNotNull(
                                    if (user.canVoid) "Void" else null,
                                    if (user.canReturnSales) "Retur Penjualan" else null,
                                    if (user.canDoPurchase) "Pembelian" else null,
                                    if (user.canEditProduct) "Edit Produk" else null,
                                    if (user.canViewReports) "Laporan" else null,
                                    if (user.canDoEod) "EOD" else null
                                ).joinToString(", "),
                                fontSize = 10.sp,
                                color = RetailGreen,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }

    // Modal Editor Karyawan & Checklist Hak Akses Granular
    if (showEditorDialog) {
        val isEdit = selectedUserToEdit != null
        var nik by remember { mutableStateOf(selectedUserToEdit?.nik ?: (20260000..20269999).random().toString()) }
        var nama by remember { mutableStateOf(selectedUserToEdit?.nama ?: "") }
        var role by remember { mutableStateOf(selectedUserToEdit?.role ?: "KASIR") }
        var password by remember { mutableStateOf(selectedUserToEdit?.password ?: "1234") }
        var pinEtrans by remember { mutableStateOf(selectedUserToEdit?.pinEtrans ?: "112233") }

        // Granular Permissions (as requested by user)
        var canDeleteCartItem by remember { mutableStateOf(selectedUserToEdit?.canDeleteCartItem ?: true) }
        var canVoid by remember { mutableStateOf(selectedUserToEdit?.canVoid ?: true) }
        var canCancelCart by remember { mutableStateOf(selectedUserToEdit?.canCancelCart ?: true) }
        var canDeletePending by remember { mutableStateOf(selectedUserToEdit?.canDeletePending ?: true) }
        var canReturnSales by remember { mutableStateOf(selectedUserToEdit?.canReturnSales ?: true) }
        var canDoPurchase by remember { mutableStateOf(selectedUserToEdit?.canDoPurchase ?: true) }
        var canDoReturnPurchase by remember { mutableStateOf(selectedUserToEdit?.canDoReturnPurchase ?: true) }
        var canEditEmployee by remember { mutableStateOf(selectedUserToEdit?.canEditEmployee ?: false) }
        var canEditProduct by remember { mutableStateOf(selectedUserToEdit?.canEditProduct ?: false) }
        var canViewReports by remember { mutableStateOf(selectedUserToEdit?.canViewReports ?: true) }
        var canDoEod by remember { mutableStateOf(selectedUserToEdit?.canDoEod ?: false) }

        AlertDialog(
            onDismissRequest = { showEditorDialog = false },
            title = { Text(if (isEdit) "EDIT DATA KARYAWAN" else "TAMBAH KARYAWAN BARU", fontWeight = FontWeight.Bold) },
            text = {
                LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 440.dp)) {
                    item {
                        val tfColors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.Black,
                            unfocusedTextColor = Color.Black,
                            focusedBorderColor = RetailNavy,
                            unfocusedBorderColor = PosCardBorder
                        )
                        OutlinedTextField(value = nik, onValueChange = { nik = it }, label = { Text("NIK Karyawan", color = Color.DarkGray) }, modifier = Modifier.fillMaxWidth(), singleLine = true, colors = tfColors)
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(value = nama, onValueChange = { nama = it }, label = { Text("Nama Lengkap", color = Color.DarkGray) }, modifier = Modifier.fillMaxWidth(), singleLine = true, colors = tfColors)
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(value = role, onValueChange = { role = it }, label = { Text("Jabatan (KASIR / ACOS / COS / ADMIN)", color = Color.DarkGray) }, modifier = Modifier.fillMaxWidth(), singleLine = true, colors = tfColors)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Password", color = Color.DarkGray) }, modifier = Modifier.weight(1f), singleLine = true, colors = tfColors)
                            OutlinedTextField(value = pinEtrans, onValueChange = { pinEtrans = it }, label = { Text("PIN E-Trans", color = Color.DarkGray) }, modifier = Modifier.weight(1f), singleLine = true, colors = tfColors)
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text("CHECKLIST HAK AKSES OPERASIONAL:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = RetailNavy)

                        AccessCheckbox("Boleh menghapus item di keranjang kasir", canDeleteCartItem) { canDeleteCartItem = it }
                        AccessCheckbox("Boleh melakukan VOID item kasir", canVoid) { canVoid = it }
                        AccessCheckbox("Boleh membatalkan seluruh transaksi (F4)", canCancelCart) { canCancelCart = it }
                        AccessCheckbox("Boleh menghapus item pending", canDeletePending) { canDeletePending = it }
                        AccessCheckbox("Boleh melakukan retur penjualan konsumen", canReturnSales) { canReturnSales = it }
                        AccessCheckbox("Boleh melakukan pembelian produk", canDoPurchase) { canDoPurchase = it }
                        AccessCheckbox("Boleh melakukan retur pembelian supplier", canDoReturnPurchase) { canDoReturnPurchase = it }
                        AccessCheckbox("Boleh edit data karyawan & akses", canEditEmployee) { canEditEmployee = it }
                        AccessCheckbox("Boleh edit dan tambah produk", canEditProduct) { canEditProduct = it }
                        AccessCheckbox("Boleh melihat laporan toko", canViewReports) { canViewReports = it }
                        AccessCheckbox("Boleh menjalankan proses EOD tutup toko", canDoEod) { canDoEod = it }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val user = CashierUserEntity(
                            nik = nik.trim(),
                            nama = nama.trim(),
                            role = role.trim().uppercase(),
                            password = password.trim(),
                            pinEtrans = pinEtrans.trim(),
                            canDeleteCartItem = canDeleteCartItem,
                            canVoid = canVoid,
                            canCancelCart = canCancelCart,
                            canDeletePending = canDeletePending,
                            canReturnSales = canReturnSales,
                            canDoPurchase = canDoPurchase,
                            canDoReturnPurchase = canDoReturnPurchase,
                            canEditEmployee = canEditEmployee,
                            canEditProduct = canEditProduct,
                            canViewReports = canViewReports,
                            canDoEod = canDoEod
                        )
                        viewModel.saveCashierUser(user) {
                            feedbackMsg = "Data karyawan ${user.nama} berhasil disimpan!"
                            showEditorDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RetailGreen)
                ) {
                    Text("SIMPAN KARYAWAN")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showEditorDialog = false }) {
                    Text("BATAL")
                }
            }
        )
    }
}

@Composable
fun AccessCheckbox(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable { onCheckedChange(!checked) }.padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked = checked, onCheckedChange = onCheckedChange, colors = CheckboxDefaults.colors(checkedColor = RetailGreen))
        Spacer(modifier = Modifier.width(4.dp))
        Text(label, fontSize = 11.sp, color = Color.Black)
    }
}
