package com.example.ui.screens.pos

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.entity.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.CartItem
import com.example.ui.viewmodel.PendingCart
import com.example.util.DocExportManager
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

fun formatRupiah(amount: Double): String {
    val format = NumberFormat.getCurrencyInstance(Locale("id", "ID"))
    format.maximumFractionDigits = 0
    return format.format(amount).replace("Rp", "Rp ")
}

// --- 1. LOV (Product Lookup) Dialog ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LovProductDialog(
    products: List<ProductEntity>,
    onDismiss: () -> Unit,
    onSelectProduct: (ProductEntity, Int) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Semua") }
    var selectedProduct by remember { mutableStateOf<ProductEntity?>(null) }
    var selectedQty by remember { mutableStateOf(1) }

    val categories = remember(products) {
        listOf("Semua") + products.map { it.kategori }.distinct().sorted()
    }

    val filtered = remember(searchQuery, selectedCategory, products) {
        products.filter { p ->
            (selectedCategory == "Semua" || p.kategori.equals(selectedCategory, ignoreCase = true)) &&
                    (p.nama.contains(searchQuery, ignoreCase = true) ||
                            p.plu.contains(searchQuery, ignoreCase = true) ||
                            p.barcode.contains(searchQuery, ignoreCase = true))
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.85f)
                .testTag("lov_product_dialog"),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                // Header (Red retail banner style)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RetailRedPrimary, RoundedCornerShape(8.dp))
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "LOV - CARI PRODUK / PLU",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 16.sp
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup", tint = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Search Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier.fillMaxWidth().testTag("lov_search_input"),
                    placeholder = { Text("Ketik Nama Barang / PLU / Barcode...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Category chips
                ScrollableTabRow(
                    selectedTabIndex = categories.indexOf(selectedCategory).coerceAtLeast(0),
                    edgePadding = 4.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    categories.forEach { cat ->
                        Tab(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            text = { Text(cat, fontSize = 12.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Table Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RetailNavy.copy(alpha = 0.1f))
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text("PLU", modifier = Modifier.weight(1.2f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.Black)
                    Text("Nama Barang", modifier = Modifier.weight(3f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.Black)
                    Text("Stok", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.Black)
                    Text("Harga", modifier = Modifier.weight(1.5f), fontWeight = FontWeight.Bold, fontSize = 11.sp, textAlign = TextAlign.End, color = Color.Black)
                }

                // Table Items
                LazyColumn(modifier = Modifier.weight(1f)) {
                    items(filtered) { prod ->
                        val isSelected = selectedProduct?.plu == prod.plu
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(if (isSelected) RetailAmberLight else Color.Transparent)
                                .clickable { selectedProduct = prod }
                                .padding(horizontal = 8.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(prod.plu, modifier = Modifier.weight(1.2f), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                            Column(modifier = Modifier.weight(3f)) {
                                Text(prod.nama, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, color = Color.Black)
                                Text("${prod.kategori} | Rak: ${prod.rakPlanogram}", fontSize = 10.sp, color = Color.DarkGray)
                            }
                            Text("${prod.stok}", modifier = Modifier.weight(1f), fontSize = 12.sp, color = Color.Black)
                            Text(formatRupiah(prod.hargaJual), modifier = Modifier.weight(1.5f), fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End, color = RetailRedDark)
                        }
                        HorizontalDivider(color = PosCardBorder.copy(alpha = 0.5f))
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Action Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Qty: ", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.Black)
                        IconButton(
                            onClick = { if (selectedQty > 1) selectedQty-- },
                            enabled = selectedProduct != null
                        ) {
                            Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Kurang")
                        }
                        Text("$selectedQty", fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(horizontal = 4.dp), color = Color.Black)
                        IconButton(
                            onClick = { selectedQty++ },
                            enabled = selectedProduct != null
                        ) {
                            Icon(Icons.Default.AddCircleOutline, contentDescription = "Tambah")
                        }
                    }

                    Row {
                        OutlinedButton(onClick = onDismiss, modifier = Modifier.padding(end = 8.dp)) {
                            Text("TUTUP")
                        }
                        Button(
                            onClick = {
                                selectedProduct?.let {
                                    onSelectProduct(it, selectedQty)
                                    onDismiss()
                                }
                            },
                            enabled = selectedProduct != null,
                            colors = ButtonDefaults.buttonColors(containerColor = RetailRedPrimary),
                            modifier = Modifier.testTag("lov_ambil_button")
                        ) {
                            Text("AMBIL (ENTER)")
                        }
                    }
                }
            }
        }
    }
}

// --- 2. Mandatory Pending Label Dialog ---
@Composable
fun PendingLabelDialog(
    onDismiss: () -> Unit,
    onConfirm: (label: String) -> Unit
) {
    var labelInput by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(0.95f),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RetailAmber, RoundedCornerShape(6.dp))
                        .padding(10.dp)
                ) {
                    Text("PENDING TRANSAKSI (F5)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    "Wajib memberi nama/label antrian pending agar mudah dicari saat recall:",
                    fontSize = 12.sp,
                    color = Color.Black,
                    fontWeight = FontWeight.Medium
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = labelInput,
                    onValueChange = {
                        labelInput = it
                        if (it.isNotBlank()) errorText = ""
                    },
                    modifier = Modifier.fillMaxWidth().testTag("pending_label_input"),
                    placeholder = { Text("Contoh: Ibu Ani / Meja 3 / Baju Biru") },
                    singleLine = true,
                    isError = errorText.isNotEmpty()
                )

                if (errorText.isNotEmpty()) {
                    Text(errorText, color = MaterialTheme.colorScheme.error, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("BATAL")
                    }
                    Button(
                        onClick = {
                            if (labelInput.trim().isEmpty()) {
                                errorText = "Label pending wajib diisi!"
                            } else {
                                onConfirm(labelInput.trim())
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = RetailAmber),
                        modifier = Modifier.weight(1f).testTag("btn_confirm_pending")
                    ) {
                        Text("SIMPAN PENDING", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// --- 3. Recall Pending List Dialog ---
@Composable
fun RecallPendingDialog(
    pendingCarts: List<PendingCart>,
    onResumeCart: (id: String) -> Unit,
    onDeleteCart: (id: String) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.8f),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RetailNavy, RoundedCornerShape(6.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("DAFTAR TRANSAKSI PENDING (RECALL F6)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    IconButton(onClick = onDismiss, modifier = Modifier.size(20.dp)) {
                        Icon(Icons.Default.Close, contentDescription = null, tint = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (pendingCarts.isEmpty()) {
                    Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text("Tidak ada transaksi dalam antrian pending.", color = GrayText, fontSize = 13.sp)
                    }
                } else {
                    LazyColumn(modifier = Modifier.weight(1f)) {
                        items(pendingCarts) { cart ->
                            val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(cart.timestamp))
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                colors = CardDefaults.cardColors(containerColor = PosSurfaceVariant),
                                border = androidx.compose.foundation.BorderStroke(1.dp, PosCardBorder)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            "🏷️ ${cart.label}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = Color.Black
                                        )
                                        Text("Pukul: $timeStr", fontSize = 11.sp, color = GrayText)
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Text(
                                        "Jumlah Item: ${cart.items.size} barang | Total: ${formatRupiah(cart.totalAmount)}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = RetailRedDark
                                    )

                                    if (cart.member != null) {
                                        Text("Member: ${cart.member.nama}", fontSize = 11.sp, color = RetailGreen)
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                        OutlinedButton(
                                            onClick = { onDeleteCart(cart.id) },
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = RetailRedPrimary),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                            modifier = Modifier.height(32.dp).padding(end = 6.dp)
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Hapus", fontSize = 11.sp)
                                        }

                                        Button(
                                            onClick = {
                                                onResumeCart(cart.id)
                                                onDismiss()
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = RetailGreen),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                                            modifier = Modifier.height(32.dp)
                                        ) {
                                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Lanjutkan", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) {
                    Text("TUTUP")
                }
            }
        }
    }
}

// --- 4. Payment Dialog with Split Payment & Member Points (Donasi removed) ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentDialog(
    grandTotal: Double,
    currentMember: MemberEntity?,
    storeConfig: StoreConfigEntity,
    appliedPoin: Int,
    onApplyMemberPoints: (Int) -> Unit,
    onApplyVoucher: (String) -> Pair<Boolean, String>,
    onDismiss: () -> Unit,
    onProcessPayment: (caraBayar: String, bayarTunai: Double, bayarNonTunai: Double, ref: String) -> Unit
) {
    var selectedMethod by remember { mutableStateOf("TUNAI") } // TUNAI, CAMPURAN, WALLET, CARD, VOUCHER
    var cashInput by remember { mutableStateOf("") }
    var nonCashInput by remember { mutableStateOf("") }
    var selectedWallet by remember { mutableStateOf("QRIS") }
    var walletPhone by remember { mutableStateOf("") }
    var selectedCardBank by remember { mutableStateOf("BCA") }
    var cardApprovalCode by remember { mutableStateOf("") }
    var voucherCodeInput by remember { mutableStateOf("") }
    var voucherMessage by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    val numericCash = cashInput.toDoubleOrNull() ?: 0.0
    val numericNonCash = nonCashInput.toDoubleOrNull() ?: 0.0
    val totalPaid = if (selectedMethod == "CAMPURAN") (numericCash + numericNonCash) else numericCash
    val kembalian = (totalPaid - grandTotal).coerceAtLeast(0.0)

    val quickCashButtons = listOf(1000.0, 5000.0, 10000.0, 20000.0, 50000.0, 100000.0)
    val walletOptions = listOf("QRIS", "DANA", "GOPAY", "OVO", "SHOPEEPAY", "LINKAJA", "KREDIVO")
    val bankOptions = listOf("BCA", "MANDIRI", "BRI", "BNI")

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f)
                .testTag("payment_dialog"),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.fillMaxSize().padding(14.dp)) {
                // Total Tagihan Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RetailRedPrimary, RoundedCornerShape(8.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("TOTAL TAGIHAN", color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(formatRupiah(grandTotal), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Batal", tint = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Member Points Deduction Section
                if (currentMember != null) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = RetailGreenLight)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Member: ${currentMember.nama} (${currentMember.poin} Poin)", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = RetailGreen)
                                Text("Tukar poin potongan harga (1 Poin = ${formatRupiah(storeConfig.nilaiPerPoin)})", fontSize = 10.sp, color = Color.DarkGray)
                            }

                            if (appliedPoin > 0) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("-${formatRupiah(appliedPoin * storeConfig.nilaiPerPoin)}", fontWeight = FontWeight.Bold, color = RetailRedDark, fontSize = 12.sp)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    TextButton(onClick = { onApplyMemberPoints(0) }) {
                                        Text("Batal", fontSize = 10.sp)
                                    }
                                }
                            } else {
                                Button(
                                    onClick = {
                                        val maxPointsByTotal = (grandTotal / storeConfig.nilaiPerPoin).toInt()
                                        val usable = currentMember.poin.coerceAtMost(maxPointsByTotal)
                                        onApplyMemberPoints(usable)
                                    },
                                    enabled = currentMember.poin > 0,
                                    colors = ButtonDefaults.buttonColors(containerColor = RetailGreen),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(30.dp)
                                ) {
                                    Text("Gunakan Poin", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                }

                // Payment Method Selector Tabs: TUNAI, CAMPURAN, WALLET, CARD
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf("TUNAI", "CAMPURAN", "WALLET", "CARD").forEach { method ->
                        val isSelected = selectedMethod == method
                        Button(
                            onClick = { selectedMethod = method },
                            modifier = Modifier.weight(1f).height(40.dp),
                            shape = RoundedCornerShape(6.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSelected) RetailNavy else PosSurfaceVariant,
                                contentColor = if (isSelected) Color.White else Color.Black
                            ),
                            contentPadding = PaddingValues(2.dp)
                        ) {
                            Text(method, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Method Specific Fields
                Box(modifier = Modifier.weight(1f)) {
                    when (selectedMethod) {
                        "TUNAI" -> {
                            Column(modifier = Modifier.fillMaxSize()) {
                                Text("Uang Tunai Konsumen:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Black)
                                OutlinedTextField(
                                    value = cashInput,
                                    onValueChange = { cashInput = it },
                                    modifier = Modifier.fillMaxWidth().testTag("cash_input_field"),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    textStyle = LocalTextStyle.current.copy(fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                )

                                Spacer(modifier = Modifier.height(6.dp))

                                // Quick Cash Buttons
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    quickCashButtons.take(3).forEach { amt ->
                                        OutlinedButton(
                                            onClick = { cashInput = amt.toLong().toString() },
                                            modifier = Modifier.weight(1f),
                                            contentPadding = PaddingValues(2.dp)
                                        ) {
                                            Text(NumberFormat.getIntegerInstance(Locale("id", "ID")).format(amt), fontSize = 11.sp, color = Color.Black)
                                        }
                                    }
                                }
                                Row(modifier = Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    quickCashButtons.drop(3).forEach { amt ->
                                        OutlinedButton(
                                            onClick = { cashInput = amt.toLong().toString() },
                                            modifier = Modifier.weight(1f),
                                            contentPadding = PaddingValues(2.dp)
                                        ) {
                                            Text(NumberFormat.getIntegerInstance(Locale("id", "ID")).format(amt), fontSize = 11.sp, color = Color.Black)
                                        }
                                    }
                                }

                                Row(modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                                    Button(
                                        onClick = { cashInput = grandTotal.toLong().toString() },
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = ButtonDefaults.buttonColors(containerColor = RetailAmber)
                                    ) {
                                        Text("UANG PAS (${formatRupiah(grandTotal)})", fontWeight = FontWeight.Bold)
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = RetailGreenLight)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("KEMBALIAN:", fontWeight = FontWeight.Bold, color = RetailGreen, fontSize = 13.sp)
                                        Text(formatRupiah(kembalian), fontWeight = FontWeight.Bold, color = RetailGreen, fontSize = 18.sp)
                                    }
                                }
                            }
                        }

                        "CAMPURAN" -> {
                            // Split Payment: Tunai + Non-Tunai
                            Column(modifier = Modifier.fillMaxSize()) {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = RetailAmberLight)
                                ) {
                                    Text(
                                        "PEMBAYARAN CAMPURAN: Bayar sebagian dengan Tunai dan sisanya Non-Tunai (EDC/QRIS).",
                                        fontSize = 11.sp,
                                        color = Color(0xFF6D4C41),
                                        modifier = Modifier.padding(6.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Text("1. Bayar Tunai (Rp):", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Black)
                                OutlinedTextField(
                                    value = cashInput,
                                    onValueChange = {
                                        cashInput = it
                                        val cVal = it.toDoubleOrNull() ?: 0.0
                                        val sisa = (grandTotal - cVal).coerceAtLeast(0.0)
                                        nonCashInput = sisa.toLong().toString()
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true
                                )

                                Spacer(modifier = Modifier.height(6.dp))

                                Text("2. Sisa Bayar Non-Tunai (EDC / QRIS):", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Black)
                                OutlinedTextField(
                                    value = nonCashInput,
                                    onValueChange = { nonCashInput = it },
                                    modifier = Modifier.fillMaxWidth(),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true
                                )

                                Spacer(modifier = Modifier.height(6.dp))

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    listOf("BCA EDC", "MANDIRI", "QRIS", "DANA").forEach { b ->
                                        FilterChip(
                                            selected = selectedCardBank == b,
                                            onClick = { selectedCardBank = b },
                                            label = { Text(b, fontSize = 10.sp) }
                                        )
                                    }
                                }
                            }
                        }

                        "WALLET" -> {
                            Column(modifier = Modifier.fillMaxSize()) {
                                Text("Pilih E-Wallet / QRIS:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Black)
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    walletOptions.take(4).forEach { w ->
                                        FilterChip(selected = selectedWallet == w, onClick = { selectedWallet = w }, label = { Text(w, fontSize = 9.sp) })
                                    }
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    walletOptions.drop(4).forEach { w ->
                                        FilterChip(selected = selectedWallet == w, onClick = { selectedWallet = w }, label = { Text(w, fontSize = 9.sp) })
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedTextField(
                                    value = walletPhone,
                                    onValueChange = { walletPhone = it },
                                    modifier = Modifier.fillMaxWidth(),
                                    label = { Text("No. HP / Kode QRIS") },
                                    placeholder = { Text("08xxxxxxxxxx") },
                                    singleLine = true
                                )
                            }
                        }

                        "CARD" -> {
                            Column(modifier = Modifier.fillMaxSize()) {
                                Text("Pilih EDC Bank:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Black)
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    bankOptions.forEach { b ->
                                        FilterChip(selected = selectedCardBank == b, onClick = { selectedCardBank = b }, label = { Text(b) })
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedTextField(
                                    value = cardApprovalCode,
                                    onValueChange = { cardApprovalCode = it },
                                    modifier = Modifier.fillMaxWidth(),
                                    label = { Text("No. Kartu / Trace / Approval Code") },
                                    singleLine = true
                                )
                            }
                        }
                    }
                }

                // Voucher Input Row
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = voucherCodeInput,
                        onValueChange = { voucherCodeInput = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Ketik Kode Voucher (Opsional)") },
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Button(
                        onClick = {
                            val res = onApplyVoucher(voucherCodeInput)
                            voucherMessage = res.second
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = RetailNavy)
                    ) {
                        Text("Klaim")
                    }
                }
                if (voucherMessage.isNotEmpty()) {
                    Text(voucherMessage, fontSize = 11.sp, color = RetailGreen, fontWeight = FontWeight.Bold)
                }

                if (errorMessage.isNotEmpty()) {
                    Text(errorMessage, color = MaterialTheme.colorScheme.error, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Bottom Process Buttons
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("BATAL")
                    }
                    Button(
                        onClick = {
                            when (selectedMethod) {
                                "TUNAI" -> {
                                    if (numericCash < grandTotal) {
                                        errorMessage = "Uang tunai kurang dari tagihan!"
                                    } else {
                                        onProcessPayment("TUNAI", numericCash, 0.0, "TUNAI")
                                    }
                                }
                                "CAMPURAN" -> {
                                    if ((numericCash + numericNonCash) < grandTotal) {
                                        errorMessage = "Total pembayaran campuran kurang dari tagihan!"
                                    } else {
                                        onProcessPayment("CAMPURAN", numericCash, numericNonCash, "CAMPURAN: Tunai + $selectedCardBank")
                                    }
                                }
                                "WALLET" -> {
                                    onProcessPayment("WALLET", 0.0, grandTotal, "$selectedWallet - $walletPhone")
                                }
                                "CARD" -> {
                                    onProcessPayment("CARD", 0.0, grandTotal, "EDC $selectedCardBank #$cardApprovalCode")
                                }
                            }
                        },
                        modifier = Modifier.weight(1.5f).testTag("payment_proses_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = RetailRedPrimary)
                    ) {
                        Text("PROSES (ENTER)", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// --- 5. Thermal Receipt Dialog with Document Storage in DodolanPro/Penjualan ---
@Composable
fun ReceiptDialog(
    transaction: TransactionEntity,
    items: List<CartItem>,
    storeConfig: StoreConfigEntity,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var saveStatusMsg by remember { mutableStateOf("") }

    val receiptText = remember(transaction, items, storeConfig) {
        buildString {
            appendLine("       ${storeConfig.storeName}       ")
            if (storeConfig.receiptShowAlamat && storeConfig.alamat.isNotBlank()) {
                appendLine("       ${storeConfig.alamat}       ")
            }
            if (storeConfig.receiptShowTelp && storeConfig.telp.isNotBlank()) {
                appendLine("        TELP: ${storeConfig.telp}        ")
            }
            if (storeConfig.receiptShowNpwp && storeConfig.npwp.isNotBlank()) {
                appendLine("     NPWP: ${storeConfig.npwp}     ")
            }
            appendLine("----------------------------------------")
            if (storeConfig.receiptShowBonNo && storeConfig.receiptShowKasir) {
                appendLine("BON   : ${transaction.bonNo} KASIR: ${transaction.kasirNama}")
            } else if (storeConfig.receiptShowBonNo) {
                appendLine("BON   : ${transaction.bonNo}")
            } else if (storeConfig.receiptShowKasir) {
                appendLine("KASIR : ${transaction.kasirNama}")
            }
            if (transaction.memberNo.isNotEmpty()) {
                appendLine("MEMBER: ${transaction.memberNo}")
            }
            appendLine("----------------------------------------")
            items.forEach { item ->
                val pluPrefix = if (storeConfig.receiptShowPlu) "[${item.product.plu}] " else ""
                val name = (pluPrefix + item.product.nama).take(22).padEnd(22)
                val qtyStr = (if (item.isRetur) "-${item.qty}" else "${item.qty}").padStart(3)
                val priceStr = formatRupiah(item.product.hargaJual).padStart(11)
                appendLine("$name $qtyStr $priceStr")
                if (storeConfig.receiptShowDiskon && item.product.isPromo && item.product.diskonPersen > 0) {
                    appendLine("  * Diskon ${item.product.diskonPersen}%")
                }
                if (item.isVoid) {
                    appendLine("  ** ITEM VOID (${item.voidReason}) **")
                } else if (item.isRetur) {
                    appendLine("  ** ITEM RETUR KONSUMEN **")
                }
            }
            appendLine("----------------------------------------")
            appendLine("Total Item : ${items.filter { !it.isVoid }.sumOf { if (it.isRetur) -it.qty else it.qty }}")
            appendLine("Subtotal   : ${formatRupiah(transaction.subtotal)}")
            if (transaction.nilaiPotonganPoin > 0) {
                appendLine("Poin Member: -${formatRupiah(transaction.nilaiPotonganPoin)} (${transaction.poinDigunakan} pt)")
            }
            if (transaction.nilaiPotonganVoucher > 0) {
                appendLine("Voucher    : -${formatRupiah(transaction.nilaiPotonganVoucher)} (${transaction.kodeVoucher})")
            }
            appendLine("TOTAL      : ${formatRupiah(transaction.grandTotal)}")
            appendLine("Cara Bayar : ${transaction.caraBayar}")
            if (transaction.caraBayar == "CAMPURAN") {
                appendLine("Bayar Tunai: ${formatRupiah(transaction.bayarTunai)}")
                appendLine("Non-Tunai  : ${formatRupiah(transaction.bayarNonTunai)}")
                appendLine("Kembalian  : ${formatRupiah(transaction.kembalian)}")
            } else if (transaction.caraBayar == "TUNAI") {
                appendLine("Tunai      : ${formatRupiah(transaction.bayarTunai)}")
                appendLine("Kembalian  : ${formatRupiah(transaction.kembalian)}")
            } else {
                appendLine("Ref        : ${transaction.refPembayaran}")
            }
            val ppn = (transaction.grandTotal * 0.11 / 1.11)
            appendLine("PPN 11%    : ${formatRupiah(ppn)}")
            if (storeConfig.receiptShowHemat && transaction.diskonTotal > 0) {
                appendLine("----------------------------------------")
                appendLine("ANDA HEMAT : ${formatRupiah(transaction.diskonTotal)}")
            }
            if (storeConfig.receiptShowVoucher && storeConfig.activeVoucherCode.isNotEmpty()) {
                appendLine("----------------------------------------")
                appendLine("KODE VOUCHER ANDA: ${storeConfig.activeVoucherCode}")
                appendLine("Gunakan utk potongan Rp ${storeConfig.voucherDiscountAmount.toLong()}")
            }
            appendLine("----------------------------------------")
            if (storeConfig.receiptShowDateTime) {
                appendLine("Tgl. ${transaction.tanggal}  ${transaction.waktu}")
            }
            appendLine("========================================")
            appendLine("   ${storeConfig.footerMsg}   ")
            if (storeConfig.receiptPolicyMsg.isNotBlank()) {
                appendLine("   ${storeConfig.receiptPolicyMsg}   ")
            }
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.85f),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.fillMaxSize().padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Receipt, contentDescription = null, tint = RetailRedPrimary)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("STRUK TRANSAKSI KASIR", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup")
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Card(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .border(1.dp, Color.LightGray, RoundedCornerShape(4.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFAFAFA))
                ) {
                    LazyColumn(modifier = Modifier.fillMaxSize().padding(10.dp)) {
                        item {
                            Text(
                                text = receiptText,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                lineHeight = 16.sp,
                                color = Color.Black
                            )
                        }
                    }
                }

                if (saveStatusMsg.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(saveStatusMsg, fontSize = 11.sp, color = RetailGreen, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Action buttons: Simpan Dokumen ke DodolanPro/Penjualan, Bagikan, Selesai
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = {
                            val saved = DocExportManager.saveDocument(
                                context = context,
                                subfolder = "Penjualan",
                                prefix = "Struk_${transaction.bonNo}",
                                extension = "txt",
                                content = receiptText
                            )
                            saveStatusMsg = "Tersimpan di DodolanPro/Penjualan/${saved.second.name}"
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("SIMPAN FILE", fontSize = 10.sp)
                    }

                    OutlinedButton(
                        onClick = {
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "Struk ${transaction.bonNo}")
                                putExtra(Intent.EXTRA_TEXT, receiptText)
                            }
                            context.startActivity(Intent.createChooser(intent, "Bagikan Struk"))
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("BAGIKAN", fontSize = 10.sp)
                    }

                    Button(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = RetailRedPrimary)
                    ) {
                        Text("SELESAI", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// --- 6. VOID Item Dialog ---
@Composable
fun VoidItemDialog(
    item: CartItem,
    onDismiss: () -> Unit,
    onConfirmVoid: (otp: String, reason: String) -> Unit
) {
    var otpCode by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("Konsumen Batal") }
    val reasons = listOf("Konsumen Batal", "Salah Input Qty", "Dobel Barcode Scan", "Barang Rusak")

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(0.95f),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RetailRedPrimary, RoundedCornerShape(6.dp))
                        .padding(10.dp)
                ) {
                    Text("OTP VOID TRANSAKSI", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("Batalkan item berikut:", fontSize = 12.sp, color = Color.Black)
                Text(item.product.nama, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.Black)
                Text("Qty: ${item.qty} | Subtotal: ${formatRupiah(item.subtotal)}", fontSize = 12.sp, color = RetailRedDark, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(10.dp))

                Text("Alasan Void:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = Color.Black)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    reasons.take(2).forEach { r ->
                        FilterChip(selected = reason == r, onClick = { reason = r }, label = { Text(r, fontSize = 10.sp) })
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    reasons.drop(2).forEach { r ->
                        FilterChip(selected = reason == r, onClick = { reason = r }, label = { Text(r, fontSize = 10.sp) })
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text("Masukkan Kode OTP / Otorisasi Supervisor:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = Color.Black)
                OutlinedTextField(
                    value = otpCode,
                    onValueChange = { otpCode = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Contoh: 123456") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    trailingIcon = {
                        TextButton(onClick = { otpCode = (100000..999999).random().toString() }) {
                            Text("Bypass OTP", fontSize = 11.sp, color = RetailNavy)
                        }
                    },
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("BATAL")
                    }
                    Button(
                        onClick = { onConfirmVoid(otpCode, reason) },
                        enabled = otpCode.length >= 4,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = RetailRedPrimary)
                    ) {
                        Text("PROSES")
                    }
                }
            }
        }
    }
}

// --- 7. RETUR Konsumen Dialog ---
@Composable
fun ReturKonsumenDialog(
    onDismiss: () -> Unit,
    onLookupBon: suspend (String) -> Pair<TransactionEntity?, List<TransactionItemEntity>>,
    onConfirmRetur: (bonNo: String, product: ProductEntity, qty: Int, reason: String, otp: String) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var bonInput by remember { mutableStateOf("") }
    var loadedTx by remember { mutableStateOf<TransactionEntity?>(null) }
    var loadedItems by remember { mutableStateOf<List<TransactionItemEntity>>(emptyList()) }
    var selectedItem by remember { mutableStateOf<TransactionItemEntity?>(null) }
    var returQty by remember { mutableStateOf(1) }
    var selectedReason by remember { mutableStateOf("BKE (Expired)") }
    var otpInput by remember { mutableStateOf("") }
    var step by remember { mutableStateOf(1) }
    var searchError by remember { mutableStateOf("") }

    val reasons = listOf("BKE (Expired)", "BR (Barang Rusak)", "BTA (Barang Cacat)", "BRP (Kemasan Pecah)")

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.85f),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RetailRedPrimary, RoundedCornerShape(6.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("RETUR TRANSAKSI KONSUMEN (F7)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup", tint = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                when (step) {
                    1 -> {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("1. Masukkan Nomor BON Transaksi Asal:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
                            Text("Bisa ketik 4 digit terakhir atau nomor bon lengkap", fontSize = 11.sp, color = GrayText)

                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = bonInput,
                                onValueChange = { bonInput = it },
                                modifier = Modifier.fillMaxWidth(),
                                placeholder = { Text("Contoh: M5X7 atau K427-0408-1234") },
                                singleLine = true
                            )

                            if (searchError.isNotEmpty()) {
                                Text(searchError, color = MaterialTheme.colorScheme.error, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = {
                                    if (bonInput.trim().isEmpty()) {
                                        searchError = "Nomor BON tidak boleh kosong!"
                                        return@Button
                                    }
                                    coroutineScope.launch {
                                        val res = onLookupBon(bonInput)
                                        if (res.first != null && res.second.isNotEmpty()) {
                                            loadedTx = res.first
                                            loadedItems = res.second
                                            step = 2
                                            searchError = ""
                                        } else {
                                            searchError = "Transaksi dengan nomor BON tersebut tidak ditemukan!"
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = RetailNavy)
                            ) {
                                Text("CARI DOKUMEN BON")
                            }
                        }
                    }

                    2 -> {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Nomor BON: ${loadedTx?.bonNo} (${loadedTx?.tanggal})", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
                            Text("Pilih barang yang akan diretur:", fontSize = 12.sp, color = GrayText)

                            Spacer(modifier = Modifier.height(8.dp))

                            LazyColumn(modifier = Modifier.weight(1f)) {
                                items(loadedItems) { item ->
                                    val isSelected = selectedItem?.id == item.id
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                            .clickable {
                                                selectedItem = item
                                                returQty = 1
                                            },
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isSelected) RetailAmberLight else PosSurfaceVariant
                                        )
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(10.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(item.namaBarang, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
                                                Text("PLU: ${item.plu} | Beli: ${item.qty} pcs", fontSize = 11.sp, color = GrayText)
                                            }
                                            Text(formatRupiah(item.hargaSatuan), fontWeight = FontWeight.Bold, color = RetailRedPrimary)
                                        }
                                    }
                                }
                            }

                            if (selectedItem != null) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Jumlah Retur: ", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = Color.Black)
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(onClick = { if (returQty > 1) returQty-- }) {
                                            Icon(Icons.Default.Remove, contentDescription = null)
                                        }
                                        Text("$returQty", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.Black)
                                        IconButton(onClick = { if (returQty < (selectedItem?.qty ?: 1)) returQty++ }) {
                                            Icon(Icons.Default.Add, contentDescription = null)
                                        }
                                    }
                                }

                                Text("Alasan Retur:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = Color.Black)
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    reasons.take(2).forEach { r ->
                                        FilterChip(selected = selectedReason == r, onClick = { selectedReason = r }, label = { Text(r, fontSize = 9.sp) })
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { step = 1 }, modifier = Modifier.weight(1f)) {
                                    Text("KEMBALI")
                                }
                                Button(
                                    onClick = { step = 3 },
                                    enabled = selectedItem != null,
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = RetailRedPrimary)
                                ) {
                                    Text("LANJUT OTP")
                                }
                            }
                        }
                    }

                    3 -> {
                        Column(modifier = Modifier.weight(1f)) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = RetailAmberLight)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text("RINGKASAN RETUR:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Black)
                                    Text("Barang: ${selectedItem?.namaBarang}", fontSize = 12.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                                    Text("Qty: -$returQty | Nilai: ${formatRupiah((selectedItem?.hargaSatuan ?: 0.0) * returQty)}", fontWeight = FontWeight.Bold, color = RetailRedDark)
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text("Scan / Masukkan OTP Retur Transaksi:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
                            OutlinedTextField(
                                value = otpInput,
                                onValueChange = { otpInput = it },
                                modifier = Modifier.fillMaxWidth(),
                                placeholder = { Text("Kode OTP Retur") },
                                trailingIcon = {
                                    TextButton(onClick = { otpInput = (100000..999999).random().toString() }) {
                                        Text("Bypass OTP", fontSize = 11.sp, color = RetailNavy)
                                    }
                                }
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { step = 2 }, modifier = Modifier.weight(1f)) {
                                    Text("KEMBALI")
                                }
                                Button(
                                    onClick = {
                                        selectedItem?.let { itm ->
                                            val dummyProd = ProductEntity(
                                                plu = itm.plu,
                                                barcode = itm.plu,
                                                nama = itm.namaBarang,
                                                kategori = "Retur",
                                                hargaBeli = itm.hargaSatuan,
                                                hargaJual = itm.hargaSatuan,
                                                hargaMember = itm.hargaSatuan,
                                                stok = 100
                                            )
                                            onConfirmRetur(loadedTx?.bonNo ?: "", dummyProd, returQty, selectedReason, otpInput)
                                            onDismiss()
                                        }
                                    },
                                    enabled = otpInput.length >= 4,
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = RetailRedPrimary)
                                ) {
                                    Text("PROSES RETUR")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- 8. Member Dialog ---
@Composable
fun MemberDialog(
    currentMember: MemberEntity?,
    onDismiss: () -> Unit,
    onLookup: (String) -> Unit,
    onRemoveMember: () -> Unit
) {
    var phoneInput by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(0.95f),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RetailRedPrimary, RoundedCornerShape(6.dp))
                        .padding(10.dp)
                ) {
                    Text("IDENTIFIKASI MEMBER KONSUMEN", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (currentMember != null) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = RetailGreenLight)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CardMembership, contentDescription = null, tint = RetailGreen)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("MEMBER TERHUBUNG", fontWeight = FontWeight.Bold, color = RetailGreen, fontSize = 14.sp)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Nama   : ${currentMember.nama}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
                            Text("No. HP : ${currentMember.noHp}", fontSize = 12.sp, color = Color.Black)
                            Text("Poin   : ${currentMember.poin} Poin", fontWeight = FontWeight.Bold, color = RetailAmber, fontSize = 13.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                onRemoveMember()
                                onDismiss()
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("HAPUS MEMBER")
                        }
                        Button(
                            onClick = onDismiss,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = RetailRedPrimary)
                        ) {
                            Text("OK")
                        }
                    }
                } else {
                    Text("Apakah Anda ingin scan kartu member atau input nomor HP konsumen?", fontSize = 13.sp, color = Color.Black)

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = phoneInput,
                        onValueChange = { phoneInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Nomor HP / Nomor Member") },
                        placeholder = { Text("08xxxxxxxxxx") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                            Text("TIDAK (F4)")
                        }
                        Button(
                            onClick = {
                                onLookup(phoneInput)
                                onDismiss()
                            },
                            enabled = phoneInput.isNotBlank(),
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = RetailRedPrimary)
                        ) {
                            Text("YA / CARI")
                        }
                    }
                }
            }
        }
    }
}

// --- 9. Login Kasir Dialog ---
@Composable
fun CashierLoginDialog(
    cashiers: List<CashierUserEntity>,
    canDismiss: Boolean = true,
    onDismiss: () -> Unit,
    onLogin: (nik: String, pass: String) -> Unit
) {
    val initialNik = remember(cashiers) { cashiers.firstOrNull()?.nik ?: "12031632" }
    var nikInput by remember(initialNik) { mutableStateOf(initialNik) }
    var passwordInput by remember { mutableStateOf("1234") }
    var detectedName by remember(initialNik) { mutableStateOf(cashiers.firstOrNull()?.nama ?: "JAKA SLAMETO") }

    LaunchedEffect(nikInput, cashiers) {
        val found = cashiers.find { it.nik == nikInput.trim() }
        detectedName = found?.nama ?: "-"
    }

    Dialog(onDismissRequest = { if (canDismiss) onDismiss() }) {
        Card(
            modifier = Modifier.fillMaxWidth(0.95f),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RetailRedPrimary, RoundedCornerShape(6.dp))
                        .padding(12.dp)
                ) {
                    Text(
                        if (canDismiss) "GANTI KASIR / SIS" else "LOGIN KASIR (WAJIB)",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = nikInput,
                    onValueChange = { nikInput = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("NIK Karyawan", color = Color.DarkGray) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.Black,
                        unfocusedTextColor = Color.Black,
                        focusedBorderColor = RetailRedPrimary,
                        unfocusedBorderColor = PosCardBorder
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = PosSurfaceVariant)
                ) {
                    Text(
                        "Nama: $detectedName",
                        modifier = Modifier.padding(10.dp),
                        fontWeight = FontWeight.Bold,
                        color = Color.Black,
                        fontSize = 13.sp
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = passwordInput,
                    onValueChange = { passwordInput = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Password Kasir", color = Color.DarkGray) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.Black,
                        unfocusedTextColor = Color.Black,
                        focusedBorderColor = RetailRedPrimary,
                        unfocusedBorderColor = PosCardBorder
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text("Pilih Cepat NIK Kasir:", fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    cashiers.take(4).forEach { c ->
                        FilterChip(
                            selected = nikInput == c.nik,
                            onClick = {
                                nikInput = c.nik
                                passwordInput = c.password
                            },
                            label = { Text(c.nama.take(12), fontSize = 10.sp, color = Color.Black) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (canDismiss) {
                        OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                            Text("BATAL", color = Color.Black)
                        }
                    }
                    Button(
                        onClick = {
                            onLogin(nikInput, passwordInput)
                            onDismiss()
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = RetailRedPrimary)
                    ) {
                        Text("MASUK", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// --- 11. Buka Shift Kasir Dialog (Wajib Sebelum Transaksi) ---
fun checkShiftTimeValid(jamMulai: String, jamSelesai: String, calendar: Calendar = Calendar.getInstance()): Boolean {
    return try {
        val currentHour = calendar.get(Calendar.HOUR_OF_DAY)
        val currentMinute = calendar.get(Calendar.MINUTE)
        val currentTotalMinutes = currentHour * 60 + currentMinute

        val startParts = jamMulai.split(":").map { it.trim().toInt() }
        val startTotalMinutes = startParts[0] * 60 + (if (startParts.size > 1) startParts[1] else 0)

        val endParts = jamSelesai.split(":").map { it.trim().toInt() }
        val endTotalMinutes = endParts[0] * 60 + (if (endParts.size > 1) endParts[1] else 0)

        if (startTotalMinutes <= endTotalMinutes) {
            currentTotalMinutes in startTotalMinutes until endTotalMinutes
        } else {
            currentTotalMinutes >= startTotalMinutes || currentTotalMinutes < endTotalMinutes
        }
    } catch (e: Exception) {
        true
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BukaShiftDialog(
    currentCashier: CashierUserEntity,
    shifts: List<ShiftConfigEntity>,
    onOpenShift: (shiftNum: Int, modal: Double) -> Unit,
    onSwitchCashier: () -> Unit
) {
    val now = Calendar.getInstance()
    val currentTimeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now.time)
    val autoMatchedShift = remember(shifts) {
        shifts.find { checkShiftTimeValid(it.jamMulai, it.jamSelesai, now) } ?: shifts.firstOrNull()
    }

    var selectedShiftNumber by remember(shifts) {
        mutableStateOf(autoMatchedShift?.shiftNumber ?: 1)
    }
    val currentSelectedShift = shifts.firstOrNull { it.shiftNumber == selectedShiftNumber }
    var modalInput by remember(currentSelectedShift) {
        mutableStateOf(currentSelectedShift?.modalAwalStandar?.toLong()?.toString() ?: "100000")
    }
    var errorMessage by remember { mutableStateOf("") }

    val quickModals = listOf(50000L, 100000L, 200000L, 500000L)

    Dialog(onDismissRequest = { /* Modal gate: non-dismissible without opening */ }) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(2.dp, RetailNavy),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = RetailNavy,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.LockClock, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("BUKA SHIFT KASIR (WAJIB)", fontWeight = FontWeight.Black, fontSize = 15.sp, color = RetailNavy)
                        Text("Jam Sekarang: $currentTimeStr WIB • Sesi Kerja Kasir", fontSize = 11.sp, color = Color.DarkGray)
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = PosCardBorder)

                // Info Petugas Aktif
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F7FA)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, PosCardBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("PETUGAS KASIR BERTUGAS:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = GrayText)
                            Text("${currentCashier.nama} (${currentCashier.nik})", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
                            Text("Jabatan: ${currentCashier.role}", fontSize = 11.sp, color = Color.DarkGray)
                        }
                        OutlinedButton(
                            onClick = onSwitchCashier,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.height(32.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = RetailNavy)
                        ) {
                            Icon(Icons.Default.SwitchAccount, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Ganti User", fontSize = 10.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Pilih Shift
                Text("1. Pilih Jadwal Shift (Sesuai Jam Kerja):", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Black)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    shifts.forEach { shift ->
                        val isSelected = shift.shiftNumber == selectedShiftNumber
                        val isTimeValid = checkShiftTimeValid(shift.jamMulai, shift.jamSelesai, now)

                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    if (isTimeValid) {
                                        selectedShiftNumber = shift.shiftNumber
                                        modalInput = shift.modalAwalStandar.toLong().toString()
                                        errorMessage = ""
                                    } else {
                                        errorMessage = "Shift ${shift.shiftName} (${shift.jamMulai}-${shift.jamSelesai}) tidak bisa dibuka! Jam sekarang: $currentTimeStr"
                                    }
                                },
                            shape = RoundedCornerShape(8.dp),
                            color = when {
                                isSelected -> RetailNavy
                                isTimeValid -> Color(0xFFF5F5F5)
                                else -> Color(0xFFEEEEEE)
                            },
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                when {
                                    isSelected -> RetailNavy
                                    isTimeValid -> PosCardBorder
                                    else -> Color(0xFFE0E0E0)
                                }
                            )
                        ) {
                            Column(
                                modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    shift.shiftName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = when {
                                        isSelected -> Color.White
                                        isTimeValid -> Color.Black
                                        else -> Color.Gray
                                    }
                                )
                                Text(
                                    "${shift.jamMulai}-${shift.jamSelesai}",
                                    fontSize = 9.sp,
                                    color = when {
                                        isSelected -> Color.White.copy(0.8f)
                                        isTimeValid -> Color.DarkGray
                                        else -> Color.Gray
                                    }
                                )
                                Text(
                                    if (isTimeValid) "● Sesuai Jam" else "✕ Di Luar Jam",
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when {
                                        isSelected -> if (isTimeValid) Color(0xFF81C784) else Color(0xFFFF8A80)
                                        isTimeValid -> RetailGreen
                                        else -> RetailRedPrimary
                                    }
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Input Modal Awal Kas
                Text("2. Masukkan Modal Kas Awal (Uang Kembalian):", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Black)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = modalInput,
                    onValueChange = { modalInput = it.filter { char -> char.isDigit() } },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Modal Awal (Rp)", color = Color.DarkGray) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.Black,
                        unfocusedTextColor = Color.Black,
                        focusedBorderColor = RetailNavy,
                        unfocusedBorderColor = PosCardBorder
                    ),
                    leadingIcon = {
                        Text("Rp", fontWeight = FontWeight.Bold, color = RetailNavy, modifier = Modifier.padding(start = 8.dp))
                    }
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Tombol Cepat Pilihan Modal
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    quickModals.forEach { amt ->
                        OutlinedButton(
                            onClick = { modalInput = amt.toString() },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(2.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Black)
                        ) {
                            Text(NumberFormat.getIntegerInstance(Locale("id", "ID")).format(amt), fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = Color.Black)
                        }
                    }
                }

                if (errorMessage.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(errorMessage, color = RetailRedPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = {
                        val shiftToOpen = shifts.find { it.shiftNumber == selectedShiftNumber }
                        if (shiftToOpen != null && !checkShiftTimeValid(shiftToOpen.jamMulai, shiftToOpen.jamSelesai, now)) {
                            errorMessage = "Shift ${shiftToOpen.shiftName} (${shiftToOpen.jamMulai}-${shiftToOpen.jamSelesai}) tidak bisa dibuka karena sudah melampaui rentang waktu! Jam sekarang: $currentTimeStr"
                            return@Button
                        }
                        val parsedModal = modalInput.toDoubleOrNull()
                        if (parsedModal == null || parsedModal < 0) {
                            errorMessage = "Masukkan nilai modal kas awal yang valid!"
                        } else {
                            onOpenShift(selectedShiftNumber, parsedModal)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = RetailGreen),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.LockOpen, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("BUKA SHIFT & MULAI TRANSAKSI", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                }
            }
        }
    }
}

// --- 12. Lock Screen Dialog (Kunci Terminal Kasir) ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LockScreenDialog(
    cashier: CashierUserEntity,
    onUnlock: (pinOrPassword: String) -> Boolean,
    onLogout: () -> Unit
) {
    var pinInput by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf("") }

    Dialog(onDismissRequest = { /* Modal: strictly locked */ }) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(2.dp, RetailRedPrimary),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = RetailRedDark,
                    modifier = Modifier.size(54.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = Color.White, modifier = Modifier.size(30.dp))
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text("TERMINAL KASIR TERKUNCI", fontWeight = FontWeight.Black, fontSize = 16.sp, color = RetailRedDark)
                Text("Petugas: ${cashier.nama} (${cashier.nik})", fontSize = 12.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                Text("Masukkan PIN atau Password untuk membuka kembali", fontSize = 11.sp, color = Color.DarkGray)

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = pinInput,
                    onValueChange = {
                        pinInput = it
                        errorText = ""
                    },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("PIN / Password Kasir", color = Color.DarkGray) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.Black,
                        unfocusedTextColor = Color.Black,
                        focusedBorderColor = RetailRedPrimary,
                        unfocusedBorderColor = PosCardBorder
                    )
                )

                // Keypad PIN Cepat
                Spacer(modifier = Modifier.height(10.dp))
                val pinKeys = listOf(
                    listOf("1", "2", "3"),
                    listOf("4", "5", "6"),
                    listOf("7", "8", "9"),
                    listOf("C", "0", "⌫")
                )

                Column(modifier = Modifier.widthIn(max = 240.dp)) {
                    pinKeys.forEach { row ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            row.forEach { k ->
                                Button(
                                    onClick = {
                                        when (k) {
                                            "C" -> pinInput = ""
                                            "⌫" -> if (pinInput.isNotEmpty()) pinInput = pinInput.dropLast(1)
                                            else -> pinInput += k
                                        }
                                    },
                                    modifier = Modifier.weight(1f).height(40.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (k == "C" || k == "⌫") Color(0xFFECEFF1) else Color(0xFFF5F5F5),
                                        contentColor = Color.Black
                                    ),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Text(k, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.Black)
                                }
                            }
                        }
                    }
                }

                if (errorText.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(errorText, color = RetailRedPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onLogout,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = RetailRedPrimary)
                    ) {
                        Icon(Icons.Default.ExitToApp, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("LOGOUT", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            if (pinInput.isEmpty()) {
                                errorText = "Masukkan PIN atau Password!"
                            } else {
                                val ok = onUnlock(pinInput)
                                if (!ok) {
                                    errorText = "PIN atau Password salah!"
                                }
                            }
                        },
                        modifier = Modifier.weight(1.3f),
                        colors = ButtonDefaults.buttonColors(containerColor = RetailGreen)
                    ) {
                        Icon(Icons.Default.LockOpen, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("BUKA KUNCI", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}

