package com.example.ui.screens.sis

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.pos.formatRupiah
import com.example.ui.theme.*
import com.example.ui.viewmodel.PosViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoucherPointsScreen(
    viewModel: PosViewModel,
    onNavigateBack: () -> Unit
) {
    val storeConfig by viewModel.storeConfig.collectAsState()

    var activeVoucherCode by remember(storeConfig) { mutableStateOf(storeConfig.activeVoucherCode) }
    var voucherDiscount by remember(storeConfig) { mutableStateOf(storeConfig.voucherDiscountAmount.toLong().toString()) }
    var voucherMinPurchase by remember(storeConfig) { mutableStateOf(storeConfig.voucherMinPurchase.toLong().toString()) }

    var belanjaPerPoin by remember(storeConfig) { mutableStateOf(storeConfig.belanjaPerPoin.toLong().toString()) }
    var nilaiPerPoin by remember(storeConfig) { mutableStateOf(storeConfig.nilaiPerPoin.toLong().toString()) }

    var feedbackMsg by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("PENGATURAN VOUCHER & POIN", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Kembali")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = RetailNavy,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(PosSurface)
                .padding(14.dp)
        ) {
            item {
                // Section 1: Pengaturan Voucher Struk
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = androidx.compose.foundation.BorderStroke(1.dp, PosCardBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ConfirmationNumber, contentDescription = null, tint = RetailRedPrimary)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("1. KODE VOUCHER PADA STRUK BELANJA", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = RetailNavy)
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Voucher ini akan otomatis tercetak di bagian bawah struk transaksi belanja konsumen untuk digunakan pada pembelian berikutnya.",
                            fontSize = 11.sp,
                            color = Color.DarkGray
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        val tfColors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.Black,
                            unfocusedTextColor = Color.Black,
                            focusedBorderColor = RetailNavy,
                            unfocusedBorderColor = PosCardBorder
                        )

                        OutlinedTextField(
                            value = activeVoucherCode,
                            onValueChange = { activeVoucherCode = it.uppercase() },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Kode Kupon Voucher (e.g. HEMAT5K)", color = Color.DarkGray) },
                            singleLine = true,
                            colors = tfColors
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = voucherDiscount,
                                onValueChange = { voucherDiscount = it },
                                modifier = Modifier.weight(1f),
                                label = { Text("Potongan Harga (Rp)", color = Color.DarkGray) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                colors = tfColors
                            )
                            OutlinedTextField(
                                value = voucherMinPurchase,
                                onValueChange = { voucherMinPurchase = it },
                                modifier = Modifier.weight(1f),
                                label = { Text("Minimal Belanja (Rp)", color = Color.DarkGray) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                colors = tfColors
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Section 2: Pengaturan Loyalty Poin Member
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = androidx.compose.foundation.BorderStroke(1.dp, PosCardBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Star, contentDescription = null, tint = RetailAmber)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("2. PENGATURAN POIN MEMBER", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = RetailNavy)
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Mekanisme perolehan poin otomatis saat transaksi member dan nilai konversi poin saat penukaran kasir.",
                            fontSize = 11.sp,
                            color = Color.DarkGray
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        val tfColors2 = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.Black,
                            unfocusedTextColor = Color.Black,
                            focusedBorderColor = RetailNavy,
                            unfocusedBorderColor = PosCardBorder
                        )

                        OutlinedTextField(
                            value = belanjaPerPoin,
                            onValueChange = { belanjaPerPoin = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Setiap Belanja Senilai (Rp) Mendapat 1 Poin", color = Color.DarkGray) },
                            placeholder = { Text("Contoh: 10000", color = Color.Gray) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            colors = tfColors2
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = nilaiPerPoin,
                            onValueChange = { nilaiPerPoin = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Nilai 1 Poin untuk Potongan Belanja (Rp)", color = Color.DarkGray) },
                            placeholder = { Text("Contoh: 100", color = Color.Gray) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            colors = tfColors2
                        )
                    }
                }

                if (feedbackMsg.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(feedbackMsg, color = RetailGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val vDisc = voucherDiscount.toDoubleOrNull() ?: 5000.0
                        val vMin = voucherMinPurchase.toDoubleOrNull() ?: 50000.0
                        val bPoin = belanjaPerPoin.toDoubleOrNull() ?: 10000.0
                        val nPoin = nilaiPerPoin.toDoubleOrNull() ?: 100.0

                        val updated = storeConfig.copy(
                            activeVoucherCode = activeVoucherCode.trim(),
                            voucherDiscountAmount = vDisc,
                            voucherMinPurchase = vMin,
                            belanjaPerPoin = bPoin,
                            nilaiPerPoin = nPoin
                        )
                        viewModel.updateStoreConfig(updated)
                        feedbackMsg = "Pengaturan Voucher & Poin berhasil disimpan!"
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = RetailGreen),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Save, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("SIMPAN PENGATURAN VOUCHER & POIN", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
