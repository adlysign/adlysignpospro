package com.example.ui.screens.sis

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.MemberEntity
import com.example.ui.screens.pos.formatRupiah
import com.example.ui.theme.*
import com.example.ui.viewmodel.PosViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MemberManagementScreen(
    viewModel: PosViewModel,
    onNavigateBack: () -> Unit
) {
    val members by viewModel.allMembers.collectAsState()
    val storeConfig by viewModel.storeConfig.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var showEditorDialog by remember { mutableStateOf(false) }
    var selectedMemberToEdit by remember { mutableStateOf<MemberEntity?>(null) }
    var feedbackMessage by remember { mutableStateOf("") }

    val filteredMembers = remember(members, searchQuery) {
        members.filter {
            it.nama.contains(searchQuery, ignoreCase = true) ||
                    it.memberNo.contains(searchQuery) ||
                    it.noHp.contains(searchQuery)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("PENGATURAN MEMBER & POIN", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Kembali")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = RetailNavy,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    selectedMemberToEdit = null
                    showEditorDialog = true
                },
                containerColor = RetailGreen,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.PersonAdd, contentDescription = "Tambah Member")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(PosSurface)
                .padding(12.dp)
        ) {
            // Header Card with Point Rule summary
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = androidx.compose.foundation.BorderStroke(1.dp, PosCardBorder)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("ATURAN POIN MEMBER AKTIF", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = RetailNavy)
                        Text("Belanja ${formatRupiah(storeConfig.belanjaPerPoin)} = 1 Poin • 1 Poin = ${formatRupiah(storeConfig.nilaiPerPoin)}", fontSize = 11.sp, color = Color.Black)
                    }
                    Surface(color = RetailGreenLight, shape = RoundedCornerShape(4.dp)) {
                        Text("${members.size} Member Terdaftar", color = RetailGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Cari Nomor Member / Nama / No HP...", fontSize = 12.sp, color = Color.Gray) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = RetailNavy) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = RetailNavy,
                    unfocusedBorderColor = PosCardBorder,
                    focusedTextColor = Color.Black,
                    unfocusedTextColor = Color.Black
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            if (feedbackMessage.isNotEmpty()) {
                Text(feedbackMessage, color = RetailGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp))
            }

            LazyColumn(modifier = Modifier.weight(1f)) {
                items(filteredMembers) { member ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable {
                                selectedMemberToEdit = member
                                showEditorDialog = true
                            },
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = androidx.compose.foundation.BorderStroke(1.dp, PosCardBorder)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(member.nama, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.Black)
                                Text("No Member: ${member.memberNo} | HP: ${member.noHp}", fontSize = 12.sp, color = Color.DarkGray)
                                if (member.alamat.isNotBlank()) {
                                    Text("Alamat: ${member.alamat}", fontSize = 11.sp, color = Color.Gray)
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Surface(
                                    color = RetailGreen,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        "${member.poin} POIN",
                                        color = Color.White,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 12.sp,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                                Text("≈ ${formatRupiah(member.poin * storeConfig.nilaiPerPoin)}", fontSize = 10.sp, color = RetailGreen, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 2.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEditorDialog) {
        val isEdit = selectedMemberToEdit != null
        var memberNo by remember { mutableStateOf(selectedMemberToEdit?.memberNo ?: ("MBR-" + (1000..9999).random())) }
        var nama by remember { mutableStateOf(selectedMemberToEdit?.nama ?: "") }
        var noHp by remember { mutableStateOf(selectedMemberToEdit?.noHp ?: "") }
        var poin by remember { mutableStateOf(selectedMemberToEdit?.poin?.toString() ?: "0") }
        var alamat by remember { mutableStateOf(selectedMemberToEdit?.alamat ?: "") }

        AlertDialog(
            onDismissRequest = { showEditorDialog = false },
            title = { Text(if (isEdit) "EDIT DATA MEMBER" else "TAMBAH MEMBER BARU", fontWeight = FontWeight.Bold, color = RetailNavy) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    val tfColors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.Black,
                        unfocusedTextColor = Color.Black,
                        focusedBorderColor = RetailNavy,
                        unfocusedBorderColor = PosCardBorder
                    )
                    OutlinedTextField(value = memberNo, onValueChange = { memberNo = it }, label = { Text("Nomor Member", color = Color.DarkGray) }, modifier = Modifier.fillMaxWidth(), singleLine = true, colors = tfColors)
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(value = nama, onValueChange = { nama = it }, label = { Text("Nama Lengkap", color = Color.DarkGray) }, modifier = Modifier.fillMaxWidth(), singleLine = true, colors = tfColors)
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(value = noHp, onValueChange = { noHp = it }, label = { Text("Nomor Telepon / WhatsApp", color = Color.DarkGray) }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true, colors = tfColors)
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(value = poin, onValueChange = { poin = it }, label = { Text("Saldo Poin", color = Color.DarkGray) }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, colors = tfColors)
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(value = alamat, onValueChange = { alamat = it }, label = { Text("Alamat (Opsional)", color = Color.DarkGray) }, modifier = Modifier.fillMaxWidth(), maxLines = 2, colors = tfColors)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val member = MemberEntity(
                            memberNo = memberNo.trim(),
                            nama = nama.trim(),
                            noHp = noHp.trim(),
                            poin = poin.toIntOrNull() ?: 0,
                            alamat = alamat.trim()
                        )
                        if (isEdit) {
                            viewModel.updateMember(member) {
                                feedbackMessage = "Member ${member.nama} diperbarui!"
                                showEditorDialog = false
                            }
                        } else {
                            viewModel.saveMember(member) {
                                feedbackMessage = "Member ${member.nama} ditambahkan!"
                                showEditorDialog = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RetailGreen)
                ) {
                    Text("SIMPAN")
                }
            },
            dismissButton = {
                Row {
                    if (isEdit) {
                        OutlinedButton(
                            onClick = {
                                selectedMemberToEdit?.let {
                                    viewModel.deleteMember(it) {
                                        feedbackMessage = "Member dihapus!"
                                        showEditorDialog = false
                                    }
                                }
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = RetailRedPrimary)
                        ) {
                            Text("HAPUS")
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                    OutlinedButton(onClick = { showEditorDialog = false }) {
                        Text("BATAL")
                    }
                }
            }
        )
    }
}
