package com.example.ui.screens.sis

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.PosViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrinterSettingsScreen(
    viewModel: PosViewModel,
    onNavigateBack: () -> Unit
) {
    val storeConfig by viewModel.storeConfig.collectAsState()

    var selectedTab by remember { mutableStateOf(0) } // 0: Perangkat Printer, 1: Desain Struk Custom, 2: Preview Struk

    // Printer Hardware State
    var paperSize by remember(storeConfig) { mutableStateOf(storeConfig.printerPaperSize) }
    var connectionType by remember(storeConfig) { mutableStateOf(storeConfig.printerConnection) }
    var copies by remember(storeConfig) { mutableStateOf(storeConfig.printerCopies) }
    var autoCut by remember(storeConfig) { mutableStateOf(storeConfig.printerAutoCut) }

    // Custom Receipt Design State
    var headerSize by remember(storeConfig) { mutableStateOf(storeConfig.receiptHeaderSize) }
    var showAlamat by remember(storeConfig) { mutableStateOf(storeConfig.receiptShowAlamat) }
    var showTelp by remember(storeConfig) { mutableStateOf(storeConfig.receiptShowTelp) }
    var showNpwp by remember(storeConfig) { mutableStateOf(storeConfig.receiptShowNpwp) }
    var showKasir by remember(storeConfig) { mutableStateOf(storeConfig.receiptShowKasir) }
    var showBonNo by remember(storeConfig) { mutableStateOf(storeConfig.receiptShowBonNo) }
    var showDateTime by remember(storeConfig) { mutableStateOf(storeConfig.receiptShowDateTime) }
    var showPlu by remember(storeConfig) { mutableStateOf(storeConfig.receiptShowPlu) }
    var showDiskon by remember(storeConfig) { mutableStateOf(storeConfig.receiptShowDiskon) }
    var showHemat by remember(storeConfig) { mutableStateOf(storeConfig.receiptShowHemat) }
    var showVoucher by remember(storeConfig) { mutableStateOf(storeConfig.receiptShowVoucher) }
    var showQrCode by remember(storeConfig) { mutableStateOf(storeConfig.receiptShowQrCode) }
    var headerMsg by remember(storeConfig) { mutableStateOf(storeConfig.headerMsg) }
    var footerMsg by remember(storeConfig) { mutableStateOf(storeConfig.footerMsg) }
    var policyMsg by remember(storeConfig) { mutableStateOf(storeConfig.receiptPolicyMsg) }

    var testPrintMsg by remember { mutableStateOf("") }
    var feedbackMsg by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("PENGATURAN PRINTER & STRUK", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Kembali")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = RetailNavy,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(PosSurface)
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.White,
                contentColor = RetailNavy
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Koneksi Printer", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Desain Struk", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.DesignServices, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("Preview Cetak", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.ReceiptLong, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
            }

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                if (selectedTab == 0) {
                    // --- TAB 0: PRINTER HARDWARE CONFIG ---
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = androidx.compose.foundation.BorderStroke(1.dp, PosCardBorder)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text("KONFIGURASI PERANGKAT PRINTER THERMAL", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = RetailNavy)

                                Spacer(modifier = Modifier.height(10.dp))

                                Text("1. Ukuran Kertas Struk:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = Color.Black)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("58mm", "80mm").forEach { sz ->
                                        FilterChip(
                                            selected = paperSize == sz,
                                            onClick = { paperSize = sz },
                                            label = { Text(if (sz == "58mm") "58mm (Standar Mini POS)" else "80mm (Lebar / Supermarket)") }
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Text("2. Metode Sambungan Printer:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = Color.Black)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("Bluetooth", "USB OTG", "Network LAN / Wi-Fi").forEach { conn ->
                                        FilterChip(
                                            selected = connectionType == conn,
                                            onClick = { connectionType = conn },
                                            label = { Text(conn) }
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Text("3. Jumlah Rangkap Cetak Nota:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = Color.Black)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = { if (copies > 1) copies-- }) {
                                        Icon(Icons.Default.RemoveCircleOutline, contentDescription = null)
                                    }
                                    Text("$copies Rangkap (1 Kasir, 1 Konsumen)", fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 6.dp), color = Color.Black)
                                    IconButton(onClick = { if (copies < 3) copies++ }) {
                                        Icon(Icons.Default.AddCircleOutline, contentDescription = null)
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Auto-Cut Potong Kertas Otomatis:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color.Black)
                                    Switch(checked = autoCut, onCheckedChange = { autoCut = it })
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedButton(
                            onClick = {
                                testPrintMsg = "Perintah Cetak Uji Coba berhasil dikirim ke printer $paperSize ($connectionType)!"
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Print, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("TEST PRINT HALAMAN UJI")
                        }

                        if (testPrintMsg.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(testPrintMsg, color = RetailNavy, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                } else if (selectedTab == 1) {
                    // --- TAB 1: CUSTOM RECEIPT DESIGN ---
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = androidx.compose.foundation.BorderStroke(1.dp, PosCardBorder)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text("PENGATURAN TAMPILAN HEADER STRUK:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = RetailNavy)

                                Spacer(modifier = Modifier.height(6.dp))

                                Text("Ukuran Nama Toko di Struk:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color.Black)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("Kecil", "Sedang", "Besar").forEach { sz ->
                                        FilterChip(
                                            selected = headerSize == sz,
                                            onClick = { headerSize = sz },
                                            label = { Text(sz) }
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                OutlinedTextField(
                                    value = headerMsg,
                                    onValueChange = { headerMsg = it },
                                    label = { Text("Pesan Header Sambutan") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                Text("Elemen Informasi Header Toko:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = RetailNavy)
                                CustomSwitchRow("Tampilkan Alamat Toko", showAlamat) { showAlamat = it }
                                CustomSwitchRow("Tampilkan Nomor Telepon Toko", showTelp) { showTelp = it }
                                CustomSwitchRow("Tampilkan NPWP Toko", showNpwp) { showNpwp = it }
                                CustomSwitchRow("Tampilkan Nama & NIK Kasir", showKasir) { showKasir = it }
                                CustomSwitchRow("Tampilkan Nomor Bon Transaksi", showBonNo) { showBonNo = it }
                                CustomSwitchRow("Tampilkan Tanggal & Jam Transaksi", showDateTime) { showDateTime = it }

                                HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                                Text("PENGATURAN ITEM & KONTEN STRUK:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = RetailNavy)
                                CustomSwitchRow("Tampilkan Kode PLU Produk", showPlu) { showPlu = it }
                                CustomSwitchRow("Tampilkan Baris Diskon Produk", showDiskon) { showDiskon = it }
                                CustomSwitchRow("Tampilkan Ringkasan Total Hemat", showHemat) { showHemat = it }

                                HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                                Text("PENGATURAN FOOTER & PROMO:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = RetailNavy)
                                CustomSwitchRow("Cetak Kode Voucher Promo Belanja", showVoucher) { showVoucher = it }
                                CustomSwitchRow("Cetak QRIS / Barcode Pembayaran", showQrCode) { showQrCode = it }

                                Spacer(modifier = Modifier.height(6.dp))

                                OutlinedTextField(
                                    value = footerMsg,
                                    onValueChange = { footerMsg = it },
                                    label = { Text("Pesan Footer Struk") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true
                                )

                                Spacer(modifier = Modifier.height(6.dp))

                                OutlinedTextField(
                                    value = policyMsg,
                                    onValueChange = { policyMsg = it },
                                    label = { Text("Kebijakan Pengembalian / Garansi") },
                                    modifier = Modifier.fillMaxWidth(),
                                    maxLines = 2
                                )
                            }
                        }
                    }
                } else {
                    // --- TAB 2: LIVE THERMAL RECEIPT PREVIEW ---
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = androidx.compose.foundation.BorderStroke(1.dp, PosCardBorder)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("SIMULASI CETAK STRUK THERMAL ($paperSize)", fontSize = 11.sp, color = GrayText, fontWeight = FontWeight.Bold)

                                Spacer(modifier = Modifier.height(8.dp))

                                // Thermal Receipt Paper simulation
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth(if (paperSize == "58mm") 0.95f else 1f)
                                        .border(1.dp, Color(0xFFE0E0E0), RoundedCornerShape(4.dp)),
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFAFAFA))
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(14.dp)
                                    ) {
                                        // Header
                                        Text(
                                            storeConfig.storeName,
                                            fontWeight = FontWeight.Black,
                                            fontSize = when (headerSize) {
                                                "Besar" -> 16.sp
                                                "Sedang" -> 14.sp
                                                else -> 12.sp
                                            },
                                            fontFamily = FontFamily.Monospace,
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier.fillMaxWidth(),
                                            color = Color.Black
                                        )

                                        if (showAlamat) {
                                            Text(storeConfig.alamat, fontSize = 10.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), color = Color.Black)
                                        }
                                        if (showTelp) {
                                            Text("Telp: ${storeConfig.telp}", fontSize = 10.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), color = Color.Black)
                                        }
                                        if (showNpwp) {
                                            Text("NPWP: ${storeConfig.npwp}", fontSize = 9.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), color = Color.Black)
                                        }

                                        Text("-".repeat(34), fontFamily = FontFamily.Monospace, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), color = Color.Black)

                                        if (showBonNo || showDateTime) {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                if (showBonNo) Text("BON: K427-0109-1234", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color.Black)
                                                if (showDateTime) Text("30/09/2026 14:30", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color.Black)
                                            }
                                        }
                                        if (showKasir) {
                                            Text("Kasir: 20230001 (KURNIAWAN)", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color.Black)
                                        }

                                        Text("=".repeat(34), fontFamily = FontFamily.Monospace, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), color = Color.Black)

                                        // Sample Item 1
                                        if (showPlu) Text("[1030001] INDOMIE GORENG SPESIAL", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = Color.Black)
                                        else Text("INDOMIE GORENG SPESIAL", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = Color.Black)
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("  3 PCS x 3.100", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color.Black)
                                            Text("9.300", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color.Black)
                                        }

                                        // Sample Item 2 with Discount
                                        if (showPlu) Text("[1030004] BIMOLI MINYAK 2L", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = Color.Black)
                                        else Text("BIMOLI MINYAK 2L", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = Color.Black)
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("  1 PCS x 38.500", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color.Black)
                                            Text("38.500", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color.Black)
                                        }
                                        if (showDiskon) {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("  * Diskon Promo JSM", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = Color.Black)
                                                Text("-3.500", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = Color.Black)
                                            }
                                        }

                                        Text("-".repeat(34), fontFamily = FontFamily.Monospace, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), color = Color.Black)

                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("TOTAL BELANJA:", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = Color.Black)
                                            Text("Rp 44.300", fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black, color = Color.Black)
                                        }
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("TUNAI:", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color.Black)
                                            Text("Rp 50.000", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color.Black)
                                        }
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("KEMBALIAN:", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color.Black)
                                            Text("Rp 5.700", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color.Black)
                                        }

                                        if (showHemat) {
                                            Text("-".repeat(34), fontFamily = FontFamily.Monospace, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), color = Color.Black)
                                            Text("ANDA HEMAT: Rp 3.500", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), color = Color.Black)
                                        }

                                        if (showVoucher) {
                                            Text("-".repeat(34), fontFamily = FontFamily.Monospace, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), color = Color.Black)
                                            Text("KODE VOUCHER BERIKUTNYA:", fontSize = 9.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), color = Color.Black)
                                            Text(storeConfig.activeVoucherCode, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), color = Color.Black)
                                            Text("Potongan Rp 5.000 Min. Belanja Rp 50.000", fontSize = 8.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), color = Color.Black)
                                        }

                                        if (showQrCode) {
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                                                Icon(Icons.Default.QrCode, contentDescription = null, modifier = Modifier.size(54.dp), tint = Color.Black)
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(footerMsg, fontSize = 9.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), color = Color.Black)
                                        Text(policyMsg, fontSize = 8.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), color = Color.Black)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Save Floating Bar
            Surface(
                color = Color.White,
                shadowElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    if (feedbackMsg.isNotEmpty()) {
                        Text(feedbackMsg, color = RetailGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp))
                    }

                    Button(
                        onClick = {
                            val updated = storeConfig.copy(
                                printerPaperSize = paperSize,
                                printerConnection = connectionType,
                                printerCopies = copies,
                                printerAutoCut = autoCut,
                                receiptHeaderSize = headerSize,
                                receiptShowAlamat = showAlamat,
                                receiptShowTelp = showTelp,
                                receiptShowNpwp = showNpwp,
                                receiptShowKasir = showKasir,
                                receiptShowBonNo = showBonNo,
                                receiptShowDateTime = showDateTime,
                                receiptShowPlu = showPlu,
                                receiptShowDiskon = showDiskon,
                                receiptShowHemat = showHemat,
                                receiptShowVoucher = showVoucher,
                                receiptShowQrCode = showQrCode,
                                headerMsg = headerMsg.trim(),
                                footerMsg = footerMsg.trim(),
                                receiptPolicyMsg = policyMsg.trim()
                            )
                            viewModel.updateStoreConfig(updated)
                            feedbackMsg = "Konfigurasi printer & desain struk berhasil disimpan!"
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = RetailGreen),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("SIMPAN SEMUA PENGATURAN", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun CustomSwitchRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 12.sp, color = Color.Black)
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.height(24.dp)
        )
    }
}
