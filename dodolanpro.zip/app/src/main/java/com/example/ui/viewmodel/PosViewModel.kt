package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.entity.*
import com.example.data.repository.PosRepository
import com.example.util.DocExportManager
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

data class PendingCart(
    val id: String = UUID.randomUUID().toString(),
    val label: String,
    val timestamp: Long = System.currentTimeMillis(),
    val items: List<CartItem>,
    val member: MemberEntity? = null
) {
    val totalAmount: Double
        get() = items.filter { !it.isVoid }.sumOf { it.unitPrice * it.qty }
}

data class CartItem(
    val product: ProductEntity,
    val qty: Int,
    val isVoid: Boolean = false,
    val isRetur: Boolean = false,
    val voidReason: String = "",
    val replacementForPlu: String = ""
) {
    val unitPrice: Double
        get() {
            if (isRetur) return -product.hargaJual
            // Check Grosir / Tiered pricing
            if (product.hargaGrosir > 0 && product.hargaGrosirQty > 0 && qty >= product.hargaGrosirQty) {
                return product.hargaGrosir
            }
            return product.hargaJual
        }

    val subtotal: Double
        get() = if (isVoid) 0.0 else (unitPrice * qty)
}

enum class PosNavDestination {
    KASIR,
    EDIT_TOKO,
    CLEREK,
    PEMBELIAN,
    PENJUALAN,
    PRODUK,
    CETAK_LABEL_HARGA,
    STOK_OPNAME,
    RETUR_PEMBELIAN,
    EOD_TUTUP_TOKO,
    LAPORAN_TOKO,
    KARYAWAN,
    VOUCHER_POIN,
    PENGATURAN_MEMBER,
    PENGATURAN_SHIFT,
    PENGATURAN_PRINTER,
    BACKUP_RESTORE,
    SIS_DASHBOARD
}

class PosViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application, viewModelScope)
    private val repository = PosRepository(db.posDao())

    // --- State: Navigation ---
    private val _currentDestination = MutableStateFlow(PosNavDestination.KASIR)
    val currentDestination: StateFlow<PosNavDestination> = _currentDestination.asStateFlow()

    fun navigateTo(dest: PosNavDestination) {
        _currentDestination.value = dest
    }

    // --- State: Active Cashier Session ---
    private val _isUserLoggedIn = MutableStateFlow(false)
    val isUserLoggedIn: StateFlow<Boolean> = _isUserLoggedIn.asStateFlow()

    private val _currentCashier = MutableStateFlow(
        CashierUserEntity(
            nik = "12031632",
            nama = "JAKA SLAMETO",
            role = "KASIR",
            password = "1234",
            pinEtrans = "123456",
            canDeleteCartItem = true,
            canVoid = true,
            canCancelCart = true,
            canDeletePending = true,
            canReturnSales = true,
            canDoPurchase = true,
            canDoReturnPurchase = true,
            canEditEmployee = false,
            canEditProduct = false,
            canViewReports = true,
            canDoEod = false
        )
    )
    val currentCashier: StateFlow<CashierUserEntity> = _currentCashier.asStateFlow()

    val allCashiers: StateFlow<List<CashierUserEntity>> = repository.allCashiers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- State: Shift & Lock Status ---
    private val _isShiftOpen = MutableStateFlow(false)
    val isShiftOpen: StateFlow<Boolean> = _isShiftOpen.asStateFlow()

    private val _activeShift = MutableStateFlow(1)
    val activeShift: StateFlow<Int> = _activeShift.asStateFlow()

    private val _shiftModalAwal = MutableStateFlow(100000.0)
    val shiftModalAwal: StateFlow<Double> = _shiftModalAwal.asStateFlow()

    private val _shiftOpenedAt = MutableStateFlow("")
    val shiftOpenedAt: StateFlow<String> = _shiftOpenedAt.asStateFlow()

    private val _isScreenLocked = MutableStateFlow(false)
    val isScreenLocked: StateFlow<Boolean> = _isScreenLocked.asStateFlow()

    val allShiftConfigs: StateFlow<List<ShiftConfigEntity>> = repository.allShiftConfigs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun isShiftTimeValid(shift: ShiftConfigEntity, currentTime: Calendar = Calendar.getInstance()): Boolean {
        try {
            val currentHour = currentTime.get(Calendar.HOUR_OF_DAY)
            val currentMinute = currentTime.get(Calendar.MINUTE)
            val currentTotalMinutes = currentHour * 60 + currentMinute

            val startParts = shift.jamMulai.split(":").map { it.trim().toInt() }
            val startTotalMinutes = startParts[0] * 60 + (if (startParts.size > 1) startParts[1] else 0)

            val endParts = shift.jamSelesai.split(":").map { it.trim().toInt() }
            val endTotalMinutes = endParts[0] * 60 + (if (endParts.size > 1) endParts[1] else 0)

            return if (startTotalMinutes <= endTotalMinutes) {
                currentTotalMinutes in startTotalMinutes until endTotalMinutes
            } else {
                currentTotalMinutes >= startTotalMinutes || currentTotalMinutes < endTotalMinutes
            }
        } catch (e: Exception) {
            return true
        }
    }

    fun openShift(shiftNum: Int, modalAwal: Double) {
        val config = allShiftConfigs.value.find { it.shiftNumber == shiftNum }
        if (config != null && !isShiftTimeValid(config)) {
            return
        }
        _activeShift.value = shiftNum
        _shiftModalAwal.value = modalAwal
        _shiftOpenedAt.value = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
        _isShiftOpen.value = true
    }

    fun closeShift() {
        _isShiftOpen.value = false
    }

    fun lockScreen() {
        _isScreenLocked.value = true
    }

    fun unlockScreen(pin: String): Boolean {
        val cashier = _currentCashier.value
        val valid = pin == cashier.password || pin == cashier.pinEtrans || pin == "1234"
        if (valid) {
            _isScreenLocked.value = false
        }
        return valid
    }

    fun autoPendingCartOnEvent(reason: String) {
        val currentItems = _cartItems.value.filter { !it.isVoid }
        if (currentItems.isNotEmpty()) {
            val timeStr = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date())
            val cashierName = _currentCashier.value.nama
            val autoTag = "Auto-Pending: $reason ($cashierName - $timeStr)"
            val pending = PendingCart(
                label = autoTag,
                items = _cartItems.value,
                member = _currentMember.value
            )
            _pendingCarts.value = _pendingCarts.value + pending
            clearCart()
        }
    }

    fun logoutCashier() {
        // Auto-pending jika ada item di keranjang sebelum logout
        autoPendingCartOnEvent("Logout Kasir")
        _isScreenLocked.value = false
        _isUserLoggedIn.value = false
        // Jangan menutup shift saat kasir logout agar saat login kembali tidak perlu buka shift (shift tetap aktif)
    }

    fun loginCashier(nik: String, pass: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val user = repository.getCashierByNik(nik)
            if (user != null && (user.password == pass || pass == "1234")) {
                _currentCashier.value = user
                _isUserLoggedIn.value = true
                onResult(true, "Login berhasil sebagai ${user.nama} (${user.role})")
            } else {
                onResult(false, "NIK atau Password kasir salah!")
            }
        }
    }

    // --- State: Store Config & License ---
    val storeConfig: StateFlow<StoreConfigEntity> = repository.storeConfig
        .map { it ?: StoreConfigEntity() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), StoreConfigEntity())

    fun updateStoreConfig(config: StoreConfigEntity) {
        viewModelScope.launch {
            repository.updateStoreConfig(config)
        }
    }

    fun activateOrUpgradeLicense(key: String, onResult: (Boolean, String) -> Unit) {
        val cleanKey = key.trim().uppercase()
        if (cleanKey.length >= 6) {
            val current = storeConfig.value
            val tier = if (cleanKey.contains("ULTRA") || cleanKey.contains("ENTERPRISE")) "ENTERPRISE LIFETIME" else "PRO UNLIMITED"
            val updated = current.copy(
                licenseKey = cleanKey,
                licenseTier = tier,
                licenseStatus = "AKTIF"
            )
            updateStoreConfig(updated)
            onResult(true, "Lisensi $tier berhasil diaktifkan!")
        } else {
            onResult(false, "Kode lisensi tidak valid!")
        }
    }

    // --- State: Products & Members & Transactions ---
    val allProducts: StateFlow<List<ProductEntity>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allProductsIncludingInactive: StateFlow<List<ProductEntity>> = repository.allProductsAll
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allMembers: StateFlow<List<MemberEntity>> = repository.allMembers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTransactions: StateFlow<List<TransactionEntity>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allClerekRecords: StateFlow<List<ClerekEntity>> = repository.allClerekRecords
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPurchases: StateFlow<List<PurchaseEntity>> = repository.allPurchases
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allStockOpnames: StateFlow<List<StockOpnameEntity>> = repository.allStockOpnames
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allReturns: StateFlow<List<ReturnDocEntity>> = repository.allReturns
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- State: POS Cart ---
    private val _cartItems = MutableStateFlow<List<CartItem>>(emptyList())
    val cartItems: StateFlow<List<CartItem>> = _cartItems.asStateFlow()

    private val _currentMember = MutableStateFlow<MemberEntity?>(null)
    val currentMember: StateFlow<MemberEntity?> = _currentMember.asStateFlow()

    private val _inputBarcodeInput = MutableStateFlow("")
    val inputBarcodeInput: StateFlow<String> = _inputBarcodeInput.asStateFlow()

    // Structured Pending Carts with Mandatory Label
    private val _pendingCarts = MutableStateFlow<List<PendingCart>>(emptyList())
    val pendingCarts: StateFlow<List<PendingCart>> = _pendingCarts.asStateFlow()

    private val _currentBonNo = MutableStateFlow(generateNewBonNo())
    val currentBonNo: StateFlow<String> = _currentBonNo.asStateFlow()

    // Voucher & Point deductions
    private val _appliedPoin = MutableStateFlow(0)
    val appliedPoin: StateFlow<Int> = _appliedPoin.asStateFlow()

    private val _appliedVoucherCode = MutableStateFlow("")
    val appliedVoucherCode: StateFlow<String> = _appliedVoucherCode.asStateFlow()

    private val _appliedVoucherDiscount = MutableStateFlow(0.0)
    val appliedVoucherDiscount: StateFlow<Double> = _appliedVoucherDiscount.asStateFlow()

    // Subtotal
    val subtotal: StateFlow<Double> = _cartItems.map { items ->
        items.filter { !it.isVoid }.sumOf { it.unitPrice * it.qty }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, 0.0)

    // GrandTotal after member points and voucher (without donation)
    val grandTotal: StateFlow<Double> = combine(
        subtotal,
        _appliedPoin,
        _appliedVoucherDiscount,
        storeConfig
    ) { sub, poin, vDiscount, cfg ->
        val poinDiscount = poin * cfg.nilaiPerPoin
        val total = (sub - poinDiscount - vDiscount).coerceAtLeast(0.0)
        total
    }.stateIn(viewModelScope, SharingStarted.Eagerly, 0.0)

    fun onBarcodeInputChanged(value: String) {
        _inputBarcodeInput.value = value
    }

    fun submitBarcodeOrPlu(code: String, onNotFound: () -> Unit = {}) {
        val query = code.trim()
        if (query.isEmpty()) return
        if (!_isShiftOpen.value) {
            onNotFound()
            return
        }
        viewModelScope.launch {
            val product = repository.getProductByPluOrBarcode(query)
            if (product != null) {
                addProductToCart(product, 1)
                _inputBarcodeInput.value = ""
            } else {
                onNotFound()
            }
        }
    }

    fun addProductToCart(product: ProductEntity, qty: Int = 1) {
        if (!_isShiftOpen.value) return
        val currentList = _cartItems.value.toMutableList()
        val index = currentList.indexOfFirst { it.product.plu == product.plu && !it.isVoid && !it.isRetur }
        if (index >= 0) {
            val existing = currentList[index]
            currentList[index] = existing.copy(qty = existing.qty + qty)
        } else {
            currentList.add(CartItem(product = product, qty = qty))
        }
        _cartItems.value = currentList
    }

    fun updateCartItemQty(index: Int, newQty: Int) {
        val currentList = _cartItems.value.toMutableList()
        if (index in currentList.indices) {
            if (newQty <= 0) {
                currentList.removeAt(index)
            } else {
                currentList[index] = currentList[index].copy(qty = newQty)
            }
            _cartItems.value = currentList
        }
    }

    fun removeCartItem(index: Int) {
        val currentList = _cartItems.value.toMutableList()
        if (index in currentList.indices) {
            currentList.removeAt(index)
            _cartItems.value = currentList
        }
    }

    fun addKantongPlastik() {
        val cfg = storeConfig.value
        viewModelScope.launch {
            val plastik = repository.getProductByPluOrBarcode(cfg.plastikPlu)
                ?: ProductEntity(
                    plu = cfg.plastikPlu,
                    barcode = "3412",
                    nama = "KP BRANDING M (KANTONG PLASTIK)",
                    kategori = "Non-Merchandise",
                    hargaBeli = 100.0,
                    hargaJual = cfg.plastikPrice,
                    hargaMember = cfg.plastikPrice,
                    stok = 1000
                )
            addProductToCart(plastik, 1)
        }
    }

    fun setMember(member: MemberEntity?) {
        _currentMember.value = member
        _appliedPoin.value = 0
    }

    fun lookupMember(key: String, onResult: (MemberEntity?) -> Unit) {
        viewModelScope.launch {
            val m = repository.getMemberByKey(key)
            if (m != null) {
                _currentMember.value = m
            }
            onResult(m)
        }
    }

    fun applyMemberPoints(points: Int) {
        val member = _currentMember.value
        if (member != null) {
            val maxUsable = member.poin.coerceAtMost(points)
            _appliedPoin.value = maxUsable
        }
    }

    fun applyVoucher(code: String): Pair<Boolean, String> {
        val cfg = storeConfig.value
        if (code.equals(cfg.activeVoucherCode, ignoreCase = true)) {
            if (subtotal.value >= cfg.voucherMinPurchase) {
                _appliedVoucherCode.value = cfg.activeVoucherCode
                _appliedVoucherDiscount.value = cfg.voucherDiscountAmount
                return Pair(true, "Voucher berhasil digunakan! Diskon Rp ${cfg.voucherDiscountAmount.toLong()}")
            } else {
                return Pair(false, "Minimal belanja untuk voucher ini adalah Rp ${cfg.voucherMinPurchase.toLong()}")
            }
        }
        return Pair(false, "Kode voucher tidak ditemukan atau tidak aktif")
    }

    fun clearVoucher() {
        _appliedVoucherCode.value = ""
        _appliedVoucherDiscount.value = 0.0
    }

    // Mandatory Label Pending
    fun pendingCurrentCart(label: String): Boolean {
        if (_cartItems.value.isEmpty()) return false
        val cleanLabel = label.trim()
        val pList = _pendingCarts.value.toMutableList()
        pList.add(
            PendingCart(
                label = if (cleanLabel.isNotEmpty()) cleanLabel else "Pelanggan #${pList.size + 1}",
                items = _cartItems.value,
                member = _currentMember.value
            )
        )
        _pendingCarts.value = pList
        _cartItems.value = emptyList()
        _currentMember.value = null
        _appliedPoin.value = 0
        clearVoucher()
        _currentBonNo.value = generateNewBonNo()
        return true
    }

    // Recall selected pending cart or delete
    fun resumePendingCart(pendingId: String): Boolean {
        val pList = _pendingCarts.value.toMutableList()
        val index = pList.indexOfFirst { it.id == pendingId }
        if (index >= 0) {
            val target = pList.removeAt(index)
            _cartItems.value = target.items
            _currentMember.value = target.member
            _pendingCarts.value = pList
            return true
        }
        return false
    }

    fun deletePendingCart(pendingId: String) {
        val pList = _pendingCarts.value.toMutableList()
        pList.removeAll { it.id == pendingId }
        _pendingCarts.value = pList
    }

    fun clearCart() {
        _cartItems.value = emptyList()
        _currentMember.value = null
        _appliedPoin.value = 0
        clearVoucher()
        _currentBonNo.value = generateNewBonNo()
    }

    fun voidItem(itemIndex: Int, otpCode: String, reason: String, onResult: (Boolean, String) -> Unit) {
        val currentList = _cartItems.value.toMutableList()
        if (itemIndex !in currentList.indices) {
            onResult(false, "Item tidak valid")
            return
        }
        if (otpCode.length < 4) {
            onResult(false, "Kode OTP minimal 4 digit!")
            return
        }
        val item = currentList[itemIndex]
        currentList[itemIndex] = item.copy(isVoid = true, voidReason = reason)
        _cartItems.value = currentList
        onResult(true, "Item ${item.product.nama} berhasil di-VOID!")
    }

    fun addReturItem(bonNo: String, product: ProductEntity, qty: Int, reason: String, otpCode: String, onResult: (Boolean, String) -> Unit) {
        if (otpCode.length < 4) {
            onResult(false, "Kode OTP Retur minimal 4 digit!")
            return
        }
        val currentList = _cartItems.value.toMutableList()
        currentList.add(
            CartItem(
                product = product,
                qty = qty,
                isRetur = true,
                voidReason = "RETUR BON: $bonNo ($reason)"
            )
        )
        _cartItems.value = currentList
        onResult(true, "Barang retur ${product.nama} (-$qty) berhasil diinput. Silakan scan barang pengganti!")
    }

    fun isReturValidForCheckout(): Pair<Boolean, String> {
        val hasRetur = _cartItems.value.any { it.isRetur }
        val currentSub = subtotal.value
        if (hasRetur && currentSub < 0.0) {
            return Pair(false, "Transaksi Tidak Bisa Kembali Uang! Silakan input Barang/PLU Pengganti.")
        }
        return Pair(true, "")
    }

    fun processCheckout(
        caraBayar: String,
        bayarTunai: Double,
        bayarNonTunai: Double,
        refPembayaran: String,
        onComplete: (Boolean, String, TransactionEntity?) -> Unit
    ) {
        val validity = isReturValidForCheckout()
        if (!validity.first) {
            onComplete(false, validity.second, null)
            return
        }

        if (!_isShiftOpen.value) {
            onComplete(false, "Shift kasir belum dibuka! Harap buka shift terlebih dahulu.", null)
            return
        }

        val items = _cartItems.value
        if (items.isEmpty() || items.all { it.isVoid }) {
            onComplete(false, "Keranjang belanja kosong!", null)
            return
        }

        val grand = grandTotal.value
        val totalBayar = bayarTunai + bayarNonTunai
        val kembalian = if (caraBayar == "TUNAI" || caraBayar == "CAMPURAN") {
            (totalBayar - grand).coerceAtLeast(0.0)
        } else 0.0

        if (totalBayar < grand) {
            onComplete(false, "Total pembayaran kurang dari total tagihan!", null)
            return
        }

        val bon = _currentBonNo.value
        val cashier = _currentCashier.value
        val member = _currentMember.value
        val poinUsed = _appliedPoin.value
        val poinDiscount = poinUsed * storeConfig.value.nilaiPerPoin
        val voucherDiscount = _appliedVoucherDiscount.value

        val txItems = items.map { item ->
            TransactionItemEntity(
                bonNo = bon,
                plu = item.product.plu,
                namaBarang = item.product.nama,
                qty = item.qty,
                hargaSatuan = item.product.hargaJual,
                diskon = 0.0,
                subtotal = item.subtotal,
                isVoid = item.isVoid,
                isRetur = item.isRetur,
                voidReason = item.voidReason
            )
        }

        viewModelScope.launch {
            val success = repository.checkoutTransaction(
                bonNo = bon,
                kasirNik = cashier.nik,
                kasirNama = cashier.nama,
                memberNo = member?.memberNo ?: "",
                subtotal = subtotal.value,
                diskonTotal = poinDiscount + voucherDiscount,
                donasi = 0.0,
                grandTotal = grand,
                caraBayar = caraBayar,
                bayarTunai = bayarTunai,
                bayarNonTunai = bayarNonTunai,
                kembalian = kembalian,
                poinDigunakan = poinUsed,
                nilaiPotonganPoin = poinDiscount,
                kodeVoucher = _appliedVoucherCode.value,
                nilaiPotonganVoucher = voucherDiscount,
                refPembayaran = refPembayaran,
                items = txItems
            )

            if (success) {
                val createdTx = TransactionEntity(
                    bonNo = bon,
                    tanggal = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date()),
                    waktu = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date()),
                    kasirNik = cashier.nik,
                    kasirNama = cashier.nama,
                    memberNo = member?.memberNo ?: "",
                    subtotal = subtotal.value,
                    diskonTotal = poinDiscount + voucherDiscount,
                    donasi = 0.0,
                    grandTotal = grand,
                    caraBayar = caraBayar,
                    bayarTunai = bayarTunai,
                    bayarNonTunai = bayarNonTunai,
                    kembalian = kembalian,
                    poinDigunakan = poinUsed,
                    nilaiPotonganPoin = poinDiscount,
                    kodeVoucher = _appliedVoucherCode.value,
                    nilaiPotonganVoucher = voucherDiscount,
                    refPembayaran = refPembayaran
                )
                clearCart()
                onComplete(true, "Transaksi berhasil disimpan!", createdTx)
            } else {
                onComplete(false, "Gagal memproses transaksi!", null)
            }
        }
    }

    // --- Clerek Shift Settlement (Guard against pending transactions!) ---
    fun canPerformClerek(): Pair<Boolean, String> {
        val pendingCount = _pendingCarts.value.size
        if (pendingCount > 0) {
            return Pair(false, "Tidak bisa Clerek! Masih ada $pendingCount transaksi dalam status PENDING. Selesaikan atau batalkan pending terlebih dahulu.")
        }
        return Pair(true, "")
    }

    fun submitClerek(modalKasir: Double, uangSetoranFisik: Double, onResult: (ClerekEntity) -> Unit) {
        viewModelScope.launch {
            val record = repository.calculateClerek(_currentCashier.value.nik, modalKasir, uangSetoranFisik)
            onResult(record)
        }
    }

    // --- Product Management (Add, Edit, Delete) ---
    fun saveOrUpdateProduct(product: ProductEntity, onDone: () -> Unit) {
        viewModelScope.launch {
            val existing = repository.getProductByPluOrBarcode(product.plu)
            if (existing != null) {
                repository.updateProduct(product)
            } else {
                repository.insertProduct(product)
            }
            onDone()
        }
    }

    fun deleteProduct(product: ProductEntity, onDone: () -> Unit) {
        viewModelScope.launch {
            repository.deleteProduct(product)
            onDone()
        }
    }

    // --- Direct Purchase Recording (Pembelian) ---
    fun recordDirectPurchase(
        faktur: String,
        supplier: String,
        keterangan: String,
        items: List<Pair<ProductEntity, Pair<Int, Double>>>, // Product -> Qty, HargaBeli
        onDone: () -> Unit
    ) {
        viewModelScope.launch {
            val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val purchaseItems = items.map { (prod, qtyAndPrice) ->
                PurchaseItemEntity(
                    noFakturBeli = faktur,
                    plu = prod.plu,
                    namaBarang = prod.nama,
                    qty = qtyAndPrice.first,
                    hargaBeli = qtyAndPrice.second,
                    subtotal = qtyAndPrice.first * qtyAndPrice.second
                )
            }
            val totalNominal = purchaseItems.sumOf { it.subtotal }
            val purchase = PurchaseEntity(
                noFakturBeli = faktur,
                tanggal = dateStr,
                supplierNama = supplier,
                kasirNik = _currentCashier.value.nik,
                totalNominal = totalNominal,
                totalItem = purchaseItems.sumOf { it.qty },
                keterangan = keterangan
            )
            repository.recordPurchase(purchase, purchaseItems)
            onDone()
        }
    }

    // --- Stock Opname ---
    fun recordStockOpname(
        soNo: String,
        rakFilter: String,
        adjustments: Map<String, Int>, // PLU -> Physical Count
        onDone: () -> Unit
    ) {
        viewModelScope.launch {
            val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            var selisihCount = 0
            var selisihValue = 0.0

            val currentProducts = repository.allProducts.first()
            for ((plu, physical) in adjustments) {
                val p = currentProducts.find { it.plu == plu }
                if (p != null && p.stok != physical) {
                    selisihCount++
                    selisihValue += (physical - p.stok) * p.hargaBeli
                }
            }

            val soRecord = StockOpnameEntity(
                soNo = soNo,
                tanggal = dateStr,
                rakFilter = rakFilter,
                totalItemDihitung = adjustments.size,
                totalSelisihItem = selisihCount,
                totalSelisihNilai = selisihValue,
                petugasNama = _currentCashier.value.nama
            )
            repository.recordStockOpname(soRecord, adjustments)
            onDone()
        }
    }

    // --- Employee Management ---
    fun saveCashierUser(user: CashierUserEntity, onDone: () -> Unit) {
        viewModelScope.launch {
            repository.saveCashier(user)
            onDone()
        }
    }

    fun updateCashierUser(user: CashierUserEntity, onDone: () -> Unit) {
        viewModelScope.launch {
            repository.updateCashier(user)
            onDone()
        }
    }

    fun deleteCashierUser(user: CashierUserEntity, onDone: () -> Unit) {
        viewModelScope.launch {
            repository.deleteCashier(user)
            onDone()
        }
    }

    // --- Save Document Helper into DodolanPro/{folder} ---
    fun exportAndSaveDocument(
        folder: String,
        prefix: String,
        content: String
    ): Pair<Boolean, File> {
        return DocExportManager.saveDocument(
            context = getApplication(),
            subfolder = folder,
            prefix = prefix,
            extension = "txt",
            content = content
        )
    }

    // --- Backup & Restore ---
    fun exportBackupToFile(onResult: (Boolean, File, String) -> Unit) {
        viewModelScope.launch {
            val json = repository.exportDatabaseToJson()
            val saveResult = DocExportManager.saveDocument(
                context = getApplication(),
                subfolder = "Backup",
                prefix = "DodolanPro_Backup",
                extension = "json",
                content = json
            )
            onResult(saveResult.first, saveResult.second, json)
        }
    }

    fun restoreBackup(jsonString: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val ok = repository.restoreDatabaseFromJson(jsonString)
            onResult(ok)
        }
    }

    fun resetToDemoData(onDone: () -> Unit) {
        viewModelScope.launch {
            repository.resetToDefaultDemoData()
            clearCart()
            onDone()
        }
    }

    suspend fun findTransactionForRetur(bonKey: String): Pair<TransactionEntity?, List<TransactionItemEntity>> {
        return repository.findTransactionForRetur(bonKey)
    }

    fun submitReturnDoc(
        nrbNo: String,
        fakturAsal: String,
        supplierNama: String,
        jenisRetur: String,
        keterangan: String,
        status: String,
        totalNilai: Double,
        onDone: () -> Unit
    ) {
        viewModelScope.launch {
            val doc = ReturnDocEntity(
                nrbNo = nrbNo,
                fakturAsal = fakturAsal,
                tanggal = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
                supplierNama = supplierNama,
                jenisRetur = jenisRetur,
                keteranganRetur = keterangan,
                status = status,
                totalNilai = totalNilai
            )
            repository.insertReturnDoc(doc)
            onDone()
        }
    }

    // --- Member CRUD ---
    fun saveMember(member: MemberEntity, onDone: () -> Unit) {
        viewModelScope.launch {
            repository.saveMember(member)
            onDone()
        }
    }

    fun updateMember(member: MemberEntity, onDone: () -> Unit) {
        viewModelScope.launch {
            repository.updateMember(member)
            onDone()
        }
    }

    fun deleteMember(member: MemberEntity, onDone: () -> Unit) {
        viewModelScope.launch {
            repository.deleteMember(member)
            onDone()
        }
    }

    // --- Shift CRUD ---
    fun saveShiftConfig(shift: ShiftConfigEntity, onDone: () -> Unit) {
        viewModelScope.launch {
            repository.saveShiftConfig(shift)
            onDone()
        }
    }

    fun updateShiftConfig(shift: ShiftConfigEntity, onDone: () -> Unit) {
        viewModelScope.launch {
            repository.updateShiftConfig(shift)
            onDone()
        }
    }

    private fun generateNewBonNo(): String {
        val cfgCode = storeConfig.value.storeCode
        val datePart = SimpleDateFormat("ddMM", Locale.getDefault()).format(Date())
        val randomPart = (1000..9999).random()
        return "$cfgCode-$datePart-$randomPart"
    }
}
