package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Retail inspired theme (Clean Red, Deep Navy, Crisp White, Amber Gold, Emerald Success)
val RetailRedPrimary = Color(0xFFD32F2F)
val RetailRedDark = Color(0xFFB71C1C)
val RetailRedLight = Color(0xFFFFCDD2)

val RetailNavy = Color(0xFF0D47A1)
val RetailBlueLight = Color(0xFFE3F2FD)

val RetailAmber = Color(0xFFFF8F00)
val RetailAmberLight = Color(0xFFFFF8E1)

val RetailGreen = Color(0xFF2E7D32)
val RetailGreenLight = Color(0xFFE8F5E9)

val TerminalDisplayBg = Color(0xFFD32F2F)
val TerminalDisplayText = Color(0xFFFFFFFF)

val PosSurface = Color(0xFFF8F9FA)
val PosSurfaceVariant = Color(0xFFECEFF1)
val PosCardBorder = Color(0xFFCFD8DC)

val GrayText = Color(0xFF546E7A)
val DarkText = Color(0xFF1E293B)
