package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import com.example.ui.screens.backup.BackupRestoreScreen
import com.example.ui.screens.clerek.ClerekScreen
import com.example.ui.screens.pos.PosScreen
import com.example.ui.screens.sis.*
import com.example.ui.theme.DodolanProTheme
import com.example.ui.theme.RetailNavy
import com.example.ui.theme.RetailRedPrimary
import com.example.ui.viewmodel.PosNavDestination
import com.example.ui.viewmodel.PosViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: PosViewModel by viewModels()

    override fun onStop() {
        super.onStop()
        viewModel.autoPendingCartOnEvent("Keluar Aplikasi")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            DodolanProTheme {
                val currentDest by viewModel.currentDestination.collectAsState()
                val configuration = LocalConfiguration.current
                val isLandscape = configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
                val isTablet = configuration.screenWidthDp >= 600

                // Back handler for secondary destinations
                if (currentDest != PosNavDestination.KASIR) {
                    BackHandler {
                        when (currentDest) {
                            PosNavDestination.SIS_DASHBOARD,
                            PosNavDestination.CLEREK,
                            PosNavDestination.BACKUP_RESTORE -> viewModel.navigateTo(PosNavDestination.KASIR)
                            else -> viewModel.navigateTo(PosNavDestination.SIS_DASHBOARD)
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxSize()) {
                    // Navigation Rail for Tablet or Landscape when on SIS or Main Screen
                    if ((isTablet || isLandscape) && currentDest != PosNavDestination.KASIR) {
                        NavigationRail(
                            containerColor = RetailNavy,
                            contentColor = Color.White
                        ) {
                            Spacer(modifier = Modifier.height(8.dp))
                            NavigationRailItem(
                                selected = currentDest == PosNavDestination.KASIR,
                                onClick = { viewModel.navigateTo(PosNavDestination.KASIR) },
                                icon = { Icon(Icons.Default.PointOfSale, contentDescription = "Kasir") },
                                label = { Text("Kasir") },
                                colors = NavigationRailItemDefaults.colors(selectedIconColor = RetailRedPrimary, selectedTextColor = Color.White, unselectedIconColor = Color.White.copy(0.7f), unselectedTextColor = Color.White.copy(0.7f))
                            )
                            NavigationRailItem(
                                selected = currentDest == PosNavDestination.CLEREK,
                                onClick = { viewModel.navigateTo(PosNavDestination.CLEREK) },
                                icon = { Icon(Icons.Default.Calculate, contentDescription = "Clerek") },
                                label = { Text("Clerek") },
                                colors = NavigationRailItemDefaults.colors(selectedIconColor = RetailRedPrimary, selectedTextColor = Color.White, unselectedIconColor = Color.White.copy(0.7f), unselectedTextColor = Color.White.copy(0.7f))
                            )
                            NavigationRailItem(
                                selected = currentDest == PosNavDestination.SIS_DASHBOARD,
                                onClick = { viewModel.navigateTo(PosNavDestination.SIS_DASHBOARD) },
                                icon = { Icon(Icons.Default.Dashboard, contentDescription = "SIS") },
                                label = { Text("SIS") },
                                colors = NavigationRailItemDefaults.colors(selectedIconColor = RetailRedPrimary, selectedTextColor = Color.White, unselectedIconColor = Color.White.copy(0.7f), unselectedTextColor = Color.White.copy(0.7f))
                            )
                            NavigationRailItem(
                                selected = currentDest == PosNavDestination.BACKUP_RESTORE,
                                onClick = { viewModel.navigateTo(PosNavDestination.BACKUP_RESTORE) },
                                icon = { Icon(Icons.Default.Backup, contentDescription = "Backup") },
                                label = { Text("Backup") },
                                colors = NavigationRailItemDefaults.colors(selectedIconColor = RetailRedPrimary, selectedTextColor = Color.White, unselectedIconColor = Color.White.copy(0.7f), unselectedTextColor = Color.White.copy(0.7f))
                            )
                        }
                    }

                    Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                        AnimatedContent(
                            targetState = currentDest,
                            transitionSpec = { fadeIn() togetherWith fadeOut() },
                            label = "nav_transition"
                        ) { dest ->
                            when (dest) {
                                PosNavDestination.KASIR -> PosScreen(
                                    viewModel = viewModel,
                                    onNavigateTo = { viewModel.navigateTo(it) }
                                )
                                PosNavDestination.EDIT_TOKO -> StoreConfigScreen(
                                    viewModel = viewModel,
                                    onNavigateBack = { viewModel.navigateTo(PosNavDestination.SIS_DASHBOARD) }
                                )
                                PosNavDestination.CLEREK -> ClerekScreen(
                                    viewModel = viewModel,
                                    onNavigateBack = { viewModel.navigateTo(PosNavDestination.KASIR) }
                                )
                                PosNavDestination.PEMBELIAN -> PurchaseScreen(
                                    viewModel = viewModel,
                                    onNavigateBack = { viewModel.navigateTo(PosNavDestination.SIS_DASHBOARD) }
                                )
                                PosNavDestination.PENJUALAN -> SalesHistoryScreen(
                                    viewModel = viewModel,
                                    onNavigateBack = { viewModel.navigateTo(PosNavDestination.SIS_DASHBOARD) },
                                    onNavigateToRetur = { viewModel.navigateTo(PosNavDestination.KASIR) }
                                )
                                PosNavDestination.PRODUK -> ProductManagementScreen(
                                    viewModel = viewModel,
                                    onNavigateBack = { viewModel.navigateTo(PosNavDestination.SIS_DASHBOARD) }
                                )
                                PosNavDestination.CETAK_LABEL_HARGA -> PriceTagScreen(
                                    viewModel = viewModel,
                                    onNavigateBack = { viewModel.navigateTo(PosNavDestination.SIS_DASHBOARD) }
                                )
                                PosNavDestination.STOK_OPNAME -> StockOpnameScreen(
                                    viewModel = viewModel,
                                    onNavigateBack = { viewModel.navigateTo(PosNavDestination.SIS_DASHBOARD) }
                                )
                                PosNavDestination.RETUR_PEMBELIAN -> ReturnPurchaseScreen(
                                    viewModel = viewModel,
                                    onNavigateBack = { viewModel.navigateTo(PosNavDestination.SIS_DASHBOARD) }
                                )
                                PosNavDestination.EOD_TUTUP_TOKO -> EodScreen(
                                    viewModel = viewModel,
                                    onNavigateBack = { viewModel.navigateTo(PosNavDestination.SIS_DASHBOARD) }
                                )
                                PosNavDestination.LAPORAN_TOKO -> ReportsScreen(
                                    viewModel = viewModel,
                                    onNavigateBack = { viewModel.navigateTo(PosNavDestination.SIS_DASHBOARD) }
                                )
                                PosNavDestination.KARYAWAN -> EmployeeManagementScreen(
                                    viewModel = viewModel,
                                    onNavigateBack = { viewModel.navigateTo(PosNavDestination.SIS_DASHBOARD) }
                                )
                                PosNavDestination.VOUCHER_POIN -> VoucherPointsScreen(
                                    viewModel = viewModel,
                                    onNavigateBack = { viewModel.navigateTo(PosNavDestination.SIS_DASHBOARD) }
                                )
                                PosNavDestination.PENGATURAN_MEMBER -> MemberManagementScreen(
                                    viewModel = viewModel,
                                    onNavigateBack = { viewModel.navigateTo(PosNavDestination.SIS_DASHBOARD) }
                                )
                                PosNavDestination.PENGATURAN_SHIFT -> ShiftManagementScreen(
                                    viewModel = viewModel,
                                    onNavigateBack = { viewModel.navigateTo(PosNavDestination.SIS_DASHBOARD) }
                                )
                                PosNavDestination.PENGATURAN_PRINTER -> PrinterSettingsScreen(
                                    viewModel = viewModel,
                                    onNavigateBack = { viewModel.navigateTo(PosNavDestination.SIS_DASHBOARD) }
                                )
                                PosNavDestination.BACKUP_RESTORE -> BackupRestoreScreen(
                                    viewModel = viewModel,
                                    onNavigateBack = { viewModel.navigateTo(PosNavDestination.KASIR) }
                                )
                                PosNavDestination.SIS_DASHBOARD -> SisDashboardScreen(
                                    viewModel = viewModel,
                                    onNavigateTo = { viewModel.navigateTo(it) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
