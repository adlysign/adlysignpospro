package com.example.util

import android.content.Context
import android.content.Intent
import android.os.Environment
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

object DocExportManager {

    fun getDodolanFolder(context: Context, subfolder: String): File {
        // Try public external storage /DodolanPro first so it appears in standard file manager
        val externalStorage = Environment.getExternalStorageDirectory()
        val publicDodolan = File(externalStorage, "DodolanPro/$subfolder")
        if (publicDodolan.exists() || publicDodolan.mkdirs()) {
            return publicDodolan
        }

        // Fallback to app external files dir or internal files
        val baseDir = File(context.getExternalFilesDir(null) ?: context.filesDir, "DodolanPro")
        val target = File(baseDir, subfolder)
        if (!target.exists()) {
            target.mkdirs()
        }
        return target
    }

    fun saveDocument(
        context: Context,
        subfolder: String,
        prefix: String,
        extension: String,
        content: String
    ): Pair<Boolean, File> {
        return try {
            val dir = getDodolanFolder(context, subfolder)
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val file = File(dir, "${prefix}_$timeStamp.$extension")
            file.writeText(content)
            Pair(true, file)
        } catch (e: Exception) {
            e.printStackTrace()
            val fallback = File(context.cacheDir, "${prefix}_fallback.$extension")
            fallback.writeText(content)
            Pair(false, fallback)
        }
    }

    fun shareDocument(context: Context, file: File, title: String) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_TEXT, file.readText())
        }
        context.startActivity(Intent.createChooser(intent, "Bagikan Dokumen"))
    }
}
