package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.PosDao
import com.example.data.local.entity.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        ProductEntity::class,
        CashierUserEntity::class,
        MemberEntity::class,
        TransactionEntity::class,
        TransactionItemEntity::class,
        ClerekEntity::class,
        PurchaseEntity::class,
        PurchaseItemEntity::class,
        PurchaseOrderEntity::class,
        GoodsReceiptEntity::class,
        StockOpnameEntity::class,
        ReturnDocEntity::class,
        BapEntity::class,
        EmployeeScheduleEntity::class,
        StoreConfigEntity::class,
        ShiftConfigEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun posDao(): PosDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "dodolan_pro_db"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database.posDao())
                    }
                }
            }
        }

        suspend fun populateInitialData(dao: PosDao) {
            // 1. Store Config
            dao.insertOrUpdateConfig(
                StoreConfigEntity(
                    id = 1,
                    storeCode = "K427",
                    storeName = "DODOLANPRO MART CIKOKOL",
                    alamat = "Jl. MH Thamrin No. 9, Cikokol, Tangerang",
                    telp = "0815-86444613",
                    npwp = "82.739.557.3-415.888",
                    headerMsg = "DODOLANPRO RETAIL SYSTEM\nPT. SUMBER ALFARIA TRIJAYA TBK",
                    footerMsg = "KRITIK & SARAN: SMS/WA 081110640888\nTERIMA KASIH ATAS KUNJUNGAN ANDA",
                    plastikPlu = "1030022",
                    plastikPrice = 200.0,
                    defaultDonasi = 0.0,
                    licenseKey = "DODOLAN-PRO-2026-LIFETIME",
                    licenseTier = "ENTERPRISE LIFETIME",
                    licenseStatus = "AKTIF",
                    printerPaperSize = "58mm",
                    printerCopies = 1,
                    belanjaPerPoin = 10000.0,
                    nilaiPerPoin = 100.0,
                    activeVoucherCode = "HEMAT5K",
                    voucherDiscountAmount = 5000.0,
                    voucherMinPurchase = 50000.0
                )
            )

            // 2. Cashiers with granular permissions
            val cashiers = listOf(
                CashierUserEntity(
                    nik = "20240001",
                    nama = "DEWI LESTARI",
                    role = "KASIR",
                    password = "1234",
                    pinEtrans = "112233",
                    canDeleteCartItem = true,
                    canVoid = true,
                    canCancelCart = true,
                    canDeletePending = true,
                    canReturnSales = true,
                    canDoPurchase = true,
                    canDoReturnPurchase = true,
                    canEditEmployee = false,
                    canEditProduct = true,
                    canViewReports = true,
                    canDoEod = false
                ),
                CashierUserEntity(
                    nik = "12031632",
                    nama = "JAKA SLAMETO",
                    role = "KASIR",
                    password = "1234",
                    pinEtrans = "123456",
                    canDeleteCartItem = true,
                    canVoid = true,
                    canCancelCart = true,
                    canDeletePending = true,
                    canReturnSales = true,
                    canDoPurchase = true,
                    canDoReturnPurchase = true,
                    canEditEmployee = false,
                    canEditProduct = false,
                    canViewReports = true,
                    canDoEod = false
                ),
                CashierUserEntity(
                    nik = "14120562",
                    nama = "CHANDRA A",
                    role = "COS (KEPALA TOKO)",
                    password = "1234",
                    pinEtrans = "654321",
                    canDeleteCartItem = true,
                    canVoid = true,
                    canCancelCart = true,
                    canDeletePending = true,
                    canReturnSales = true,
                    canDoPurchase = true,
                    canDoReturnPurchase = true,
                    canEditEmployee = true,
                    canEditProduct = true,
                    canViewReports = true,
                    canDoEod = true
                ),
                CashierUserEntity(
                    nik = "12067095",
                    nama = "JAJANG NURZAMAN",
                    role = "ACOS (ASST CHIEF)",
                    password = "1234",
                    pinEtrans = "111222",
                    canDeleteCartItem = true,
                    canVoid = true,
                    canCancelCart = true,
                    canDeletePending = true,
                    canReturnSales = true,
                    canDoPurchase = true,
                    canDoReturnPurchase = true,
                    canEditEmployee = true,
                    canEditProduct = true,
                    canViewReports = true,
                    canDoEod = true
                )
            )
            dao.insertCashiers(cashiers)

            // 3. Members with points
            val members = listOf(
                MemberEntity("0895620798464", "Budi Santoso", "0895620798464", 3500, "Cikokol, Tangerang"),
                MemberEntity("0812345678901", "Siti Aminah", "0812345678901", 12500, "Alam Sutera"),
                MemberEntity("0878123456789", "Ahmad Fauzi", "0878123456789", 8200, "Serpong")
            )
            dao.insertMembers(members)

            // 4. Products with multi-tier pricing, category, variant, and rack
            val products = listOf(
                ProductEntity(
                    plu = "234",
                    barcode = "899990902823",
                    nama = "DJI SAM SOE 12",
                    kategori = "Rokok",
                    hargaBeli = 17500.0,
                    hargaJual = 19700.0,
                    hargaMember = 19500.0,
                    stok = 120,
                    satuan = "BKS",
                    rakPlanogram = "RAK-01",
                    isPromo = true,
                    promoLabel = "PROMO HEMAT",
                    hargaGrosirQty = 5,
                    hargaGrosir = 19200.0
                ),
                ProductEntity(
                    plu = "1752",
                    barcode = "899881660355",
                    nama = "KG AST BISC RED MINI CAN",
                    kategori = "Biskuit",
                    hargaBeli = 50000.0,
                    hargaJual = 55900.0,
                    hargaMember = 54900.0,
                    stok = 45,
                    satuan = "KLG",
                    rakPlanogram = "RAK-02",
                    hargaGrosirQty = 2,
                    hargaGrosir = 53000.0
                ),
                ProductEntity(
                    plu = "7132",
                    barcode = "899421411012",
                    nama = "KG SALTCHEESE BISC 200G",
                    kategori = "Biskuit",
                    hargaBeli = 10000.0,
                    hargaJual = 11700.0,
                    hargaMember = 11500.0,
                    stok = 80,
                    satuan = "PCS",
                    rakPlanogram = "RAK-02",
                    hargaGrosirQty = 3,
                    hargaGrosir = 11000.0
                ),
                ProductEntity(
                    plu = "1030022",
                    barcode = "3412",
                    nama = "KP BRANDING M (KANTONG PLASTIK)",
                    kategori = "Non-Merchandise",
                    hargaBeli = 100.0,
                    hargaJual = 200.0,
                    hargaMember = 200.0,
                    stok = 5000,
                    satuan = "PCS",
                    rakPlanogram = "KASIR-01"
                ),
                ProductEntity(
                    plu = "1217232",
                    barcode = "89923450001",
                    nama = "TELUR AYAM NGR 8KL/PCS",
                    kategori = "Sembako",
                    hargaBeli = 1500.0,
                    hargaJual = 1800.0,
                    hargaMember = 1750.0,
                    stok = 200,
                    satuan = "BUTIR",
                    rakPlanogram = "RAK-03"
                ),
                ProductEntity(
                    plu = "246",
                    barcode = "899898912116",
                    nama = "GG PROFESSIONAL 16",
                    kategori = "Rokok",
                    hargaBeli = 30000.0,
                    hargaJual = 32500.0,
                    hargaMember = 32500.0,
                    stok = 150,
                    satuan = "BKS",
                    rakPlanogram = "RAK-01"
                ),
                ProductEntity(
                    plu = "275",
                    barcode = "8998110",
                    nama = "LUCKY STRIKE FILTER 20",
                    kategori = "Rokok",
                    hargaBeli = 27000.0,
                    hargaJual = 29900.0,
                    hargaMember = 29900.0,
                    stok = 60,
                    satuan = "BKS",
                    rakPlanogram = "RAK-01"
                ),
                ProductEntity(
                    plu = "5868",
                    barcode = "899100111112",
                    nama = "AQUA AIR PET 600ML",
                    kategori = "Minuman",
                    hargaBeli = 2800.0,
                    hargaJual = 3500.0,
                    hargaMember = 3200.0,
                    stok = 350,
                    satuan = "BTL",
                    rakPlanogram = "RAK-04",
                    isPromo = true,
                    diskonPersen = 5.0,
                    promoLabel = "Beli 2 Lebih Hemat",
                    hargaGrosirQty = 2,
                    hargaGrosir = 3200.0
                ),
                ProductEntity(
                    plu = "115789",
                    barcode = "899110228141",
                    nama = "MINTZ CHEWY PEPERMINT 125G",
                    kategori = "Permen",
                    hargaBeli = 5000.0,
                    hargaJual = 6300.0,
                    hargaMember = 6000.0,
                    stok = 90,
                    satuan = "PCS",
                    rakPlanogram = "RAK-05"
                ),
                ProductEntity(
                    plu = "426552",
                    barcode = "899600130101",
                    nama = "MILK LIFE UHT COKELAT TP 200ML",
                    kategori = "Susu",
                    hargaBeli = 3800.0,
                    hargaJual = 4900.0,
                    hargaMember = 4500.0,
                    stok = 110,
                    satuan = "TP",
                    rakPlanogram = "RAK-04",
                    isPromo = true,
                    diskonPersen = 8.0,
                    promoLabel = "SPECIAL UHT"
                ),
                ProductEntity(
                    plu = "1234042",
                    barcode = "899100130226",
                    nama = "WALL'S CORNETTO BLK&WHT 110ML",
                    kategori = "Es Krim (BKL)",
                    hargaBeli = 8500.0,
                    hargaJual = 12000.0,
                    hargaMember = 11000.0,
                    stok = 40,
                    satuan = "PCS",
                    rakPlanogram = "FREEZER-01",
                    isSewaPromosi = true
                ),
                ProductEntity(
                    plu = "1351",
                    barcode = "899109111128",
                    nama = "SILVER QUEEN MIDI 33G",
                    kategori = "Cokelat",
                    hargaBeli = 7000.0,
                    hargaJual = 9000.0,
                    hargaMember = 8500.0,
                    stok = 65,
                    satuan = "PCS",
                    rakPlanogram = "RAK-05",
                    isSewaPromosi = true
                ),
                ProductEntity(
                    plu = "6976",
                    barcode = "89927720001",
                    nama = "BIMOLI JERIGEN 5L",
                    kategori = "Minyak Goreng",
                    hargaBeli = 88000.0,
                    hargaJual = 98500.0,
                    hargaMember = 97000.0,
                    stok = 25,
                    satuan = "JRG",
                    rakPlanogram = "RAK-03"
                )
            )
            dao.insertProducts(products)

            // 5. Initial Sample Purchase
            val samplePurchase = PurchaseEntity(
                noFakturBeli = "PB-20260930-001",
                tanggal = "2026-09-30",
                supplierNama = "DC SAT CILEUNGSI",
                kasirNik = "20230001",
                totalNominal = 2500000.0,
                totalItem = 120,
                keterangan = "Pembelian Reguler DC"
            )
            dao.insertPurchase(samplePurchase)

            // 6. Initial Shifts
            val defaultShifts = listOf(
                ShiftConfigEntity(shiftNumber = 1, shiftName = "Shift 1 (Pagi)", jamMulai = "07:00", jamSelesai = "15:00", modalAwalStandar = 100000.0),
                ShiftConfigEntity(shiftNumber = 2, shiftName = "Shift 2 (Siang)", jamMulai = "15:00", jamSelesai = "23:00", modalAwalStandar = 100000.0),
                ShiftConfigEntity(shiftNumber = 3, shiftName = "Shift 3 (Malam)", jamMulai = "23:00", jamSelesai = "07:00", modalAwalStandar = 100000.0)
            )
            dao.insertShiftConfigs(defaultShifts)
        }
    }
}
