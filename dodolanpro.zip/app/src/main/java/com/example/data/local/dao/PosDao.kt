package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PosDao {

    // --- Products ---
    @Query("SELECT * FROM products WHERE statusAktif = 1 ORDER BY nama ASC")
    fun getAllProducts(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products ORDER BY nama ASC")
    fun getAllProductsIncludingInactive(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE statusAktif = 1 ORDER BY nama ASC")
    suspend fun getAllProductsList(): List<ProductEntity>

    @Query("SELECT * FROM products WHERE plu = :query OR barcode = :query LIMIT 1")
    suspend fun getProductByPluOrBarcode(query: String): ProductEntity?

    @Query("SELECT * FROM products WHERE nama LIKE '%' || :query || '%' OR plu LIKE '%' || :query || '%' OR barcode LIKE '%' || :query || '%'")
    suspend fun searchProducts(query: String): List<ProductEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<ProductEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: ProductEntity)

    @Update
    suspend fun updateProduct(product: ProductEntity)

    @Delete
    suspend fun deleteProduct(product: ProductEntity)

    @Query("UPDATE products SET stok = stok - :qty WHERE plu = :plu")
    suspend fun deductStock(plu: String, qty: Int)

    @Query("UPDATE products SET stok = stok + :qty WHERE plu = :plu")
    suspend fun addStock(plu: String, qty: Int)

    @Query("UPDATE products SET stok = :newStok WHERE plu = :plu")
    suspend fun setStock(plu: String, newStok: Int)

    // --- Cashiers ---
    @Query("SELECT * FROM cashier_users ORDER BY nama ASC")
    fun getAllCashiers(): Flow<List<CashierUserEntity>>

    @Query("SELECT * FROM cashier_users")
    suspend fun getAllCashiersList(): List<CashierUserEntity>

    @Query("SELECT * FROM cashier_users WHERE nik = :nik LIMIT 1")
    suspend fun getCashierByNik(nik: String): CashierUserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCashier(cashier: CashierUserEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCashiers(cashiers: List<CashierUserEntity>)

    @Update
    suspend fun updateCashier(cashier: CashierUserEntity)

    @Delete
    suspend fun deleteCashier(cashier: CashierUserEntity)

    // --- Members ---
    @Query("SELECT * FROM members ORDER BY nama ASC")
    fun getAllMembers(): Flow<List<MemberEntity>>

    @Query("SELECT * FROM members")
    suspend fun getAllMembersList(): List<MemberEntity>

    @Query("SELECT * FROM members WHERE memberNo = :key OR noHp = :key LIMIT 1")
    suspend fun getMemberByKey(key: String): MemberEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMember(member: MemberEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMembers(members: List<MemberEntity>)

    @Query("UPDATE members SET poin = poin + :pointsEarned WHERE memberNo = :memberNo")
    suspend fun addMemberPoints(memberNo: String, pointsEarned: Int)

    @Query("UPDATE members SET poin = CASE WHEN poin >= :pointsUsed THEN poin - :pointsUsed ELSE 0 END WHERE memberNo = :memberNo")
    suspend fun deductMemberPoints(memberNo: String, pointsUsed: Int)

    @Update
    suspend fun updateMember(member: MemberEntity)

    @Delete
    suspend fun deleteMember(member: MemberEntity)

    // --- Shift Configs ---
    @Query("SELECT * FROM shift_configs ORDER BY shiftNumber ASC")
    fun getAllShiftConfigs(): Flow<List<ShiftConfigEntity>>

    @Query("SELECT * FROM shift_configs ORDER BY shiftNumber ASC")
    suspend fun getAllShiftConfigsList(): List<ShiftConfigEntity>

    @Query("SELECT * FROM shift_configs WHERE shiftNumber = :shiftNo LIMIT 1")
    suspend fun getShiftConfigByNumber(shiftNo: Int): ShiftConfigEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShiftConfig(shift: ShiftConfigEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShiftConfigs(shifts: List<ShiftConfigEntity>)

    @Update
    suspend fun updateShiftConfig(shift: ShiftConfigEntity)

    @Query("DELETE FROM shift_configs")
    suspend fun clearShiftConfigs()

    // --- Transactions ---
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    suspend fun getAllTransactionsList(): List<TransactionEntity>

    @Query("SELECT * FROM transactions WHERE bonNo = :bonNo LIMIT 1")
    suspend fun getTransactionByBon(bonNo: String): TransactionEntity?

    @Query("SELECT * FROM transactions WHERE bonNo LIKE '%' || :bonSuffix LIMIT 1")
    suspend fun getTransactionByBonSuffix(bonSuffix: String): TransactionEntity?

    @Query("SELECT * FROM transactions WHERE kasirNik = :nik AND isClerek = 0")
    suspend fun getUnclerekTransactionsForKasir(nik: String): List<TransactionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity)

    @Update
    suspend fun updateTransaction(transaction: TransactionEntity)

    @Query("UPDATE transactions SET isClerek = 1 WHERE kasirNik = :nik AND isClerek = 0")
    suspend fun markTransactionsClerek(nik: String)

    // --- Transaction Items ---
    @Query("SELECT * FROM transaction_items WHERE bonNo = :bonNo")
    suspend fun getItemsForBon(bonNo: String): List<TransactionItemEntity>

    @Query("SELECT * FROM transaction_items")
    suspend fun getAllTransactionItemsList(): List<TransactionItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransactionItems(items: List<TransactionItemEntity>)

    // --- Clerek ---
    @Query("SELECT * FROM clerek_records ORDER BY timestamp DESC")
    fun getAllClerekRecords(): Flow<List<ClerekEntity>>

    @Query("SELECT * FROM clerek_records ORDER BY timestamp DESC")
    suspend fun getAllClerekList(): List<ClerekEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClerek(clerek: ClerekEntity)

    // --- Purchases (Pembelian) ---
    @Query("SELECT * FROM purchases ORDER BY timestamp DESC")
    fun getAllPurchases(): Flow<List<PurchaseEntity>>

    @Query("SELECT * FROM purchases ORDER BY timestamp DESC")
    suspend fun getAllPurchasesList(): List<PurchaseEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPurchase(purchase: PurchaseEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPurchaseItems(items: List<PurchaseItemEntity>)

    @Query("SELECT * FROM purchase_items WHERE noFakturBeli = :faktur")
    suspend fun getItemsForPurchase(faktur: String): List<PurchaseItemEntity>

    // --- PO & LPB ---
    @Query("SELECT * FROM purchase_orders ORDER BY poNo DESC")
    fun getAllPurchaseOrders(): Flow<List<PurchaseOrderEntity>>

    @Query("SELECT * FROM purchase_orders")
    suspend fun getAllPurchaseOrdersList(): List<PurchaseOrderEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPurchaseOrder(po: PurchaseOrderEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPurchaseOrders(pos: List<PurchaseOrderEntity>)

    @Query("SELECT * FROM goods_receipts ORDER BY lpbNo DESC")
    fun getAllGoodsReceipts(): Flow<List<GoodsReceiptEntity>>

    @Query("SELECT * FROM goods_receipts")
    suspend fun getAllGoodsReceiptsList(): List<GoodsReceiptEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoodsReceipt(lpb: GoodsReceiptEntity)

    // --- Stock Opnames ---
    @Query("SELECT * FROM stock_opname_records ORDER BY timestamp DESC")
    fun getAllStockOpnames(): Flow<List<StockOpnameEntity>>

    @Query("SELECT * FROM stock_opname_records ORDER BY timestamp DESC")
    suspend fun getAllStockOpnamesList(): List<StockOpnameEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStockOpname(so: StockOpnameEntity)

    // --- Returns ---
    @Query("SELECT * FROM return_docs ORDER BY nrbNo DESC")
    fun getAllReturns(): Flow<List<ReturnDocEntity>>

    @Query("SELECT * FROM return_docs")
    suspend fun getAllReturnsList(): List<ReturnDocEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReturnDoc(retur: ReturnDocEntity)

    @Update
    suspend fun updateReturnDoc(retur: ReturnDocEntity)

    // --- BAP ---
    @Query("SELECT * FROM bap_records ORDER BY bapNo DESC")
    fun getAllBapRecords(): Flow<List<BapEntity>>

    @Query("SELECT * FROM bap_records")
    suspend fun getAllBapList(): List<BapEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBap(bap: BapEntity)

    // --- Schedules ---
    @Query("SELECT * FROM employee_schedules ORDER BY karyawanNama ASC")
    fun getAllSchedules(): Flow<List<EmployeeScheduleEntity>>

    @Query("SELECT * FROM employee_schedules")
    suspend fun getAllSchedulesList(): List<EmployeeScheduleEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchedule(schedule: EmployeeScheduleEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchedules(schedules: List<EmployeeScheduleEntity>)

    // --- Store Config ---
    @Query("SELECT * FROM store_config WHERE id = 1 LIMIT 1")
    fun getStoreConfig(): Flow<StoreConfigEntity?>

    @Query("SELECT * FROM store_config WHERE id = 1 LIMIT 1")
    suspend fun getStoreConfigOnce(): StoreConfigEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateConfig(config: StoreConfigEntity)

    // Clear All for Restore
    @Query("DELETE FROM products")
    suspend fun clearProducts()

    @Query("DELETE FROM cashier_users")
    suspend fun clearCashiers()

    @Query("DELETE FROM members")
    suspend fun clearMembers()

    @Query("DELETE FROM transactions")
    suspend fun clearTransactions()

    @Query("DELETE FROM transaction_items")
    suspend fun clearTransactionItems()

    @Query("DELETE FROM clerek_records")
    suspend fun clearClerek()

    @Query("DELETE FROM purchases")
    suspend fun clearPurchases()

    @Query("DELETE FROM purchase_items")
    suspend fun clearPurchaseItems()

    @Query("DELETE FROM purchase_orders")
    suspend fun clearPurchaseOrders()

    @Query("DELETE FROM goods_receipts")
    suspend fun clearGoodsReceipts()

    @Query("DELETE FROM stock_opname_records")
    suspend fun clearStockOpnames()

    @Query("DELETE FROM return_docs")
    suspend fun clearReturns()

    @Query("DELETE FROM bap_records")
    suspend fun clearBap()

    @Query("DELETE FROM employee_schedules")
    suspend fun clearSchedules()
}
