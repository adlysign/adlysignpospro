package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey val plu: String,
    val barcode: String,
    val nama: String,
    val kategori: String,
    val hargaBeli: Double,
    val hargaJual: Double,
    val hargaMember: Double,
    val stok: Int,
    val satuan: String = "PCS",
    val rakPlanogram: String = "001-01",
    val minStok: Int = 5,
    val isPromo: Boolean = false,
    val diskonPersen: Double = 0.0,
    val isSewaPromosi: Boolean = false,
    val promoLabel: String = "",
    val statusAktif: Boolean = true,
    // Pengaturan Khusus:
    val hargaGrosirQty: Int = 2,
    val hargaGrosir: Double = 0.0,
    val varian: String = "",
    val isRepack: Boolean = false
)

@Entity(tableName = "cashier_users")
data class CashierUserEntity(
    @PrimaryKey val nik: String,
    val nama: String,
    val role: String, // KASIR, ACOS (Asst Chief), COS (Chief of Store), ADMIN
    val password: String,
    val pinEtrans: String,
    val isActive: Boolean = true,
    // Hak Akses Granular Karyawan:
    val canDeleteCartItem: Boolean = true,
    val canVoid: Boolean = true,
    val canCancelCart: Boolean = true,
    val canDeletePending: Boolean = true,
    val canReturnSales: Boolean = true,
    val canDoPurchase: Boolean = true,
    val canDoReturnPurchase: Boolean = true,
    val canEditEmployee: Boolean = false,
    val canEditProduct: Boolean = false,
    val canViewReports: Boolean = true,
    val canDoEod: Boolean = false
)

@Entity(tableName = "members")
data class MemberEntity(
    @PrimaryKey val memberNo: String,
    val nama: String,
    val noHp: String,
    val poin: Int = 0,
    val alamat: String = ""
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey val bonNo: String,
    val tanggal: String,
    val waktu: String,
    val kasirNik: String,
    val kasirNama: String,
    val memberNo: String = "",
    val subtotal: Double,
    val diskonTotal: Double,
    val donasi: Double = 0.0,
    val grandTotal: Double,
    val caraBayar: String, // TUNAI, WALLET, CARD, VOUCHER, CAMPURAN
    val bayarTunai: Double,
    val bayarNonTunai: Double = 0.0,
    val kembalian: Double,
    val poinDigunakan: Int = 0,
    val nilaiPotonganPoin: Double = 0.0,
    val kodeVoucher: String = "",
    val nilaiPotonganVoucher: Double = 0.0,
    val refPembayaran: String = "", // e.g. DANA / BCA / EDC ref / CAMPURAN
    val status: String = "SELESAI", // SELESAI, VOID, RETUR
    val isClerek: Boolean = false,
    val shift: Int = 1,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "transaction_items")
data class TransactionItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bonNo: String,
    val plu: String,
    val namaBarang: String,
    val qty: Int,
    val hargaSatuan: Double,
    val diskon: Double = 0.0,
    val subtotal: Double,
    val isVoid: Boolean = false,
    val isRetur: Boolean = false,
    val voidReason: String = "",
    val replacementForPlu: String = ""
)

@Entity(tableName = "clerek_records")
data class ClerekEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tanggal: String,
    val kasirNik: String,
    val kasirNama: String,
    val shift: Int = 1,
    val modalKasir: Double = 100000.0,
    val totalJualUmum: Double,
    val totalTunai: Double,
    val totalCard: Double,
    val totalWallet: Double,
    val totalVoucher: Double,
    val totalDonasi: Double = 0.0,
    val uangSetoranFisik: Double,
    val selisih: Double,
    val status: String = "SETTLED", // SETTLED, CLOSED
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "purchases")
data class PurchaseEntity(
    @PrimaryKey val noFakturBeli: String,
    val tanggal: String,
    val supplierNama: String,
    val kasirNik: String,
    val totalNominal: Double,
    val totalItem: Int,
    val keterangan: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "purchase_items")
data class PurchaseItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val noFakturBeli: String,
    val plu: String,
    val namaBarang: String,
    val qty: Int,
    val hargaBeli: Double,
    val subtotal: Double
)

@Entity(tableName = "purchase_orders")
data class PurchaseOrderEntity(
    @PrimaryKey val poNo: String,
    val tanggalPo: String,
    val supplierId: String,
    val supplierNama: String,
    val jenisPo: String, // DC, BKL
    val status: String = "DRAFT", // DRAFT, DIKIRIM, DITERIMA
    val totalNominal: Double,
    val itemsJson: String = ""
)

@Entity(tableName = "goods_receipts")
data class GoodsReceiptEntity(
    @PrimaryKey val lpbNo: String,
    val fakturNo: String,
    val poNo: String,
    val tanggalLpb: String,
    val tanggalFaktur: String,
    val supplierNama: String,
    val jenisLpb: String, // REGULER, BKL, ATK
    val totalFaktur: Double,
    val status: String = "SELESAI",
    val itemsJson: String = ""
)

@Entity(tableName = "return_docs")
data class ReturnDocEntity(
    @PrimaryKey val nrbNo: String,
    val fakturAsal: String,
    val tanggal: String,
    val supplierNama: String,
    val jenisRetur: String, // DC, BKL, TOKO
    val keteranganRetur: String, // BKE (Expired), BR (Rusak), BRP (Rusak Pengiriman), BTA (Tidak Ada), BKC (Kurang)
    val status: String, // FORM, FIXED
    val totalNilai: Double,
    val itemsJson: String = ""
)

@Entity(tableName = "stock_opname_records")
data class StockOpnameEntity(
    @PrimaryKey val soNo: String,
    val tanggal: String,
    val rakFilter: String,
    val totalItemDihitung: Int,
    val totalSelisihItem: Int,
    val totalSelisihNilai: Double,
    val petugasNama: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "bap_records")
data class BapEntity(
    @PrimaryKey val bapNo: String,
    val judul: String,
    val tanggal: String,
    val tempat: String = "Toko DodolanPro",
    val jenisBap: String,
    val deskripsi: String,
    val pembuatNama: String,
    val pembuatJabatan: String,
    val menyetujuiNama: String = "Kurniawan (AC)",
    val status: String = "DISETUJUI"
)

@Entity(tableName = "employee_schedules")
data class EmployeeScheduleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bulanTahun: String,
    val karyawanNik: String,
    val karyawanNama: String,
    val jabatan: String,
    val schedulesJson: String
)

@Entity(tableName = "store_config")
data class StoreConfigEntity(
    @PrimaryKey val id: Int = 1,
    val storeCode: String = "K427",
    val storeName: String = "DODOLANPRO MART",
    val alamat: String = "Jl. Merdeka No. 45, Kota Pusat",
    val telp: String = "0812-3456-7890",
    val npwp: String = "82.739.557.3-415.000",
    val headerMsg: String = "SELAMAT BERBELANJA DI DODOLANPRO",
    val footerMsg: String = "TERIMA KASIH ATAS KUNJUNGAN ANDA",
    val plastikPlu: String = "1030022",
    val plastikPrice: Double = 200.0,
    val defaultDonasi: Double = 0.0,
    // Lisensi DodolanPro
    val licenseKey: String = "DODOLAN-PRO-2026-PREMIUM",
    val licenseTier: String = "PRO ENTERPRISE (LIFETIME)",
    val licenseStatus: String = "AKTIF",
    // Printer Settings
    val printerPaperSize: String = "58mm", // 58mm atau 80mm
    val printerCopies: Int = 1,
    val printerAutoCut: Boolean = true,
    val printerConnection: String = "Bluetooth", // Bluetooth, USB, Network
    // Desain & Pengaturan Struk Custom
    val receiptHeaderSize: String = "Besar", // Besar, Sedang, Kecil
    val receiptShowAlamat: Boolean = true,
    val receiptShowTelp: Boolean = true,
    val receiptShowNpwp: Boolean = true,
    val receiptShowKasir: Boolean = true,
    val receiptShowBonNo: Boolean = true,
    val receiptShowDateTime: Boolean = true,
    val receiptShowPlu: Boolean = true,
    val receiptShowDiskon: Boolean = true,
    val receiptShowHemat: Boolean = true,
    val receiptShowVoucher: Boolean = true,
    val receiptShowQrCode: Boolean = true,
    val receiptPolicyMsg: String = "Barang yang sudah dibeli tidak dapat ditukar tanpa struk asli.",
    // Voucher & Poin
    val belanjaPerPoin: Double = 10000.0, // Belanja Rp 10.000 dapat 1 poin
    val nilaiPerPoin: Double = 100.0, // 1 Poin = Rp 100
    val activeVoucherCode: String = "DODOLAN5K",
    val voucherDiscountAmount: Double = 5000.0,
    val voucherMinPurchase: Double = 50000.0
)

@Entity(tableName = "shift_configs")
data class ShiftConfigEntity(
    @PrimaryKey val shiftNumber: Int,
    val shiftName: String,
    val jamMulai: String,
    val jamSelesai: String,
    val modalAwalStandar: Double = 100000.0,
    val isActive: Boolean = true
)

