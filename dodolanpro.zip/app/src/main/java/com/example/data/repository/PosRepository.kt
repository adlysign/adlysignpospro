package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.dao.PosDao
import com.example.data.local.entity.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class PosRepository(private val dao: PosDao) {

    val allProducts: Flow<List<ProductEntity>> = dao.getAllProducts()
    val allProductsAll: Flow<List<ProductEntity>> = dao.getAllProductsIncludingInactive()
    val allTransactions: Flow<List<TransactionEntity>> = dao.getAllTransactions()
    val allClerekRecords: Flow<List<ClerekEntity>> = dao.getAllClerekRecords()
    val allPurchases: Flow<List<PurchaseEntity>> = dao.getAllPurchases()
    val allStockOpnames: Flow<List<StockOpnameEntity>> = dao.getAllStockOpnames()
    val allReturns: Flow<List<ReturnDocEntity>> = dao.getAllReturns()
    val allBapRecords: Flow<List<BapEntity>> = dao.getAllBapRecords()
    val allSchedules: Flow<List<EmployeeScheduleEntity>> = dao.getAllSchedules()
    val storeConfig: Flow<StoreConfigEntity?> = dao.getStoreConfig()
    val allMembers: Flow<List<MemberEntity>> = dao.getAllMembers()
    val allCashiers: Flow<List<CashierUserEntity>> = dao.getAllCashiers()
    val allShiftConfigs: Flow<List<ShiftConfigEntity>> = dao.getAllShiftConfigs()

    suspend fun getProductByPluOrBarcode(code: String): ProductEntity? = withContext(Dispatchers.IO) {
        dao.getProductByPluOrBarcode(code.trim())
    }

    suspend fun searchProducts(query: String): List<ProductEntity> = withContext(Dispatchers.IO) {
        dao.searchProducts(query.trim())
    }

    suspend fun insertProduct(product: ProductEntity) = withContext(Dispatchers.IO) {
        dao.insertProduct(product)
    }

    suspend fun updateProduct(product: ProductEntity) = withContext(Dispatchers.IO) {
        dao.updateProduct(product)
    }

    suspend fun deleteProduct(product: ProductEntity) = withContext(Dispatchers.IO) {
        dao.deleteProduct(product)
    }

    suspend fun getCashierByNik(nik: String): CashierUserEntity? = withContext(Dispatchers.IO) {
        dao.getCashierByNik(nik.trim())
    }

    suspend fun saveCashier(cashier: CashierUserEntity) = withContext(Dispatchers.IO) {
        dao.insertCashier(cashier)
    }

    suspend fun updateCashier(cashier: CashierUserEntity) = withContext(Dispatchers.IO) {
        dao.updateCashier(cashier)
    }

    suspend fun deleteCashier(cashier: CashierUserEntity) = withContext(Dispatchers.IO) {
        dao.deleteCashier(cashier)
    }

    suspend fun getMemberByKey(key: String): MemberEntity? = withContext(Dispatchers.IO) {
        dao.getMemberByKey(key.trim())
    }

    suspend fun saveMember(member: MemberEntity) = withContext(Dispatchers.IO) {
        dao.insertMember(member)
    }

    suspend fun updateMember(member: MemberEntity) = withContext(Dispatchers.IO) {
        dao.updateMember(member)
    }

    suspend fun deleteMember(member: MemberEntity) = withContext(Dispatchers.IO) {
        dao.deleteMember(member)
    }

    suspend fun saveShiftConfig(shift: ShiftConfigEntity) = withContext(Dispatchers.IO) {
        dao.insertShiftConfig(shift)
    }

    suspend fun updateShiftConfig(shift: ShiftConfigEntity) = withContext(Dispatchers.IO) {
        dao.updateShiftConfig(shift)
    }

    suspend fun getItemsForBon(bonNo: String): List<TransactionItemEntity> = withContext(Dispatchers.IO) {
        dao.getItemsForBon(bonNo)
    }

    suspend fun findTransactionForRetur(bonKey: String): Pair<TransactionEntity?, List<TransactionItemEntity>> = withContext(Dispatchers.IO) {
        val cleanKey = bonKey.trim()
        val trans = dao.getTransactionByBon(cleanKey) ?: dao.getTransactionByBonSuffix(cleanKey)
        val items = if (trans != null) dao.getItemsForBon(trans.bonNo) else emptyList()
        Pair(trans, items)
    }

    suspend fun checkoutTransaction(
        bonNo: String,
        kasirNik: String,
        kasirNama: String,
        memberNo: String,
        subtotal: Double,
        diskonTotal: Double,
        donasi: Double,
        grandTotal: Double,
        caraBayar: String,
        bayarTunai: Double,
        bayarNonTunai: Double,
        kembalian: Double,
        poinDigunakan: Int,
        nilaiPotonganPoin: Double,
        kodeVoucher: String,
        nilaiPotonganVoucher: Double,
        refPembayaran: String,
        items: List<TransactionItemEntity>
    ): Boolean = withContext(Dispatchers.IO) {
        val dateFormat = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())
        val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        val now = Date()

        val transaction = TransactionEntity(
            bonNo = bonNo,
            tanggal = dateFormat.format(now),
            waktu = timeFormat.format(now),
            kasirNik = kasirNik,
            kasirNama = kasirNama,
            memberNo = memberNo,
            subtotal = subtotal,
            diskonTotal = diskonTotal,
            donasi = donasi,
            grandTotal = grandTotal,
            caraBayar = caraBayar,
            bayarTunai = bayarTunai,
            bayarNonTunai = bayarNonTunai,
            kembalian = kembalian,
            poinDigunakan = poinDigunakan,
            nilaiPotonganPoin = nilaiPotonganPoin,
            kodeVoucher = kodeVoucher,
            nilaiPotonganVoucher = nilaiPotonganVoucher,
            refPembayaran = refPembayaran,
            status = "SELESAI",
            isClerek = false,
            shift = 1,
            timestamp = now.time
        )
        dao.insertTransaction(transaction)
        dao.insertTransactionItems(items)

        // Deduct/Add stock
        for (item in items) {
            if (item.isRetur) {
                dao.addStock(item.plu, item.qty)
            } else if (!item.isVoid) {
                dao.deductStock(item.plu, item.qty)
            }
        }

        // Member points update
        if (memberNo.isNotEmpty()) {
            if (poinDigunakan > 0) {
                dao.deductMemberPoints(memberNo, poinDigunakan)
            }
            val cfg = dao.getStoreConfigOnce() ?: StoreConfigEntity()
            if (cfg.belanjaPerPoin > 0) {
                val earned = (grandTotal / cfg.belanjaPerPoin).toInt()
                if (earned > 0) {
                    dao.addMemberPoints(memberNo, earned)
                }
            }
        }
        true
    }

    suspend fun calculateClerek(kasirNik: String, modalKasir: Double, uangSetoranFisik: Double): ClerekEntity = withContext(Dispatchers.IO) {
        val unclerekList = dao.getUnclerekTransactionsForKasir(kasirNik)
        val kasir = dao.getCashierByNik(kasirNik)
        val kasirNama = kasir?.nama ?: "KASIR"

        var totalJualUmum = 0.0
        var totalTunai = 0.0
        var totalCard = 0.0
        var totalWallet = 0.0
        var totalVoucher = 0.0

        for (tx in unclerekList) {
            totalJualUmum += tx.grandTotal
            when (tx.caraBayar) {
                "TUNAI" -> totalTunai += (tx.bayarTunai - tx.kembalian)
                "CARD" -> totalCard += tx.grandTotal
                "WALLET" -> totalWallet += tx.grandTotal
                "VOUCHER" -> totalVoucher += tx.grandTotal
                "CAMPURAN" -> {
                    totalTunai += (tx.bayarTunai - tx.kembalian).coerceAtLeast(0.0)
                    totalCard += tx.bayarNonTunai
                }
                else -> totalTunai += tx.grandTotal
            }
        }

        val selisih = uangSetoranFisik - totalTunai

        val dateFormat = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())
        val record = ClerekEntity(
            tanggal = dateFormat.format(Date()),
            kasirNik = kasirNik,
            kasirNama = kasirNama,
            shift = 1,
            modalKasir = modalKasir,
            totalJualUmum = totalJualUmum,
            totalTunai = totalTunai,
            totalCard = totalCard,
            totalWallet = totalWallet,
            totalVoucher = totalVoucher,
            totalDonasi = 0.0,
            uangSetoranFisik = uangSetoranFisik,
            selisih = selisih,
            status = "SETTLED",
            timestamp = System.currentTimeMillis()
        )

        dao.insertClerek(record)
        dao.markTransactionsClerek(kasirNik)
        record
    }

    // --- PURCHASE MANAGEMENT ---
    suspend fun recordPurchase(
        purchase: PurchaseEntity,
        items: List<PurchaseItemEntity>
    ) = withContext(Dispatchers.IO) {
        dao.insertPurchase(purchase)
        dao.insertPurchaseItems(items)
        // Automatically add to stock and update buy price in products!
        for (item in items) {
            val existing = dao.getProductByPluOrBarcode(item.plu)
            if (existing != null) {
                val updated = existing.copy(
                    stok = existing.stok + item.qty,
                    hargaBeli = item.hargaBeli
                )
                dao.updateProduct(updated)
            }
        }
    }

    suspend fun getPurchaseItems(faktur: String): List<PurchaseItemEntity> = withContext(Dispatchers.IO) {
        dao.getItemsForPurchase(faktur)
    }

    // --- STOCK OPNAME MANAGEMENT ---
    suspend fun recordStockOpname(
        so: StockOpnameEntity,
        adjustments: Map<String, Int> // PLU -> counted physical stock
    ) = withContext(Dispatchers.IO) {
        dao.insertStockOpname(so)
        for ((plu, physicalStok) in adjustments) {
            dao.setStock(plu, physicalStok)
        }
    }

    suspend fun insertReturnDoc(retur: ReturnDocEntity) = withContext(Dispatchers.IO) {
        dao.insertReturnDoc(retur)
    }

    suspend fun updateStoreConfig(config: StoreConfigEntity) = withContext(Dispatchers.IO) {
        dao.insertOrUpdateConfig(config)
    }

    suspend fun getStoreConfigOnce(): StoreConfigEntity {
        return withContext(Dispatchers.IO) {
            dao.getStoreConfigOnce() ?: StoreConfigEntity()
        }
    }

    // --- BACKUP & RESTORE JSON ---
    suspend fun exportDatabaseToJson(): String = withContext(Dispatchers.IO) {
        val root = JSONObject()
        root.put("app", "DodolanPro")
        root.put("version", "2.0")
        root.put("exportTimestamp", System.currentTimeMillis())
        root.put("exportDate", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()))

        // Config
        val config = dao.getStoreConfigOnce() ?: StoreConfigEntity()
        val configJson = JSONObject().apply {
            put("storeCode", config.storeCode)
            put("storeName", config.storeName)
            put("alamat", config.alamat)
            put("telp", config.telp)
            put("npwp", config.npwp)
            put("headerMsg", config.headerMsg)
            put("footerMsg", config.footerMsg)
            put("licenseKey", config.licenseKey)
            put("licenseTier", config.licenseTier)
            put("licenseStatus", config.licenseStatus)
            put("printerPaperSize", config.printerPaperSize)
            put("belanjaPerPoin", config.belanjaPerPoin)
            put("nilaiPerPoin", config.nilaiPerPoin)
        }
        root.put("storeConfig", configJson)

        // Products
        val products = dao.getAllProductsList()
        val prodArray = JSONArray()
        for (p in products) {
            prodArray.put(JSONObject().apply {
                put("plu", p.plu)
                put("barcode", p.barcode)
                put("nama", p.nama)
                put("kategori", p.kategori)
                put("hargaBeli", p.hargaBeli)
                put("hargaJual", p.hargaJual)
                put("hargaMember", p.hargaMember)
                put("stok", p.stok)
                put("satuan", p.satuan)
                put("rakPlanogram", p.rakPlanogram)
                put("minStok", p.minStok)
                put("isPromo", p.isPromo)
                put("diskonPersen", p.diskonPersen)
                put("hargaGrosirQty", p.hargaGrosirQty)
                put("hargaGrosir", p.hargaGrosir)
                put("varian", p.varian)
                put("isRepack", p.isRepack)
            })
        }
        root.put("products", prodArray)

        // Transactions
        val transactions = dao.getAllTransactionsList()
        val transArray = JSONArray()
        for (t in transactions) {
            transArray.put(JSONObject().apply {
                put("bonNo", t.bonNo)
                put("tanggal", t.tanggal)
                put("waktu", t.waktu)
                put("kasirNik", t.kasirNik)
                put("kasirNama", t.kasirNama)
                put("memberNo", t.memberNo)
                put("subtotal", t.subtotal)
                put("diskonTotal", t.diskonTotal)
                put("grandTotal", t.grandTotal)
                put("caraBayar", t.caraBayar)
                put("bayarTunai", t.bayarTunai)
                put("bayarNonTunai", t.bayarNonTunai)
                put("kembalian", t.kembalian)
                put("status", t.status)
            })
        }
        root.put("transactions", transArray)

        // Members
        val members = dao.getAllMembersList()
        val memberArray = JSONArray()
        for (m in members) {
            memberArray.put(JSONObject().apply {
                put("memberNo", m.memberNo)
                put("nama", m.nama)
                put("noHp", m.noHp)
                put("poin", m.poin)
                put("alamat", m.alamat)
            })
        }
        root.put("members", memberArray)

        root.toString(2)
    }

    suspend fun restoreDatabaseFromJson(jsonString: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject(jsonString)
            if (root.has("products")) {
                val pArray = root.getJSONArray("products")
                val pList = mutableListOf<ProductEntity>()
                for (i in 0 until pArray.length()) {
                    val p = pArray.getJSONObject(i)
                    pList.add(
                        ProductEntity(
                            plu = p.getString("plu"),
                            barcode = p.optString("barcode", p.getString("plu")),
                            nama = p.getString("nama"),
                            kategori = p.optString("kategori", "Umum"),
                            hargaBeli = p.optDouble("hargaBeli", 0.0),
                            hargaJual = p.optDouble("hargaJual", 0.0),
                            hargaMember = p.optDouble("hargaMember", p.optDouble("hargaJual", 0.0)),
                            stok = p.optInt("stok", 0),
                            satuan = p.optString("satuan", "PCS"),
                            rakPlanogram = p.optString("rakPlanogram", "RAK-01"),
                            minStok = p.optInt("minStok", 5),
                            isPromo = p.optBoolean("isPromo", false),
                            diskonPersen = p.optDouble("diskonPersen", 0.0),
                            hargaGrosirQty = p.optInt("hargaGrosirQty", 2),
                            hargaGrosir = p.optDouble("hargaGrosir", 0.0),
                            varian = p.optString("varian", ""),
                            isRepack = p.optBoolean("isRepack", false)
                        )
                    )
                }
                dao.clearProducts()
                dao.insertProducts(pList)
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun resetToDefaultDemoData() = withContext(Dispatchers.IO) {
        dao.clearProducts()
        dao.clearTransactions()
        dao.clearTransactionItems()
        dao.clearClerek()
        dao.clearPurchases()
        dao.clearPurchaseItems()
        dao.clearStockOpnames()
        dao.clearMembers()
        AppDatabase.populateInitialData(dao)
    }
}
