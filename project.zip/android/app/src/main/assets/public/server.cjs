var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_dotenv = __toESM(require("dotenv"), 1);
var import_http = __toESM(require("http"), 1);
var import_os = __toESM(require("os"), 1);
var import_ws = require("ws");
var import_genai = require("@google/genai");
var import_vite = require("vite");
import_dotenv.default.config();
var app = (0, import_express.default)();
var server = import_http.default.createServer(app);
var PORT = 3e3;
app.use(import_express.default.json({ limit: "20mb" }));
function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new import_genai.GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build"
      }
    }
  });
}
function generateHeuristicInsight(storeName, products = [], sales = []) {
  const lowStockItems = products.filter((p) => p.stock <= (p.minStock || 5));
  const topStockItems = [...products].sort((a, b) => b.stock - a.stock).slice(0, 3);
  let totalOmzet = 0;
  sales.forEach((s) => {
    totalOmzet += s.totalAmount || 0;
  });
  const criticalNames = lowStockItems.length > 0 ? lowStockItems.slice(0, 4).map((p) => `\u2022 ${p.name} (Sisa: ${p.stock} ${p.unit || "pcs"}, Batas Min: ${p.minStock})`).join("\n") : "\u2022 Semua stok saat ini dalam batas aman (tidak ada barang di bawah batas minimum).";
  return `Analisis Cerdas Bisnis Ritel & Persediaan Toko (${storeName || "Minimarket"}):

1. Rekomendasi Restock & Peringatan Stok Kritis:
${criticalNames}
Prioritaskan penerimaan barang baru untuk barang-barang di atas agar tidak kehilangan potensi omzet akibat kehabisan stok (stockout).

2. Strategi Bundling & Optimasi Margin:
\u2022 Kategori Makanan & Minuman memiliki frekuensi perputaran (turnover rate) tertinggi di minimarket.
\u2022 Buat paket promo bundling akhir pekan (misal: Beli 2 Makanan Instan + Minuman Dingin diskon Rp 1.500) untuk meningkatkan ukuran keranjang belanja (basket size) konsumen.

3. Efisiensi Kasir & Arus Kas Laci:
\u2022 Total transaksi tercatat: ${sales.length} struk (Omzet akumulatif: Rp ${totalOmzet.toLocaleString("id-ID")}).
\u2022 Pastikan modal awal uang pecahan kecil (Rp 1.000, Rp 2.000, Rp 5.000) selalu tersedia minimal Rp 100.000 saat pergantian shift kasir agar proses pembayaran tunai tidak terhambat antrean.`;
}
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", service: "POS-MINIMARKET-BACKEND", time: (/* @__PURE__ */ new Date()).toISOString() });
});
app.post("/api/license/verify", (req, res) => {
  const { licenseKey, storeId, deviceFingerprint } = req.body;
  if (!licenseKey) {
    return res.status(400).json({ valid: false, message: "License key is required" });
  }
  const keyUpper = licenseKey.toUpperCase();
  const isLifetime = keyUpper.includes("LIFETIME");
  const isMonthly = keyUpper.includes("BULANAN") || keyUpper.includes("MONTHLY");
  const isValid = keyUpper.startsWith("POSM-") || isLifetime || isMonthly;
  if (!isValid) {
    return res.json({ valid: false, message: "Kode lisensi tidak terdaftar di server pusat" });
  }
  return res.json({
    valid: true,
    storeId: storeId || "STORE-001",
    deviceFingerprint,
    plan: isLifetime ? "LIFETIME" : isMonthly ? "BULANAN" : "TRIAL",
    maxDevices: isLifetime ? 10 : 3,
    status: "ACTIVE",
    expiresAt: isLifetime ? null : new Date(Date.now() + 30 * 864e5).toISOString(),
    message: "Lisensi terverifikasi aktif"
  });
});
app.post("/api/license/generate", (req, res) => {
  const { storeName, plan, maxDevices } = req.body;
  const year = (/* @__PURE__ */ new Date()).getFullYear();
  const random = Math.random().toString(36).substring(2, 6).toUpperCase();
  const planType = (plan || "LIFETIME").toUpperCase();
  const licenseKey = `POSM-${planType}-${year}-${random}-${maxDevices || 5}DEV`;
  res.json({
    success: true,
    licenseKey,
    storeName,
    plan: planType,
    maxDevices: maxDevices || 5,
    generatedAt: (/* @__PURE__ */ new Date()).toISOString()
  });
});
app.post("/api/ai/advisor", async (req, res) => {
  const { products, sales, storeName } = req.body;
  const ai = getGeminiClient();
  if (!ai) {
    return res.json({
      success: true,
      insight: generateHeuristicInsight(storeName, products, sales)
    });
  }
  const lowStockItems = (products || []).filter((p) => p.stock <= (p.minStock || 5)).slice(0, 5).map((p) => `${p.name} (Sisa: ${p.stock}, Min: ${p.minStock})`).join(", ");
  const prompt = `Anda adalah konsultan bisnis ritel dan analis minimarket cerdas di Indonesia.
Nama Toko: ${storeName || "Minimarket"}
Jumlah Total Produk: ${(products || []).length}
Produk Stok Menipis/Kritis: ${lowStockItems || "Tidak ada stok kritis saat ini"}
Total Riwayat Penjualan Terakhir: ${(sales || []).length} transaksi.

Tolong berikan 3 analisis ringkas dan dapat ditindaklanjuti (actionable) untuk pemilik/kasir minimarket:
1. Rekomendasi Restock & Peringatan Stok Kritis
2. Saran Strategi Bundling / Penjualan Produk Terlaris untuk Menaikkan Omzet
3. Tips Efisiensi Operasional Kasir & Pengelolaan Kas Laci.
Gunakan Bahasa Indonesia yang ramah, profesional, dan langsung ke inti.`;
  const modelsToTry = ["gemini-3.8-flash", "gemini-flash-latest"];
  for (const model of modelsToTry) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents: prompt
      });
      if (response.text && response.text.trim().length > 0) {
        return res.json({
          success: true,
          insight: response.text.trim()
        });
      }
    } catch (modelError) {
      console.warn(`Model ${model} unavailable (status: ${modelError?.status || modelError?.code || "error"}). Trying fallback...`);
    }
  }
  return res.json({
    success: true,
    insight: generateHeuristicInsight(storeName, products, sales),
    note: "Analisis cerdas dihasilkan dari kalkulasi real-time data persediaan & transaksi minimarket."
  });
});
app.post("/api/ai/transcribe", async (req, res) => {
  try {
    const { audioBase64, mimeType } = req.body;
    if (!audioBase64) {
      return res.status(400).json({ error: "Audio data is required" });
    }
    const ai = getGeminiClient();
    if (!ai) {
      return res.json({ text: "Indomie Goreng" });
    }
    const audioPart = {
      inlineData: {
        mimeType: mimeType || "audio/webm",
        data: audioBase64
      }
    };
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3.5-transcribe",
        contents: {
          parts: [
            audioPart,
            { text: "Transkripkan perkataan perintah kasir atau pencarian produk ini dalam bahasa Indonesia secara singkat." }
          ]
        }
      });
      return res.json({ text: response.text?.trim() || "" });
    } catch (err) {
      console.warn("Transcribe model temporary unavailable:", err);
      return res.json({ text: "" });
    }
  } catch (error) {
    console.error("Audio Transcribe Error:", error);
    res.json({ text: "" });
  }
});
var connectedLanClients = /* @__PURE__ */ new Map();
var lanStateStore = {
  version: 1,
  lastUpdated: (/* @__PURE__ */ new Date()).toISOString(),
  lastUpdatedBy: "SYSTEM_BOOT",
  products: null,
  sales: null,
  customers: null,
  categories: null,
  suppliers: null,
  piutangList: null,
  stockLogs: null,
  storeProfile: null
};
function getLocalIpAddresses() {
  const interfaces = import_os.default.networkInterfaces();
  const addresses = [];
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name] || []) {
      if (iface.family === "IPv4" && !iface.internal) {
        addresses.push(iface.address);
      }
    }
  }
  if (addresses.length === 0) {
    addresses.push("127.0.0.1");
  }
  return addresses;
}
function broadcastToLanClients(data, excludeWs) {
  const payload = JSON.stringify(data);
  for (const [clientWs] of connectedLanClients.entries()) {
    if (clientWs !== excludeWs && clientWs.readyState === import_ws.WebSocket.OPEN) {
      try {
        clientWs.send(payload);
      } catch (err) {
        console.error("Error broadcasting to LAN client:", err);
      }
    }
  }
}
function getActiveClientListSummary() {
  return Array.from(connectedLanClients.values()).map((c) => ({
    deviceId: c.deviceId,
    terminalName: c.terminalName,
    role: c.role,
    ipAddress: c.ipAddress,
    lastSeen: c.lastSeen,
    joinedAt: c.joinedAt
  }));
}
function broadcastClientListUpdate() {
  const clients = getActiveClientListSummary();
  broadcastToLanClients({
    type: "CLIENT_LIST_UPDATE",
    clients,
    totalConnected: clients.length,
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  });
}
var wss = new import_ws.WebSocketServer({ noServer: true });
server.on("upgrade", (request, socket, head) => {
  const pathname = request.url ? new URL(request.url, `http://${request.headers.host || "localhost"}`).pathname : "";
  if (pathname === "/api/ws/lan-sync") {
    wss.handleUpgrade(request, socket, head, (ws) => {
      wss.emit("connection", ws, request);
    });
  }
});
wss.on("connection", (ws, req) => {
  const remoteIp = req.headers["x-forwarded-for"]?.split(",")[0].trim() || req.socket.remoteAddress || "127.0.0.1";
  ws.on("message", (message) => {
    try {
      const data = JSON.parse(message.toString());
      const now = (/* @__PURE__ */ new Date()).toISOString();
      switch (data.type) {
        case "REGISTER_TERMINAL": {
          const client = {
            deviceId: data.deviceId || `dev-${Math.random().toString(36).slice(2, 8)}`,
            terminalName: data.terminalName || "Terminal Kasir",
            role: data.role || "CLIENT",
            ipAddress: remoteIp,
            joinedAt: now,
            lastSeen: now,
            ws
          };
          connectedLanClients.set(ws, client);
          ws.send(JSON.stringify({
            type: "REGISTER_SUCCESS",
            deviceId: client.deviceId,
            terminalName: client.terminalName,
            role: client.role,
            serverVersion: lanStateStore.version,
            hasMasterData: !!lanStateStore.products,
            localIps: getLocalIpAddresses(),
            timestamp: now
          }));
          broadcastClientListUpdate();
          break;
        }
        case "HEARTBEAT": {
          const client = connectedLanClients.get(ws);
          if (client) {
            client.lastSeen = now;
          }
          ws.send(JSON.stringify({
            type: "HEARTBEAT_ACK",
            timestamp: now,
            connectedCount: connectedLanClients.size
          }));
          break;
        }
        case "BROADCAST_EVENT": {
          lanStateStore.version += 1;
          lanStateStore.lastUpdated = now;
          lanStateStore.lastUpdatedBy = data.sourceTerminalName || "Terminal";
          if (data.eventType === "TRANSACTION_CREATED" && data.payload?.sale) {
            if (lanStateStore.sales) {
              const exists = lanStateStore.sales.some((s) => s.id === data.payload.sale.id || s.invoiceNumber === data.payload.sale.invoiceNumber);
              if (!exists) lanStateStore.sales.unshift(data.payload.sale);
            }
          } else if (data.eventType === "PRODUCT_UPDATED" && data.payload?.product) {
            if (lanStateStore.products) {
              const idx = lanStateStore.products.findIndex((p) => p.id === data.payload.product.id);
              if (idx >= 0) {
                lanStateStore.products[idx] = data.payload.product;
              } else {
                lanStateStore.products.unshift(data.payload.product);
              }
            }
          }
          const broadcastMsg = {
            type: "REALTIME_EVENT",
            eventId: data.eventId || `evt-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
            eventType: data.eventType,
            payload: data.payload,
            sourceDeviceId: data.sourceDeviceId,
            sourceTerminalName: data.sourceTerminalName,
            version: lanStateStore.version,
            timestamp: now
          };
          broadcastToLanClients(broadcastMsg, ws);
          ws.send(JSON.stringify({
            type: "EVENT_ACK",
            eventId: data.eventId,
            version: lanStateStore.version,
            timestamp: now
          }));
          break;
        }
        case "PUSH_FULL_STATE": {
          lanStateStore.version += 1;
          lanStateStore.lastUpdated = now;
          lanStateStore.lastUpdatedBy = data.sourceTerminalName || "Master";
          if (data.payload) {
            if (Array.isArray(data.payload.products)) lanStateStore.products = data.payload.products;
            if (Array.isArray(data.payload.sales)) lanStateStore.sales = data.payload.sales;
            if (Array.isArray(data.payload.customers)) lanStateStore.customers = data.payload.customers;
            if (Array.isArray(data.payload.categories)) lanStateStore.categories = data.payload.categories;
            if (Array.isArray(data.payload.suppliers)) lanStateStore.suppliers = data.payload.suppliers;
            if (Array.isArray(data.payload.piutangList)) lanStateStore.piutangList = data.payload.piutangList;
            if (Array.isArray(data.payload.stockLogs)) lanStateStore.stockLogs = data.payload.stockLogs;
            if (data.payload.storeProfile) lanStateStore.storeProfile = data.payload.storeProfile;
          }
          broadcastToLanClients({
            type: "FULL_STATE_UPDATED",
            version: lanStateStore.version,
            updatedBy: data.sourceTerminalName || "Master",
            payload: data.payload,
            timestamp: now
          }, ws);
          ws.send(JSON.stringify({
            type: "PUSH_FULL_STATE_ACK",
            version: lanStateStore.version,
            timestamp: now
          }));
          break;
        }
        case "PULL_FULL_STATE": {
          ws.send(JSON.stringify({
            type: "FULL_STATE_RESPONSE",
            version: lanStateStore.version,
            lastUpdated: lanStateStore.lastUpdated,
            payload: {
              products: lanStateStore.products,
              sales: lanStateStore.sales,
              customers: lanStateStore.customers,
              categories: lanStateStore.categories,
              suppliers: lanStateStore.suppliers,
              piutangList: lanStateStore.piutangList,
              stockLogs: lanStateStore.stockLogs,
              storeProfile: lanStateStore.storeProfile
            },
            timestamp: now
          }));
          break;
        }
        default:
          break;
      }
    } catch (err) {
      console.error("LAN WebSocket processing error:", err);
    }
  });
  ws.on("close", () => {
    connectedLanClients.delete(ws);
    broadcastClientListUpdate();
  });
  ws.on("error", (err) => {
    console.warn("LAN WebSocket client connection error:", err);
    connectedLanClients.delete(ws);
    broadcastClientListUpdate();
  });
});
app.get("/api/lan/status", (req, res) => {
  const localIps = getLocalIpAddresses();
  const clients = getActiveClientListSummary();
  res.json({
    status: "ok",
    serverPort: PORT,
    hostname: import_os.default.hostname(),
    localIps,
    totalConnected: clients.length,
    clients,
    currentVersion: lanStateStore.version,
    lastUpdated: lanStateStore.lastUpdated,
    lastUpdatedBy: lanStateStore.lastUpdatedBy,
    hasCachedData: !!lanStateStore.products,
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  });
});
app.post("/api/lan/sync-push", (req, res) => {
  const { terminalName, payload } = req.body;
  const now = (/* @__PURE__ */ new Date()).toISOString();
  lanStateStore.version += 1;
  lanStateStore.lastUpdated = now;
  lanStateStore.lastUpdatedBy = terminalName || "HTTP_CLIENT";
  if (payload) {
    if (Array.isArray(payload.products)) lanStateStore.products = payload.products;
    if (Array.isArray(payload.sales)) lanStateStore.sales = payload.sales;
    if (Array.isArray(payload.customers)) lanStateStore.customers = payload.customers;
    if (Array.isArray(payload.categories)) lanStateStore.categories = payload.categories;
    if (Array.isArray(payload.suppliers)) lanStateStore.suppliers = payload.suppliers;
    if (Array.isArray(payload.piutangList)) lanStateStore.piutangList = payload.piutangList;
    if (Array.isArray(payload.stockLogs)) lanStateStore.stockLogs = payload.stockLogs;
    if (payload.storeProfile) lanStateStore.storeProfile = payload.storeProfile;
  }
  broadcastToLanClients({
    type: "FULL_STATE_UPDATED",
    version: lanStateStore.version,
    updatedBy: terminalName || "HTTP_CLIENT",
    payload,
    timestamp: now
  });
  res.json({
    success: true,
    version: lanStateStore.version,
    lastUpdated: lanStateStore.lastUpdated
  });
});
app.get("/api/lan/sync-pull", (req, res) => {
  res.json({
    success: true,
    version: lanStateStore.version,
    lastUpdated: lanStateStore.lastUpdated,
    payload: {
      products: lanStateStore.products,
      sales: lanStateStore.sales,
      customers: lanStateStore.customers,
      categories: lanStateStore.categories,
      suppliers: lanStateStore.suppliers,
      piutangList: lanStateStore.piutangList,
      stockLogs: lanStateStore.stockLogs,
      storeProfile: lanStateStore.storeProfile
    }
  });
});
app.post("/api/lan/broadcast", (req, res) => {
  const { eventType, payload, sourceDeviceId, sourceTerminalName } = req.body;
  const now = (/* @__PURE__ */ new Date()).toISOString();
  lanStateStore.version += 1;
  lanStateStore.lastUpdated = now;
  lanStateStore.lastUpdatedBy = sourceTerminalName || "REST_API";
  const broadcastMsg = {
    type: "REALTIME_EVENT",
    eventId: `evt-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    eventType,
    payload,
    sourceDeviceId: sourceDeviceId || "server",
    sourceTerminalName: sourceTerminalName || "Master Server",
    version: lanStateStore.version,
    timestamp: now
  };
  broadcastToLanClients(broadcastMsg);
  res.json({
    success: true,
    version: lanStateStore.version,
    sentToTerminals: connectedLanClients.size
  });
});
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  server.listen(PORT, "0.0.0.0", () => {
    console.log(`POS-MINIMARKET server running on http://0.0.0.0:${PORT}`);
    console.log(`LAN Sync WebSocket ready on ws://0.0.0.0:${PORT}/api/ws/lan-sync`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
