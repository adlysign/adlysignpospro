package com.adlysign.pospro;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
