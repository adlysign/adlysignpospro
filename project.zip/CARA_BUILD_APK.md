# ADLYSIGN POS PRO - Panduan Lengkap Build APK Android Siap Jual

Selamat! Paket ini berisi seluruh source code dan konfigurasi Android Studio untuk aplikasi **ADLYSIGN POS PRO** (Aplikasi Kasir & Minimarket Retail).

---

## Persyaratan:
1. Laptop / Komputer dengan OS Windows, Mac, atau Linux
2. **Android Studio** (disarankan versi Hedgehog / Iguana / Jellyfish / Ladybug terbaru) ATAU JDK 17+
3. Perangkat Android (HP, Tablet Kasir, Mesin POS Android Sunmi/iMin/Kassen)

---

## Cara Build APK Cepat (Lewat Android Studio - Paling Mudah)
1. Buka aplikasi **Android Studio**.
2. Pilih menu **File -> Open...** lalu arahkan dan pilih folder **`android`** di dalam paket ini.
3. Tunggu hingga proses Gradle Sync selesai (otomatis mendownload dependency Android).
4. Untuk membuat file APK Siap Instal (Debug / Testing):
   - Klik menu **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**
   - Setelah selesai, klik notifikasi **"locate"** di pojok kanan bawah.
   - File APK Anda ada di folder:
     `app/build/outputs/apk/debug/app-debug.apk`
   - File APK ini bisa langsung dicopy ke HP Android atau dikirim via WhatsApp ke pelanggan/pembeli!

---

## Cara Membuat APK Release & Keystore (Untuk Dijual Komersial / Play Store)
1. Di Android Studio, klik menu **Build -> Generate Signed Bundle / APK...**
2. Pilih **APK** (atau **Android App Bundle** jika ingin upload ke Google Play Console).
3. Buat Key store path baru (**Create new...**):
   - Masukkan password keystore Anda (simpan password ini dengan aman!).
   - Isi Alias: `adlysign_pos`
   - Isi Certificate info: Nama Toko / Developer Anda.
4. Pilih Build Variants: **`release`**.
5. Centang **V1 (Jar Signature)** dan **V2 (Full APK Signature)**.
6. Klik **Finish**.
7. File APK Release siap jual akan tersimpan di:
   `app/release/app-release.apk`

---

## Cara Build Lewat Command Line / Terminal (Tanpa Android Studio)
Buka terminal di folder `android` lalu jalankan perintah:

- Di Windows (PowerShell / CMD):
  ```bash
  .\gradlew.bat assembleRelease
  ```
- Di macOS / Linux:
  ```bash
  chmod +x gradlew
  ./gradlew assembleRelease
  ```

File APK output: `app/build/outputs/apk/release/app-release-unsigned.apk`

---

## Fitur Unggulan Android POS:
- **Offline Full**: Data transaksi, kasir, produk, dan stok tersimpan aman di HP/tablet meski tanpa sinyal internet.
- **Hardware Printer Bluetooth**: Mendukung printer kasir thermal ukuran 58mm dan 80mm ESC/POS.
- **Scanner Barcode**: Menggunakan kamera HP Android atau scanner USB/Bluetooth eksternal.
- **Sistem Lisensi Serial Key**: Kunci lisensi ke Device Fingerprint ID pembeli agar software Anda tidak dibajak!
