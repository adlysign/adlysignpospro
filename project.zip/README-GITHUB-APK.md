# ADLYSIGN POS PRO - GitHub APK Builder

## Cara memakai di HP Android

1. Buat repository baru di GitHub.
2. Upload seluruh isi folder project ini ke repository (termasuk folder `.github`).
3. Pastikan file `.github/workflows/build-apk.yml` ikut ter-upload.
4. Buka tab **Actions**.
5. Pilih **Build Android APK**.
6. Tekan **Run workflow**.
7. Tunggu sampai status berubah menjadi hijau.
8. Buka hasil workflow tersebut.
9. Pada bagian **Artifacts**, download **ADLYSIGN-POS-PRO-apk**.
10. Ekstrak ZIP artifact, lalu install `app-debug.apk` di HP.

Catatan:
- Workflow ini menghasilkan APK debug untuk pengujian/instalasi.
- GitHub Actions membangun APK di server GitHub, sehingga HP tidak perlu menjalankan Gradle.
